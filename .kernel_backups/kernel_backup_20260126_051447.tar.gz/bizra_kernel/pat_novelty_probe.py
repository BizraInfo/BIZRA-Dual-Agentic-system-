"""
PAT Novelty Probe - Semantic Distance Measurement
=================================================
Measures novelty as semantic distance from known patterns.

From PAT Enforcement Constitution:
- novelty_minimum: 0.75
- Novel insights require >= 0.75 semantic distance

SAPE Integration:
- New probe type: NOVELTY (weight: 0.12)
- High novelty gets elevation priority boost: 1.3x
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple, Any
from collections import defaultdict
import hashlib
import re
import math


@dataclass
class KnownPattern:
    """A known pattern for novelty comparison."""
    pattern_id: str
    content: str
    tokens: Set[str]
    frequency: int = 1
    category: str = "general"
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> dict:
        return {
            "pattern_id": self.pattern_id,
            "content": self.content[:100],
            "token_count": len(self.tokens),
            "frequency": self.frequency,
            "category": self.category,
        }


@dataclass
class NoveltyProbeResult:
    """Result of novelty probe execution."""
    novelty_score: float  # 0.0 to 1.0
    passed: bool  # True if >= threshold
    semantic_distance: float  # Raw distance from known patterns
    closest_pattern: Optional[str]  # ID of closest known pattern
    novel_elements: List[str]  # Elements not found in known patterns
    evidence: List[str]  # Evidence for the score
    threshold: float = 0.75  # Novelty threshold
    latency_ms: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    @property
    def is_novel(self) -> bool:
        """Alias for passed - indicates if content is novel."""
        return self.passed

    def to_dict(self) -> dict:
        return {
            "novelty_score": self.novelty_score,
            "passed": self.passed,
            "semantic_distance": self.semantic_distance,
            "closest_pattern": self.closest_pattern,
            "novel_elements": self.novel_elements[:10],
            "evidence": self.evidence,
            "latency_ms": self.latency_ms,
            "timestamp": self.timestamp,
        }


class PATNoveltyProbe:
    """
    Novelty Probe for PAT Enforcement.

    Measures semantic distance from known patterns using:
    - Token-based Jaccard distance
    - N-gram overlap analysis
    - Structural novelty detection

    Threshold: 0.75 minimum novelty score
    """

    NOVELTY_THRESHOLD = 0.75
    WEIGHT = 0.12  # SAPE probe weight

    def __init__(self, session_id: str = "default"):
        """Initialize novelty probe with pattern store."""
        self.session_id = session_id
        self.known_patterns: Dict[str, KnownPattern] = {}
        self.pattern_tokens: Dict[str, Set[str]] = {}
        self.ngram_index: Dict[str, List[str]] = defaultdict(list)

        # Pre-load common patterns
        self._load_common_patterns()

    def _load_common_patterns(self) -> None:
        """Load common patterns to compare against."""
        common = [
            ("greeting", "Hello, how can I help you today?"),
            ("error_handling", "Please try again or contact support if the issue persists."),
            ("acknowledgment", "I understand. Let me help you with that."),
            ("clarification", "Could you please provide more details about your request?"),
            ("summary_intro", "Here is a summary of the key points:"),
            ("list_intro", "The following items are relevant:"),
            ("conclusion", "In conclusion, the main takeaways are:"),
            ("caveat", "Please note that this information may vary depending on context."),
            ("recommendation", "Based on my analysis, I recommend:"),
            ("step_intro", "Here are the steps to follow:"),
        ]

        for category, content in common:
            self.register_pattern(content, category)

    def _tokenize(self, text: str) -> Set[str]:
        """Tokenize text into normalized words."""
        # Normalize: lowercase, remove punctuation
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        tokens = set(text.split())
        # Remove very short tokens and stopwords
        stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
                    'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
                    'would', 'could', 'should', 'may', 'might', 'must', 'shall',
                    'can', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by',
                    'from', 'as', 'into', 'through', 'during', 'before', 'after',
                    'above', 'below', 'between', 'under', 'and', 'but', 'or',
                    'nor', 'so', 'yet', 'both', 'either', 'neither', 'not', 'only',
                    'own', 'same', 'than', 'too', 'very', 'just', 'also', 'now',
                    'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how',
                    'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other',
                    'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same',
                    'than', 'too', 'very', 'i', 'me', 'my', 'myself', 'we', 'our',
                    'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'he',
                    'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it',
                    'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves',
                    'this', 'that', 'these', 'those'}
        return {t for t in tokens if len(t) > 2 and t not in stopwords}

    def _generate_ngrams(self, text: str, n: int = 3) -> Set[str]:
        """Generate character n-grams from text."""
        text = text.lower()
        text = re.sub(r'\s+', ' ', text)
        ngrams = set()
        for i in range(len(text) - n + 1):
            ngrams.add(text[i:i + n])
        return ngrams

    def _compute_pattern_id(self, content: str) -> str:
        """Compute unique ID for a pattern."""
        return hashlib.sha256(content.lower().encode()).hexdigest()[:12]

    def register_pattern(self, content: str, category: str = "general") -> str:
        """
        Register a known pattern for comparison.

        Args:
            content: Pattern content
            category: Pattern category

        Returns:
            Pattern ID
        """
        pattern_id = self._compute_pattern_id(content)

        if pattern_id in self.known_patterns:
            self.known_patterns[pattern_id].frequency += 1
            return pattern_id

        tokens = self._tokenize(content)
        pattern = KnownPattern(
            pattern_id=pattern_id,
            content=content,
            tokens=tokens,
            category=category,
        )

        self.known_patterns[pattern_id] = pattern
        self.pattern_tokens[pattern_id] = tokens

        # Index n-grams
        ngrams = self._generate_ngrams(content)
        for ngram in ngrams:
            self.ngram_index[ngram].append(pattern_id)

        return pattern_id

    def _jaccard_distance(self, set1: Set[str], set2: Set[str]) -> float:
        """Calculate Jaccard distance between two sets."""
        if not set1 or not set2:
            return 1.0  # Maximum distance if either is empty

        intersection = len(set1 & set2)
        union = len(set1 | set2)

        if union == 0:
            return 1.0

        similarity = intersection / union
        return 1.0 - similarity  # Convert to distance

    def _calculate_semantic_distance(
        self,
        content: str
    ) -> Tuple[float, Optional[str]]:
        """
        Calculate minimum semantic distance from known patterns.

        Returns:
            Tuple of (min_distance, closest_pattern_id)
        """
        if not self.known_patterns:
            return 1.0, None  # Maximum novelty if no known patterns

        content_tokens = self._tokenize(content)
        content_ngrams = self._generate_ngrams(content)

        min_distance = 1.0
        closest_pattern = None

        for pattern_id, pattern in self.known_patterns.items():
            # Token-based distance (weight: 0.6)
            token_distance = self._jaccard_distance(content_tokens, pattern.tokens)

            # N-gram-based distance (weight: 0.4)
            pattern_ngrams = self._generate_ngrams(pattern.content)
            ngram_distance = self._jaccard_distance(content_ngrams, pattern_ngrams)

            # Combined distance
            combined_distance = (0.6 * token_distance) + (0.4 * ngram_distance)

            if combined_distance < min_distance:
                min_distance = combined_distance
                closest_pattern = pattern_id

        return min_distance, closest_pattern

    def _identify_novel_elements(self, content: str) -> List[str]:
        """Identify elements not found in known patterns."""
        content_tokens = self._tokenize(content)

        # Collect all known tokens
        all_known_tokens: Set[str] = set()
        for tokens in self.pattern_tokens.values():
            all_known_tokens.update(tokens)

        # Find novel tokens
        novel_tokens = content_tokens - all_known_tokens

        # Filter to significant tokens (longer, less common)
        significant_novel = [t for t in novel_tokens if len(t) > 4]

        return significant_novel[:20]  # Return top 20

    def _compute_structural_novelty(self, content: str) -> float:
        """Compute novelty based on structural patterns."""
        # Check for unusual structures
        novelty_indicators = [
            (r'\[\w+\]', 0.1),  # Claim tags
            (r'→|←|↔', 0.15),  # Arrow notation
            (r'\d+\.\d+', 0.05),  # Decimal numbers
            (r'```\w*', 0.1),  # Code blocks
            (r'##+ ', 0.05),  # Headers
            (r'\$[^$]+\$', 0.2),  # Math notation
            (r'≥|≤|≠|∈|∉', 0.15),  # Math symbols
        ]

        structural_novelty = 0.0
        for pattern, weight in novelty_indicators:
            if re.search(pattern, content):
                structural_novelty += weight

        return min(structural_novelty, 0.3)  # Cap at 0.3

    def probe(self, content: str) -> NoveltyProbeResult:
        """
        Execute novelty probe on content.

        Args:
            content: Content to analyze for novelty

        Returns:
            NoveltyProbeResult with score and evidence
        """
        import time
        start_time = time.time()

        # Calculate semantic distance
        semantic_distance, closest_pattern = self._calculate_semantic_distance(content)

        # Identify novel elements
        novel_elements = self._identify_novel_elements(content)

        # Calculate structural novelty
        structural_novelty = self._compute_structural_novelty(content)

        # Compute final novelty score
        # Base: semantic distance
        # Bonus: structural novelty + novel element count
        base_novelty = semantic_distance
        novel_element_bonus = min(len(novel_elements) * 0.02, 0.15)
        novelty_score = min(1.0, base_novelty + structural_novelty + novel_element_bonus)

        # Generate evidence
        evidence = []
        evidence.append(f"Semantic distance: {semantic_distance:.3f}")
        if closest_pattern:
            evidence.append(f"Closest pattern: {closest_pattern}")
        evidence.append(f"Novel elements: {len(novel_elements)}")
        evidence.append(f"Structural novelty: {structural_novelty:.3f}")
        evidence.append(f"Final score: {novelty_score:.3f}")

        latency_ms = (time.time() - start_time) * 1000

        return NoveltyProbeResult(
            novelty_score=novelty_score,
            passed=novelty_score >= self.NOVELTY_THRESHOLD,
            semantic_distance=semantic_distance,
            closest_pattern=closest_pattern,
            novel_elements=novel_elements,
            evidence=evidence,
            latency_ms=latency_ms,
        )

    def observe_response(self, content: str, register: bool = True) -> NoveltyProbeResult:
        """
        Observe a response and optionally register it as a known pattern.

        Args:
            content: Response content
            register: Whether to register as known pattern after probing

        Returns:
            NoveltyProbeResult
        """
        result = self.probe(content)

        # Register if novel enough
        if register and result.passed:
            self.register_pattern(content, category="response")

        return result

    def get_statistics(self) -> dict:
        """Get novelty probe statistics."""
        return {
            "known_patterns": len(self.known_patterns),
            "ngram_index_size": len(self.ngram_index),
            "threshold": self.NOVELTY_THRESHOLD,
            "weight": self.WEIGHT,
            "patterns_by_category": self._count_by_category(),
        }

    def _count_by_category(self) -> Dict[str, int]:
        """Count patterns by category."""
        counts: Dict[str, int] = defaultdict(int)
        for pattern in self.known_patterns.values():
            counts[pattern.category] += 1
        return dict(counts)


# SAPE Integration: ProbeType extension
class SapeNoveltyProbe:
    """
    SAPE-compatible novelty probe wrapper.

    Integrates with bizra_kernel/sape_engine.py as a new probe type.
    """

    PROBE_TYPE = "NOVELTY"
    WEIGHT = 0.12

    def __init__(self, novelty_probe: Optional[PATNoveltyProbe] = None):
        self.probe = novelty_probe or PATNoveltyProbe()

    async def execute(
        self,
        content: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Execute novelty probe in SAPE format.

        Args:
            content: Content to probe
            context: Additional context

        Returns:
            SAPE-compatible result dict
        """
        result = self.probe.probe(content)

        return {
            "probe": self.PROBE_TYPE,
            "score": result.novelty_score,
            "passed": result.passed,
            "evidence": result.evidence,
            "latency_ms": result.latency_ms,
            "timestamp": result.timestamp,
            "metadata": {
                "semantic_distance": result.semantic_distance,
                "closest_pattern": result.closest_pattern,
                "novel_elements_count": len(result.novel_elements),
            },
        }


if __name__ == "__main__":
    # Test the novelty probe
    probe = PATNoveltyProbe("test-session")

    # Test with common content (should have low novelty)
    common_result = probe.probe("Hello, how can I help you today?")
    print(f"Common content novelty: {common_result.novelty_score:.3f} (passed: {common_result.passed})")

    # Test with novel content
    novel_content = """
    The intersection of [NOVEL] category theory and [CROSS_DOMAIN] neuroscience
    reveals isomorphic structures between functors and neural activation patterns.
    This suggests a deep connection: F: Cat → Neural where composition preserves
    semantic relationships across domains with unrelatedness ≥ 0.75.
    """
    novel_result = probe.probe(novel_content)
    print(f"Novel content novelty: {novel_result.novelty_score:.3f} (passed: {novel_result.passed})")
    print(f"Novel elements: {novel_result.novel_elements[:5]}")
