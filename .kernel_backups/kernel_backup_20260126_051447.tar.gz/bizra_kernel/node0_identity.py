"""
BIZRA Node0 Cryptographic Identity
===================================
The public key IS Node0 identity. Hardware covenant is supporting evidence.

This module implements:
1. Ed25519 keypair generation and storage
2. Genesis signing and verification
3. Tier-2 upgrade attestation
4. Restricted mode enforcement

Trust Model:
- Node0 identity = Ed25519 public key
- Hardware covenant = proof-of-location + anomaly detector
- Genesis signature = cryptographic proof of origin

Usage:
    from bizra_kernel.node0_identity import Node0Identity

    identity = Node0Identity.load_or_create()
    signature = identity.sign_genesis(genesis_data)
    verified = identity.verify_genesis(genesis_data, signature)
"""

import os
import json
import hashlib
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, Optional, Tuple
from dataclasses import dataclass, field

# Cryptographic imports
try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
    from cryptography.hazmat.backends import default_backend
    from cryptography.exceptions import InvalidSignature
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    Ed25519PrivateKey = None
    Ed25519PublicKey = None

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS (with environment variable overrides for testability)
# ═══════════════════════════════════════════════════════════════════════════════

# SECURITY: Default paths use WSL ext4 filesystem for proper POSIX permissions.
# Windows-mounted paths (/mnt/<drive>) do NOT provide proper file permission
# enforcement and should only be used via explicit env override with security warning.
DEFAULT_KEY_DIR = Path.home() / ".bizra" / "secure" / "node0_keys"
DEFAULT_ATTESTATION_DIR = Path.home() / ".bizra" / "attestations"

# Legacy paths - checked to prevent silent key rotation
# CRITICAL: If keys exist in legacy paths, we must use them to preserve Node0 identity
LEGACY_KEY_DIRS = [
    Path("/mnt/c/BIZRA-SECURE-VAULT/node0_keys"),
    Path("/mnt/d/BIZRA-SECURE-VAULT/node0_keys"),
]
LEGACY_ATTESTATION_DIRS = [
    Path("/mnt/c/BIZRA-DATA-LAKE/00_GENESIS/attestations"),
    Path("/mnt/d/BIZRA-DATA-LAKE/00_GENESIS/attestations"),
]


def _is_windows_mount(path: Path) -> bool:
    """Check if path is on a Windows mount (any /mnt/<single-letter>/)."""
    import re
    path_str = str(path.resolve()) if path.exists() else str(path)
    return bool(re.match(r"^/mnt/[a-zA-Z]/", path_str))


def _check_windows_mount_security(path: Path, context: str, is_legacy: bool = False) -> None:
    """Warn if path is on Windows mount (insecure for key custody)."""
    if _is_windows_mount(path):
        path_str = str(path)[:30]
        if is_legacy:
            logger.warning(
                f"SECURITY: {context} using legacy path on Windows mount ({path_str}...). "
                "Migrate to ~/.bizra/secure/ for proper POSIX permission enforcement."
            )
        else:
            logger.warning(
                f"SECURITY: {context} is on Windows mount ({path_str}...). "
                "Move to WSL ext4 (e.g., ~/.bizra/) for proper POSIX permission enforcement."
            )


def _dir_has_keys(d: Path) -> bool:
    """Check if directory contains Node0 keypair."""
    return (d / "node0_signing.key").exists() and (d / "node0_signing.pub").exists()


def _dir_has_attestations(d: Path) -> bool:
    """Check if directory contains attestation files."""
    if not d.exists():
        return False
    return any(d.glob("T2-ATT-*.json"))


def _get_vault_dir() -> Path:
    """
    Get vault directory with fallback logic to prevent silent key rotation.

    Priority:
    1. BIZRA_VAULT_DIR env var (explicit override)
    2. New default if it contains keys
    3. Legacy paths if they contain keys (with migration warning)
    4. New default (for fresh installation)
    """
    # 1. Explicit env override takes priority
    env = os.getenv("BIZRA_VAULT_DIR")
    if env:
        path = Path(env)
        _check_windows_mount_security(path, "key_dir")
        return path

    # 2. New default if it already has keys
    if _dir_has_keys(DEFAULT_KEY_DIR):
        return DEFAULT_KEY_DIR

    # 3. Check legacy paths - CRITICAL to prevent silent key rotation
    for legacy in LEGACY_KEY_DIRS:
        if _dir_has_keys(legacy):
            _check_windows_mount_security(legacy, "key_dir", is_legacy=True)
            logger.warning(
                f"NODE0 IDENTITY: Using legacy key_dir at {legacy}. "
                "Run 'bizra node0 migrate-keys' to move to secure WSL location."
            )
            return legacy

    # 4. Fresh installation - use new secure default
    return DEFAULT_KEY_DIR


def _get_attestation_dir() -> Path:
    """
    Get attestation directory with fallback logic.

    Priority:
    1. BIZRA_ATTESTATION_DIR env var (explicit override)
    2. New default if it contains attestations
    3. Legacy paths if they contain attestations
    4. New default
    """
    env = os.getenv("BIZRA_ATTESTATION_DIR")
    if env:
        path = Path(env)
        _check_windows_mount_security(path, "attestation_dir")
        return path

    if _dir_has_attestations(DEFAULT_ATTESTATION_DIR):
        return DEFAULT_ATTESTATION_DIR

    for legacy in LEGACY_ATTESTATION_DIRS:
        if _dir_has_attestations(legacy):
            _check_windows_mount_security(legacy, "attestation_dir", is_legacy=True)
            return legacy

    return DEFAULT_ATTESTATION_DIR


# Legacy constants for backward compatibility
# WARNING: These are evaluated at import time - prefer _get_vault_dir() in new code
# TODO: Gradually eliminate direct use of these constants
KEY_DIR = DEFAULT_KEY_DIR
PRIVATE_KEY_PATH = KEY_DIR / "node0_signing.key"
PUBLIC_KEY_PATH = KEY_DIR / "node0_signing.pub"
ATTESTATION_DIR = DEFAULT_ATTESTATION_DIR

# Restricted mode flag file
RESTRICTED_MODE_FLAG = Path("/tmp/bizra_restricted_mode")


# ═══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class RestrictedModeState:
    """State when running in restricted mode (Tier-1 failure)."""
    active: bool = False
    reason: str = ""
    timestamp: str = ""
    disabled_capabilities: list = field(default_factory=lambda: [
        "signing",
        "minting",
        "poi_attestation",
        "canonical_ledger_writes",
        "genesis_sync",
    ])


@dataclass
class Tier2Attestation:
    """Attestation for Tier-2 hardware changes."""
    attestation_id: str
    previous_tier2_hash: str
    new_tier2_hash: str
    reason: str
    changed_components: Dict[str, Any]
    timestamp: str
    signature: str  # Ed25519 signature of the attestation


# ═══════════════════════════════════════════════════════════════════════════════
# NODE0 IDENTITY CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class Node0Identity:
    """
    Cryptographic identity manager for Node0.

    The public key IS the Node0 identity - not the hardware fingerprint.
    Hardware covenant provides supporting evidence and anomaly detection.

    Paths can be overridden via environment variables:
        - BIZRA_VAULT_DIR: Directory for key storage
        - BIZRA_ATTESTATION_DIR: Directory for attestation storage
    """

    def __init__(
        self,
        private_key: Optional[Ed25519PrivateKey] = None,
        public_key: Optional[Ed25519PublicKey] = None,
        key_dir: Optional[Path] = None,
        attestation_dir: Optional[Path] = None,
    ):
        self._private_key = private_key
        self._public_key = public_key
        self._restricted_mode = RestrictedModeState()

        # Use provided paths, env vars, or defaults
        self._key_dir = key_dir or _get_vault_dir()
        self._attestation_dir = attestation_dir or _get_attestation_dir()

        # Security check for explicitly provided paths
        if key_dir is not None:
            _check_windows_mount_security(key_dir, "key_dir")
        if attestation_dir is not None:
            _check_windows_mount_security(attestation_dir, "attestation_dir")

        if not CRYPTO_AVAILABLE:
            logger.warning("cryptography library not available - using fallback mode")

    @property
    def key_dir(self) -> Path:
        """Get the key storage directory."""
        return self._key_dir

    @property
    def private_key_path(self) -> Path:
        """Get the private key path."""
        return self._key_dir / "node0_signing.key"

    @property
    def public_key_path(self) -> Path:
        """Get the public key path."""
        return self._key_dir / "node0_signing.pub"

    @property
    def attestation_dir(self) -> Path:
        """Get the attestation directory."""
        return self._attestation_dir

    @classmethod
    def load_or_create(
        cls,
        force_create: bool = False,
        key_dir: Optional[Path] = None,
        attestation_dir: Optional[Path] = None,
    ) -> "Node0Identity":
        """
        Load existing keypair or create new one.

        CRITICAL: This should only create keys on the actual Node0 hardware.

        Args:
            force_create: If True, create new keypair even if one exists
            key_dir: Override key storage directory (or use BIZRA_VAULT_DIR env)
            attestation_dir: Override attestation directory (or use BIZRA_ATTESTATION_DIR env)
        """
        if not CRYPTO_AVAILABLE:
            logger.error("Cannot create identity - cryptography library not installed")
            return cls(key_dir=key_dir, attestation_dir=attestation_dir)

        # Determine key directory
        kdir = key_dir or _get_vault_dir()
        adir = attestation_dir or _get_attestation_dir()
        private_key_path = kdir / "node0_signing.key"

        if private_key_path.exists() and not force_create:
            return cls._load_from_files(kdir, adir)

        # Create new keypair
        return cls._create_new_keypair(kdir, adir)

    @classmethod
    def _load_from_files(cls, key_dir: Path, attestation_dir: Path) -> "Node0Identity":
        """Load keypair from secure storage."""
        logger.info(f"Loading Node0 identity from: {key_dir}")

        private_key_path = key_dir / "node0_signing.key"
        public_key_path = key_dir / "node0_signing.pub"

        # Load private key
        with open(private_key_path, "rb") as f:
            private_key = serialization.load_pem_private_key(
                f.read(),
                password=None,  # In production, use password from HSM/TPM
                backend=default_backend(),
            )

        # Load public key
        with open(public_key_path, "rb") as f:
            public_key = serialization.load_pem_public_key(
                f.read(),
                backend=default_backend(),
            )

        logger.info("Node0 identity loaded successfully")
        return cls(private_key, public_key, key_dir=key_dir, attestation_dir=attestation_dir)

    @classmethod
    def _create_new_keypair(cls, key_dir: Path, attestation_dir: Path) -> "Node0Identity":
        """
        Create a new Ed25519 keypair.

        WARNING: This is a one-time operation for Node0.
        """
        logger.warning("CREATING NEW NODE0 KEYPAIR - This should only happen once!")

        private_key_path = key_dir / "node0_signing.key"
        public_key_path = key_dir / "node0_signing.pub"

        # Generate keypair
        private_key = Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        # Ensure directory exists with restricted permissions
        key_dir.mkdir(parents=True, exist_ok=True)
        os.chmod(key_dir, 0o700)

        # Save private key (encrypted in production)
        with open(private_key_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),  # Use password in prod
            ))
        os.chmod(private_key_path, 0o600)

        # Save public key
        with open(public_key_path, "wb") as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            ))

        logger.info(f"Node0 keypair created at: {key_dir}")
        logger.info(f"Public key fingerprint: {cls._key_fingerprint(public_key)}")

        return cls(private_key, public_key, key_dir=key_dir, attestation_dir=attestation_dir)

    @staticmethod
    def _key_fingerprint(public_key: Ed25519PublicKey) -> str:
        """Get SHA-256 fingerprint of public key."""
        pub_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return hashlib.sha256(pub_bytes).hexdigest()

    # ═══════════════════════════════════════════════════════════════════════════
    # GENESIS SIGNING
    # ═══════════════════════════════════════════════════════════════════════════

    def sign_genesis(self, genesis_data: Dict[str, Any]) -> Dict[str, str]:
        """
        Sign the genesis block.

        Args:
            genesis_data: Genesis block data (without signature field)

        Returns:
            Signature dict with algorithm, pubkey, and signature
        """
        if not self._private_key:
            raise RuntimeError("Cannot sign - private key not loaded")

        if self._restricted_mode.active:
            raise RuntimeError("Cannot sign in restricted mode")

        # Create canonical representation (sorted, no whitespace)
        # Remove any existing signature first
        data_to_sign = {k: v for k, v in genesis_data.items() if k != "signature"}
        canonical = json.dumps(data_to_sign, sort_keys=True, separators=(",", ":"))

        # Compute hash
        genesis_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

        # Sign the hash
        signature_bytes = self._private_key.sign(genesis_hash.encode("utf-8"))

        logger.info(f"Genesis signed. Hash: {genesis_hash[:16]}...")

        return {
            "algorithm": "Ed25519",
            "pubkey": self.public_key_pem,
            "pubkey_fingerprint": self.public_key_fingerprint,
            "genesis_hash": genesis_hash,
            "signature": signature_bytes.hex(),
            "signed_at": datetime.now(timezone.utc).isoformat(),
        }

    def verify_genesis(
        self,
        genesis_data: Dict[str, Any],
        signature_info: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Verify genesis block signature.

        Args:
            genesis_data: Genesis block data
            signature_info: Signature dict (or extracted from genesis_data["signature"])

        Returns:
            Verification result
        """
        if not CRYPTO_AVAILABLE:
            return {
                "verified": False,
                "error": "cryptography library not available",
            }

        # Extract signature info
        sig_info = signature_info or genesis_data.get("signature", {})

        if not sig_info or not sig_info.get("signature"):
            return {
                "verified": False,
                "error": "No signature found in genesis",
            }

        # Recreate canonical representation
        data_to_verify = {k: v for k, v in genesis_data.items() if k != "signature"}
        canonical = json.dumps(data_to_verify, sort_keys=True, separators=(",", ":"))
        computed_hash = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

        # Verify hash matches
        if sig_info.get("genesis_hash") != computed_hash:
            return {
                "verified": False,
                "error": "Genesis hash mismatch - data has been modified",
                "expected_hash": sig_info.get("genesis_hash", "")[:16] + "...",
                "computed_hash": computed_hash[:16] + "...",
            }

        # Load public key from signature info
        try:
            pubkey_pem = sig_info.get("pubkey", "")
            if pubkey_pem:
                verifying_key = serialization.load_pem_public_key(
                    pubkey_pem.encode("utf-8"),
                    backend=default_backend(),
                )
            elif self._public_key:
                verifying_key = self._public_key
            else:
                return {
                    "verified": False,
                    "error": "No public key available for verification",
                }

            # Verify signature
            signature_bytes = bytes.fromhex(sig_info["signature"])
            verifying_key.verify(signature_bytes, computed_hash.encode("utf-8"))

            return {
                "verified": True,
                "message": "Genesis signature verified - this is authentic",
                "pubkey_fingerprint": sig_info.get("pubkey_fingerprint", ""),
                "genesis_hash": computed_hash[:16] + "...",
            }

        except InvalidSignature:
            return {
                "verified": False,
                "error": "Invalid signature - genesis may be tampered",
            }
        except Exception as e:
            return {
                "verified": False,
                "error": f"Verification failed: {str(e)}",
            }

    # ═══════════════════════════════════════════════════════════════════════════
    # TIER-2 ATTESTATION
    # ═══════════════════════════════════════════════════════════════════════════

    def create_tier2_attestation(
        self,
        previous_hash: str,
        new_hash: str,
        reason: str,
        changed_components: Dict[str, Any],
    ) -> Tier2Attestation:
        """
        Create a signed attestation for Tier-2 hardware changes.

        This allows legitimate upgrades (RAM, NIC replacement) while
        maintaining audit trail.
        """
        if not self._private_key:
            raise RuntimeError("Cannot create attestation - private key not loaded")

        if self._restricted_mode.active:
            raise RuntimeError("Cannot create attestation in restricted mode")

        timestamp = datetime.now(timezone.utc).isoformat()

        # Create attestation ID
        attestation_id = f"T2-ATT-{hashlib.sha256(f'{previous_hash}{new_hash}{timestamp}'.encode()).hexdigest()[:12]}"

        # Create attestation data
        attestation_data = {
            "attestation_id": attestation_id,
            "previous_tier2_hash": previous_hash,
            "new_tier2_hash": new_hash,
            "reason": reason,
            "changed_components": changed_components,
            "timestamp": timestamp,
        }

        # Sign attestation
        canonical = json.dumps(attestation_data, sort_keys=True, separators=(",", ":"))
        signature_bytes = self._private_key.sign(canonical.encode("utf-8"))

        attestation = Tier2Attestation(
            attestation_id=attestation_id,
            previous_tier2_hash=previous_hash,
            new_tier2_hash=new_hash,
            reason=reason,
            changed_components=changed_components,
            timestamp=timestamp,
            signature=signature_bytes.hex(),
        )

        # Store attestation
        self._store_attestation(attestation)

        logger.info(f"Tier-2 attestation created: {attestation_id}")
        return attestation

    def verify_tier2_attestation(
        self,
        current_tier2_hash: str,
        expected_tier2_hash: str,
    ) -> Dict[str, Any]:
        """
        Verify that a Tier-2 mismatch has a valid attestation.

        Returns:
            Verification result with attestation if found
        """
        if current_tier2_hash == expected_tier2_hash:
            return {
                "verified": True,
                "attestation_required": False,
                "message": "Tier-2 hashes match",
            }

        # Look for matching attestation
        attestation = self._find_attestation(expected_tier2_hash, current_tier2_hash)

        if not attestation:
            return {
                "verified": False,
                "attestation_required": True,
                "message": "Tier-2 mismatch requires attestation",
                "expected_hash": expected_tier2_hash[:16] + "...",
                "current_hash": current_tier2_hash[:16] + "...",
            }

        # Verify attestation signature
        attestation_data = {
            "attestation_id": attestation["attestation_id"],
            "previous_tier2_hash": attestation["previous_tier2_hash"],
            "new_tier2_hash": attestation["new_tier2_hash"],
            "reason": attestation["reason"],
            "changed_components": attestation["changed_components"],
            "timestamp": attestation["timestamp"],
        }

        canonical = json.dumps(attestation_data, sort_keys=True, separators=(",", ":"))

        try:
            signature_bytes = bytes.fromhex(attestation["signature"])
            self._public_key.verify(signature_bytes, canonical.encode("utf-8"))

            return {
                "verified": True,
                "attestation_required": True,
                "attestation_valid": True,
                "attestation": attestation,
                "message": f"Tier-2 change attested: {attestation['reason']}",
            }
        except InvalidSignature:
            return {
                "verified": False,
                "attestation_required": True,
                "attestation_valid": False,
                "message": "Attestation signature invalid",
            }

    def _store_attestation(self, attestation: Tier2Attestation) -> None:
        """Store attestation to the ledger."""
        self._attestation_dir.mkdir(parents=True, exist_ok=True)

        attestation_file = self._attestation_dir / f"{attestation.attestation_id}.json"
        with open(attestation_file, "w") as f:
            json.dump({
                "attestation_id": attestation.attestation_id,
                "previous_tier2_hash": attestation.previous_tier2_hash,
                "new_tier2_hash": attestation.new_tier2_hash,
                "reason": attestation.reason,
                "changed_components": attestation.changed_components,
                "timestamp": attestation.timestamp,
                "signature": attestation.signature,
            }, f, indent=2)

    def _find_attestation(
        self,
        previous_hash: str,
        new_hash: str,
    ) -> Optional[Dict[str, Any]]:
        """Find attestation for a Tier-2 transition."""
        if not self._attestation_dir.exists():
            return None

        for attestation_file in self._attestation_dir.glob("T2-ATT-*.json"):
            try:
                with open(attestation_file) as f:
                    attestation = json.load(f)

                if (attestation["previous_tier2_hash"] == previous_hash and
                    attestation["new_tier2_hash"] == new_hash):
                    return attestation
            except Exception:
                continue

        return None

    # ═══════════════════════════════════════════════════════════════════════════
    # RESTRICTED MODE
    # ═══════════════════════════════════════════════════════════════════════════

    def enter_restricted_mode(self, reason: str) -> None:
        """
        Enter restricted mode (Tier-1 verification failed).

        In restricted mode, the following are DISABLED:
        - Signing operations
        - Minting / PoI attestation
        - Canonical ledger writes
        - Genesis sync
        """
        self._restricted_mode = RestrictedModeState(
            active=True,
            reason=reason,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

        # Write flag file for other processes
        RESTRICTED_MODE_FLAG.write_text(json.dumps({
            "active": True,
            "reason": reason,
            "timestamp": self._restricted_mode.timestamp,
            "disabled": self._restricted_mode.disabled_capabilities,
        }))

        logger.error("=" * 60)
        logger.error("  RESTRICTED MODE ACTIVATED")
        logger.error("=" * 60)
        logger.error(f"  Reason: {reason}")
        logger.error("  Disabled capabilities:")
        for cap in self._restricted_mode.disabled_capabilities:
            logger.error(f"    - {cap}")
        logger.error("=" * 60)

    def exit_restricted_mode(self) -> None:
        """Exit restricted mode (requires re-verification)."""
        self._restricted_mode = RestrictedModeState()

        if RESTRICTED_MODE_FLAG.exists():
            RESTRICTED_MODE_FLAG.unlink()

        logger.info("Restricted mode deactivated")

    @property
    def is_restricted(self) -> bool:
        """Check if running in restricted mode."""
        return self._restricted_mode.active

    @property
    def restricted_state(self) -> RestrictedModeState:
        """Get current restricted mode state."""
        return self._restricted_mode

    def check_capability(self, capability: str) -> bool:
        """Check if a capability is allowed."""
        if not self._restricted_mode.active:
            return True

        return capability not in self._restricted_mode.disabled_capabilities

    # ═══════════════════════════════════════════════════════════════════════════
    # PROPERTIES
    # ═══════════════════════════════════════════════════════════════════════════

    @property
    def public_key_fingerprint(self) -> str:
        """Get the public key fingerprint (THIS IS THE NODE0 IDENTITY)."""
        if not self._public_key:
            return ""
        return self._key_fingerprint(self._public_key)

    @property
    def public_key_pem(self) -> str:
        """Get PEM-encoded public key."""
        if not self._public_key:
            return ""
        return self._public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode("utf-8")

    @property
    def has_private_key(self) -> bool:
        """Check if private key is loaded (can sign)."""
        return self._private_key is not None


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    print("\n" + "=" * 60)
    print("  BIZRA NODE0 CRYPTOGRAPHIC IDENTITY")
    print("=" * 60)

    if not CRYPTO_AVAILABLE:
        print("\nERROR: cryptography library not installed")
        print("Install with: pip install cryptography")
        exit(1)

    # Load or create identity
    identity = Node0Identity.load_or_create()

    print(f"\nNode0 Identity (Public Key Fingerprint):")
    print(f"  {identity.public_key_fingerprint}")

    print(f"\nPrivate Key Loaded: {identity.has_private_key}")
    print(f"Restricted Mode: {identity.is_restricted}")

    # Demo signing
    if identity.has_private_key:
        demo_genesis = {
            "version": "1.0",
            "name": "BIZRA Genesis Demo",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        print("\nSigning demo genesis...")
        signature = identity.sign_genesis(demo_genesis)
        print(f"  Genesis Hash: {signature['genesis_hash'][:32]}...")
        print(f"  Signature: {signature['signature'][:32]}...")

        print("\nVerifying signature...")
        demo_genesis["signature"] = signature
        result = identity.verify_genesis(demo_genesis)
        print(f"  Verified: {result['verified']}")
        print(f"  Message: {result.get('message', result.get('error', 'N/A'))}")
