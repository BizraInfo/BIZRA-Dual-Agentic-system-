"""
bizra_kernel/gold_mine_connector.py - Gold Mine Graph Connector
================================================================

Connects to the freshly built Gold Mine knowledge graph (56,358 nodes, 88,649 edges)
stored in BIZRA-DATA-LAKE/03_INDEXED/graph/.

The Gold Mine provides:
- Document nodes with source paths
- Entity nodes (concepts extracted from documents)
- MENTIONS edges linking documents to entities
- Embedding vectors (384-dim) for semantic search

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                    GOLD MINE CONNECTOR                          │
    ├─────────────────────────────────────────────────────────────────┤
    │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
    │  │   NODE INDEX    │  │   EDGE INDEX    │  │  EMBEDDING      │ │
    │  │   (56k nodes)   │  │   (88k edges)   │  │  SEARCH         │ │
    │  │                 │  │                 │  │  (384-dim)      │ │
    │  │ • Document      │  │ • MENTIONS      │  │ • cosine sim    │ │
    │  │ • Entity        │  │ • Adjacency     │  │ • top-k         │ │
    │  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
    │                                                                 │
    │  ┌─────────────────────────────────────────────────────────────┐│
    │  │                    QUERY API                                ││
    │  │  query_by_entity() → Entity-based node lookup               ││
    │  │  multi_hop_expand() → BFS graph traversal                   ││
    │  │  semantic_search() → Embedding similarity search            ││
    │  └─────────────────────────────────────────────────────────────┘│
    └─────────────────────────────────────────────────────────────────┘

Part of BIZRA Genesis Gold Mine Integration
"""

import hashlib
import json
import logging
import math
import os
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Set, Tuple

# numpy is optional - only used for semantic search
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    np = None  # type: ignore
    HAS_NUMPY = False

logger = logging.getLogger(__name__)

# Configuration
DATA_LAKE_PATH = Path(os.getenv("DATA_LAKE_PATH", "/mnt/c/BIZRA-DATA-LAKE"))
GOLD_MINE_PATH = DATA_LAKE_PATH / "03_INDEXED" / "graph"
EMBEDDINGS_PATH = DATA_LAKE_PATH / "03_INDEXED" / "embeddings"

# Embedding dimension (nomic-embed-text default)
EMBEDDING_DIM = 384


@dataclass
class GoldMineNode:
    """A node in the Gold Mine knowledge graph."""
    id: str
    label: str
    kind: str  # "Document" or "Entity"
    source: Optional[str] = None
    embedding: Optional[List[float]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "label": self.label,
            "kind": self.kind,
            "source": self.source,
            "has_embedding": self.embedding is not None,
            "metadata": self.metadata,
        }


@dataclass
class GoldMineEdge:
    """An edge in the Gold Mine knowledge graph."""
    source: str  # source node id
    target: str  # target node id
    relation: str  # "MENTIONS", etc.
    weight: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MultiHopResult:
    """Result of a multi-hop graph traversal."""
    seed_ids: List[str]
    reached_nodes: List[GoldMineNode]
    traversed_edges: List[GoldMineEdge]
    hops_used: int
    paths: List[List[str]]  # List of paths (node id sequences)


class GoldMineConnector:
    """
    Connector to Gold Mine graph (03_INDEXED/graph/).

    Provides:
    - Stream loading of nodes.jsonl and edges.jsonl
    - Entity-based node lookup
    - Multi-hop graph traversal (BFS)
    - Semantic search via embedding similarity

    Usage:
        connector = GoldMineConnector()
        await connector.initialize()
        nodes = connector.query_by_entity("BIZRA", limit=10)
    """

    def __init__(self, graph_path: Optional[Path] = None, embeddings_path: Optional[Path] = None):
        self.graph_path = graph_path or GOLD_MINE_PATH
        self.embeddings_path = embeddings_path or EMBEDDINGS_PATH

        # Node storage
        self._nodes: Dict[str, GoldMineNode] = {}
        self._nodes_by_kind: Dict[str, List[str]] = defaultdict(list)
        self._label_to_ids: Dict[str, List[str]] = defaultdict(list)

        # Edge storage
        self._edges: List[GoldMineEdge] = []
        self._adjacency_out: Dict[str, List[Tuple[str, str]]] = defaultdict(list)  # source -> [(target, relation)]
        self._adjacency_in: Dict[str, List[Tuple[str, str]]] = defaultdict(list)   # target -> [(source, relation)]

        # Entity index (lowercase label -> node ids)
        self._entity_index: Dict[str, List[str]] = defaultdict(list)

        # Embedding cache
        self._embeddings: Dict[str, np.ndarray] = {}

        # Status
        self._initialized = False
        self._stats = {
            "nodes": 0,
            "edges": 0,
            "documents": 0,
            "entities": 0,
            "embeddings_loaded": 0,
        }

    def is_available(self) -> bool:
        """Check if Gold Mine data is accessible."""
        nodes_path = self.graph_path / "nodes.jsonl"
        return nodes_path.exists()

    async def initialize(self) -> None:
        """
        Load nodes.jsonl and edges.jsonl (streaming for memory efficiency).

        For 56k nodes + 88k edges, this typically takes 2-5 seconds.
        """
        if self._initialized:
            return

        logger.info("Initializing Gold Mine connector from %s", self.graph_path)
        start = datetime.now(timezone.utc)

        # Load nodes
        nodes_path = self.graph_path / "nodes.jsonl"
        if nodes_path.exists():
            for node in self._stream_jsonl(nodes_path):
                self._add_node(node)

        # Load edges
        edges_path = self.graph_path / "edges.jsonl"
        if edges_path.exists():
            for edge in self._stream_jsonl(edges_path):
                self._add_edge(edge)

        # Update stats
        self._stats["nodes"] = len(self._nodes)
        self._stats["edges"] = len(self._edges)
        self._stats["documents"] = len(self._nodes_by_kind.get("Document", []))
        self._stats["entities"] = len(self._nodes_by_kind.get("Entity", []))

        elapsed = (datetime.now(timezone.utc) - start).total_seconds()
        logger.info(
            "Gold Mine initialized: %d nodes (%d docs, %d entities), %d edges in %.2fs",
            self._stats["nodes"],
            self._stats["documents"],
            self._stats["entities"],
            self._stats["edges"],
            elapsed,
        )

        self._initialized = True

    def _stream_jsonl(self, path: Path) -> Iterator[Dict[str, Any]]:
        """Stream JSONL file line by line for memory efficiency."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            yield json.loads(line)
                        except json.JSONDecodeError as e:
                            logger.warning("Invalid JSON in %s: %s", path.name, e)
        except Exception as e:
            logger.error("Error reading %s: %s", path, e)

    def _add_node(self, data: Dict[str, Any]) -> None:
        """Add a node to the index."""
        node = GoldMineNode(
            id=data.get("id", ""),
            label=data.get("label", ""),
            kind=data.get("kind", "Unknown"),
            source=data.get("source"),
            metadata={k: v for k, v in data.items() if k not in ("id", "label", "kind", "source")},
        )

        if not node.id:
            return

        self._nodes[node.id] = node
        self._nodes_by_kind[node.kind].append(node.id)

        # Index by lowercase label for search
        label_lower = node.label.lower()
        self._label_to_ids[label_lower].append(node.id)

        # Build entity index (for entities, index by label; for docs, index by words in label)
        if node.kind == "Entity":
            # Entity nodes have format "ent::concept"
            entity_name = node.label.lower()
            self._entity_index[entity_name].append(node.id)
        else:
            # For documents, index significant words
            words = label_lower.replace("_", " ").replace("-", " ").split()
            for word in words:
                if len(word) > 3:  # Skip short words
                    self._entity_index[word].append(node.id)

    def _add_edge(self, data: Dict[str, Any]) -> None:
        """Add an edge to the adjacency index."""
        edge = GoldMineEdge(
            source=data.get("source", ""),
            target=data.get("target", ""),
            relation=data.get("relation", "RELATED"),
            weight=data.get("weight", 1.0),
            metadata={k: v for k, v in data.items() if k not in ("source", "target", "relation", "weight")},
        )

        if not edge.source or not edge.target:
            return

        self._edges.append(edge)
        self._adjacency_out[edge.source].append((edge.target, edge.relation))
        self._adjacency_in[edge.target].append((edge.source, edge.relation))

    def query_by_entity(
        self,
        entity: str,
        limit: int = 10,
        kinds: Optional[List[str]] = None,
    ) -> List[GoldMineNode]:
        """
        Find nodes mentioning an entity.

        Args:
            entity: Entity name to search for (case-insensitive)
            limit: Maximum results to return
            kinds: Filter by node kinds (e.g., ["Document", "Entity"])

        Returns:
            List of matching GoldMineNode objects
        """
        entity_lower = entity.lower()
        results = []
        seen_ids: Set[str] = set()

        # 1. Exact match in entity index
        for node_id in self._entity_index.get(entity_lower, []):
            if node_id not in seen_ids:
                node = self._nodes.get(node_id)
                if node and (kinds is None or node.kind in kinds):
                    results.append(node)
                    seen_ids.add(node_id)
                    if len(results) >= limit:
                        return results

        # 2. Partial match (entity is substring of label)
        for label, node_ids in self._label_to_ids.items():
            if entity_lower in label:
                for node_id in node_ids:
                    if node_id not in seen_ids:
                        node = self._nodes.get(node_id)
                        if node and (kinds is None or node.kind in kinds):
                            results.append(node)
                            seen_ids.add(node_id)
                            if len(results) >= limit:
                                return results

        return results

    def multi_hop_expand(
        self,
        seed_ids: List[str],
        max_hops: int = 3,
        max_nodes_per_hop: int = 20,
        relation_filter: Optional[List[str]] = None,
    ) -> MultiHopResult:
        """
        Expand from seed nodes via graph traversal (BFS).

        Args:
            seed_ids: Starting node IDs
            max_hops: Maximum number of hops
            max_nodes_per_hop: Limit nodes expanded per hop
            relation_filter: Only follow specific relations

        Returns:
            MultiHopResult with reached nodes, edges, and paths
        """
        visited: Set[str] = set(seed_ids)
        current_frontier: Set[str] = set(seed_ids)
        reached_nodes: List[GoldMineNode] = []
        traversed_edges: List[GoldMineEdge] = []
        all_paths: List[List[str]] = [[sid] for sid in seed_ids]

        # Add seed nodes to results
        for sid in seed_ids:
            if sid in self._nodes:
                reached_nodes.append(self._nodes[sid])

        for hop in range(max_hops):
            next_frontier: Set[str] = set()
            new_paths: List[List[str]] = []

            for node_id in current_frontier:
                # Explore outgoing edges
                for target_id, relation in self._adjacency_out.get(node_id, []):
                    if relation_filter and relation not in relation_filter:
                        continue
                    if target_id not in visited:
                        visited.add(target_id)
                        next_frontier.add(target_id)

                        if target_id in self._nodes:
                            reached_nodes.append(self._nodes[target_id])

                        # Track edge
                        traversed_edges.append(GoldMineEdge(
                            source=node_id,
                            target=target_id,
                            relation=relation,
                        ))

                        # Extend paths
                        for path in all_paths:
                            if path[-1] == node_id:
                                new_paths.append(path + [target_id])

                        if len(next_frontier) >= max_nodes_per_hop:
                            break

                # Explore incoming edges (reverse traversal)
                for source_id, relation in self._adjacency_in.get(node_id, []):
                    if relation_filter and relation not in relation_filter:
                        continue
                    if source_id not in visited:
                        visited.add(source_id)
                        next_frontier.add(source_id)

                        if source_id in self._nodes:
                            reached_nodes.append(self._nodes[source_id])

                        # Track edge
                        traversed_edges.append(GoldMineEdge(
                            source=source_id,
                            target=node_id,
                            relation=relation,
                        ))

                        if len(next_frontier) >= max_nodes_per_hop:
                            break

            all_paths.extend(new_paths)

            if not next_frontier:
                break
            current_frontier = next_frontier

        return MultiHopResult(
            seed_ids=seed_ids,
            reached_nodes=reached_nodes,
            traversed_edges=traversed_edges,
            hops_used=min(max_hops, hop + 1) if 'hop' in dir() else 0,
            paths=all_paths,
        )

    def get_neighbors(
        self,
        node_id: str,
        direction: str = "both",
        relation_filter: Optional[List[str]] = None,
    ) -> List[Tuple[GoldMineNode, str]]:
        """
        Get immediate neighbors of a node.

        Args:
            node_id: Node to get neighbors for
            direction: "out", "in", or "both"
            relation_filter: Only return specific relations

        Returns:
            List of (neighbor_node, relation) tuples
        """
        neighbors = []

        if direction in ("out", "both"):
            for target_id, relation in self._adjacency_out.get(node_id, []):
                if relation_filter and relation not in relation_filter:
                    continue
                if target_id in self._nodes:
                    neighbors.append((self._nodes[target_id], relation))

        if direction in ("in", "both"):
            for source_id, relation in self._adjacency_in.get(node_id, []):
                if relation_filter and relation not in relation_filter:
                    continue
                if source_id in self._nodes:
                    neighbors.append((self._nodes[source_id], relation))

        return neighbors

    async def load_embedding(self, node_id: str) -> Optional[Any]:
        """
        Load embedding for a node from disk.

        Embeddings are stored as .npy files in the embeddings directory.
        Requires numpy to be installed.
        """
        if not HAS_NUMPY:
            logger.warning("numpy not available for embedding loading")
            return None

        if node_id in self._embeddings:
            return self._embeddings[node_id]

        # Try multiple possible paths
        embedding_paths = [
            self.embeddings_path / f"{node_id}.npy",
            self.embeddings_path / f"{node_id[:2]}" / f"{node_id}.npy",  # Sharded
        ]

        for emb_path in embedding_paths:
            if emb_path.exists():
                try:
                    embedding = np.load(emb_path)
                    self._embeddings[node_id] = embedding
                    self._stats["embeddings_loaded"] += 1
                    return embedding
                except Exception as e:
                    logger.warning("Error loading embedding %s: %s", emb_path, e)

        return None

    def semantic_search(
        self,
        query_embedding: List[float],
        top_k: int = 10,
        kinds: Optional[List[str]] = None,
    ) -> List[Tuple[GoldMineNode, float]]:
        """
        Find nodes by embedding similarity (cosine).

        Args:
            query_embedding: Query vector (384-dim)
            top_k: Number of results
            kinds: Filter by node kinds

        Returns:
            List of (node, similarity_score) tuples, sorted by score descending

        Note: Requires numpy. Returns empty list if numpy not available.
        """
        if not HAS_NUMPY:
            logger.warning("numpy not available for semantic search")
            return []

        if not self._embeddings:
            logger.warning("No embeddings loaded for semantic search")
            return []

        query_vec = np.array(query_embedding, dtype=np.float32)
        query_norm = np.linalg.norm(query_vec)

        if query_norm == 0:
            return []

        query_vec = query_vec / query_norm

        scores: List[Tuple[str, float]] = []
        for node_id, embedding in self._embeddings.items():
            if kinds:
                node = self._nodes.get(node_id)
                if not node or node.kind not in kinds:
                    continue

            emb_norm = np.linalg.norm(embedding)
            if emb_norm == 0:
                continue

            similarity = float(np.dot(query_vec, embedding / emb_norm))
            scores.append((node_id, similarity))

        # Sort by similarity descending
        scores.sort(key=lambda x: x[1], reverse=True)

        results = []
        for node_id, score in scores[:top_k]:
            node = self._nodes.get(node_id)
            if node:
                results.append((node, score))

        return results

    def get_node(self, node_id: str) -> Optional[GoldMineNode]:
        """Get a single node by ID."""
        return self._nodes.get(node_id)

    def get_nodes_by_kind(self, kind: str) -> List[GoldMineNode]:
        """Get all nodes of a specific kind."""
        return [self._nodes[nid] for nid in self._nodes_by_kind.get(kind, []) if nid in self._nodes]

    def get_statistics(self) -> Dict[str, Any]:
        """Get connector statistics."""
        return {
            **self._stats,
            "initialized": self._initialized,
            "path": str(self.graph_path),
            "entity_terms": len(self._entity_index),
            "embeddings_cached": len(self._embeddings),
        }

    def generate_receipt(self, operation: str, **kwargs) -> Dict[str, Any]:
        """Generate an evidence receipt for Gold Mine operations."""
        return {
            "receipt_id": hashlib.sha256(f"{operation}:{datetime.now(timezone.utc).isoformat()}".encode()).hexdigest()[:16],
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "operation": operation,
            "connector": "GoldMineConnector",
            "statistics": self.get_statistics(),
            "params": kwargs,
        }


# Module-level singleton
_connector: Optional[GoldMineConnector] = None


def get_gold_mine_connector() -> GoldMineConnector:
    """Get or create the global Gold Mine connector instance."""
    global _connector
    if _connector is None:
        _connector = GoldMineConnector()
    return _connector


async def initialize_gold_mine() -> GoldMineConnector:
    """Initialize and return the global Gold Mine connector."""
    connector = get_gold_mine_connector()
    await connector.initialize()
    return connector


if __name__ == "__main__":
    import asyncio

    async def test():
        connector = GoldMineConnector()
        await connector.initialize()

        print(f"\nStatistics: {connector.get_statistics()}")

        # Test entity query
        nodes = connector.query_by_entity("BIZRA", limit=5)
        print(f"\nQuery 'BIZRA': {len(nodes)} results")
        for node in nodes:
            print(f"  - [{node.kind}] {node.label}")

        # Test multi-hop
        if nodes:
            result = connector.multi_hop_expand([nodes[0].id], max_hops=2)
            print(f"\nMulti-hop from {nodes[0].label}: {len(result.reached_nodes)} nodes reached")

    asyncio.run(test())
