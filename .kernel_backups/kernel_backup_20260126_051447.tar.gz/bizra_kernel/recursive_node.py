import os
import uuid
import json
import threading
import hashlib
from datetime import datetime
from typing import Optional, Dict, Any, List
from enum import Enum


class SeedState(Enum):
    """Seed lifecycle states - mirrors seed_manager.SeedState."""
    DORMANT = "dormant"
    GERMINATING = "germinating"
    SAPLING = "sapling"
    MATURE = "mature"
    FRUITING = "fruiting"
    ELDER = "elder"


class RecursiveNode:
    """
    Self-spawning node architecture for the BIZRA Network State.
    Hardened with Ω-Class Depth Guards and Thread-Safety.
    """
    MAX_DEPTH = 3
    _lock = threading.RLock()
    
    def __init__(self, node_id=None, parent_id=None, depth=0, max_depth=None):
        if not node_id:
            # Phase 4: Ancestry-Linked ID (Prevent Spoofing)
            import hashlib
            salt = uuid.uuid4().hex[:4]
            base = f"{parent_id}:{salt}" if parent_id else f"ROOT:{salt}"
            node_hash = hashlib.sha256(base.encode()).hexdigest()[:8].upper()
            self.node_id = f"BIZRA-{node_hash}"
        else:
            self.node_id = node_id

        self.parent_id = parent_id
        self.depth = depth
        self.max_depth = max_depth if max_depth is not None else self.MAX_DEPTH
        self.children = []
        self.status = "SEED"
        self.config_dir = f"bizra_network/{self.node_id}"
        os.makedirs(self.config_dir, exist_ok=True)

        # Seed lifecycle integration (Phase 1: Autonomous Forest Growth)
        self.seed_state: SeedState = SeedState.DORMANT
        self.ihsan_score: float = 0.0
        self.poi_events: int = 0
        self.covenant_accepted: bool = False
        self.token_balance: float = 0.0
        self.germinated_at: Optional[datetime] = None
        self.created_at: datetime = datetime.utcnow()
        
    def activate(self):
        self.status = "ORGANISM"
        self._save_state()
        print(f"[NODE ACTIVATED] {self.node_id} (Depth: {self.depth}, Parent: {self.parent_id})")
        
    def spawn_child(self):
        """Recursively scale the network by birthing a child node. Thread-safe."""
        with self._lock:
            if self.depth >= self.max_depth:
                print(f"[!] RECURSION BLOCKED: Node {self.node_id} reached Max Depth ({self.max_depth}).")
                return None
                
            child = RecursiveNode(parent_id=self.node_id, depth=self.depth + 1, max_depth=self.max_depth)
            self.children.append(child.node_id)
            child.activate()
            self._save_state()
            return child

    def budget_aware_spawn(self, budget_score: float, threshold: float = 0.35):
        """Spawn only if cognitive budget supports recursion."""
        if budget_score < threshold:
            print(f"[!] RECURSION PAUSED: Budget {budget_score:.3f} below threshold {threshold:.2f}.")
            return None
        return self.spawn_child()

    def set_dynamic_max_depth(self, max_depth: int):
        """Allow SovereignEngine to tune depth dynamically."""
        with self._lock:
            self.max_depth = max(0, max_depth)

    def germinate(self) -> bool:
        """
        Transition from DORMANT to GERMINATING state.

        Returns:
            True if germination successful, False if not in DORMANT state
        """
        with self._lock:
            if self.seed_state != SeedState.DORMANT:
                return False
            self.seed_state = SeedState.GERMINATING
            self.germinated_at = datetime.utcnow()
            self.status = "GERMINATING"
            self._save_state()
            print(f"[GERMINATED] {self.node_id} entered GERMINATING state")
            return True

    def can_fruit(self) -> bool:
        """
        Check if node is ready to reproduce (create children).

        Requirements:
        - State is FRUITING or ELDER
        - Ihsān score >= 0.95
        - PoI events >= 10
        - Covenant accepted
        - Children count < 7 (biblical seed metaphor)

        Returns:
            True if can create offspring, False otherwise
        """
        with self._lock:
            # Must be in reproductive state
            if self.seed_state not in [SeedState.FRUITING, SeedState.ELDER]:
                return False

            # Ihsān threshold check (0.95)
            if self.ihsan_score < 0.95:
                return False

            # PoI threshold check (10 events minimum)
            if self.poi_events < 10:
                return False

            # Covenant requirement
            if not self.covenant_accepted:
                return False

            # Max children limit (7 for first seeds)
            if len(self.children) >= 7:
                return False

            # Age check - 7 days minimum
            if self.germinated_at:
                age_days = (datetime.utcnow() - self.germinated_at).days
                if age_days < 7:
                    return False

            return True

    def inherit_covenant(self, parent: 'RecursiveNode') -> None:
        """
        Inherit parent's covenant acceptance.

        Args:
            parent: Parent node to inherit from
        """
        with self._lock:
            if parent.covenant_accepted:
                self.covenant_accepted = True
                print(f"[COVENANT INHERITED] {self.node_id} inherited covenant from {parent.node_id}")
                self._save_state()

    def record_poi(self, event: Dict[str, Any]) -> None:
        """
        Record a Proof-of-Impact event.

        Args:
            event: Event details including type and impact_score
        """
        with self._lock:
            self.poi_events += 1

            # Update Ihsān score based on impact
            impact_score = event.get("impact_score", 0.01)
            self.ihsan_score = min(1.0, self.ihsan_score + impact_score * 0.1)

            print(f"[POI RECORDED] {self.node_id}: event #{self.poi_events}, "
                  f"Ihsān now {self.ihsan_score:.3f}")
            self._save_state()

    def advance_seed_state(self) -> Optional[SeedState]:
        """
        Advance to next seed lifecycle state if eligible.

        Returns:
            New state if advanced, None if not eligible
        """
        with self._lock:
            lifecycle = [
                SeedState.DORMANT,
                SeedState.GERMINATING,
                SeedState.SAPLING,
                SeedState.MATURE,
                SeedState.FRUITING,
                SeedState.ELDER,
            ]
            current_idx = lifecycle.index(self.seed_state)

            # Already at final state
            if current_idx >= len(lifecycle) - 1:
                return None

            # Check advancement requirements
            eligible = self._check_advancement_eligible(current_idx)
            if not eligible:
                return None

            previous = self.seed_state
            self.seed_state = lifecycle[current_idx + 1]
            self.status = self.seed_state.value.upper()
            self._save_state()

            print(f"[LIFECYCLE ADVANCED] {self.node_id}: {previous.value} → {self.seed_state.value}")
            return self.seed_state

    def _check_advancement_eligible(self, current_idx: int) -> bool:
        """Check eligibility for next lifecycle stage."""
        # DORMANT → GERMINATING
        if current_idx == 0:
            return True
        # GERMINATING → SAPLING
        if current_idx == 1:
            return self.poi_events >= 1
        # SAPLING → MATURE
        if current_idx == 2:
            return self.poi_events >= 5 and self.ihsan_score >= 0.8
        # MATURE → FRUITING
        if current_idx == 3:
            return self.poi_events >= 10 and self.ihsan_score >= 0.95 and self.covenant_accepted
        # FRUITING → ELDER
        if current_idx == 4:
            return len(self.children) >= 3 and self.poi_events >= 50 and self.ihsan_score >= 0.98
        return False

    def _save_state(self):
        state = {
            "node_id": self.node_id,
            "parent_id": self.parent_id,
            "children": self.children,
            "status": self.status,
            "max_depth": self.max_depth,
            "birth_time": datetime.utcnow().isoformat(),
            # Seed lifecycle fields
            "seed_state": self.seed_state.value,
            "ihsan_score": self.ihsan_score,
            "poi_events": self.poi_events,
            "covenant_accepted": self.covenant_accepted,
            "token_balance": self.token_balance,
            "germinated_at": self.germinated_at.isoformat() if self.germinated_at else None,
            "created_at": self.created_at.isoformat() if hasattr(self, 'created_at') else datetime.utcnow().isoformat(),
        }
        with open(f"{self.config_dir}/manifest.json", "w") as f:
            json.dump(state, f, indent=4)

if __name__ == "__main__":
    print("--- BIZRA RECURSIVE NETWORK GENESIS ---")
    root = RecursiveNode(node_id="BIZRA-MASTER-0")
    root.activate()
    
    # Spawn 2nd generation
    print("\nScaling to 2nd Generation...")
    child_1 = root.spawn_child()
    
    # Spawn 3rd generation from child
    print("\nScaling to 3rd Generation (Recursive)...")
    grand_child = child_1.spawn_child()
    
    print(f"\nNetwork State: Root -> {root.children[0]} -> {child_1.children[0]}")
    print("--- RECURSIVE SCALING SUCCESSFUL ---")
