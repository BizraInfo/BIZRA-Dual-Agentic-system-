"""
bizra_kernel/autopoietic_bridge.py - Python Bridge for AutopoieticLoop

Provides Python integration for the Rust AutopoieticLoop system,
enabling SAPE/GoT integration and Python-based evaluation hooks.

Usage:
    from bizra_kernel.autopoietic_bridge import AutopoieticClient

    client = AutopoieticClient()
    await client.start(generation_duration_ms=60000)
    status = await client.status()
    await client.stop()
"""

import asyncio
import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

import aiohttp

logger = logging.getLogger(__name__)


class KEPState(Enum):
    """Knowledge Explosion Point states."""
    NORMAL = "Normal"
    APPROACHING = "Approaching"
    ENTERING_EXPLOSION = "EnteringExplosion"
    IN_EXPLOSION = "InExplosion"
    EXITING_EXPLOSION = "ExitingExplosion"
    PLATEAU = "Plateau"


@dataclass
class KEPProgress:
    """KEP progress metrics."""
    knowledge_mass: int = 0
    discovery_velocity: float = 0.0
    synergy_density: float = 0.0
    learning_rate_multiplier: float = 1.0
    synergies_detected: int = 0
    compounds_synthesized: int = 0


@dataclass
class IhsanDimensions:
    """The 8 Ihsān dimensions."""
    correctness: float = 0.0
    safety: float = 0.0
    user_benefit: float = 0.0
    efficiency: float = 0.0
    auditability: float = 0.0
    anti_centralization: float = 0.0
    robustness: float = 0.0
    adl_fairness: float = 0.0

    def aggregate(self) -> float:
        """Calculate weighted aggregate score."""
        return (
            self.correctness * 0.22 +
            self.safety * 0.22 +
            self.user_benefit * 0.14 +
            self.efficiency * 0.12 +
            self.auditability * 0.12 +
            self.anti_centralization * 0.08 +
            self.robustness * 0.06 +
            self.adl_fairness * 0.04
        )


@dataclass
class GenerationPerformance:
    """Performance metrics for a single generation."""
    generation: int
    aggregate_ihsan: float
    tasks_processed: int
    successful_executions: int
    rejections: int
    avg_latency_ms: int
    p95_latency_ms: int
    kep_progress: KEPProgress
    improvements_count: int
    proof_hash: str
    receipt_id: str
    duration_ms: int


@dataclass
class AutopoieticStatus:
    """Current status of the AutopoieticLoop."""
    running: bool
    current_generation: int = 0
    kep_state: KEPState = KEPState.NORMAL
    aggregate_ihsan: float = 0.0
    active_agents: int = 0
    blueprint_count: int = 0
    convergence_state: str = ""
    proof_chain_length: int = 0
    receipts_emitted: int = 0


@dataclass
class ChainVerification:
    """Result of proof chain verification."""
    is_valid: bool
    verified_nodes: int
    total_nodes: int
    errors: List[str]
    chain_hash: str


class AutopoieticClient:
    """
    Python client for the Rust AutopoieticLoop HTTP API.

    Provides async methods to control and monitor the autopoietic system.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8080",
        api_token: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Initialize the AutopoieticClient.

        Args:
            base_url: Base URL of the BIZRA Elite server
            api_token: API token for authentication
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session."""
        if self._session is None or self._session.closed:
            headers = {}
            if self.api_token:
                headers["Authorization"] = f"Bearer {self.api_token}"
            self._session = aiohttp.ClientSession(
                timeout=self.timeout,
                headers=headers,
            )
        return self._session

    async def close(self):
        """Close the HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()

    async def _request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict] = None,
        params: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Make HTTP request to the autopoietic API."""
        session = await self._get_session()
        url = f"{self.base_url}{endpoint}"

        try:
            async with session.request(
                method,
                url,
                json=json_data,
                params=params,
            ) as response:
                data = await response.json()

                if response.status >= 400:
                    error_msg = data.get("error", "Unknown error")
                    raise AutopoieticError(
                        f"API error ({response.status}): {error_msg}"
                    )

                return data

        except aiohttp.ClientError as e:
            raise AutopoieticError(f"Connection error: {e}") from e

    # ═══════════════════════════════════════════════════════════════════════════════
    # LOOP CONTROL
    # ═══════════════════════════════════════════════════════════════════════════════

    async def start(
        self,
        generation_duration_ms: int = 60000,
        max_generations: int = 0,
        ihsan_threshold: float = 0.95,
    ) -> Dict[str, Any]:
        """
        Start the autopoietic loop.

        Args:
            generation_duration_ms: Duration of each generation in milliseconds
            max_generations: Maximum generations (0 = unlimited)
            ihsan_threshold: Ihsān threshold (default 0.95)

        Returns:
            Start response with configuration
        """
        logger.info(
            f"Starting autopoietic loop: duration={generation_duration_ms}ms, "
            f"max={max_generations}, ihsan={ihsan_threshold}"
        )

        return await self._request(
            "POST",
            "/autopoietic/start",
            json_data={
                "generation_duration_ms": generation_duration_ms,
                "max_generations": max_generations,
                "ihsan_threshold": ihsan_threshold,
            },
        )

    async def stop(self) -> Dict[str, Any]:
        """Stop the autopoietic loop gracefully."""
        logger.info("Stopping autopoietic loop")
        return await self._request("POST", "/autopoietic/stop")

    async def status(self) -> AutopoieticStatus:
        """Get current loop status."""
        data = await self._request("GET", "/autopoietic/status")

        if not data.get("running", False):
            return AutopoieticStatus(running=False)

        kep_state_str = data.get("kep_state", "Normal")
        kep_state = KEPState(kep_state_str) if kep_state_str in [e.value for e in KEPState] else KEPState.NORMAL

        return AutopoieticStatus(
            running=True,
            current_generation=data.get("current_generation", 0),
            kep_state=kep_state,
            aggregate_ihsan=data.get("aggregate_ihsan", 0.0),
            active_agents=data.get("active_agents", 0),
            blueprint_count=data.get("blueprint_count", 0),
            convergence_state=data.get("convergence_state", ""),
            proof_chain_length=data.get("proof_chain_length", 0),
            receipts_emitted=data.get("receipts_emitted", 0),
        )

    async def history(self, limit: int = 10) -> List[GenerationPerformance]:
        """
        Get evolution history.

        Args:
            limit: Maximum number of generations to return

        Returns:
            List of generation performance records
        """
        data = await self._request(
            "GET",
            "/autopoietic/history",
            params={"limit": limit},
        )

        result = []
        for item in data.get("history", []):
            kep_data = item.get("kep_progress", {})
            kep_progress = KEPProgress(
                knowledge_mass=kep_data.get("knowledge_mass", 0),
                discovery_velocity=kep_data.get("discovery_velocity", 0.0),
                synergy_density=kep_data.get("synergy_density", 0.0),
            )

            result.append(GenerationPerformance(
                generation=item.get("generation", 0),
                aggregate_ihsan=item.get("aggregate_ihsan", 0.0),
                tasks_processed=item.get("tasks_processed", 0),
                successful_executions=item.get("successful_executions", 0),
                rejections=item.get("rejections", 0),
                avg_latency_ms=item.get("avg_latency_ms", 0),
                p95_latency_ms=item.get("p95_latency_ms", 0),
                kep_progress=kep_progress,
                improvements_count=item.get("improvements_count", 0),
                proof_hash=item.get("proof_hash", ""),
                receipt_id=item.get("receipt_id", ""),
                duration_ms=item.get("duration_ms", 0),
            ))

        return result

    async def verify_chain(self) -> ChainVerification:
        """Verify proof chain integrity."""
        data = await self._request("GET", "/autopoietic/verify")

        return ChainVerification(
            is_valid=data.get("is_valid", False),
            verified_nodes=data.get("verified_nodes", 0),
            total_nodes=data.get("total_nodes", 0),
            errors=data.get("errors", []),
            chain_hash=data.get("chain_hash", ""),
        )

    # ═══════════════════════════════════════════════════════════════════════════════
    # BLUEPRINT INJECTION
    # ═══════════════════════════════════════════════════════════════════════════════

    async def inject_blueprint(
        self,
        id: str,
        name: str,
        team: str,
        capability_slot: str,
        system_prompt: str,
        model: str = "qwen2.5:7b",
    ) -> Dict[str, Any]:
        """
        Inject a custom blueprint into the loop.

        Args:
            id: Unique blueprint ID
            name: Human-readable name
            team: "PAT" or "SAT"
            capability_slot: Capability slot identifier
            system_prompt: System prompt for the agent
            model: Model to use

        Returns:
            Injection confirmation
        """
        return await self._request(
            "POST",
            "/autopoietic/inject",
            json_data={
                "id": id,
                "name": name,
                "team": team,
                "capability_slot": capability_slot,
                "system_prompt": system_prompt,
                "model": model,
            },
        )

    # ═══════════════════════════════════════════════════════════════════════════════
    # SAPE INTEGRATION
    # ═══════════════════════════════════════════════════════════════════════════════

    async def run_sape_probes(self, content: str) -> Dict[str, Any]:
        """
        Run SAPE probes on content.

        Args:
            content: Content to analyze

        Returns:
            SAPE probe results with Ihsān score
        """
        return await self._request(
            "POST",
            "/sape/probes",
            json_data={"content": content},
        )

    async def get_sape_stats(self) -> Dict[str, Any]:
        """Get SAPE engine statistics."""
        return await self._request("GET", "/sape/stats")

    # ═══════════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════════

    @staticmethod
    def compute_lineage_hash(
        parent_hash: Optional[str],
        blueprint_id: str,
        generation: int,
    ) -> str:
        """Compute lineage hash for blueprint evolution tracking."""
        content = f"{parent_hash or 'genesis'}|{blueprint_id}|{generation}"
        return f"lin:{hashlib.sha256(content.encode()).hexdigest()}"

    @staticmethod
    def compute_proof_hash(
        generation: int,
        previous_hash: str,
        improvements_hash: str,
        ihsan_score: float,
        timestamp_nanos: int,
    ) -> str:
        """Compute proof node hash for chain verification."""
        content = f"{generation}|{previous_hash}|{improvements_hash}|{ihsan_score:.6f}|{timestamp_nanos}"
        return f"proof:{hashlib.sha256(content.encode()).hexdigest()}"


class AutopoieticError(Exception):
    """Exception raised for autopoietic client errors."""
    pass


# ═══════════════════════════════════════════════════════════════════════════════
# EVALUATION HOOKS
# ═══════════════════════════════════════════════════════════════════════════════

class EvaluationHook:
    """
    Base class for custom evaluation hooks.

    Subclass this to add Python-based evaluation logic that can be
    called from the autopoietic loop.
    """

    async def pre_generation(self, generation: int) -> None:
        """Called before each generation starts."""
        pass

    async def post_generation(
        self,
        generation: int,
        performance: GenerationPerformance,
    ) -> Optional[Dict[str, Any]]:
        """
        Called after each generation completes.

        Returns:
            Optional dictionary of additional metrics to include
        """
        return None

    async def on_kep_transition(
        self,
        from_state: KEPState,
        to_state: KEPState,
        generation: int,
    ) -> None:
        """Called when KEP state transitions."""
        pass

    async def on_ihsan_failure(
        self,
        generation: int,
        score: float,
        threshold: float,
    ) -> None:
        """Called when Ihsān gate fails."""
        logger.warning(
            f"Ihsān gate failed at generation {generation}: "
            f"{score:.4f} < {threshold:.4f}"
        )


class SAPEEvaluationHook(EvaluationHook):
    """
    Evaluation hook that integrates with SAPE pattern elevation.

    This hook tracks patterns across generations and suggests
    elevations for frequently successful patterns.
    """

    def __init__(self):
        self.pattern_counts: Dict[str, int] = {}
        self.elevation_threshold = 3

    async def post_generation(
        self,
        generation: int,
        performance: GenerationPerformance,
    ) -> Optional[Dict[str, Any]]:
        """Track patterns and suggest elevations."""
        # In a full implementation, this would analyze the generation's
        # execution patterns and track successful ones

        # Check for patterns that should be elevated
        elevations = []
        for pattern_id, count in self.pattern_counts.items():
            if count >= self.elevation_threshold:
                elevations.append({
                    "pattern_id": pattern_id,
                    "occurrences": count,
                    "recommendation": "elevate",
                })

        if elevations:
            return {"suggested_elevations": elevations}

        return None


# ═══════════════════════════════════════════════════════════════════════════════
# CONVENIENCE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

async def quick_status(base_url: str = "http://localhost:8080") -> AutopoieticStatus:
    """Quick status check without persistent client."""
    client = AutopoieticClient(base_url)
    try:
        return await client.status()
    finally:
        await client.close()


async def quick_start(
    base_url: str = "http://localhost:8080",
    generation_duration_ms: int = 60000,
    max_generations: int = 0,
) -> Dict[str, Any]:
    """Quick start without persistent client."""
    client = AutopoieticClient(base_url)
    try:
        return await client.start(
            generation_duration_ms=generation_duration_ms,
            max_generations=max_generations,
        )
    finally:
        await client.close()


if __name__ == "__main__":
    # Example usage
    async def main():
        client = AutopoieticClient(base_url="http://localhost:8080")

        try:
            # Check status
            status = await client.status()
            print(f"Loop running: {status.running}")

            if not status.running:
                # Start the loop
                result = await client.start(
                    generation_duration_ms=10000,  # 10 seconds per generation
                    max_generations=5,
                )
                print(f"Started: {result}")

            # Wait and check status
            await asyncio.sleep(2)
            status = await client.status()
            print(f"Generation: {status.current_generation}")
            print(f"KEP State: {status.kep_state.value}")
            print(f"Ihsān: {status.aggregate_ihsan:.4f}")

            # Get history
            history = await client.history(limit=5)
            for perf in history:
                print(f"  Gen {perf.generation}: Ihsān={perf.aggregate_ihsan:.4f}")

            # Verify chain
            verification = await client.verify_chain()
            print(f"Chain valid: {verification.is_valid}")

        finally:
            await client.close()

    asyncio.run(main())
