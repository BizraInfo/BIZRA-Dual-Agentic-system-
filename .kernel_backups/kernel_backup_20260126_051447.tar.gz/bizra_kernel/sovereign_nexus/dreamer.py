"""
BIZRA Sovereign Nexus - Autonomous Dreamer
==========================================
Proactive hypothesis generation without external input.

The Dreamer runs during idle periods (budget_score >= 0.75) to:
- Pick research seeds from L4 semantic memory
- Mine patterns from Data Lake via MCP
- Generate hypotheses using Graph-of-Thought
- Crystallize validated insights (SNR >= 0.95) to L5 procedural memory
"""

import os
import logging
import hashlib
import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum

logger = logging.getLogger("nexus.dreamer")


class DreamPhase(Enum):
    """Phases of the dream cycle."""
    IDLE = "idle"
    SEED_SELECTION = "seed_selection"
    PATTERN_MINING = "pattern_mining"
    HYPOTHESIS_GENERATION = "hypothesis_generation"
    VALIDATION = "validation"
    CRYSTALLIZATION = "crystallization"


@dataclass
class DreamSeed:
    """A seed for dream generation."""
    seed_id: str
    concept: str
    source_tier: str  # Usually "L4_semantic"
    relevance_score: float
    disciplines: List[str] = field(default_factory=list)


@dataclass
class DreamHypothesis:
    """A hypothesis generated during dreaming."""
    hypothesis_id: str
    statement: str
    supporting_patterns: List[str]
    disciplines_involved: List[str]
    confidence: float
    snr_score: float
    ihsan_alignment: float
    got_cluster_id: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class DreamResult:
    """Result of a dream cycle."""
    dream_id: str
    phase: DreamPhase
    seeds_explored: int
    patterns_mined: int
    hypotheses_generated: int
    hypotheses_crystallized: int
    total_duration_ms: float
    snr_achieved: float
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "dream_id": self.dream_id,
            "phase": self.phase.value,
            "seeds_explored": self.seeds_explored,
            "patterns_mined": self.patterns_mined,
            "hypotheses_generated": self.hypotheses_generated,
            "hypotheses_crystallized": self.hypotheses_crystallized,
            "total_duration_ms": self.total_duration_ms,
            "snr_achieved": self.snr_achieved,
            "timestamp": self.timestamp,
        }


class AutonomousDreamer:
    """
    Autonomous Dreamer for the Sovereign Nexus.

    Proactively generates hypotheses during idle periods:
    1. Picks research seeds from L4 semantic memory
    2. Mines patterns from Data Lake
    3. Generates hypotheses via Graph-of-Thought
    4. Crystallizes validated insights (SNR >= 0.95) to L5 memory
    """

    def __init__(
        self,
        snr_threshold: float = 0.95,
        budget_threshold: float = 0.75,
        max_hypotheses_per_cycle: int = 5
    ):
        self.snr_threshold = snr_threshold
        self.budget_threshold = budget_threshold
        self.max_hypotheses_per_cycle = max_hypotheses_per_cycle

        self._current_phase = DreamPhase.IDLE
        self._dream_counter = 0
        self._hypothesis_counter = 0
        self._seeds: List[DreamSeed] = []
        self._patterns: List[Dict[str, Any]] = []
        self._hypotheses: List[DreamHypothesis] = []
        self._crystallized: List[DreamHypothesis] = []

        # Components (will be injected by SovereignNexus)
        self._data_lake_adapter = None
        self._got_orchestrator = None
        self._memory_system = None
        self._topology_engine = None

    def _next_dream_id(self) -> str:
        self._dream_counter += 1
        return f"dream-{self._dream_counter:08d}"

    def _next_hypothesis_id(self) -> str:
        self._hypothesis_counter += 1
        return f"hyp-{self._hypothesis_counter:08d}"

    def set_data_lake_adapter(self, adapter) -> None:
        """Inject Data Lake adapter."""
        self._data_lake_adapter = adapter

    def set_got_orchestrator(self, got) -> None:
        """Inject GoT orchestrator."""
        self._got_orchestrator = got

    def set_memory_system(self, memory) -> None:
        """Inject memory system."""
        self._memory_system = memory

    def set_topology_engine(self, topology) -> None:
        """Inject topology engine."""
        self._topology_engine = topology

    async def dream_cycle(
        self,
        budget_score: float,
        context: Optional[Dict[str, Any]] = None
    ) -> DreamResult:
        """
        Execute a dream cycle.

        Only runs when budget_score >= budget_threshold (0.75).
        """
        dream_id = self._next_dream_id()
        start_time = asyncio.get_event_loop().time()

        # Check budget
        if budget_score < self.budget_threshold:
            logger.debug(f"Dream cycle skipped: budget {budget_score:.4f} < {self.budget_threshold:.4f}")
            return DreamResult(
                dream_id=dream_id,
                phase=DreamPhase.IDLE,
                seeds_explored=0,
                patterns_mined=0,
                hypotheses_generated=0,
                hypotheses_crystallized=0,
                total_duration_ms=0,
                snr_achieved=0,
            )

        logger.info(f"Dream cycle starting: {dream_id}")
        self._current_phase = DreamPhase.SEED_SELECTION

        # Phase 1: Pick research seeds from L4 memory
        seeds = await self._pick_seeds(context)
        self._seeds = seeds

        # Phase 2: Mine patterns from Data Lake
        self._current_phase = DreamPhase.PATTERN_MINING
        patterns = await self._mine_patterns(seeds)
        self._patterns = patterns

        # Phase 3: Generate hypotheses via GoT
        self._current_phase = DreamPhase.HYPOTHESIS_GENERATION
        hypotheses = await self._generate_hypotheses(seeds, patterns)
        self._hypotheses = hypotheses

        # Phase 4: Validate hypotheses
        self._current_phase = DreamPhase.VALIDATION
        validated = self._validate_hypotheses(hypotheses)

        # Phase 5: Crystallize validated insights
        self._current_phase = DreamPhase.CRYSTALLIZATION
        crystallized = await self._crystallize(validated)
        self._crystallized.extend(crystallized)

        # Calculate final SNR
        final_snr = self._calculate_dream_snr(crystallized)

        self._current_phase = DreamPhase.IDLE
        duration_ms = (asyncio.get_event_loop().time() - start_time) * 1000

        result = DreamResult(
            dream_id=dream_id,
            phase=DreamPhase.IDLE,
            seeds_explored=len(seeds),
            patterns_mined=len(patterns),
            hypotheses_generated=len(hypotheses),
            hypotheses_crystallized=len(crystallized),
            total_duration_ms=duration_ms,
            snr_achieved=final_snr,
        )

        logger.info(
            f"Dream cycle complete: {dream_id} | "
            f"Seeds: {len(seeds)} | Patterns: {len(patterns)} | "
            f"Hypotheses: {len(hypotheses)} | Crystallized: {len(crystallized)} | "
            f"SNR: {final_snr:.4f}"
        )

        return result

    async def _pick_seeds(
        self,
        context: Optional[Dict[str, Any]]
    ) -> List[DreamSeed]:
        """Pick research seeds from L4 semantic memory."""
        seeds = []

        # Get disciplines from topology
        disciplines = []
        if self._topology_engine:
            # Pick active disciplines
            for disc in self._topology_engine.disciplines.values():
                if disc.activation_count > 0:
                    disciplines.append(disc.name)

        if not disciplines:
            # Default disciplines for dreaming
            disciplines = ["ethics", "complexity_science", "futures_studies", "ihsan_studies"]

        # Create seeds from disciplines
        for disc in disciplines[:5]:
            seed = DreamSeed(
                seed_id=f"seed-{hashlib.sha256(disc.encode()).hexdigest()[:8]}",
                concept=disc,
                source_tier="L4_semantic",
                relevance_score=0.8,
                disciplines=[disc],
            )
            seeds.append(seed)

        # Try to get seeds from memory if available
        if self._memory_system:
            try:
                semantic_facts = self._memory_system.get_semantic_facts()
                for fact in semantic_facts[:5]:
                    seed = DreamSeed(
                        seed_id=f"seed-{hashlib.sha256(str(fact).encode()).hexdigest()[:8]}",
                        concept=fact.get("concept", "unknown"),
                        source_tier="L4_semantic",
                        relevance_score=fact.get("relevance", 0.7),
                        disciplines=fact.get("disciplines", []),
                    )
                    seeds.append(seed)
            except Exception as e:
                logger.warning(f"Memory seed extraction failed: {e}")

        return seeds

    async def _mine_patterns(
        self,
        seeds: List[DreamSeed]
    ) -> List[Dict[str, Any]]:
        """Mine patterns from Data Lake for research seeds."""
        patterns = []

        if not self._data_lake_adapter:
            # Simulate pattern mining
            for seed in seeds:
                patterns.append({
                    "pattern_id": f"pat-{hashlib.sha256(seed.concept.encode()).hexdigest()[:8]}",
                    "source_seed": seed.seed_id,
                    "concept": seed.concept,
                    "frequency": 5,
                    "insights": [f"Pattern related to {seed.concept}"],
                })
            return patterns

        # Real pattern mining
        for seed in seeds:
            try:
                mined = await self._data_lake_adapter.mine_patterns(seed.concept)
                for p in mined[:3]:
                    patterns.append({
                        "pattern_id": p.get("id", "unknown"),
                        "source_seed": seed.seed_id,
                        "concept": seed.concept,
                        "frequency": p.get("frequency", 1),
                        "insights": p.get("insights", []),
                    })
            except Exception as e:
                logger.warning(f"Pattern mining failed for {seed.concept}: {e}")

        return patterns

    async def _generate_hypotheses(
        self,
        seeds: List[DreamSeed],
        patterns: List[Dict[str, Any]]
    ) -> List[DreamHypothesis]:
        """Generate hypotheses using Graph-of-Thought reasoning."""
        hypotheses = []

        if not self._got_orchestrator:
            # Simulate hypothesis generation
            for i, seed in enumerate(seeds[:self.max_hypotheses_per_cycle]):
                hypothesis = DreamHypothesis(
                    hypothesis_id=self._next_hypothesis_id(),
                    statement=f"Hypothesis: {seed.concept} can be enhanced through cross-disciplinary synthesis",
                    supporting_patterns=[p["pattern_id"] for p in patterns if p["source_seed"] == seed.seed_id],
                    disciplines_involved=seed.disciplines,
                    confidence=0.8 + (i * 0.02),
                    snr_score=0.90 + (i * 0.01),
                    ihsan_alignment=0.95,
                )
                hypotheses.append(hypothesis)
            return hypotheses

        # Real hypothesis generation via GoT
        try:
            # Build thought nodes from seeds and patterns
            for seed in seeds[:self.max_hypotheses_per_cycle]:
                # Add seed as thought
                seed_node = self._got_orchestrator.add_thought(
                    content=f"Research seed: {seed.concept}",
                    lens=seed.disciplines[0] if seed.disciplines else "generic",
                    snr=seed.relevance_score
                )

                # Add related patterns as thoughts
                related_patterns = [p for p in patterns if p["source_seed"] == seed.seed_id]
                for pattern in related_patterns[:3]:
                    pattern_node = self._got_orchestrator.add_thought(
                        content=str(pattern.get("insights", [])),
                        lens="empirical",
                        snr=0.8
                    )
                    # Link to seed
                    self._got_orchestrator.link_thoughts(
                        seed_node.id,
                        pattern_node.id,
                        relation="supports"
                    )

            # Synthesize hypotheses
            cluster_snr = self._got_orchestrator.get_cluster_snr()
            summary = self._got_orchestrator.summarize()

            # Create hypothesis from synthesis
            hypothesis = DreamHypothesis(
                hypothesis_id=self._next_hypothesis_id(),
                statement=f"Synthesized insight from {len(seeds)} seeds across {summary.get('lenses', [])}",
                supporting_patterns=[p["pattern_id"] for p in patterns],
                disciplines_involved=list(summary.get("lenses", [])),
                confidence=cluster_snr,
                snr_score=cluster_snr,
                ihsan_alignment=0.95,
                got_cluster_id=summary.get("session_id"),
            )
            hypotheses.append(hypothesis)

        except Exception as e:
            logger.error(f"GoT hypothesis generation failed: {e}")

        return hypotheses

    def _validate_hypotheses(
        self,
        hypotheses: List[DreamHypothesis]
    ) -> List[DreamHypothesis]:
        """Validate hypotheses against SNR threshold."""
        validated = []

        for hypothesis in hypotheses:
            # SNR-gated validation
            if hypothesis.snr_score >= self.snr_threshold:
                validated.append(hypothesis)
                logger.debug(f"Hypothesis validated: {hypothesis.hypothesis_id} (SNR: {hypothesis.snr_score:.4f})")
            else:
                logger.debug(f"Hypothesis rejected: {hypothesis.hypothesis_id} (SNR: {hypothesis.snr_score:.4f})")

        return validated

    async def _crystallize(
        self,
        hypotheses: List[DreamHypothesis]
    ) -> List[DreamHypothesis]:
        """Crystallize validated hypotheses to L5 procedural memory."""
        crystallized = []

        for hypothesis in hypotheses:
            try:
                # Store in memory system if available
                if self._memory_system:
                    self._memory_system.add_procedural_skill(
                        skill_name=f"dream_insight_{hypothesis.hypothesis_id}",
                        skill_description=hypothesis.statement,
                        evidence=[f"SNR: {hypothesis.snr_score}", f"Disciplines: {hypothesis.disciplines_involved}"],
                    )

                crystallized.append(hypothesis)
                logger.info(f"Hypothesis crystallized: {hypothesis.hypothesis_id}")

            except Exception as e:
                logger.error(f"Crystallization failed for {hypothesis.hypothesis_id}: {e}")

        return crystallized

    def _calculate_dream_snr(
        self,
        crystallized: List[DreamHypothesis]
    ) -> float:
        """Calculate overall SNR for the dream cycle."""
        if not crystallized:
            return 0.0

        return sum(h.snr_score for h in crystallized) / len(crystallized)

    def get_dream_history(self, limit: int = 10) -> List[DreamHypothesis]:
        """Get recent crystallized hypotheses."""
        return self._crystallized[-limit:]

    @property
    def current_phase(self) -> DreamPhase:
        """Get current dream phase."""
        return self._current_phase

    @property
    def is_dreaming(self) -> bool:
        """Check if currently dreaming."""
        return self._current_phase != DreamPhase.IDLE

    def get_statistics(self) -> Dict[str, Any]:
        """Get dreamer statistics."""
        return {
            "total_dreams": self._dream_counter,
            "total_hypotheses": self._hypothesis_counter,
            "crystallized_count": len(self._crystallized),
            "current_phase": self._current_phase.value,
            "is_dreaming": self.is_dreaming,
            "snr_threshold": self.snr_threshold,
            "budget_threshold": self.budget_threshold,
        }


if __name__ == "__main__":
    import asyncio

    async def main():
        dreamer = AutonomousDreamer()

        print("\n" + "=" * 60)
        print("  BIZRA AUTONOMOUS DREAMER")
        print("=" * 60)

        stats = dreamer.get_statistics()
        print(f"\nSNR Threshold: {stats['snr_threshold']:.4f}")
        print(f"Budget Threshold: {stats['budget_threshold']:.4f}")

        # Test dream cycle (high budget)
        print("\n1. Testing dream cycle (high budget)...")
        result = await dreamer.dream_cycle(budget_score=0.85)
        print(f"   Dream ID: {result.dream_id}")
        print(f"   Seeds: {result.seeds_explored}")
        print(f"   Patterns: {result.patterns_mined}")
        print(f"   Hypotheses: {result.hypotheses_generated}")
        print(f"   Crystallized: {result.hypotheses_crystallized}")
        print(f"   SNR: {result.snr_achieved:.4f}")

        # Test dream cycle (low budget)
        print("\n2. Testing dream cycle (low budget)...")
        result = await dreamer.dream_cycle(budget_score=0.5)
        print(f"   Phase: {result.phase.value} (skipped)")

        # Get history
        print("\n3. Dream history:")
        history = dreamer.get_dream_history()
        for h in history:
            print(f"   - {h.hypothesis_id}: SNR {h.snr_score:.4f}")

        print("\n" + "=" * 60)

    asyncio.run(main())
