"""
BIZRA Sovereign Nexus - Neural Subsystem
========================================
Wraps HypergraphRAG and Multimodal perception for neural operations.

Provides:
- Hypergraph knowledge retrieval (709k nodes, 1.4M edges)
- Multimodal perception (text, code, structured data)
- Embedding generation and similarity search
- Neural pattern recognition
"""

import os
import logging
import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum

logger = logging.getLogger("nexus.neural")


class PerceptionMode(Enum):
    """Multimodal perception modes."""
    TEXT = "text"
    CODE = "code"
    STRUCTURED = "structured"
    HYBRID = "hybrid"


@dataclass
class HypergraphNode:
    """A node in the hypergraph knowledge store."""
    node_id: str
    content: str
    node_type: str
    embedding: Optional[List[float]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    edges: List[str] = field(default_factory=list)


@dataclass
class HypergraphEdge:
    """A hyperedge connecting multiple nodes."""
    edge_id: str
    node_ids: List[str]
    edge_type: str
    weight: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PerceptionResult:
    """Result of multimodal perception."""
    perception_id: str
    mode: PerceptionMode
    content_hash: str
    features: List[str]
    embedding: Optional[List[float]]
    confidence: float
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class NeuralSubsystem:
    """
    Neural Subsystem for the Sovereign Nexus.

    Integrates:
    - HypergraphRAG for knowledge retrieval
    - Multimodal perception for diverse inputs
    - Embedding generation for similarity search
    """

    def __init__(
        self,
        ihsan_threshold: float = 0.95,
        embedding_dim: int = 1536
    ):
        self.ihsan_threshold = ihsan_threshold
        self.embedding_dim = embedding_dim
        self._hypergraph_connector = None
        self._multimodal_perception = None
        self._node_cache: Dict[str, HypergraphNode] = {}
        self._edge_cache: Dict[str, HypergraphEdge] = {}
        self._perception_counter = 0

        # Initialize components
        self._initialize_components()

    def _initialize_components(self) -> None:
        """Initialize HypergraphRAG and Multimodal components."""
        # Try to import HypergraphRAG connector
        try:
            from constellation.memory.hypergraph_connector import HypergraphConnector
            self._hypergraph_connector = HypergraphConnector()
            logger.info("HypergraphRAG connector initialized")
        except ImportError:
            logger.warning("HypergraphRAG not available, using local mode")
        except Exception as e:
            logger.warning(f"HypergraphRAG init failed: {e}")

        # Try to import Multimodal perception
        try:
            from bizra_kernel.multimodal_perception import MultimodalPerception
            self._multimodal_perception = MultimodalPerception()
            logger.info("Multimodal perception initialized")
        except ImportError:
            logger.warning("Multimodal perception not available")
        except Exception as e:
            logger.warning(f"Multimodal perception init failed: {e}")

    def _next_perception_id(self) -> str:
        self._perception_counter += 1
        return f"perc-{self._perception_counter:08d}"

    def perceive(
        self,
        content: str,
        mode: PerceptionMode = PerceptionMode.HYBRID
    ) -> PerceptionResult:
        """
        Perceive content using multimodal perception.

        Extracts features and generates embeddings for downstream use.
        """
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]

        # Extract features based on mode
        features = self._extract_features(content, mode)

        # Generate embedding
        embedding = self._generate_embedding(content)

        # Calculate confidence
        confidence = self._calculate_perception_confidence(features, embedding)

        return PerceptionResult(
            perception_id=self._next_perception_id(),
            mode=mode,
            content_hash=content_hash,
            features=features,
            embedding=embedding,
            confidence=confidence,
        )

    def _extract_features(
        self,
        content: str,
        mode: PerceptionMode
    ) -> List[str]:
        """Extract features from content based on perception mode."""
        features = []

        if mode in (PerceptionMode.TEXT, PerceptionMode.HYBRID):
            # Text features
            words = content.split()
            features.extend([
                f"word_count:{len(words)}",
                f"char_count:{len(content)}",
            ])

            # Detect key concepts
            concept_keywords = ["system", "ethics", "algorithm", "data", "model"]
            for kw in concept_keywords:
                if kw.lower() in content.lower():
                    features.append(f"concept:{kw}")

        if mode in (PerceptionMode.CODE, PerceptionMode.HYBRID):
            # Code features
            if "def " in content or "class " in content:
                features.append("code:python")
            if "fn " in content or "impl " in content:
                features.append("code:rust")
            if "function " in content or "const " in content:
                features.append("code:javascript")

        if mode in (PerceptionMode.STRUCTURED, PerceptionMode.HYBRID):
            # Structured data features
            if "{" in content and "}" in content:
                features.append("structure:json_like")
            if "---" in content:
                features.append("structure:yaml_like")

        return features

    def _generate_embedding(
        self,
        content: str
    ) -> Optional[List[float]]:
        """Generate embedding for content."""
        if self._multimodal_perception:
            try:
                return self._multimodal_perception.generate_embedding(content)
            except Exception as e:
                logger.warning(f"Embedding generation failed: {e}")

        # Fallback: simple hash-based pseudo-embedding (for testing)
        import struct
        content_hash = hashlib.sha256(content.encode()).digest()
        # Convert hash to pseudo-embedding
        embedding = []
        for i in range(0, min(32, self.embedding_dim // 4), 4):
            val = struct.unpack('f', content_hash[i:i+4])[0]
            # Normalize to [-1, 1]
            embedding.append(max(-1.0, min(1.0, val / 1000)))

        # Pad to full dimension
        while len(embedding) < self.embedding_dim:
            embedding.append(0.0)

        return embedding[:self.embedding_dim]

    def _calculate_perception_confidence(
        self,
        features: List[str],
        embedding: Optional[List[float]]
    ) -> float:
        """Calculate confidence score for perception result."""
        confidence = 0.5

        # More features = higher confidence
        confidence += min(0.3, len(features) * 0.05)

        # Valid embedding = higher confidence
        if embedding and len(embedding) == self.embedding_dim:
            confidence += 0.2

        return min(1.0, confidence)

    def query_hypergraph(
        self,
        query: str,
        limit: int = 10,
        node_types: Optional[List[str]] = None
    ) -> List[HypergraphNode]:
        """
        Query the hypergraph knowledge store.

        Returns relevant nodes based on semantic similarity.
        """
        if self._hypergraph_connector:
            try:
                results = self._hypergraph_connector.query(
                    query=query,
                    limit=limit,
                    node_types=node_types
                )
                return [
                    HypergraphNode(
                        node_id=r.get("id", ""),
                        content=r.get("content", ""),
                        node_type=r.get("type", "unknown"),
                        metadata=r.get("metadata", {}),
                    )
                    for r in results
                ]
            except Exception as e:
                logger.warning(f"Hypergraph query failed: {e}")

        # Fallback: return cached nodes that match
        return [
            node for node in self._node_cache.values()
            if query.lower() in node.content.lower()
        ][:limit]

    def add_node(
        self,
        content: str,
        node_type: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> HypergraphNode:
        """Add a node to the hypergraph."""
        node_id = f"node-{hashlib.sha256(content.encode()).hexdigest()[:12]}"

        # Generate embedding
        embedding = self._generate_embedding(content)

        node = HypergraphNode(
            node_id=node_id,
            content=content,
            node_type=node_type,
            embedding=embedding,
            metadata=metadata or {},
        )

        if self._hypergraph_connector:
            try:
                self._hypergraph_connector.add_node(
                    node_id=node_id,
                    content=content,
                    node_type=node_type,
                    embedding=embedding,
                    metadata=metadata,
                )
            except Exception as e:
                logger.warning(f"Failed to add node to hypergraph: {e}")

        # Always cache locally
        self._node_cache[node_id] = node

        return node

    def add_edge(
        self,
        node_ids: List[str],
        edge_type: str,
        weight: float = 1.0,
        metadata: Optional[Dict[str, Any]] = None
    ) -> HypergraphEdge:
        """Add a hyperedge connecting multiple nodes."""
        edge_id = f"edge-{hashlib.sha256(''.join(node_ids).encode()).hexdigest()[:12]}"

        edge = HypergraphEdge(
            edge_id=edge_id,
            node_ids=node_ids,
            edge_type=edge_type,
            weight=weight,
            metadata=metadata or {},
        )

        if self._hypergraph_connector:
            try:
                self._hypergraph_connector.add_edge(
                    edge_id=edge_id,
                    node_ids=node_ids,
                    edge_type=edge_type,
                    weight=weight,
                    metadata=metadata,
                )
            except Exception as e:
                logger.warning(f"Failed to add edge to hypergraph: {e}")

        # Cache locally
        self._edge_cache[edge_id] = edge

        # Update node edges
        for node_id in node_ids:
            if node_id in self._node_cache:
                self._node_cache[node_id].edges.append(edge_id)

        return edge

    def find_similar(
        self,
        content: str,
        limit: int = 5,
        threshold: float = 0.7
    ) -> List[Tuple[HypergraphNode, float]]:
        """
        Find nodes similar to the given content.

        Uses embedding similarity for matching.
        """
        query_embedding = self._generate_embedding(content)
        if not query_embedding:
            return []

        similarities = []
        for node in self._node_cache.values():
            if node.embedding:
                similarity = self._cosine_similarity(query_embedding, node.embedding)
                if similarity >= threshold:
                    similarities.append((node, similarity))

        # Sort by similarity descending
        similarities.sort(key=lambda x: x[1], reverse=True)
        return similarities[:limit]

    def _cosine_similarity(
        self,
        vec1: List[float],
        vec2: List[float]
    ) -> float:
        """Calculate cosine similarity between two vectors."""
        import math

        if len(vec1) != len(vec2):
            return 0.0

        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = math.sqrt(sum(a * a for a in vec1))
        norm2 = math.sqrt(sum(b * b for b in vec2))

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return dot_product / (norm1 * norm2)

    def get_statistics(self) -> Dict[str, Any]:
        """Get neural subsystem statistics."""
        return {
            "hypergraph_available": self._hypergraph_connector is not None,
            "multimodal_available": self._multimodal_perception is not None,
            "cached_nodes": len(self._node_cache),
            "cached_edges": len(self._edge_cache),
            "embedding_dim": self.embedding_dim,
            "perception_count": self._perception_counter,
        }


if __name__ == "__main__":
    # Self-test
    subsystem = NeuralSubsystem()

    print("\n" + "=" * 60)
    print("  BIZRA NEURAL SUBSYSTEM")
    print("=" * 60)

    stats = subsystem.get_statistics()
    print(f"\nHypergraph Available: {stats['hypergraph_available']}")
    print(f"Multimodal Available: {stats['multimodal_available']}")

    # Test perception
    print("\n1. Testing perception...")
    result = subsystem.perceive(
        "def optimize_query(db): return db.execute('SELECT *')",
        mode=PerceptionMode.HYBRID
    )
    print(f"   Mode: {result.mode.value}")
    print(f"   Features: {result.features}")
    print(f"   Confidence: {result.confidence:.4f}")

    # Test node addition
    print("\n2. Adding nodes...")
    node1 = subsystem.add_node("BIZRA uses PAT-SAT architecture", "concept")
    node2 = subsystem.add_node("Ihsan threshold is 0.95", "rule")
    print(f"   Added: {node1.node_id}, {node2.node_id}")

    # Test edge addition
    print("\n3. Adding edge...")
    edge = subsystem.add_edge([node1.node_id, node2.node_id], "relates_to")
    print(f"   Added: {edge.edge_id}")

    # Test similarity
    print("\n4. Finding similar nodes...")
    similar = subsystem.find_similar("PAT-SAT system architecture")
    print(f"   Found: {len(similar)} similar nodes")

    print("\n" + "=" * 60)
