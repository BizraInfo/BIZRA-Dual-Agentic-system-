"""
BIZRA Sovereign Nexus - Symbolic Subsystem
==========================================
Wraps the 47-Discipline Topology and Synergy Detection for symbolic reasoning.

Provides:
- 47-discipline symbolic mapping
- Cross-discipline synergy detection
- Pattern generalization via Abstraction Elevator
- Symbolic reasoning chains
"""

import os
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("nexus.symbolic")


@dataclass
class SymbolicChain:
    """A chain of symbolic reasoning steps."""
    chain_id: str
    steps: List[Dict[str, Any]]
    disciplines_invoked: List[str]
    synthesis_result: str
    confidence: float
    ihsan_alignment: float
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class SynergyResult:
    """Result of cross-discipline synergy detection."""
    synergy_id: str
    disciplines: List[str]
    shared_concepts: List[str]
    emergent_insights: List[str]
    synergy_score: float
    synthesis_type: str  # "additive", "multiplicative", "transcendent"


class SymbolicSubsystem:
    """
    Symbolic Subsystem for the Sovereign Nexus.

    Integrates:
    - DisciplineTopologyEngine for 47-discipline mapping
    - SynergyDetector for cross-domain synthesis
    - AbstractionElevator for pattern generalization
    """

    def __init__(
        self,
        ihsan_threshold: float = 0.95
    ):
        self.ihsan_threshold = ihsan_threshold
        self._topology_engine = None
        self._synergy_detector = None
        self._abstraction_elevator = None
        self._chain_counter = 0
        self._synergy_counter = 0

        # Initialize components
        self._initialize_components()

    def _initialize_components(self) -> None:
        """Initialize Topology, Synergy, and Abstraction components."""
        # Import DisciplineTopologyEngine
        try:
            from ..topology_engine import DisciplineTopologyEngine
            self._topology_engine = DisciplineTopologyEngine(
                ihsan_threshold=self.ihsan_threshold
            )
            logger.info("DisciplineTopologyEngine initialized")
        except Exception as e:
            logger.warning(f"DisciplineTopologyEngine init failed: {e}")

        # Import SynergyDetector
        try:
            from bizra_kernel.kep.synergy_detector import SynergyDetector
            self._synergy_detector = SynergyDetector()
            logger.info("SynergyDetector initialized")
        except ImportError:
            logger.warning("SynergyDetector not available")
        except Exception as e:
            logger.warning(f"SynergyDetector init failed: {e}")

        # Import AbstractionElevator
        try:
            from bizra_kernel.abstraction_elevator import AbstractionElevator
            self._abstraction_elevator = AbstractionElevator()
            logger.info("AbstractionElevator initialized")
        except Exception as e:
            logger.warning(f"AbstractionElevator init failed: {e}")

    def _next_chain_id(self) -> str:
        self._chain_counter += 1
        return f"chain-{self._chain_counter:08d}"

    def _next_synergy_id(self) -> str:
        self._synergy_counter += 1
        return f"synergy-{self._synergy_counter:08d}"

    def reason_symbolic(
        self,
        query: str,
        disciplines: Optional[List[str]] = None,
        max_steps: int = 5
    ) -> SymbolicChain:
        """
        Perform symbolic reasoning across disciplines.

        Builds a reasoning chain that traverses the discipline topology.
        """
        steps = []
        disciplines_invoked = disciplines or []

        # If no disciplines specified, auto-detect from query
        if not disciplines_invoked and self._topology_engine:
            disciplines_invoked = self._detect_relevant_disciplines(query)

        # Build reasoning chain
        for i, discipline in enumerate(disciplines_invoked[:max_steps]):
            step = self._create_reasoning_step(
                step_number=i + 1,
                discipline=discipline,
                query=query,
                previous_steps=steps
            )
            steps.append(step)

            # Activate discipline in topology
            if self._topology_engine:
                self._topology_engine.activate_discipline(discipline)

        # Synthesize result
        synthesis = self._synthesize_chain(steps)

        # Calculate confidence and alignment
        confidence = self._calculate_chain_confidence(steps)
        ihsan_alignment = self._calculate_ihsan_alignment(steps)

        return SymbolicChain(
            chain_id=self._next_chain_id(),
            steps=steps,
            disciplines_invoked=disciplines_invoked,
            synthesis_result=synthesis,
            confidence=confidence,
            ihsan_alignment=ihsan_alignment,
        )

    def _detect_relevant_disciplines(self, query: str) -> List[str]:
        """Auto-detect relevant disciplines from query."""
        if not self._topology_engine:
            return []

        query_lower = query.lower()
        relevant = []

        # Map keywords to disciplines
        keyword_map = {
            "ethics": "ethics",
            "moral": "ethics",
            "fair": "ethics",
            "economic": "economics",
            "market": "economics",
            "price": "economics",
            "logic": "formal_logic",
            "proof": "formal_logic",
            "algorithm": "computer_science",
            "code": "computer_science",
            "encrypt": "cryptography",
            "secure": "cryptography",
            "complex": "complexity_science",
            "system": "systems_theory",
            "psychology": "psychology",
            "behavior": "psychology",
            "future": "futures_studies",
            "ihsan": "ihsan_studies",
            "excellence": "ihsan_studies",
        }

        for keyword, discipline in keyword_map.items():
            if keyword in query_lower and discipline not in relevant:
                relevant.append(discipline)

        # Default to at least ethics and ihsan_studies
        if not relevant:
            relevant = ["ethics", "ihsan_studies"]

        return relevant[:5]  # Limit to 5 disciplines

    def _create_reasoning_step(
        self,
        step_number: int,
        discipline: str,
        query: str,
        previous_steps: List[Dict]
    ) -> Dict[str, Any]:
        """Create a single reasoning step."""
        step = {
            "step_number": step_number,
            "discipline": discipline,
            "query_aspect": query[:100],
            "reasoning": f"Applying {discipline} lens to analyze the problem.",
            "insights": [],
        }

        # Get discipline info from topology
        if self._topology_engine:
            disc = self._topology_engine.get_discipline(discipline)
            if disc:
                step["layer"] = disc.layer.value
                step["key_concepts"] = disc.key_concepts
                step["insights"] = [
                    f"From {discipline}: Consider {concept} implications"
                    for concept in disc.key_concepts[:2]
                ]

        # Build on previous steps
        if previous_steps:
            prev = previous_steps[-1]
            step["builds_on"] = prev["discipline"]

        return step

    def _synthesize_chain(self, steps: List[Dict]) -> str:
        """Synthesize reasoning chain into a coherent result."""
        if not steps:
            return "No reasoning steps to synthesize."

        disciplines = [s["discipline"] for s in steps]
        insights = []
        for s in steps:
            insights.extend(s.get("insights", []))

        synthesis = (
            f"Synthesis across {len(disciplines)} disciplines "
            f"({', '.join(disciplines)}): "
        )

        if insights:
            synthesis += f"Key insights: {'; '.join(insights[:3])}"
        else:
            synthesis += "Cross-disciplinary analysis complete."

        return synthesis

    def _calculate_chain_confidence(self, steps: List[Dict]) -> float:
        """Calculate confidence score for reasoning chain."""
        if not steps:
            return 0.0

        base_confidence = 0.7

        # More steps = more thorough
        step_bonus = min(0.2, len(steps) * 0.04)

        # Having insights increases confidence
        insight_count = sum(len(s.get("insights", [])) for s in steps)
        insight_bonus = min(0.1, insight_count * 0.02)

        return min(1.0, base_confidence + step_bonus + insight_bonus)

    def _calculate_ihsan_alignment(self, steps: List[Dict]) -> float:
        """Calculate Ihsan alignment for reasoning chain."""
        if not steps:
            return 0.0

        # Base alignment
        alignment = 0.9

        # Check if ethics or ihsan_studies involved
        disciplines = [s["discipline"] for s in steps]
        if "ethics" in disciplines:
            alignment += 0.03
        if "ihsan_studies" in disciplines:
            alignment += 0.05

        return min(1.0, alignment)

    def detect_synergies(
        self,
        disciplines: List[str]
    ) -> List[SynergyResult]:
        """
        Detect synergies between disciplines.

        Identifies shared concepts and emergent insights.
        """
        synergies = []

        if len(disciplines) < 2:
            return synergies

        # Use SynergyDetector if available
        if self._synergy_detector:
            try:
                results = self._synergy_detector.detect(disciplines)
                for r in results:
                    synergies.append(SynergyResult(
                        synergy_id=self._next_synergy_id(),
                        disciplines=r.get("disciplines", disciplines),
                        shared_concepts=r.get("shared_concepts", []),
                        emergent_insights=r.get("emergent_insights", []),
                        synergy_score=r.get("score", 0.8),
                        synthesis_type=r.get("type", "additive"),
                    ))
                return synergies
            except Exception as e:
                logger.warning(f"SynergyDetector failed: {e}")

        # Fallback: Use topology engine for bridge-based synergy
        if self._topology_engine:
            for i, d1 in enumerate(disciplines):
                for d2 in disciplines[i+1:]:
                    path = self._topology_engine.find_synthesis_path(d1, d2)
                    if path:
                        synergies.append(SynergyResult(
                            synergy_id=self._next_synergy_id(),
                            disciplines=[d1, d2],
                            shared_concepts=path,
                            emergent_insights=[
                                f"Bridge path: {' -> '.join(path)}"
                            ],
                            synergy_score=0.8,
                            synthesis_type="additive",
                        ))

        return synergies

    def elevate_pattern(
        self,
        pattern_description: str,
        source_disciplines: List[str],
        evidence: List[str]
    ) -> Optional[Dict[str, Any]]:
        """
        Elevate a recurring pattern to a principle via Abstraction Elevator.

        Requires Ihsan-compliant evidence (>= 0.95).
        """
        if not self._abstraction_elevator:
            logger.warning("AbstractionElevator not available")
            return None

        try:
            from bizra_kernel.abstraction_elevator import DomainType

            # Map disciplines to domains
            domain_map = {
                "ethics": DomainType.ETHICAL,
                "ihsan_studies": DomainType.ETHICAL,
                "economics": DomainType.ECONOMIC,
                "computer_science": DomainType.TECHNICAL,
                "cryptography": DomainType.TECHNICAL,
            }

            primary_domain = DomainType.TECHNICAL
            for disc in source_disciplines:
                if disc in domain_map:
                    primary_domain = domain_map[disc]
                    break

            # Record instance
            instance = self._abstraction_elevator.record_instance(
                domain=primary_domain,
                description=pattern_description,
                key_features=evidence[:5],
                outcome="Elevated to principle",
            )

            # Try auto-elevation
            new_principles = self._abstraction_elevator.auto_elevate()

            if new_principles:
                return {
                    "elevated": True,
                    "instance_id": instance.instance_id,
                    "new_principles": [p.to_dict() for p in new_principles],
                }

            return {
                "elevated": False,
                "instance_id": instance.instance_id,
                "reason": "Insufficient evidence for elevation",
            }

        except Exception as e:
            logger.error(f"Pattern elevation failed: {e}")
            return None

    def get_discipline_info(
        self,
        discipline_name: str
    ) -> Optional[Dict[str, Any]]:
        """Get information about a discipline."""
        if not self._topology_engine:
            return None

        discipline = self._topology_engine.get_discipline(discipline_name)
        if discipline:
            return discipline.to_dict()
        return None

    def get_all_disciplines(self) -> List[Dict[str, Any]]:
        """Get all disciplines in the topology."""
        if not self._topology_engine:
            return []

        return [
            d.to_dict() for d in self._topology_engine.disciplines.values()
        ]

    def get_statistics(self) -> Dict[str, Any]:
        """Get symbolic subsystem statistics."""
        stats = {
            "topology_available": self._topology_engine is not None,
            "synergy_detector_available": self._synergy_detector is not None,
            "abstraction_elevator_available": self._abstraction_elevator is not None,
            "chain_count": self._chain_counter,
            "synergy_count": self._synergy_counter,
        }

        if self._topology_engine:
            topo_stats = self._topology_engine.get_statistics()
            stats["total_disciplines"] = topo_stats["total_disciplines"]
            stats["total_bridges"] = topo_stats["total_bridges"]

        return stats


if __name__ == "__main__":
    # Self-test
    subsystem = SymbolicSubsystem()

    print("\n" + "=" * 60)
    print("  BIZRA SYMBOLIC SUBSYSTEM")
    print("=" * 60)

    stats = subsystem.get_statistics()
    print(f"\nTopology Available: {stats['topology_available']}")
    print(f"Total Disciplines: {stats.get('total_disciplines', 'N/A')}")

    # Test symbolic reasoning
    print("\n1. Testing symbolic reasoning...")
    chain = subsystem.reason_symbolic(
        query="How should we handle ethical AI deployment in economic systems?",
        disciplines=["ethics", "economics", "computer_science"]
    )
    print(f"   Chain ID: {chain.chain_id}")
    print(f"   Steps: {len(chain.steps)}")
    print(f"   Confidence: {chain.confidence:.4f}")
    print(f"   Ihsan Alignment: {chain.ihsan_alignment:.4f}")

    # Test synergy detection
    print("\n2. Testing synergy detection...")
    synergies = subsystem.detect_synergies(["ethics", "economics", "ihsan_studies"])
    print(f"   Synergies found: {len(synergies)}")
    for syn in synergies[:2]:
        print(f"   - {syn.disciplines}: {syn.synergy_score:.2f}")

    # Test pattern elevation
    print("\n3. Testing pattern elevation...")
    result = subsystem.elevate_pattern(
        pattern_description="Ethical AI requires economic incentive alignment",
        source_disciplines=["ethics", "economics", "computer_science"],
        evidence=["Verified in production systems", "Consistent with Ihsan principles"]
    )
    if result:
        print(f"   Elevated: {result['elevated']}")

    print("\n" + "=" * 60)
