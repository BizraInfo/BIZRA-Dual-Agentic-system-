"""
BIZRA Sovereign Nexus - Optimization Subsystem
==============================================
Wraps SNRTracker with self-healing loop for continuous optimization.

Provides:
- SNR (Signal-to-Noise Ratio) tracking
- Self-healing optimization loop
- Automatic SAPE elevation triggers
- Performance metrics and alerts
"""

import os
import logging
import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional
from enum import Enum

logger = logging.getLogger("nexus.optimization")


class HealingAction(Enum):
    """Types of self-healing actions."""
    REDUCE_TOKENS = "reduce_tokens"
    ELEVATE_PATTERN = "elevate_pattern"
    ADJUST_MODEL = "adjust_model"
    RESET_CONTEXT = "reset_context"
    ALERT_OPERATOR = "alert_operator"


@dataclass
class SNRSnapshot:
    """Snapshot of SNR metrics."""
    current_snr: float
    target_snr: float
    meets_target: bool
    token_efficiency: float
    confidence: float
    ethical_compliance: float
    tool_directness: float
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class HealingEvent:
    """A self-healing event."""
    event_id: str
    action: HealingAction
    trigger: str
    before_snr: float
    after_snr: float
    success: bool
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class OptimizationSubsystem:
    """
    Optimization Subsystem for the Sovereign Nexus.

    Integrates:
    - SNRTracker for token efficiency metrics
    - Self-healing loop for automatic optimization
    - SAPE elevation triggers for pattern optimization
    """

    def __init__(
        self,
        target_snr: float = 0.95,
        ihsan_threshold: float = 0.95,
        healing_interval: float = 10.0  # seconds
    ):
        self.target_snr = target_snr
        self.ihsan_threshold = ihsan_threshold
        self.healing_interval = healing_interval
        self._snr_tracker = None
        self._healing_events: List[HealingEvent] = []
        self._healing_counter = 0
        self._healing_loop_running = False
        self._healing_callbacks: List[Callable] = []

        # Initialize components
        self._initialize_components()

    def _initialize_components(self) -> None:
        """Initialize SNRTracker."""
        try:
            from bizra_kernel.snr_tracker import SNRTracker, SNRMetrics
            self._snr_tracker = SNRTracker()
            logger.info("SNRTracker initialized")
        except ImportError:
            logger.warning("SNRTracker not available, using internal tracking")
            self._internal_metrics: List[Dict] = []
        except Exception as e:
            logger.warning(f"SNRTracker init failed: {e}")
            self._internal_metrics: List[Dict] = []

    def _next_healing_id(self) -> str:
        self._healing_counter += 1
        return f"heal-{self._healing_counter:08d}"

    def record_metrics(
        self,
        total_tokens: int,
        useful_tokens: int,
        confidence_score: float,
        ethical_compliance: float,
        tool_directness: float,
        latency_ms: int,
        agent_role: str,
        safety_compliance: float = 1.0
    ) -> SNRSnapshot:
        """
        Record SNR metrics for an interaction.

        Returns snapshot with current metrics and target comparison.
        """
        if self._snr_tracker:
            try:
                from bizra_kernel.snr_tracker import SNRMetrics

                metrics = SNRMetrics(
                    total_tokens=total_tokens,
                    useful_tokens=useful_tokens,
                    confidence_score=confidence_score,
                    ethical_compliance=ethical_compliance,
                    tool_directness=tool_directness,
                    latency_ms=latency_ms,
                    agent_role=agent_role,
                    safety_compliance=safety_compliance,
                )
                self._snr_tracker.record(metrics)
                current_snr = metrics.snr_score
            except Exception as e:
                logger.warning(f"SNRTracker record failed: {e}")
                current_snr = self._calculate_snr(
                    total_tokens, useful_tokens, confidence_score,
                    ethical_compliance, tool_directness, safety_compliance
                )
        else:
            current_snr = self._calculate_snr(
                total_tokens, useful_tokens, confidence_score,
                ethical_compliance, tool_directness, safety_compliance
            )

            # Store internally
            self._internal_metrics.append({
                "total_tokens": total_tokens,
                "useful_tokens": useful_tokens,
                "confidence_score": confidence_score,
                "ethical_compliance": ethical_compliance,
                "tool_directness": tool_directness,
                "snr_score": current_snr,
                "agent_role": agent_role,
                "timestamp": datetime.utcnow().isoformat(),
            })

        token_efficiency = useful_tokens / max(1, total_tokens)

        snapshot = SNRSnapshot(
            current_snr=current_snr,
            target_snr=self.target_snr,
            meets_target=current_snr >= self.target_snr,
            token_efficiency=token_efficiency,
            confidence=confidence_score,
            ethical_compliance=ethical_compliance,
            tool_directness=tool_directness,
        )

        # Check if healing needed
        if not snapshot.meets_target:
            self._trigger_self_healing(snapshot)

        return snapshot

    def _calculate_snr(
        self,
        total_tokens: int,
        useful_tokens: int,
        confidence: float,
        ethical: float,
        directness: float,
        safety: float
    ) -> float:
        """Calculate SNR score."""
        if total_tokens == 0:
            return 0.0

        token_efficiency = useful_tokens / total_tokens
        return (
            token_efficiency
            * confidence
            * ethical
            * directness
            * safety
        )

    def _trigger_self_healing(self, snapshot: SNRSnapshot) -> None:
        """Trigger self-healing when SNR drops below target."""
        logger.info(f"Self-healing triggered: SNR {snapshot.current_snr:.4f} < {self.target_snr:.4f}")

        # Determine healing action based on deficit
        action = self._select_healing_action(snapshot)

        before_snr = snapshot.current_snr

        # Execute healing
        success = self._execute_healing(action, snapshot)

        # Record event
        event = HealingEvent(
            event_id=self._next_healing_id(),
            action=action,
            trigger=f"SNR below target: {snapshot.current_snr:.4f}",
            before_snr=before_snr,
            after_snr=self.get_current_snr(),
            success=success,
        )
        self._healing_events.append(event)

        # Notify callbacks
        for callback in self._healing_callbacks:
            try:
                callback(event)
            except Exception as e:
                logger.error(f"Healing callback failed: {e}")

    def _select_healing_action(self, snapshot: SNRSnapshot) -> HealingAction:
        """Select appropriate healing action based on metrics."""
        # Low token efficiency -> reduce tokens
        if snapshot.token_efficiency < 0.7:
            return HealingAction.REDUCE_TOKENS

        # Low confidence -> adjust model
        if snapshot.confidence < 0.8:
            return HealingAction.ADJUST_MODEL

        # Low ethical compliance -> alert operator
        if snapshot.ethical_compliance < self.ihsan_threshold:
            return HealingAction.ALERT_OPERATOR

        # Default: elevate pattern for future optimization
        return HealingAction.ELEVATE_PATTERN

    def _execute_healing(
        self,
        action: HealingAction,
        snapshot: SNRSnapshot
    ) -> bool:
        """Execute a healing action."""
        logger.info(f"Executing healing action: {action.value}")

        if action == HealingAction.REDUCE_TOKENS:
            # Signal token reduction to model hub
            return self._signal_token_reduction()

        elif action == HealingAction.ELEVATE_PATTERN:
            # Trigger SAPE elevation
            return self._trigger_sape_elevation()

        elif action == HealingAction.ADJUST_MODEL:
            # Signal model adjustment
            return self._signal_model_adjustment()

        elif action == HealingAction.RESET_CONTEXT:
            # Signal context reset
            return self._signal_context_reset()

        elif action == HealingAction.ALERT_OPERATOR:
            # Log alert
            logger.warning(f"ALERT: SNR below Ihsan threshold! {snapshot.current_snr:.4f}")
            return True

        return False

    def _signal_token_reduction(self) -> bool:
        """Signal token reduction to model routing."""
        # In production, this would communicate with SovereignModelHub
        logger.info("Token reduction signal sent")
        return True

    def _trigger_sape_elevation(self) -> bool:
        """Trigger SAPE pattern elevation."""
        # In production, this would communicate with SAPEEngine
        logger.info("SAPE elevation triggered")
        return True

    def _signal_model_adjustment(self) -> bool:
        """Signal model adjustment."""
        logger.info("Model adjustment signal sent")
        return True

    def _signal_context_reset(self) -> bool:
        """Signal context reset."""
        logger.info("Context reset signal sent")
        return True

    def get_current_snr(self) -> float:
        """Get current SNR score."""
        if self._snr_tracker:
            return self._snr_tracker.get_current_snr()

        if hasattr(self, '_internal_metrics') and self._internal_metrics:
            return self._internal_metrics[-1]["snr_score"]

        return 0.0

    def get_average_snr(self, window: int = 100) -> float:
        """Get average SNR over recent window."""
        if self._snr_tracker:
            return self._snr_tracker.get_average_snr(window)

        if hasattr(self, '_internal_metrics') and self._internal_metrics:
            recent = self._internal_metrics[-window:]
            return sum(m["snr_score"] for m in recent) / len(recent)

        return 0.0

    def get_agent_rankings(self) -> List[Dict[str, Any]]:
        """Get agents ranked by SNR performance."""
        if self._snr_tracker:
            return self._snr_tracker.get_agent_rankings()

        # Internal tracking
        if hasattr(self, '_internal_metrics'):
            by_agent = {}
            for m in self._internal_metrics:
                role = m["agent_role"]
                if role not in by_agent:
                    by_agent[role] = []
                by_agent[role].append(m["snr_score"])

            rankings = []
            for agent, scores in by_agent.items():
                avg_snr = sum(scores) / len(scores)
                rankings.append({
                    "agent": agent,
                    "avg_snr": avg_snr,
                    "sample_count": len(scores),
                    "meets_target": avg_snr >= self.target_snr,
                })

            return sorted(rankings, key=lambda x: x["avg_snr"], reverse=True)

        return []

    def detect_elevation_candidates(self) -> List[Dict[str, Any]]:
        """Detect patterns that should be elevated via SAPE."""
        if self._snr_tracker:
            return self._snr_tracker.detect_patterns()

        # Simple detection from internal metrics
        candidates = []
        rankings = self.get_agent_rankings()

        for ranking in rankings:
            if not ranking["meets_target"] and ranking["sample_count"] > 5:
                candidates.append({
                    "agent": ranking["agent"],
                    "avg_snr": ranking["avg_snr"],
                    "recommendation": f"Agent {ranking['agent']} needs optimization",
                })

        return candidates

    def register_healing_callback(
        self,
        callback: Callable[[HealingEvent], None]
    ) -> None:
        """Register callback for healing events."""
        self._healing_callbacks.append(callback)

    async def start_healing_loop(self) -> None:
        """Start the self-healing optimization loop."""
        if self._healing_loop_running:
            return

        self._healing_loop_running = True
        logger.info("Self-healing loop started")

        while self._healing_loop_running:
            try:
                current_snr = self.get_average_snr(window=10)

                if current_snr < self.target_snr:
                    snapshot = SNRSnapshot(
                        current_snr=current_snr,
                        target_snr=self.target_snr,
                        meets_target=False,
                        token_efficiency=0.8,  # Estimated
                        confidence=0.9,
                        ethical_compliance=0.95,
                        tool_directness=0.9,
                    )
                    self._trigger_self_healing(snapshot)

                await asyncio.sleep(self.healing_interval)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Healing loop error: {e}")
                await asyncio.sleep(self.healing_interval)

        logger.info("Self-healing loop stopped")

    def stop_healing_loop(self) -> None:
        """Stop the self-healing loop."""
        self._healing_loop_running = False

    def get_healing_history(self, limit: int = 50) -> List[HealingEvent]:
        """Get recent healing events."""
        return self._healing_events[-limit:]

    def get_statistics(self) -> Dict[str, Any]:
        """Get optimization subsystem statistics."""
        stats = {
            "snr_tracker_available": self._snr_tracker is not None,
            "target_snr": self.target_snr,
            "current_snr": self.get_current_snr(),
            "average_snr": self.get_average_snr(),
            "meets_target": self.get_average_snr() >= self.target_snr,
            "healing_events": len(self._healing_events),
            "healing_loop_running": self._healing_loop_running,
            "elevation_candidates": len(self.detect_elevation_candidates()),
        }

        # Add agent rankings
        rankings = self.get_agent_rankings()
        if rankings:
            stats["top_agent"] = rankings[0] if rankings else None
            stats["agents_meeting_target"] = sum(1 for r in rankings if r["meets_target"])

        return stats


if __name__ == "__main__":
    # Self-test
    subsystem = OptimizationSubsystem()

    print("\n" + "=" * 60)
    print("  BIZRA OPTIMIZATION SUBSYSTEM")
    print("=" * 60)

    stats = subsystem.get_statistics()
    print(f"\nSNRTracker Available: {stats['snr_tracker_available']}")
    print(f"Target SNR: {stats['target_snr']:.4f}")

    # Test metrics recording
    print("\n1. Recording metrics...")
    for i in range(5):
        snapshot = subsystem.record_metrics(
            total_tokens=1000 + i * 100,
            useful_tokens=800 + i * 50,
            confidence_score=0.95,
            ethical_compliance=0.97,
            tool_directness=0.90,
            latency_ms=50 + i * 10,
            agent_role="MasterReasoner",
        )
        print(f"   [{i+1}] SNR: {snapshot.current_snr:.4f} | Target: {snapshot.meets_target}")

    # Test healing history
    print("\n2. Healing events:")
    events = subsystem.get_healing_history(limit=5)
    for event in events:
        print(f"   - {event.action.value}: {event.before_snr:.4f} -> {event.after_snr:.4f}")

    # Test agent rankings
    print("\n3. Agent rankings:")
    rankings = subsystem.get_agent_rankings()
    for r in rankings[:3]:
        status = "PASS" if r["meets_target"] else "FAIL"
        print(f"   {r['agent']}: {r['avg_snr']:.4f} [{status}]")

    # Test elevation candidates
    print("\n4. Elevation candidates:")
    candidates = subsystem.detect_elevation_candidates()
    for c in candidates:
        print(f"   - {c['agent']}: {c['recommendation']}")

    print("\n" + "=" * 60)
