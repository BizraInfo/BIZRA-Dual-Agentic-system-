"""
BIZRA Sovereign Nexus - Agentic Subsystem
=========================================
Wraps core.agent_factory for PAT/SAT orchestration with warm pools.

Provides:
- PAT (Personal Agentic Team) spawning and management
- SAT (System Agentic Team) validation
- Warm pool management for fast agent acquisition
- Agent lifecycle coordination
"""

import os
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
from enum import Enum

logger = logging.getLogger("nexus.agentic")


class AgentTeam(Enum):
    """Agent team types."""
    PAT = "PAT"
    SAT = "SAT"


class AgentStatus(Enum):
    """Agent status."""
    READY = "ready"
    BUSY = "busy"
    SUSPENDED = "suspended"
    ERROR = "error"


@dataclass
class AgentInfo:
    """Information about an agent."""
    agent_id: str
    agent_name: str
    team: AgentTeam
    status: AgentStatus
    model: str
    capabilities: List[str] = field(default_factory=list)
    session_id: Optional[str] = None
    spawned_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    metrics: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskResult:
    """Result from agent task execution."""
    task_id: str
    agent_id: str
    success: bool
    result: str
    latency_ms: float
    snr_score: float
    ihsan_score: float
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class AgenticSubsystem:
    """
    Agentic Subsystem for the Sovereign Nexus.

    Integrates:
    - AgentFactory for PAT/SAT spawning
    - Warm pools for fast agent acquisition
    - Task coordination and lifecycle management
    """

    # PAT Agent roles
    PAT_AGENTS = [
        "MasterReasoner",
        "MemoryArchitect",
        "CreativeSynthesizer",
        "DataAnalyzer",
        "Communicator",
        "ExecutionPlanner",
        "EthicsGuardian",
    ]

    # SAT Agent roles
    SAT_AGENTS = [
        "PoiVerifier",
        "ResourceAllocator",
        "RiskGuardian",
        "GovernanceEngine",
        "EvidenceEngine",
    ]

    def __init__(
        self,
        ihsan_threshold: float = 0.95,
        enable_warm_pools: bool = True,
        lazy_init: bool = True  # Defer factory init until first use
    ):
        self.ihsan_threshold = ihsan_threshold
        self.enable_warm_pools = enable_warm_pools
        self._lazy_init = lazy_init
        self._agent_factory = None
        self._factory_initialized = False
        self._active_agents: Dict[str, AgentInfo] = {}
        self._task_counter = 0

        # Only initialize eagerly if not lazy
        if not lazy_init:
            self._initialize_components()

    def _ensure_initialized(self) -> None:
        """Ensure components are initialized (lazy init support)."""
        if not self._factory_initialized:
            self._initialize_components()
            self._factory_initialized = True

    def _initialize_components(self) -> None:
        """Initialize AgentFactory."""
        try:
            from core.agent_factory import AgentFactory
            self._agent_factory = AgentFactory()
            logger.info("AgentFactory initialized")

            # Check warm pools
            if self.enable_warm_pools:
                try:
                    pool_status = self._agent_factory.get_warm_pool_status()
                    logger.info(f"Warm pools active: {pool_status}")
                except AttributeError:
                    logger.info("Warm pools not available in AgentFactory")

        except ImportError:
            logger.warning("core.agent_factory not available, using simulation")
        except Exception as e:
            logger.warning(f"AgentFactory init failed: {e}")

    def _next_task_id(self) -> str:
        self._task_counter += 1
        return f"task-{self._task_counter:08d}"

    def spawn_pat_agent(
        self,
        role: str,
        session_id: Optional[str] = None
    ) -> Optional[AgentInfo]:
        """
        Spawn a PAT (Personal Agentic Team) agent.

        Uses warm pools if available for fast acquisition.
        """
        self._ensure_initialized()

        if role not in self.PAT_AGENTS:
            logger.warning(f"Unknown PAT role: {role}")
            return None

        if self._agent_factory:
            try:
                agent = self._agent_factory.spawn_pat(role, session_id)
                agent_info = AgentInfo(
                    agent_id=agent.agent_id,
                    agent_name=role,
                    team=AgentTeam.PAT,
                    status=AgentStatus.READY,
                    model=agent.model,
                    capabilities=agent.capabilities,
                    session_id=session_id,
                )
                self._active_agents[agent_info.agent_id] = agent_info
                return agent_info
            except Exception as e:
                logger.error(f"PAT spawn failed: {e}")

        # Simulation mode
        import hashlib
        agent_id = f"pat-{hashlib.sha256(f'{role}{datetime.utcnow().isoformat()}'.encode()).hexdigest()[:8]}"

        agent_info = AgentInfo(
            agent_id=agent_id,
            agent_name=role,
            team=AgentTeam.PAT,
            status=AgentStatus.READY,
            model="simulated",
            capabilities=self._get_role_capabilities(role),
            session_id=session_id,
        )
        self._active_agents[agent_id] = agent_info
        logger.info(f"PAT agent spawned (simulation): {role}")
        return agent_info

    def spawn_sat_agent(
        self,
        role: str
    ) -> Optional[AgentInfo]:
        """
        Spawn a SAT (System Agentic Team) agent.

        SAT agents are rule-based with minimal resources.
        """
        self._ensure_initialized()

        if role not in self.SAT_AGENTS:
            logger.warning(f"Unknown SAT role: {role}")
            return None

        if self._agent_factory:
            try:
                agent = self._agent_factory.spawn_sat(role)
                agent_info = AgentInfo(
                    agent_id=agent.agent_id,
                    agent_name=role,
                    team=AgentTeam.SAT,
                    status=AgentStatus.READY,
                    model="rule_based",
                    capabilities=agent.capabilities,
                )
                self._active_agents[agent_info.agent_id] = agent_info
                return agent_info
            except Exception as e:
                logger.error(f"SAT spawn failed: {e}")

        # Simulation mode
        import hashlib
        agent_id = f"sat-{hashlib.sha256(f'{role}{datetime.utcnow().isoformat()}'.encode()).hexdigest()[:8]}"

        agent_info = AgentInfo(
            agent_id=agent_id,
            agent_name=role,
            team=AgentTeam.SAT,
            status=AgentStatus.READY,
            model="rule_based",
            capabilities=self._get_role_capabilities(role),
        )
        self._active_agents[agent_id] = agent_info
        logger.info(f"SAT agent spawned (simulation): {role}")
        return agent_info

    def _get_role_capabilities(self, role: str) -> List[str]:
        """Get capabilities for an agent role."""
        capabilities_map = {
            # PAT
            "MasterReasoner": ["strategic_thinking", "planning", "synthesis"],
            "MemoryArchitect": ["knowledge_organization", "retrieval", "indexing"],
            "CreativeSynthesizer": ["writing", "ideation", "generation"],
            "DataAnalyzer": ["pattern_recognition", "analysis", "statistics"],
            "Communicator": ["external_comms", "formatting", "presentation"],
            "ExecutionPlanner": ["task_planning", "scheduling", "resource_allocation"],
            "EthicsGuardian": ["safety", "bias_detection", "ethical_review"],
            # SAT
            "PoiVerifier": ["impact_verification", "attestation"],
            "ResourceAllocator": ["compute_optimization", "memory_management"],
            "RiskGuardian": ["security_monitoring", "threat_detection"],
            "GovernanceEngine": ["policy_enforcement", "compliance"],
            "EvidenceEngine": ["audit_trail", "receipt_generation"],
        }
        return capabilities_map.get(role, [])

    def execute_task(
        self,
        agent_id: str,
        task: str,
        context: Optional[Dict[str, Any]] = None
    ) -> TaskResult:
        """
        Execute a task using an agent.

        Validates Ihsan compliance and tracks metrics.
        """
        agent = self._active_agents.get(agent_id)
        if not agent:
            return TaskResult(
                task_id=self._next_task_id(),
                agent_id=agent_id,
                success=False,
                result="Agent not found",
                latency_ms=0,
                snr_score=0,
                ihsan_score=0,
            )

        # Mark agent as busy
        agent.status = AgentStatus.BUSY
        start = datetime.utcnow()

        try:
            if self._agent_factory:
                # Real execution
                result = self._agent_factory.execute(agent_id, task, context)
                latency = (datetime.utcnow() - start).total_seconds() * 1000

                return TaskResult(
                    task_id=self._next_task_id(),
                    agent_id=agent_id,
                    success=result.get("success", False),
                    result=result.get("output", ""),
                    latency_ms=latency,
                    snr_score=result.get("snr_score", 0.95),
                    ihsan_score=result.get("ihsan_score", 0.95),
                )

            # Simulation mode
            latency = 50.0  # Simulated latency
            snr_score = 0.95
            ihsan_score = 0.96

            return TaskResult(
                task_id=self._next_task_id(),
                agent_id=agent_id,
                success=True,
                result=f"[Simulated] Task executed by {agent.agent_name}: {task[:50]}...",
                latency_ms=latency,
                snr_score=snr_score,
                ihsan_score=ihsan_score,
            )

        finally:
            # Mark agent as ready
            agent.status = AgentStatus.READY

    def run_sat_consensus(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None,
        required_approvals: int = 3
    ) -> Dict[str, Any]:
        """
        Run SAT consensus validation.

        Requires 3/5 SAT agent approvals for consensus.
        """
        votes = []

        for role in self.SAT_AGENTS:
            agent = self.spawn_sat_agent(role)
            if agent:
                # Simulate validation
                approved = self._simulate_sat_validation(role, task, context)
                votes.append({
                    "agent": role,
                    "agent_id": agent.agent_id,
                    "approved": approved,
                    "reason": "Validation passed" if approved else "Validation failed",
                })

        approvals = sum(1 for v in votes if v["approved"])
        consensus_reached = approvals >= required_approvals

        return {
            "consensus_reached": consensus_reached,
            "approvals": approvals,
            "required": required_approvals,
            "votes": votes,
            "timestamp": datetime.utcnow().isoformat(),
        }

    def _simulate_sat_validation(
        self,
        role: str,
        task: str,
        context: Optional[Dict[str, Any]]
    ) -> bool:
        """Simulate SAT agent validation."""
        # Deterministic simulation based on role
        task_lower = task.lower()

        if role == "RiskGuardian":
            # Check for risky keywords
            risk_keywords = ["hack", "exploit", "delete", "destroy"]
            if any(kw in task_lower for kw in risk_keywords):
                return False

        if role == "GovernanceEngine":
            # Check for policy keywords
            policy_keywords = ["unauthorized", "bypass", "override"]
            if any(kw in task_lower for kw in policy_keywords):
                return False

        # Default: approve
        return True

    def terminate_agent(self, agent_id: str) -> bool:
        """Terminate an agent."""
        if agent_id in self._active_agents:
            if self._agent_factory:
                try:
                    self._agent_factory.terminate(agent_id)
                except Exception as e:
                    logger.error(f"Agent termination failed: {e}")

            del self._active_agents[agent_id]
            logger.info(f"Agent terminated: {agent_id}")
            return True
        return False

    def get_active_agents(
        self,
        team: Optional[AgentTeam] = None
    ) -> List[AgentInfo]:
        """Get list of active agents."""
        agents = list(self._active_agents.values())
        if team:
            agents = [a for a in agents if a.team == team]
        return agents

    def get_warm_pool_stats(self) -> Dict[str, Any]:
        """Get warm pool statistics."""
        if self._agent_factory:
            try:
                return self._agent_factory.get_warm_pool_status()
            except AttributeError:
                pass

        return {
            "enabled": self.enable_warm_pools,
            "simulation_mode": True,
        }

    def get_statistics(self) -> Dict[str, Any]:
        """Get agentic subsystem statistics."""
        active_pat = len([a for a in self._active_agents.values() if a.team == AgentTeam.PAT])
        active_sat = len([a for a in self._active_agents.values() if a.team == AgentTeam.SAT])

        return {
            "agent_factory_available": self._agent_factory is not None,
            "warm_pools_enabled": self.enable_warm_pools,
            "active_agents": len(self._active_agents),
            "active_pat": active_pat,
            "active_sat": active_sat,
            "task_count": self._task_counter,
            "warm_pool_stats": self.get_warm_pool_stats(),
        }


if __name__ == "__main__":
    # Self-test
    subsystem = AgenticSubsystem()

    print("\n" + "=" * 60)
    print("  BIZRA AGENTIC SUBSYSTEM")
    print("=" * 60)

    stats = subsystem.get_statistics()
    print(f"\nAgentFactory Available: {stats['agent_factory_available']}")
    print(f"Warm Pools Enabled: {stats['warm_pools_enabled']}")

    # Test PAT spawning
    print("\n1. Spawning PAT agents...")
    for role in ["MasterReasoner", "EthicsGuardian"]:
        agent = subsystem.spawn_pat_agent(role)
        if agent:
            print(f"   Spawned: {agent.agent_name} ({agent.agent_id})")

    # Test SAT spawning
    print("\n2. Spawning SAT agents...")
    for role in ["RiskGuardian", "EvidenceEngine"]:
        agent = subsystem.spawn_sat_agent(role)
        if agent:
            print(f"   Spawned: {agent.agent_name} ({agent.agent_id})")

    # Test task execution
    print("\n3. Testing task execution...")
    agents = subsystem.get_active_agents(AgentTeam.PAT)
    if agents:
        result = subsystem.execute_task(
            agents[0].agent_id,
            "Analyze the ethical implications of AI deployment"
        )
        print(f"   Task: {result.task_id}")
        print(f"   Success: {result.success}")
        print(f"   SNR: {result.snr_score:.4f}")

    # Test SAT consensus
    print("\n4. Testing SAT consensus...")
    consensus = subsystem.run_sat_consensus("Deploy new AI model")
    print(f"   Consensus: {consensus['consensus_reached']}")
    print(f"   Approvals: {consensus['approvals']}/{consensus['required']}")

    print("\n" + "=" * 60)
