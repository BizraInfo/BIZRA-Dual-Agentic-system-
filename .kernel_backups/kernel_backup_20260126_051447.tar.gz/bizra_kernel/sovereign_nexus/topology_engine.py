"""
BIZRA Sovereign Nexus - Discipline Topology Engine
===================================================
Implements the 47-Discipline Topology mapping across 7 layers,
enabling cross-domain synthesis and interdisciplinary reasoning.

Architecture:
    L1 Foundation    → Formal foundations (logic, set theory, etc.)
    L2 Physicality   → Natural sciences (thermodynamics, neuroscience, etc.)
    L3 Societal      → Social sciences (economics, psychology, etc.)
    L4 Creative      → Creative domains (architecture, music, etc.)
    L5 Transcendent  → Philosophical domains (ethics, metaphysics, etc.)
    L6 Applied       → Engineering domains (CS, cryptography, etc.)
    L7 Synthesis     → Meta-domains (complexity, futures studies, etc.)

Cross-Layer Bridges:
    - Vertical bridges: L1↔L2↔L3↔L4↔L5↔L6↔L7
    - Diagonal bridges: Cross-layer synergies (e.g., ethics↔economics)
    - Emergent bridges: Discovered via pattern detection
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple, Any
from datetime import datetime
import hashlib


class DisciplineLayer(Enum):
    """Seven layers of the 47-Discipline Topology."""
    L1_FOUNDATION = 1
    L2_PHYSICALITY = 2
    L3_SOCIETAL = 3
    L4_CREATIVE = 4
    L5_TRANSCENDENT = 5
    L6_APPLIED = 6
    L7_SYNTHESIS = 7

    @property
    def name_readable(self) -> str:
        names = {
            1: "Foundation",
            2: "Physicality",
            3: "Societal",
            4: "Creative",
            5: "Transcendent",
            6: "Applied",
            7: "Synthesis"
        }
        return names.get(self.value, "Unknown")


@dataclass
class Discipline:
    """Represents a single discipline in the topology."""
    id: str
    name: str
    layer: DisciplineLayer
    description: str
    key_concepts: List[str] = field(default_factory=list)
    related_disciplines: List[str] = field(default_factory=list)
    ihsan_alignment: float = 1.0
    activation_count: int = 0

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "layer": self.layer.value,
            "layer_name": self.layer.name_readable,
            "description": self.description,
            "key_concepts": self.key_concepts,
            "related_disciplines": self.related_disciplines,
            "ihsan_alignment": self.ihsan_alignment,
            "activation_count": self.activation_count,
        }


@dataclass
class CrossLayerBridge:
    """A bridge connecting two disciplines across layers."""
    bridge_id: str
    source_discipline: str
    target_discipline: str
    source_layer: DisciplineLayer
    target_layer: DisciplineLayer
    bridge_type: str  # "vertical", "diagonal", "emergent"
    strength: float  # 0.0 to 1.0
    synergy_concepts: List[str] = field(default_factory=list)
    discovered_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> dict:
        return {
            "bridge_id": self.bridge_id,
            "source": self.source_discipline,
            "target": self.target_discipline,
            "layers": f"L{self.source_layer.value}↔L{self.target_layer.value}",
            "type": self.bridge_type,
            "strength": self.strength,
            "synergy_concepts": self.synergy_concepts,
        }


class DisciplineTopologyEngine:
    """
    The 47-Discipline Topology Engine.

    Features:
    - 7-layer discipline mapping
    - Cross-layer bridge detection
    - Discipline activation tracking
    - Synergy pattern recognition
    """

    # 47 Disciplines organized by layer
    TOPOLOGY: Dict[DisciplineLayer, List[str]] = {
        DisciplineLayer.L1_FOUNDATION: [
            "formal_logic",
            "number_theory",
            "set_theory",
            "graph_theory",
            "information_theory",
            "cybernetics",
            "systems_theory",
        ],
        DisciplineLayer.L2_PHYSICALITY: [
            "thermodynamics",
            "quantum_mechanics",
            "neuroscience",
            "evolutionary_biology",
            "ecological_science",
            "materials_science",
        ],
        DisciplineLayer.L3_SOCIETAL: [
            "economics",
            "game_theory",
            "sociology",
            "anthropology",
            "political_science",
            "law",
            "linguistics",
            "psychology",
        ],
        DisciplineLayer.L4_CREATIVE: [
            "architecture",
            "design_thinking",
            "music_theory",
            "narratology",
            "visual_arts",
            "poetics",
        ],
        DisciplineLayer.L5_TRANSCENDENT: [
            "ethics",
            "theology",
            "epistemology",
            "metaphysics",
            "aesthetics",
            "phenomenology",
        ],
        DisciplineLayer.L6_APPLIED: [
            "computer_science",
            "cryptography",
            "data_science",
            "network_engineering",
            "robotics",
            "energy_engineering",
        ],
        DisciplineLayer.L7_SYNTHESIS: [
            "chaos_theory",
            "complexity_science",
            "semiotics",
            "decision_theory",
            "pedagogy",
            "history",
            "futures_studies",
            "ihsan_studies",
        ],
    }

    # Built-in cross-layer bridges
    PREDEFINED_BRIDGES: List[Tuple[str, str, str]] = [
        # Ethics bridges
        ("ethics", "economics", "moral_economics"),
        ("ethics", "computer_science", "ai_ethics"),
        ("ethics", "law", "legal_ethics"),
        # Logic bridges
        ("formal_logic", "computer_science", "formal_verification"),
        ("formal_logic", "linguistics", "formal_semantics"),
        # Systems bridges
        ("systems_theory", "complexity_science", "complex_systems"),
        ("systems_theory", "ecology_science", "ecosystem_dynamics"),
        # Information bridges
        ("information_theory", "cryptography", "secure_communication"),
        ("information_theory", "neuroscience", "neural_coding"),
        # Game theory bridges
        ("game_theory", "economics", "mechanism_design"),
        ("game_theory", "political_science", "voting_theory"),
        # Ihsan bridges
        ("ihsan_studies", "ethics", "excellence_ethics"),
        ("ihsan_studies", "computer_science", "ethical_ai"),
    ]

    def __init__(self, ihsan_threshold: float = 0.95):
        self.ihsan_threshold = ihsan_threshold
        self.disciplines: Dict[str, Discipline] = {}
        self.bridges: Dict[str, CrossLayerBridge] = {}
        self._bridge_counter = 0

        # Initialize topology
        self._initialize_disciplines()
        self._initialize_predefined_bridges()

    def _initialize_disciplines(self) -> None:
        """Initialize all 47 disciplines from the topology."""
        for layer, discipline_names in self.TOPOLOGY.items():
            for name in discipline_names:
                discipline_id = f"{layer.name}-{name}"
                self.disciplines[name] = Discipline(
                    id=discipline_id,
                    name=name.replace("_", " ").title(),
                    layer=layer,
                    description=self._generate_description(name, layer),
                    key_concepts=self._generate_key_concepts(name),
                    related_disciplines=[],
                    ihsan_alignment=1.0,
                )

    def _generate_description(self, name: str, layer: DisciplineLayer) -> str:
        """Generate a description for a discipline."""
        layer_context = {
            DisciplineLayer.L1_FOUNDATION: "foundational framework for",
            DisciplineLayer.L2_PHYSICALITY: "natural science understanding of",
            DisciplineLayer.L3_SOCIETAL: "social science approach to",
            DisciplineLayer.L4_CREATIVE: "creative exploration of",
            DisciplineLayer.L5_TRANSCENDENT: "philosophical inquiry into",
            DisciplineLayer.L6_APPLIED: "practical application of",
            DisciplineLayer.L7_SYNTHESIS: "meta-level synthesis of",
        }
        return f"The {layer_context[layer]} {name.replace('_', ' ')}"

    def _generate_key_concepts(self, name: str) -> List[str]:
        """Generate key concepts for a discipline."""
        concept_map = {
            "formal_logic": ["inference", "validity", "soundness", "proof"],
            "ethics": ["virtue", "duty", "consequence", "excellence"],
            "computer_science": ["algorithm", "computation", "abstraction", "complexity"],
            "ihsan_studies": ["excellence", "beauty", "perfection", "witness"],
            "economics": ["incentives", "markets", "efficiency", "allocation"],
            "game_theory": ["strategy", "equilibrium", "payoff", "cooperation"],
            "cryptography": ["encryption", "authentication", "integrity", "zero_knowledge"],
            "complexity_science": ["emergence", "self_organization", "adaptation", "nonlinearity"],
        }
        return concept_map.get(name, [name.replace("_", " ")])

    def _initialize_predefined_bridges(self) -> None:
        """Initialize predefined cross-layer bridges."""
        for source, target, synergy in self.PREDEFINED_BRIDGES:
            if source in self.disciplines and target in self.disciplines:
                self._create_bridge(source, target, synergy)

    def _next_bridge_id(self) -> str:
        self._bridge_counter += 1
        return f"BRIDGE-{self._bridge_counter:05d}"

    def _create_bridge(
        self,
        source_name: str,
        target_name: str,
        synergy_concept: str,
        bridge_type: str = "predefined"
    ) -> Optional[CrossLayerBridge]:
        """Create a cross-layer bridge between disciplines."""
        source = self.disciplines.get(source_name)
        target = self.disciplines.get(target_name)

        if not source or not target:
            return None

        # Determine bridge type based on layer difference
        layer_diff = abs(source.layer.value - target.layer.value)
        if layer_diff == 0:
            actual_type = "horizontal"
        elif layer_diff == 1:
            actual_type = "vertical"
        else:
            actual_type = "diagonal"

        if bridge_type == "emergent":
            actual_type = "emergent"

        bridge = CrossLayerBridge(
            bridge_id=self._next_bridge_id(),
            source_discipline=source_name,
            target_discipline=target_name,
            source_layer=source.layer,
            target_layer=target.layer,
            bridge_type=actual_type,
            strength=1.0,
            synergy_concepts=[synergy_concept],
        )

        self.bridges[bridge.bridge_id] = bridge

        # Update related disciplines
        if target_name not in source.related_disciplines:
            source.related_disciplines.append(target_name)
        if source_name not in target.related_disciplines:
            target.related_disciplines.append(source_name)

        return bridge

    def activate_discipline(self, name: str) -> Optional[Discipline]:
        """Activate a discipline (record usage)."""
        discipline = self.disciplines.get(name)
        if discipline:
            discipline.activation_count += 1
        return discipline

    def get_discipline(self, name: str) -> Optional[Discipline]:
        """Get a discipline by name."""
        return self.disciplines.get(name)

    def get_layer_disciplines(self, layer: DisciplineLayer) -> List[Discipline]:
        """Get all disciplines in a layer."""
        return [d for d in self.disciplines.values() if d.layer == layer]

    def get_bridges_for_discipline(self, name: str) -> List[CrossLayerBridge]:
        """Get all bridges involving a discipline."""
        return [
            b for b in self.bridges.values()
            if b.source_discipline == name or b.target_discipline == name
        ]

    def detect_emergent_bridges(
        self,
        concept_a: str,
        concept_b: str,
        shared_concepts: List[str]
    ) -> Optional[CrossLayerBridge]:
        """
        Detect emergent bridges based on shared concepts.

        Called when two disciplines share concepts but lack an explicit bridge.
        """
        # Find disciplines containing these concepts
        source_discipline = None
        target_discipline = None

        for name, discipline in self.disciplines.items():
            if concept_a in discipline.key_concepts and not source_discipline:
                source_discipline = name
            elif concept_b in discipline.key_concepts and not target_discipline:
                target_discipline = name

        if source_discipline and target_discipline and source_discipline != target_discipline:
            # Check if bridge already exists
            existing = [
                b for b in self.bridges.values()
                if (b.source_discipline == source_discipline and b.target_discipline == target_discipline) or
                   (b.source_discipline == target_discipline and b.target_discipline == source_discipline)
            ]
            if not existing:
                synergy = "_".join(shared_concepts[:2])
                return self._create_bridge(
                    source_discipline,
                    target_discipline,
                    synergy,
                    bridge_type="emergent"
                )
        return None

    def find_synthesis_path(
        self,
        source_name: str,
        target_name: str,
        max_hops: int = 4
    ) -> Optional[List[str]]:
        """
        Find a synthesis path between two disciplines.

        Uses BFS to find the shortest path through bridges.
        """
        if source_name not in self.disciplines or target_name not in self.disciplines:
            return None

        if source_name == target_name:
            return [source_name]

        # BFS
        from collections import deque
        visited = {source_name}
        queue = deque([(source_name, [source_name])])

        while queue:
            current, path = queue.popleft()

            if len(path) > max_hops:
                continue

            current_disc = self.disciplines.get(current)
            if not current_disc:
                continue

            for neighbor in current_disc.related_disciplines:
                if neighbor == target_name:
                    return path + [neighbor]

                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))

        return None

    def compute_synergy_score(
        self,
        discipline_names: List[str]
    ) -> float:
        """
        Compute synergy score for a combination of disciplines.

        Higher score indicates better cross-disciplinary synthesis potential.
        """
        if len(discipline_names) < 2:
            return 0.0

        disciplines = [self.disciplines.get(n) for n in discipline_names]
        disciplines = [d for d in disciplines if d is not None]

        if len(disciplines) < 2:
            return 0.0

        # Layer diversity bonus
        layers = set(d.layer for d in disciplines)
        layer_diversity = len(layers) / 7.0

        # Bridge connectivity bonus
        bridge_count = 0
        for i, d1 in enumerate(disciplines):
            for d2 in disciplines[i+1:]:
                if d2.id.split("-")[-1] in d1.related_disciplines:
                    bridge_count += 1

        max_bridges = len(disciplines) * (len(disciplines) - 1) / 2
        connectivity = bridge_count / max(1, max_bridges)

        # Ihsan alignment
        ihsan_avg = sum(d.ihsan_alignment for d in disciplines) / len(disciplines)

        # Composite score
        synergy = (
            layer_diversity * 0.3 +
            connectivity * 0.3 +
            ihsan_avg * 0.4
        )

        return min(1.0, synergy)

    def map_to_abstraction_domain(
        self,
        discipline_name: str
    ) -> Optional[str]:
        """
        Map a discipline to AbstractionElevator DomainType.

        Provides integration with the existing abstraction system.
        """
        mapping = {
            # Technical
            "computer_science": "technical",
            "cryptography": "technical",
            "data_science": "technical",
            "network_engineering": "technical",
            "robotics": "technical",
            "energy_engineering": "technical",
            "information_theory": "technical",
            # Ethical
            "ethics": "ethical",
            "ihsan_studies": "ethical",
            "theology": "ethical",
            # Economic
            "economics": "economic",
            "game_theory": "economic",
            # Social
            "sociology": "social",
            "anthropology": "social",
            "political_science": "social",
            "law": "social",
            "linguistics": "social",
            "psychology": "social",
            # Temporal
            "history": "temporal",
            "futures_studies": "temporal",
            # Causal
            "formal_logic": "causal",
            "systems_theory": "causal",
            "complexity_science": "causal",
            "chaos_theory": "causal",
        }
        return mapping.get(discipline_name)

    def get_statistics(self) -> Dict[str, Any]:
        """Get topology statistics."""
        layer_counts = {}
        for layer in DisciplineLayer:
            layer_counts[layer.name_readable] = len(self.get_layer_disciplines(layer))

        most_active = sorted(
            self.disciplines.values(),
            key=lambda d: d.activation_count,
            reverse=True
        )[:5]

        return {
            "total_disciplines": len(self.disciplines),
            "total_bridges": len(self.bridges),
            "by_layer": layer_counts,
            "bridge_types": {
                "vertical": len([b for b in self.bridges.values() if b.bridge_type == "vertical"]),
                "diagonal": len([b for b in self.bridges.values() if b.bridge_type == "diagonal"]),
                "emergent": len([b for b in self.bridges.values() if b.bridge_type == "emergent"]),
            },
            "most_active": [
                {"name": d.name, "layer": d.layer.name_readable, "count": d.activation_count}
                for d in most_active
            ],
        }

    def to_dict(self) -> Dict[str, Any]:
        """Export topology as dictionary."""
        return {
            "disciplines": {k: v.to_dict() for k, v in self.disciplines.items()},
            "bridges": {k: v.to_dict() for k, v in self.bridges.items()},
            "statistics": self.get_statistics(),
        }


if __name__ == "__main__":
    # Self-test
    engine = DisciplineTopologyEngine()

    print("\n" + "=" * 60)
    print("  BIZRA 47-DISCIPLINE TOPOLOGY ENGINE")
    print("=" * 60)

    stats = engine.get_statistics()
    print(f"\nTotal Disciplines: {stats['total_disciplines']}")
    print(f"Total Bridges: {stats['total_bridges']}")

    print("\nDisciplines by Layer:")
    for layer, count in stats["by_layer"].items():
        print(f"  {layer}: {count}")

    print("\nBridge Types:")
    for btype, count in stats["bridge_types"].items():
        print(f"  {btype}: {count}")

    # Test synergy
    print("\nSynergy Score Test:")
    combo = ["ethics", "economics", "computer_science", "ihsan_studies"]
    score = engine.compute_synergy_score(combo)
    print(f"  {combo}: {score:.4f}")

    # Test path finding
    print("\nSynthesis Path (ethics -> cryptography):")
    path = engine.find_synthesis_path("ethics", "cryptography")
    if path:
        print(f"  {' -> '.join(path)}")
    else:
        print("  No path found")

    print("\n" + "=" * 60)
