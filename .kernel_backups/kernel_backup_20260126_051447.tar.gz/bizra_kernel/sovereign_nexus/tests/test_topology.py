"""
Tests for DisciplineTopologyEngine
==================================
Validates the 47-discipline topology mapping and cross-layer bridges.
"""

import pytest
from ..topology_engine import (
    DisciplineTopologyEngine,
    DisciplineLayer,
    Discipline,
    CrossLayerBridge,
)


class TestDisciplineTopologyEngine:
    """Test suite for DisciplineTopologyEngine."""

    @pytest.fixture
    def engine(self):
        """Create a fresh topology engine for each test."""
        return DisciplineTopologyEngine(ihsan_threshold=0.95)

    def test_initialization(self, engine):
        """Test that engine initializes with 47 disciplines."""
        assert len(engine.disciplines) == 47
        assert len(engine.bridges) > 0  # Should have predefined bridges

    def test_layer_counts(self, engine):
        """Test that each layer has the expected discipline count."""
        expected_counts = {
            DisciplineLayer.L1_FOUNDATION: 7,
            DisciplineLayer.L2_PHYSICALITY: 6,
            DisciplineLayer.L3_SOCIETAL: 8,
            DisciplineLayer.L4_CREATIVE: 6,
            DisciplineLayer.L5_TRANSCENDENT: 6,
            DisciplineLayer.L6_APPLIED: 6,
            DisciplineLayer.L7_SYNTHESIS: 8,
        }

        for layer, expected in expected_counts.items():
            disciplines = engine.get_layer_disciplines(layer)
            assert len(disciplines) == expected, f"Layer {layer.name} should have {expected} disciplines"

    def test_get_discipline(self, engine):
        """Test discipline retrieval."""
        ethics = engine.get_discipline("ethics")
        assert ethics is not None
        assert ethics.name == "Ethics"
        assert ethics.layer == DisciplineLayer.L5_TRANSCENDENT

        ihsan = engine.get_discipline("ihsan_studies")
        assert ihsan is not None
        assert ihsan.layer == DisciplineLayer.L7_SYNTHESIS

    def test_activate_discipline(self, engine):
        """Test discipline activation tracking."""
        initial_count = engine.get_discipline("ethics").activation_count
        engine.activate_discipline("ethics")
        assert engine.get_discipline("ethics").activation_count == initial_count + 1

    def test_bridge_creation(self, engine):
        """Test cross-layer bridge creation."""
        # Check predefined bridges exist
        ethics_bridges = engine.get_bridges_for_discipline("ethics")
        assert len(ethics_bridges) > 0

        # Test bridge types
        bridge_types = set(b.bridge_type for b in ethics_bridges)
        assert len(bridge_types) > 0

    def test_synergy_score(self, engine):
        """Test synergy score calculation."""
        # Single discipline
        single_score = engine.compute_synergy_score(["ethics"])
        assert single_score == 0.0

        # Multiple disciplines from same layer
        same_layer = engine.compute_synergy_score(["ethics", "theology"])
        assert same_layer > 0.0

        # Cross-layer disciplines
        cross_layer = engine.compute_synergy_score([
            "ethics",
            "economics",
            "computer_science",
            "ihsan_studies"
        ])
        assert cross_layer > same_layer  # Cross-layer should have higher synergy

    def test_synthesis_path(self, engine):
        """Test synthesis path finding."""
        # Direct path via existing bridge
        path = engine.find_synthesis_path("ethics", "economics")
        assert path is not None
        assert path[0] == "ethics"
        assert path[-1] == "economics"

        # Longer path
        path = engine.find_synthesis_path("formal_logic", "ethics")
        # Should find a path through intermediates
        if path:
            assert path[0] == "formal_logic"
            assert path[-1] == "ethics"

    def test_emergent_bridge_detection(self, engine):
        """Test emergent bridge detection."""
        # Should be able to detect bridges from shared concepts
        bridge = engine.detect_emergent_bridges(
            "verification",
            "safety",
            ["correctness", "proof"]
        )
        # May or may not create bridge depending on existing disciplines
        # Just verify it doesn't crash

    def test_abstraction_domain_mapping(self, engine):
        """Test mapping to AbstractionElevator domains."""
        assert engine.map_to_abstraction_domain("ethics") == "ethical"
        assert engine.map_to_abstraction_domain("economics") == "economic"
        assert engine.map_to_abstraction_domain("computer_science") == "technical"
        assert engine.map_to_abstraction_domain("unknown_discipline") is None

    def test_statistics(self, engine):
        """Test statistics generation."""
        stats = engine.get_statistics()

        assert stats["total_disciplines"] == 47
        assert stats["total_bridges"] > 0
        assert "by_layer" in stats
        assert "bridge_types" in stats
        assert "most_active" in stats

    def test_ihsan_threshold(self, engine):
        """Test Ihsan threshold is respected."""
        assert engine.ihsan_threshold == 0.95

        # All disciplines should have Ihsan alignment
        for disc in engine.disciplines.values():
            assert disc.ihsan_alignment >= 0.0
            assert disc.ihsan_alignment <= 1.0


class TestDisciplineLayer:
    """Test DisciplineLayer enum."""

    def test_layer_values(self):
        """Test layer value ordering."""
        assert DisciplineLayer.L1_FOUNDATION.value == 1
        assert DisciplineLayer.L7_SYNTHESIS.value == 7

    def test_layer_names(self):
        """Test layer readable names."""
        assert DisciplineLayer.L1_FOUNDATION.name_readable == "Foundation"
        assert DisciplineLayer.L5_TRANSCENDENT.name_readable == "Transcendent"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
