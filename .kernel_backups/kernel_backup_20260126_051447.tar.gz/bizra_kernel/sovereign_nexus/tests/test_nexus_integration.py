"""
Integration Tests for SovereignNexus
====================================
End-to-end tests validating the unified control interface.
"""

import pytest
import asyncio
from ..nexus import SovereignNexus, NexusState, TaskExecution


class TestSovereignNexusIntegration:
    """Integration test suite for SovereignNexus."""

    @pytest.fixture
    def nexus(self):
        """Create a fresh Nexus for each test."""
        return SovereignNexus(
            heartbeat_hz=147.0,
            ihsan_threshold=0.95,
            snr_target=0.95,
            enable_dreaming=True
        )

    def test_nexus_initialization(self, nexus):
        """Test Nexus initializes correctly."""
        assert nexus.nexus_id is not None
        assert nexus.heartbeat_hz == 147.0
        assert nexus.ihsan_threshold == 0.95
        assert nexus.snr_target == 0.95
        assert nexus.enable_dreaming is True

    def test_subsystems_initialized(self, nexus):
        """Test all subsystems are initialized."""
        assert nexus.neural is not None
        assert nexus.symbolic is not None
        assert nexus.agentic is not None
        assert nexus.optimization is not None

    def test_adapters_initialized(self, nexus):
        """Test all adapters are initialized."""
        assert nexus.rust_bridge is not None
        assert nexus.synapse is not None
        assert nexus.data_lake is not None

    def test_core_components_initialized(self, nexus):
        """Test core components are initialized."""
        assert nexus.topology is not None
        assert nexus.dreamer is not None

    def test_nexus_state(self, nexus):
        """Test Nexus state retrieval."""
        state = nexus.get_state()

        assert isinstance(state, NexusState)
        assert state.nexus_id == nexus.nexus_id
        assert state.heartbeat_count >= 0
        assert state.uptime_seconds >= 0
        assert isinstance(state.active_disciplines, list)

    def test_nexus_state_to_dict(self, nexus):
        """Test NexusState to_dict conversion."""
        state = nexus.get_state()
        state_dict = state.to_dict()

        assert "nexus_id" in state_dict
        assert "heartbeat_count" in state_dict
        assert "current_snr" in state_dict
        assert "ihsan_score" in state_dict
        assert "dream_active" in state_dict

    @pytest.mark.asyncio
    async def test_task_execution_success(self, nexus):
        """Test successful task execution."""
        result = await nexus.execute(
            task="Analyze the ethical implications of AI",
            require_sat_consensus=True
        )

        assert isinstance(result, TaskExecution)
        assert result.task_id.startswith("task-")
        assert result.success is True
        assert result.snr_score > 0
        assert result.ihsan_score > 0
        assert len(result.disciplines_invoked) > 0

    @pytest.mark.asyncio
    async def test_task_execution_with_disciplines(self, nexus):
        """Test task execution invokes relevant disciplines."""
        result = await nexus.execute(
            task="Calculate optimal economic strategy for sustainability",
            require_sat_consensus=True
        )

        # Should detect economics and sustainability-related disciplines
        disciplines_lower = [d.lower() for d in result.disciplines_invoked]
        # At least some disciplines should be invoked
        assert len(result.disciplines_invoked) > 0

    @pytest.mark.asyncio
    async def test_task_execution_without_sat_consensus(self, nexus):
        """Test task execution without SAT consensus requirement."""
        result = await nexus.execute(
            task="Simple analysis task",
            require_sat_consensus=False
        )

        assert result.success is True
        # No SAT agents should be in the agents_used when consensus not required
        sat_agents = ["PoiVerifier", "ResourceAllocator", "RiskGuardian", "GovernanceEngine", "EvidenceEngine"]
        # May or may not have SAT agents depending on implementation

    def test_snr_stats(self, nexus):
        """Test SNR statistics retrieval."""
        stats = nexus.get_snr_stats()

        assert "target_snr" in stats
        assert "current_snr" in stats
        assert "meets_target" in stats

    def test_topology_stats(self, nexus):
        """Test topology statistics retrieval."""
        stats = nexus.get_topology_stats()

        assert stats["total_disciplines"] == 47
        assert stats["total_bridges"] > 0
        assert "by_layer" in stats

    def test_dreamer_stats(self, nexus):
        """Test dreamer statistics retrieval."""
        stats = nexus.get_dreamer_stats()

        assert "total_dreams" in stats
        assert "snr_threshold" in stats
        assert stats["snr_threshold"] == 0.95

    def test_full_statistics(self, nexus):
        """Test comprehensive statistics retrieval."""
        stats = nexus.get_full_statistics()

        assert "nexus" in stats
        assert "snr" in stats
        assert "topology" in stats
        assert "dreamer" in stats
        assert "neural" in stats
        assert "symbolic" in stats
        assert "agentic" in stats
        assert "synapse" in stats
        assert "data_lake" in stats
        assert "rust_bridge" in stats

    def test_nexus_stop(self, nexus):
        """Test Nexus stop."""
        nexus.stop()
        assert nexus._running is False


class TestSovereignNexusHeartbeat:
    """Tests for the 147Hz heartbeat loop."""

    @pytest.fixture
    def nexus(self):
        return SovereignNexus(
            heartbeat_hz=1000.0,  # High frequency for faster testing
            enable_dreaming=False  # Disable dreaming for faster tests
        )

    @pytest.mark.asyncio
    async def test_heartbeat_runs(self, nexus):
        """Test heartbeat loop runs."""
        # Start heartbeat in background
        task = asyncio.create_task(nexus.run_heartbeat_loop())

        # Let it run for a short time
        await asyncio.sleep(0.1)

        # Stop it
        nexus.stop()

        # Cancel and wait
        try:
            task.cancel()
            await task
        except asyncio.CancelledError:
            pass

        # Should have run some heartbeats
        assert nexus._heartbeat_count > 0


class TestSovereignNexusSAPE:
    """Tests for SAPE integration."""

    @pytest.fixture
    def nexus(self):
        return SovereignNexus()

    @pytest.mark.asyncio
    async def test_sape_validation_pass(self, nexus):
        """Test SAPE validation passes for benign task."""
        result = await nexus.execute(
            task="Summarize the key principles of ethical AI development",
            require_sat_consensus=False
        )

        assert result.success is True

    @pytest.mark.asyncio
    async def test_sape_validation_fail(self, nexus):
        """Test SAPE validation fails for potentially harmful task."""
        result = await nexus.execute(
            task="Hack into the system and exploit vulnerabilities to steal data",
            require_sat_consensus=False
        )

        # SAPE should detect threat keywords and fail
        # Implementation may vary - check result indicates validation ran
        assert result.task_id is not None


class TestLegacyCompatibility:
    """Tests for backward compatibility with SovereignKernel."""

    def test_legacy_kernel_import(self):
        """Test legacy SovereignKernel can be imported from nexus."""
        from ..nexus import SovereignKernel

        kernel = SovereignKernel()
        assert kernel.nexus is not None

    def test_legacy_execute_sovereign_task(self):
        """Test legacy execute_sovereign_task API."""
        from ..nexus import SovereignKernel

        kernel = SovereignKernel()
        result = kernel.execute_sovereign_task(
            "Test task",
            {"truthfulness": 1.0, "dignity": 1.0, "fairness": 1.0, "sustainability": 1.0}
        )

        assert "status" in result
        assert "snr" in result


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
