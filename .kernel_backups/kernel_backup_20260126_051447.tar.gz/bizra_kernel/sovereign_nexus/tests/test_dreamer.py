"""
Tests for AutonomousDreamer
===========================
Validates the autonomous dreaming capability and SNR-gated crystallization.
"""

import pytest
import asyncio
from ..dreamer import (
    AutonomousDreamer,
    DreamResult,
    DreamPhase,
    DreamSeed,
    DreamHypothesis,
)


class TestAutonomousDreamer:
    """Test suite for AutonomousDreamer."""

    @pytest.fixture
    def dreamer(self):
        """Create a fresh dreamer for each test."""
        return AutonomousDreamer(
            snr_threshold=0.95,
            budget_threshold=0.75,
            max_hypotheses_per_cycle=5
        )

    @pytest.mark.asyncio
    async def test_dream_cycle_high_budget(self, dreamer):
        """Test dream cycle with high budget (should run)."""
        result = await dreamer.dream_cycle(budget_score=0.85)

        assert result.dream_id.startswith("dream-")
        assert result.seeds_explored > 0
        assert result.phase == DreamPhase.IDLE  # Should complete

    @pytest.mark.asyncio
    async def test_dream_cycle_low_budget(self, dreamer):
        """Test dream cycle with low budget (should skip)."""
        result = await dreamer.dream_cycle(budget_score=0.5)

        assert result.dream_id.startswith("dream-")
        assert result.seeds_explored == 0
        assert result.phase == DreamPhase.IDLE
        assert result.patterns_mined == 0

    @pytest.mark.asyncio
    async def test_dream_cycle_boundary_budget(self, dreamer):
        """Test dream cycle at budget boundary."""
        # Exactly at threshold
        result = await dreamer.dream_cycle(budget_score=0.75)
        assert result.seeds_explored > 0

        # Just below threshold
        result = await dreamer.dream_cycle(budget_score=0.74)
        assert result.seeds_explored == 0

    @pytest.mark.asyncio
    async def test_hypothesis_generation(self, dreamer):
        """Test hypothesis generation during dreaming."""
        result = await dreamer.dream_cycle(budget_score=0.9)

        assert result.hypotheses_generated >= 0
        # Some hypotheses may or may not be crystallized depending on SNR

    @pytest.mark.asyncio
    async def test_snr_gated_crystallization(self, dreamer):
        """Test that only high-SNR hypotheses are crystallized."""
        # Run dream cycle
        await dreamer.dream_cycle(budget_score=0.9)

        # Check crystallized hypotheses meet threshold
        for hypothesis in dreamer._crystallized:
            assert hypothesis.snr_score >= dreamer.snr_threshold

    def test_dream_phases(self, dreamer):
        """Test dream phase transitions."""
        assert dreamer.current_phase == DreamPhase.IDLE
        assert not dreamer.is_dreaming

    def test_statistics(self, dreamer):
        """Test dreamer statistics."""
        stats = dreamer.get_statistics()

        assert "total_dreams" in stats
        assert "total_hypotheses" in stats
        assert "crystallized_count" in stats
        assert "current_phase" in stats
        assert "is_dreaming" in stats
        assert stats["snr_threshold"] == 0.95
        assert stats["budget_threshold"] == 0.75

    @pytest.mark.asyncio
    async def test_multiple_dream_cycles(self, dreamer):
        """Test running multiple dream cycles."""
        results = []
        for _ in range(3):
            result = await dreamer.dream_cycle(budget_score=0.85)
            results.append(result)

        # Dream IDs should be unique
        dream_ids = [r.dream_id for r in results]
        assert len(dream_ids) == len(set(dream_ids))

        # Stats should accumulate
        stats = dreamer.get_statistics()
        assert stats["total_dreams"] >= 3

    def test_dream_history(self, dreamer):
        """Test dream history retrieval."""
        history = dreamer.get_dream_history(limit=10)
        # Initially empty
        assert len(history) == 0

    @pytest.mark.asyncio
    async def test_dream_result_dict(self, dreamer):
        """Test DreamResult to_dict conversion."""
        result = await dreamer.dream_cycle(budget_score=0.85)
        result_dict = result.to_dict()

        assert "dream_id" in result_dict
        assert "phase" in result_dict
        assert "seeds_explored" in result_dict
        assert "snr_achieved" in result_dict
        assert "timestamp" in result_dict


class TestDreamSeed:
    """Test DreamSeed dataclass."""

    def test_seed_creation(self):
        """Test seed creation."""
        seed = DreamSeed(
            seed_id="seed-001",
            concept="ethics",
            source_tier="L4_semantic",
            relevance_score=0.8,
            disciplines=["ethics", "ihsan_studies"]
        )

        assert seed.seed_id == "seed-001"
        assert seed.concept == "ethics"
        assert seed.relevance_score == 0.8


class TestDreamHypothesis:
    """Test DreamHypothesis dataclass."""

    def test_hypothesis_creation(self):
        """Test hypothesis creation."""
        hypothesis = DreamHypothesis(
            hypothesis_id="hyp-001",
            statement="Test hypothesis",
            supporting_patterns=["pat-001"],
            disciplines_involved=["ethics"],
            confidence=0.9,
            snr_score=0.96,
            ihsan_alignment=0.95,
        )

        assert hypothesis.hypothesis_id == "hyp-001"
        assert hypothesis.snr_score >= 0.95


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
