"""
BIZRA Sovereign Nexus - Apex Orchestrator
=========================================
Unified Control Interface for BIZRA Sovereign Intelligence.

The SovereignNexus consolidates 11 components into a unified apex:
- 47-Discipline Topology Engine
- Autonomous Dreaming capability
- SNR self-healing optimization (0.95 Ihsan threshold)
- 147Hz heartbeat with dream interleaving
"""

import os
import logging
import asyncio
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

from .topology_engine import DisciplineTopologyEngine, DisciplineLayer
from .dreamer import AutonomousDreamer, DreamResult, DreamPhase

from .subsystems import (
    NeuralSubsystem,
    SymbolicSubsystem,
    AgenticSubsystem,
    OptimizationSubsystem,
)

from .adapters import (
    RustBridgeAdapter,
    SynapseAdapter,
    DataLakeAdapter,
)

logger = logging.getLogger("nexus")


# ═══════════════════════════════════════════════════════════════════════════════
# STARTUP ENFORCEMENT
# ═══════════════════════════════════════════════════════════════════════════════


class SovereignNexusStartupError(Exception):
    """
    Raised when Nexus startup fails hardware verification.

    This is a HARD failure - the system MUST NOT start unless explicitly
    running in permissive mode (BIZRA_PERMISSIVE_STARTUP=true).
    """

    def __init__(self, message: str, tier1_failed: bool = False, restricted_mode: bool = False):
        super().__init__(message)
        self.tier1_failed = tier1_failed
        self.restricted_mode = restricted_mode


def _is_permissive_startup() -> bool:
    """
    Check if running in permissive startup mode.

    SECURITY WARNING: Permissive mode should ONLY be used for:
    - Initial development/testing
    - CI/CD pipelines with mock hardware
    - Disaster recovery scenarios

    NEVER use permissive mode in production with real Node0 identity.

    Returns:
        True if BIZRA_PERMISSIVE_STARTUP is set to 'true', '1', or 'yes'
    """
    value = os.getenv("BIZRA_PERMISSIVE_STARTUP", "").lower().strip()
    return value in ("true", "1", "yes")


@dataclass
class NexusState:
    """Current state of the Sovereign Nexus."""
    nexus_id: str
    heartbeat_count: int
    uptime_seconds: float
    current_snr: float
    ihsan_score: float
    dream_active: bool
    active_disciplines: List[str]
    active_agents: int
    hardware_verified: bool = True  # Node0 identity verified
    is_node0: bool = True           # This IS the genesis node
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nexus_id": self.nexus_id,
            "heartbeat_count": self.heartbeat_count,
            "uptime_seconds": self.uptime_seconds,
            "current_snr": self.current_snr,
            "ihsan_score": self.ihsan_score,
            "dream_active": self.dream_active,
            "active_disciplines": self.active_disciplines,
            "active_agents": self.active_agents,
            "hardware_verified": self.hardware_verified,
            "is_node0": self.is_node0,
            "timestamp": self.timestamp,
        }


@dataclass
class TaskExecution:
    """Result of task execution through the Nexus."""
    task_id: str
    success: bool
    result: str
    snr_score: float
    ihsan_score: float
    disciplines_invoked: List[str]
    agents_used: List[str]
    latency_ms: float
    receipt_id: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class SovereignNexus:
    """
    Sovereign Nexus - Unified Control Interface for BIZRA.

    The apex orchestrator that consolidates:
    - CognitivePermanence (Memory)
    - OmniAwareness (Proprioception)
    - SovereignModelHub (Model Routing)
    - DisciplineTopologyEngine (47 Disciplines)
    - AutonomousDreamer (Proactive Insights)
    - GoTOrchestrator (Multi-lens Reasoning)
    - SNRTracker (Token Efficiency)
    - GiantProtocol (8 Principles)
    - SynergyDetector (Cross-domain)
    - RecursiveNode (Self-spawning)
    - AbstractionElevator (Pattern Elevation)

    Architecture:
        SovereignNexus
        ├── Subsystems
        │   ├── NeuralSubsystem
        │   ├── SymbolicSubsystem
        │   ├── AgenticSubsystem
        │   └── OptimizationSubsystem
        ├── Adapters
        │   ├── RustBridgeAdapter
        │   ├── SynapseAdapter
        │   └── DataLakeAdapter
        ├── DisciplineTopologyEngine
        └── AutonomousDreamer
    """

    def __init__(
        self,
        *,
        heartbeat_hz: float = 147.0,
        ihsan_threshold: float = 0.95,
        snr_target: float = 0.95,
        enable_dreaming: bool = True,
        nexus_id: Optional[str] = None
    ):
        self.heartbeat_hz = heartbeat_hz
        self.ihsan_threshold = ihsan_threshold
        self.snr_target = snr_target
        self.enable_dreaming = enable_dreaming

        # Generate Nexus ID
        self.nexus_id = nexus_id or f"nexus-{hashlib.sha256(str(datetime.utcnow()).encode()).hexdigest()[:8]}"

        # State tracking
        self._heartbeat_count = 0
        self._start_time = datetime.utcnow()
        self._running = False
        self._task_counter = 0

        # Initialize components
        self._initialize_subsystems()
        self._initialize_adapters()
        self._initialize_core_components()
        self._wire_components()

        # Verify hardware covenant (Node0 identity)
        self._hardware_verified = self._verify_genesis_hardware()

        logger.info(f"SovereignNexus initialized: {self.nexus_id}")
        logger.info(f"  Heartbeat: {self.heartbeat_hz}Hz | Ihsan: {self.ihsan_threshold} | SNR: {self.snr_target}")
        logger.info(f"  Hardware Verified: {self._hardware_verified}")

    def _initialize_subsystems(self) -> None:
        """Initialize all subsystems."""
        self.neural = NeuralSubsystem(ihsan_threshold=self.ihsan_threshold)
        self.symbolic = SymbolicSubsystem(ihsan_threshold=self.ihsan_threshold)
        self.agentic = AgenticSubsystem(
            ihsan_threshold=self.ihsan_threshold,
            enable_warm_pools=True
        )
        self.optimization = OptimizationSubsystem(
            target_snr=self.snr_target,
            ihsan_threshold=self.ihsan_threshold
        )

        logger.info("Subsystems initialized")

    def _initialize_adapters(self) -> None:
        """Initialize all adapters."""
        self.rust_bridge = RustBridgeAdapter(ihsan_threshold=self.ihsan_threshold)
        self.synapse = SynapseAdapter(nexus_id=self.nexus_id)
        self.data_lake = DataLakeAdapter()

        logger.info("Adapters initialized")

    def _initialize_core_components(self) -> None:
        """Initialize core components."""
        # Topology Engine
        self.topology = DisciplineTopologyEngine(ihsan_threshold=self.ihsan_threshold)

        # Autonomous Dreamer
        self.dreamer = AutonomousDreamer(
            snr_threshold=self.snr_target,
            budget_threshold=0.75
        )

        # Legacy component wrappers (for backward compatibility)
        self._memory = None
        self._awareness = None
        self._model_hub = None
        self._got = None

        self._initialize_legacy_components()

        logger.info("Core components initialized")

    def _initialize_legacy_components(self) -> None:
        """Initialize legacy components for backward compatibility."""
        try:
            from bizra_kernel.memory_system import CognitivePermanence
            self._memory = CognitivePermanence()
        except ImportError:
            logger.warning("CognitivePermanence not available")

        try:
            from bizra_kernel.omni_awareness import OmniAwareness
            if self._memory:
                self._awareness = OmniAwareness(self._memory)
        except ImportError:
            logger.warning("OmniAwareness not available")

        try:
            from bizra_kernel.model_hub import SovereignModelHub
            self._model_hub = SovereignModelHub()
        except ImportError:
            logger.warning("SovereignModelHub not available")

        try:
            from bizra_kernel.got_orchestrator import GoTOrchestrator
            self._got = GoTOrchestrator(session_id=f"nexus-{self.nexus_id}")
        except ImportError:
            logger.warning("GoTOrchestrator not available")

    def _wire_components(self) -> None:
        """Wire components together."""
        # Inject adapters into Dreamer
        self.dreamer.set_data_lake_adapter(self.data_lake)
        self.dreamer.set_got_orchestrator(self._got)
        self.dreamer.set_memory_system(self._memory)
        self.dreamer.set_topology_engine(self.topology)

        # Register optimization healing callback
        self.optimization.register_healing_callback(self._on_healing_event)

        logger.info("Components wired")

    def _verify_genesis_hardware(self) -> bool:
        """
        Verify this machine matches the genesis block hardware covenant.

        Called at Nexus initialization to confirm "This IS Node0".

        FAIL-CLOSED ENFORCEMENT:
        - Tier 1 mismatch → HARD FAIL (raise SovereignNexusStartupError)
        - Tier 2 mismatch → WARN + require attestation (Node0 with changes)
        - Tier 3 mismatch → LOG ONLY (Environmental change)

        Permissive mode (BIZRA_PERMISSIVE_STARTUP=true) bypasses enforcement
        for development/testing only - NEVER in production.

        Returns:
            True if hardware verified

        Raises:
            SovereignNexusStartupError: On Tier-1 failure (unless permissive mode)
        """
        permissive = _is_permissive_startup()

        if permissive:
            logger.warning("=" * 60)
            logger.warning("  PERMISSIVE STARTUP MODE - HARDWARE VERIFICATION BYPASSED")
            logger.warning("  DO NOT USE IN PRODUCTION")
            logger.warning("=" * 60)

        try:
            from bizra_kernel.genesis_sync import load_genesis, verify_hardware_covenant
            from bizra_kernel.node0_identity import Node0Identity

            # Load genesis
            genesis = load_genesis()
            covenant = genesis.get("hardware_covenant")

            if not covenant:
                if permissive:
                    logger.warning("⚠ Genesis has no hardware covenant - permissive mode, continuing")
                    return True
                # No covenant = fail-closed unless permissive
                logger.error("✗ Genesis has no hardware covenant - STARTUP BLOCKED")
                raise SovereignNexusStartupError(
                    "Genesis block has no hardware covenant. "
                    "Run coronation ceremony first, or set BIZRA_PERMISSIVE_STARTUP=true for testing.",
                    tier1_failed=True,
                )

            expected_fingerprint = covenant.get("fingerprint")
            if not expected_fingerprint:
                if permissive:
                    logger.warning("⚠ Hardware covenant has no fingerprint - permissive mode, continuing")
                    return True
                logger.error("✗ Hardware covenant has no fingerprint - STARTUP BLOCKED")
                raise SovereignNexusStartupError(
                    "Hardware covenant has no fingerprint. Genesis is incomplete.",
                    tier1_failed=True,
                )

            # ═══════════════════════════════════════════════════════════════
            # PHASE 1: Verify genesis signature
            # ═══════════════════════════════════════════════════════════════
            signature = genesis.get("signature")
            if signature:
                identity = Node0Identity.load_or_create()
                sig_result = identity.verify_genesis(genesis)

                if not sig_result.get("verified", False):
                    logger.error("✗ Genesis signature verification FAILED")
                    logger.error(f"  Error: {sig_result.get('error', 'Unknown')}")

                    if not permissive:
                        # Enter restricted mode
                        identity.enter_restricted_mode("Genesis signature invalid")
                        raise SovereignNexusStartupError(
                            f"Genesis signature verification failed: {sig_result.get('error')}",
                            tier1_failed=True,
                            restricted_mode=True,
                        )
                    logger.warning("  Permissive mode - continuing despite signature failure")
                else:
                    logger.info("✓ Genesis signature verified")
            else:
                logger.warning("⚠ Genesis has no signature - signature verification skipped")

            # ═══════════════════════════════════════════════════════════════
            # PHASE 2: Verify hardware covenant
            # ═══════════════════════════════════════════════════════════════
            result = verify_hardware_covenant(genesis)

            if result["verified"]:
                logger.info("✓ Hardware verification PASSED - This IS Node0")

                # Log tier results
                for tier_name, tier_result in result.get("tier_results", {}).items():
                    action = tier_result.get("action", "UNKNOWN")
                    if action == "PASS":
                        logger.debug(f"  {tier_name}: PASS")
                    elif action == "WARN_REQUIRE_ATTESTATION":
                        logger.warning(f"  {tier_name}: {action} - Hardware component changed")
                    elif action == "LOG_ONLY":
                        logger.info(f"  {tier_name}: {action} - Environmental change detected")

                # Emit warnings
                for warning in result.get("warnings", []):
                    logger.warning(f"  ⚠ {warning}")

                # Emit boot receipt (append-only evidence)
                self._emit_boot_receipt(
                    genesis=genesis,
                    verification_result=result,
                    identity=identity if 'identity' in dir() else None,
                )

                return True
            else:
                # ═══════════════════════════════════════════════════════════
                # TIER-1 FAILURE - HARD FAIL
                # ═══════════════════════════════════════════════════════════
                logger.error("=" * 60)
                logger.error("  HARDWARE VERIFICATION FAILED - THIS IS NOT NODE0")
                logger.error("=" * 60)
                logger.error(f"  Expected fingerprint: {result.get('expected_fingerprint', 'N/A')[:16]}...")
                logger.error(f"  Current fingerprint: {result.get('current_fingerprint', 'N/A')[:16]}...")

                tier_results = result.get("tier_results", {})
                tier1_result = tier_results.get("tier1_root", {})
                if tier1_result.get("action") == "HARD_FAIL":
                    logger.error("  Tier-1 ROOT mismatch: HARD FAIL")
                    for diff in tier1_result.get("differences", []):
                        logger.error(f"    - {diff}")

                if not permissive:
                    # Enter restricted mode
                    try:
                        identity = Node0Identity.load_or_create()
                        identity.enter_restricted_mode("Tier-1 hardware mismatch")
                    except Exception as e:
                        logger.error(f"  Could not enter restricted mode: {e}")

                    raise SovereignNexusStartupError(
                        "Hardware verification failed: Tier-1 ROOT mismatch. "
                        "This machine is NOT the genesis node. "
                        "Set BIZRA_PERMISSIVE_STARTUP=true to bypass (testing only).",
                        tier1_failed=True,
                        restricted_mode=True,
                    )

                logger.warning("  PERMISSIVE MODE - Continuing despite Tier-1 failure")
                return False

        except SovereignNexusStartupError:
            # Re-raise our own exceptions
            raise

        except FileNotFoundError as e:
            if permissive:
                logger.warning(f"⚠ Hardware verification skipped - genesis not found: {e}")
                return True
            logger.error(f"✗ Genesis file not found: {e}")
            raise SovereignNexusStartupError(
                f"Genesis file not found: {e}. "
                "Run coronation ceremony first, or set BIZRA_PERMISSIVE_STARTUP=true for testing.",
                tier1_failed=True,
            )

        except ImportError as e:
            if permissive:
                logger.warning(f"⚠ Hardware verification skipped - module not available: {e}")
                return True
            logger.error(f"✗ Required module not available: {e}")
            raise SovereignNexusStartupError(
                f"Required module not available: {e}",
                tier1_failed=False,
            )

        except Exception as e:
            logger.error(f"✗ Hardware verification error: {e}")
            if not permissive:
                raise SovereignNexusStartupError(
                    f"Hardware verification failed: {e}",
                    tier1_failed=False,
                )
            return False

    def _emit_boot_receipt(
        self,
        genesis: dict,
        verification_result: dict,
        identity: Optional[Any] = None,
    ) -> None:
        """
        Emit an append-only boot receipt after successful hardware verification.

        This provides auditable evidence that Node0 identity was validated on boot.
        """
        import json

        receipt_dir = os.getenv("BIZRA_RECEIPT_PATH", "docs/evidence/receipts")
        boot_receipt_dir = os.path.join(receipt_dir, "boot_receipts")

        try:
            os.makedirs(boot_receipt_dir, exist_ok=True)

            # Extract key information
            covenant = genesis.get("hardware_covenant", {})
            signature = genesis.get("signature", {})

            boot_receipt = {
                "receipt_type": "NEXUS_BOOT",
                "nexus_id": self.nexus_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "genesis_hash": signature.get("genesis_hash", "unsigned")[:16] + "...",
                "pubkey_fingerprint": (
                    identity.public_key_fingerprint if identity else
                    signature.get("pubkey_fingerprint", "unknown")
                ),
                "hardware_fingerprint": covenant.get("fingerprint", "unknown")[:16] + "...",
                "tier_results": {
                    tier: result.get("action", "UNKNOWN")
                    for tier, result in verification_result.get("tier_results", {}).items()
                },
                "restricted_mode": False,
                "ihsan_threshold": self.ihsan_threshold,
                "snr_target": self.snr_target,
            }

            # Add integrity hash
            receipt_canonical = json.dumps(boot_receipt, sort_keys=True, separators=(",", ":"))
            boot_receipt["integrity_hash"] = hashlib.sha256(receipt_canonical.encode()).hexdigest()

            # Write receipt (append-only: use unique timestamp-based filename)
            timestamp_slug = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
            receipt_path = os.path.join(boot_receipt_dir, f"boot_{self.nexus_id}_{timestamp_slug}.json")

            with open(receipt_path, "w") as f:
                json.dump(boot_receipt, f, indent=2)

            logger.info(f"Boot receipt emitted: {receipt_path}")

        except Exception as e:
            # Boot receipt failure is non-fatal but should be logged
            logger.warning(f"Failed to emit boot receipt: {e}")

    def _on_healing_event(self, event) -> None:
        """Handle self-healing events."""
        logger.info(f"Healing event: {event.action.value} | Before: {event.before_snr:.4f} | After: {event.after_snr:.4f}")

        # Publish to Synapse
        self.synapse.publish_snr_update(
            current_snr=event.after_snr,
            target_snr=self.snr_target,
            healing_actions=[event.action.value]
        )

    def _next_task_id(self) -> str:
        self._task_counter += 1
        return f"task-{self._task_counter:08d}"

    async def execute(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None,
        require_sat_consensus: bool = True
    ) -> TaskExecution:
        """
        Execute a task through the Sovereign Nexus.

        Flow:
        1. SAPE validation via Rust bridge
        2. SAT consensus (if required)
        3. Discipline activation via Topology
        4. Symbolic reasoning chain
        5. Neural perception/embedding
        6. PAT execution
        7. SNR tracking
        8. Receipt emission
        """
        task_id = self._next_task_id()
        start_time = asyncio.get_event_loop().time()
        agents_used = []
        disciplines_invoked = []

        logger.info(f"Executing task: {task_id}")

        # Step 1: SAPE Validation
        sape_result = self.rust_bridge.run_full_sape_validation(task, context)
        if not sape_result["overall_passed"]:
            return TaskExecution(
                task_id=task_id,
                success=False,
                result=f"SAPE validation failed: score {sape_result['overall_score']:.4f}",
                snr_score=sape_result["overall_score"],
                ihsan_score=sape_result["overall_score"],
                disciplines_invoked=[],
                agents_used=[],
                latency_ms=(asyncio.get_event_loop().time() - start_time) * 1000,
            )

        # Step 2: SAT Consensus
        if require_sat_consensus:
            consensus = self.agentic.run_sat_consensus(task, context)
            if not consensus["consensus_reached"]:
                return TaskExecution(
                    task_id=task_id,
                    success=False,
                    result=f"SAT consensus failed: {consensus['approvals']}/3",
                    snr_score=0.0,
                    ihsan_score=0.0,
                    disciplines_invoked=[],
                    agents_used=[v["agent"] for v in consensus["votes"]],
                    latency_ms=(asyncio.get_event_loop().time() - start_time) * 1000,
                )
            agents_used.extend([v["agent"] for v in consensus["votes"]])

        # Step 3: Discipline Activation
        detected_disciplines = self.symbolic._detect_relevant_disciplines(task)
        for disc in detected_disciplines:
            self.topology.activate_discipline(disc)
            disciplines_invoked.append(disc)

            # Publish activation
            self.synapse.publish_discipline_activation(
                discipline_name=disc,
                layer=self.topology.get_discipline(disc).layer.value if self.topology.get_discipline(disc) else 0,
                activation_count=self.topology.get_discipline(disc).activation_count if self.topology.get_discipline(disc) else 1
            )

        # Step 4: Symbolic Reasoning
        reasoning_chain = self.symbolic.reason_symbolic(
            query=task,
            disciplines=disciplines_invoked[:5]
        )

        # Step 5: Neural Perception
        perception = self.neural.perceive(task)

        # Step 6: PAT Execution
        master_reasoner = self.agentic.spawn_pat_agent("MasterReasoner")
        if master_reasoner:
            agents_used.append(master_reasoner.agent_name)
            pat_result = self.agentic.execute_task(
                master_reasoner.agent_id,
                task,
                context
            )
        else:
            pat_result = None

        # Step 7: SNR Tracking
        snr_snapshot = self.optimization.record_metrics(
            total_tokens=len(task.split()) * 2,
            useful_tokens=len(task.split()),
            confidence_score=reasoning_chain.confidence,
            ethical_compliance=reasoning_chain.ihsan_alignment,
            tool_directness=0.9,
            latency_ms=int((asyncio.get_event_loop().time() - start_time) * 1000),
            agent_role="MasterReasoner",
        )

        # Step 8: Receipt Emission
        receipt_id = None
        if sape_result["overall_passed"] and snr_snapshot.meets_target:
            # Generate receipt via Rust bridge
            receipt_id = f"RCP-{hashlib.sha256(f'{task_id}{datetime.utcnow()}'.encode()).hexdigest()[:12]}"

        latency_ms = (asyncio.get_event_loop().time() - start_time) * 1000

        result = TaskExecution(
            task_id=task_id,
            success=True,
            result=f"Task executed via {len(disciplines_invoked)} disciplines. {reasoning_chain.synthesis_result}",
            snr_score=snr_snapshot.current_snr,
            ihsan_score=reasoning_chain.ihsan_alignment,
            disciplines_invoked=disciplines_invoked,
            agents_used=agents_used,
            latency_ms=latency_ms,
            receipt_id=receipt_id,
        )

        logger.info(f"Task complete: {task_id} | SNR: {snr_snapshot.current_snr:.4f} | Latency: {latency_ms:.2f}ms")
        return result

    async def run_heartbeat_loop(self) -> None:
        """
        Run the 147Hz heartbeat loop with dream interleaving.

        The heartbeat:
        1. Updates presence in Synapse
        2. Checks cognitive budget
        3. Triggers dream cycles when budget is high
        4. Monitors SNR and triggers healing
        """
        if self._running:
            logger.warning("Heartbeat loop already running")
            return

        self._running = True
        interval = 1.0 / self.heartbeat_hz

        logger.info(f"Starting heartbeat loop at {self.heartbeat_hz}Hz")

        # Connect to Synapse
        self.synapse.connect()

        while self._running:
            try:
                self._heartbeat_count += 1

                # Get current SNR
                current_snr = self.optimization.get_current_snr()

                # Get cognitive budget
                budget_score = 0.8  # Default
                if self._awareness:
                    try:
                        budget = self._awareness.compute_cognitive_budget()
                        budget_score = budget.get("budget_score", 0.8)
                    except Exception:
                        pass

                # Publish heartbeat
                self.synapse.publish_heartbeat(
                    snr_score=current_snr,
                    dream_active=self.dreamer.is_dreaming
                )

                # Dream interleaving (every 100 heartbeats when budget is high)
                if (
                    self.enable_dreaming and
                    self._heartbeat_count % 100 == 0 and
                    budget_score >= 0.75 and
                    not self.dreamer.is_dreaming
                ):
                    asyncio.create_task(self._dream_cycle(budget_score))

                await asyncio.sleep(interval)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Heartbeat error: {e}")
                await asyncio.sleep(interval)

        self.synapse.disconnect()
        logger.info("Heartbeat loop stopped")

    async def _dream_cycle(self, budget_score: float) -> None:
        """Execute a dream cycle."""
        try:
            result = await self.dreamer.dream_cycle(budget_score)

            # Publish dream events
            self.synapse.publish_dream_event(
                event_type="complete",
                dream_id=result.dream_id,
                payload=result.to_dict()
            )

        except Exception as e:
            logger.error(f"Dream cycle error: {e}")

    def stop(self) -> None:
        """Stop the Nexus."""
        self._running = False
        self.optimization.stop_healing_loop()
        logger.info("Nexus stopping")

    def get_state(self) -> NexusState:
        """Get current Nexus state."""
        uptime = (datetime.utcnow() - self._start_time).total_seconds()

        # Get active disciplines
        active_disciplines = [
            d.name for d in self.topology.disciplines.values()
            if d.activation_count > 0
        ][:10]

        # Get active agents
        active_agents = len(self.agentic.get_active_agents())

        return NexusState(
            nexus_id=self.nexus_id,
            heartbeat_count=self._heartbeat_count,
            uptime_seconds=uptime,
            current_snr=self.optimization.get_current_snr(),
            ihsan_score=self.ihsan_threshold,
            dream_active=self.dreamer.is_dreaming,
            active_disciplines=active_disciplines,
            active_agents=active_agents,
            hardware_verified=self._hardware_verified,
            is_node0=self._hardware_verified,  # Node0 = hardware verified
        )

    def get_snr_stats(self) -> Dict[str, Any]:
        """Get SNR statistics."""
        return self.optimization.get_statistics()

    def get_topology_stats(self) -> Dict[str, Any]:
        """Get topology statistics."""
        return self.topology.get_statistics()

    def get_dreamer_stats(self) -> Dict[str, Any]:
        """Get dreamer statistics."""
        return self.dreamer.get_statistics()

    def get_full_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics."""
        return {
            "nexus": self.get_state().to_dict(),
            "snr": self.get_snr_stats(),
            "topology": self.get_topology_stats(),
            "dreamer": self.get_dreamer_stats(),
            "neural": self.neural.get_statistics(),
            "symbolic": self.symbolic.get_statistics(),
            "agentic": self.agentic.get_statistics(),
            "synapse": self.synapse.health_check(),
            "data_lake": self.data_lake.get_statistics(),
            "rust_bridge": self.rust_bridge.get_escalation_stats(),
        }


# Legacy compatibility wrapper
class SovereignKernel:
    """
    Legacy wrapper for backward compatibility with SovereignKernel API.

    Delegates to SovereignNexus internally.
    """

    def __init__(self):
        self.nexus = SovereignNexus()

    def execute_sovereign_task(
        self,
        prompt: str,
        mission_metrics: Optional[Dict[str, float]] = None,
        request_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Legacy API: Execute task via Nexus."""
        import asyncio

        async def _execute():
            result = await self.nexus.execute(
                task=prompt,
                context={"mission_metrics": mission_metrics, "request_id": request_id}
            )
            return {
                "status": "SUCCESS" if result.success else "VETOED",
                "latency": f"{result.latency_ms:.2f}ms",
                "snr": result.snr_score,
                "ihsan": result.ihsan_score,
                "ledger_hash": result.receipt_id or "N/A",
                "disciplines": result.disciplines_invoked,
            }

        return asyncio.run(_execute())


if __name__ == "__main__":
    import asyncio

    async def main():
        nexus = SovereignNexus(
            heartbeat_hz=147.0,
            ihsan_threshold=0.95,
            snr_target=0.95,
            enable_dreaming=True
        )

        print("\n" + "=" * 60)
        print("  BIZRA SOVEREIGN NEXUS")
        print("=" * 60)

        state = nexus.get_state()
        print(f"\nNexus ID: {state.nexus_id}")
        print(f"Heartbeat: {nexus.heartbeat_hz}Hz")
        print(f"Ihsan Threshold: {nexus.ihsan_threshold}")
        print(f"SNR Target: {nexus.snr_target}")

        # Test task execution
        print("\n1. Executing test task...")
        result = await nexus.execute(
            task="Analyze the ethical implications of autonomous AI systems",
            require_sat_consensus=True
        )
        print(f"   Task ID: {result.task_id}")
        print(f"   Success: {result.success}")
        print(f"   SNR: {result.snr_score:.4f}")
        print(f"   Ihsan: {result.ihsan_score:.4f}")
        print(f"   Disciplines: {result.disciplines_invoked}")
        print(f"   Agents: {result.agents_used}")
        print(f"   Latency: {result.latency_ms:.2f}ms")

        # Get full statistics
        print("\n2. Full statistics:")
        stats = nexus.get_full_statistics()
        print(f"   Topology: {stats['topology']['total_disciplines']} disciplines, {stats['topology']['total_bridges']} bridges")
        print(f"   SNR: current={stats['snr']['current_snr']:.4f}, target={stats['snr']['target_snr']:.4f}")
        print(f"   Dreamer: {stats['dreamer']['total_dreams']} dreams, {stats['dreamer']['crystallized_count']} crystallized")

        # Test legacy API
        print("\n3. Testing legacy SovereignKernel API...")
        kernel = SovereignKernel()
        legacy_result = kernel.execute_sovereign_task(
            "Test legacy API",
            {"truthfulness": 1.0, "dignity": 1.0, "fairness": 1.0, "sustainability": 1.0}
        )
        print(f"   Status: {legacy_result['status']}")
        print(f"   SNR: {legacy_result['snr']:.4f}")

        print("\n" + "=" * 60)

    asyncio.run(main())
