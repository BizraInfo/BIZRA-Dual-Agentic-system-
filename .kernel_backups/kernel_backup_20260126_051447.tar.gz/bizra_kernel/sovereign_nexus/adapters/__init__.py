"""
BIZRA Sovereign Nexus - Adapters
================================
Bridge adapters that connect the Sovereign Nexus to external systems:

- RustBridgeAdapter: FFI wrapper for the Rust FATE engine
- SynapseAdapter: Wrapper for Trinity Synapse (Redis pub/sub)
- DataLakeAdapter: Bridge to BIZRA-DATA-LAKE via MCP
"""

from .rust_bridge_adapter import RustBridgeAdapter
from .synapse_adapter import SynapseAdapter
from .data_lake_adapter import DataLakeAdapter

__all__ = [
    "RustBridgeAdapter",
    "SynapseAdapter",
    "DataLakeAdapter",
]
