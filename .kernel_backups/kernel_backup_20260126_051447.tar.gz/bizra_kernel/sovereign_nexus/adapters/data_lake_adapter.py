"""
BIZRA Sovereign Nexus - Data Lake Adapter
=========================================
Bridge to BIZRA-DATA-LAKE via MCP (Model Context Protocol).

Provides access to:
- 6-tier memory hierarchy (M1-M6)
- Hypergraph knowledge store (709k nodes, 1.4M edges)
- PoI (Proof-of-Impact) ledger
- Gold layer curated data
"""

import os
import json
import logging
import hashlib
import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
from enum import Enum

# Optional dependency - aiohttp for MCP communication
try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

logger = logging.getLogger("nexus.data_lake")


class MemoryTier(Enum):
    """BIZRA-DATA-LAKE memory tiers."""
    M1_SESSION = 1       # TaskMaster Session (immediate)
    M2_SHORT_TERM = 2    # Short-term Episodic
    M3_MEDIUM_TERM = 3   # Medium-term Semantic
    M4_LONG_TERM = 4     # Long-term Procedural
    M5_HISTORICAL = 5    # Historical Archive
    M6_SOVEREIGN = 6     # Sovereign (Cross-Domain)


@dataclass
class DataLakeQuery:
    """Query to the Data Lake."""
    query_id: str
    query: str
    tier: Optional[MemoryTier] = None
    filters: Dict[str, Any] = field(default_factory=dict)
    limit: int = 100
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class DataLakeResult:
    """Result from Data Lake query."""
    query_id: str
    success: bool
    results: List[Dict[str, Any]]
    tier_source: Optional[MemoryTier]
    total_count: int
    latency_ms: float
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class PoIAttestation:
    """Proof-of-Impact attestation from the ledger."""
    attestation_id: str
    task_id: str
    impact_type: str
    impact_score: float
    evidence_hash: str
    validator_ids: List[str]
    timestamp: str


class DataLakeAdapter:
    """
    Adapter for BIZRA-DATA-LAKE via MCP.

    Architecture:
        DataLakeAdapter
        ├── MCP Bridge (https://localhost:8443)
        ├── Gold Layer (curated Parquet)
        ├── PoI Ledger (JSONL attestations)
        └── Hypergraph (709k nodes)
    """

    def __init__(
        self,
        mcp_url: Optional[str] = None,
        data_lake_path: Optional[str] = None,
        timeout: int = 30
    ):
        self.mcp_url = mcp_url or os.getenv(
            "DATA_LAKE_MCP_URL",
            "https://localhost:8443"
        )
        self.data_lake_path = data_lake_path or os.getenv(
            "DATA_LAKE_PATH",
            "/mnt/c/BIZRA-DATA-LAKE"
        )
        self.timeout = timeout
        self._query_counter = 0
        self._cache: Dict[str, DataLakeResult] = {}

        # Verify Data Lake path
        self.local_available = os.path.exists(self.data_lake_path)
        if self.local_available:
            logger.info(f"Data Lake path verified: {self.data_lake_path}")
        else:
            logger.warning(f"Data Lake path not found: {self.data_lake_path}")

    def _next_query_id(self) -> str:
        self._query_counter += 1
        return f"dlq-{self._query_counter:08d}"

    async def query(
        self,
        query_text: str,
        tier: Optional[MemoryTier] = None,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 100,
        use_cache: bool = True
    ) -> DataLakeResult:
        """
        Query the Data Lake.

        Tries MCP first, falls back to local if unavailable.
        """
        query = DataLakeQuery(
            query_id=self._next_query_id(),
            query=query_text,
            tier=tier,
            filters=filters or {},
            limit=limit,
        )

        # Check cache
        cache_key = hashlib.sha256(
            f"{query_text}:{tier}:{json.dumps(filters or {})}".encode()
        ).hexdigest()[:16]

        if use_cache and cache_key in self._cache:
            cached = self._cache[cache_key]
            logger.debug(f"Cache hit for query: {query.query_id}")
            return cached

        # Try MCP first
        start = asyncio.get_event_loop().time()
        result = await self._query_mcp(query)

        if not result.success and self.local_available:
            # Fall back to local
            result = await self._query_local(query)

        result.latency_ms = (asyncio.get_event_loop().time() - start) * 1000

        # Cache result
        if result.success:
            self._cache[cache_key] = result

        return result

    async def _query_mcp(self, query: DataLakeQuery) -> DataLakeResult:
        """Query via MCP JSON-RPC."""
        if not AIOHTTP_AVAILABLE:
            logger.debug("aiohttp not available, skipping MCP query")
            return DataLakeResult(
                query_id=query.query_id,
                success=False,
                results=[],
                tier_source=None,
                total_count=0,
                latency_ms=0,
            )
        try:
            payload = {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "knowledge_retrieve",
                    "arguments": {
                        "query": query.query,
                        "tier": query.tier.value if query.tier else None,
                        "filters": query.filters,
                        "limit": query.limit,
                    }
                },
                "id": query.query_id,
            }

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.mcp_url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=self.timeout),
                    ssl=False  # Allow self-signed certs in dev
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        if "result" in data:
                            results = data["result"].get("content", [])
                            return DataLakeResult(
                                query_id=query.query_id,
                                success=True,
                                results=results,
                                tier_source=query.tier,
                                total_count=len(results),
                                latency_ms=0,
                            )
                        elif "error" in data:
                            logger.error(f"MCP error: {data['error']}")

        except asyncio.TimeoutError:
            logger.warning("MCP query timed out")
        except aiohttp.ClientError as e:
            logger.warning(f"MCP connection error: {e}")
        except Exception as e:
            logger.error(f"MCP query failed: {e}")

        return DataLakeResult(
            query_id=query.query_id,
            success=False,
            results=[],
            tier_source=None,
            total_count=0,
            latency_ms=0,
        )

    async def _query_local(self, query: DataLakeQuery) -> DataLakeResult:
        """Query local Data Lake files."""
        results = []

        try:
            # Search in Gold layer
            gold_path = os.path.join(self.data_lake_path, "04_GOLD")
            if os.path.exists(gold_path):
                # Search indexed files
                index_path = os.path.join(self.data_lake_path, "03_INDEXED")
                if os.path.exists(index_path):
                    # Simple keyword search in index
                    for filename in os.listdir(index_path):
                        if filename.endswith(".json"):
                            filepath = os.path.join(index_path, filename)
                            try:
                                with open(filepath, "r", encoding="utf-8") as f:
                                    data = json.load(f)
                                    if self._matches_query(data, query.query):
                                        results.append(data)
                                        if len(results) >= query.limit:
                                            break
                            except Exception:
                                pass

        except Exception as e:
            logger.error(f"Local query failed: {e}")

        return DataLakeResult(
            query_id=query.query_id,
            success=len(results) > 0,
            results=results,
            tier_source=query.tier,
            total_count=len(results),
            latency_ms=0,
        )

    def _matches_query(self, data: Dict[str, Any], query: str) -> bool:
        """Check if data matches query (simple keyword matching)."""
        query_lower = query.lower()
        data_str = json.dumps(data).lower()
        return query_lower in data_str

    async def store(
        self,
        content: str,
        tier: MemoryTier,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Store content in the Data Lake.

        Routes to appropriate tier based on content type.
        """
        if not AIOHTTP_AVAILABLE:
            logger.debug("aiohttp not available, using local storage")
            return await self._store_local(content, tier, metadata)
        try:
            payload = {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "memory_store",
                    "arguments": {
                        "content": content,
                        "tier": tier.value,
                        "metadata": metadata or {},
                    }
                },
                "id": self._next_query_id(),
            }

            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.mcp_url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=self.timeout),
                    ssl=False
                ) as response:
                    return response.status == 200

        except Exception as e:
            logger.error(f"Store failed: {e}")

        # Try local storage as fallback
        return await self._store_local(content, tier, metadata)

    async def _store_local(
        self,
        content: str,
        tier: MemoryTier,
        metadata: Optional[Dict[str, Any]]
    ) -> bool:
        """Store content locally."""
        try:
            tier_path = os.path.join(
                self.data_lake_path,
                f"0{tier.value}_{'RAW' if tier.value <= 2 else 'INDEXED'}"
            )
            os.makedirs(tier_path, exist_ok=True)

            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            content_hash = hashlib.sha256(content.encode()).hexdigest()[:8]
            filename = f"{timestamp}_{content_hash}.json"

            data = {
                "content": content,
                "tier": tier.value,
                "metadata": metadata or {},
                "timestamp": datetime.utcnow().isoformat(),
            }

            filepath = os.path.join(tier_path, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            return True

        except Exception as e:
            logger.error(f"Local store failed: {e}")
            return False

    async def get_poi_attestations(
        self,
        task_id: Optional[str] = None,
        limit: int = 100
    ) -> List[PoIAttestation]:
        """
        Get Proof-of-Impact attestations from the ledger.

        PoI attestations validate verified impact of AI actions.
        """
        attestations = []

        try:
            poi_path = os.path.join(self.data_lake_path, "04_GOLD", "poi_ledger.jsonl")

            if os.path.exists(poi_path):
                with open(poi_path, "r", encoding="utf-8") as f:
                    for line in f:
                        if not line.strip():
                            continue
                        try:
                            data = json.loads(line)
                            if task_id and data.get("task_id") != task_id:
                                continue
                            attestations.append(PoIAttestation(
                                attestation_id=data.get("attestation_id", ""),
                                task_id=data.get("task_id", ""),
                                impact_type=data.get("impact_type", ""),
                                impact_score=data.get("impact_score", 0.0),
                                evidence_hash=data.get("evidence_hash", ""),
                                validator_ids=data.get("validator_ids", []),
                                timestamp=data.get("timestamp", ""),
                            ))
                            if len(attestations) >= limit:
                                break
                        except json.JSONDecodeError:
                            pass

        except Exception as e:
            logger.error(f"Failed to read PoI ledger: {e}")

        return attestations

    async def record_poi(
        self,
        task_id: str,
        impact_type: str,
        impact_score: float,
        evidence: Dict[str, Any],
        validator_ids: List[str]
    ) -> Optional[PoIAttestation]:
        """
        Record a new Proof-of-Impact attestation.

        Requires Ihsan-compliant impact score (>= 0.95).
        """
        if impact_score < 0.95:
            logger.warning(f"PoI rejected: impact score {impact_score} < 0.95")
            return None

        evidence_hash = hashlib.sha256(
            json.dumps(evidence, sort_keys=True).encode()
        ).hexdigest()

        attestation = PoIAttestation(
            attestation_id=f"POI-{hashlib.sha256(f'{task_id}{datetime.utcnow().isoformat()}'.encode()).hexdigest()[:12]}",
            task_id=task_id,
            impact_type=impact_type,
            impact_score=impact_score,
            evidence_hash=evidence_hash,
            validator_ids=validator_ids,
            timestamp=datetime.utcnow().isoformat(),
        )

        # Write to ledger
        try:
            poi_path = os.path.join(self.data_lake_path, "04_GOLD", "poi_ledger.jsonl")
            os.makedirs(os.path.dirname(poi_path), exist_ok=True)

            with open(poi_path, "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "attestation_id": attestation.attestation_id,
                    "task_id": attestation.task_id,
                    "impact_type": attestation.impact_type,
                    "impact_score": attestation.impact_score,
                    "evidence_hash": attestation.evidence_hash,
                    "validator_ids": attestation.validator_ids,
                    "timestamp": attestation.timestamp,
                }) + "\n")

            logger.info(f"PoI recorded: {attestation.attestation_id}")
            return attestation

        except Exception as e:
            logger.error(f"Failed to record PoI: {e}")
            return None

    async def mine_patterns(
        self,
        discipline: str,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Mine patterns from Data Lake for a discipline.

        Used by the AutonomousDreamer for hypothesis generation.
        """
        result = await self.query(
            query_text=f"patterns related to {discipline}",
            tier=MemoryTier.M4_LONG_TERM,
            limit=limit,
        )

        if result.success:
            return result.results

        return []

    def get_statistics(self) -> Dict[str, Any]:
        """Get Data Lake statistics."""
        stats = {
            "mcp_url": self.mcp_url,
            "local_available": self.local_available,
            "cache_size": len(self._cache),
        }

        if self.local_available:
            try:
                # Count files in each tier
                tier_counts = {}
                for tier in MemoryTier:
                    tier_path = os.path.join(
                        self.data_lake_path,
                        f"0{tier.value}_{'RAW' if tier.value <= 2 else 'INDEXED'}"
                    )
                    if os.path.exists(tier_path):
                        tier_counts[tier.name] = len(os.listdir(tier_path))
                    else:
                        tier_counts[tier.name] = 0

                stats["tier_counts"] = tier_counts

            except Exception as e:
                logger.error(f"Stats collection failed: {e}")

        return stats


if __name__ == "__main__":
    import asyncio

    async def main():
        adapter = DataLakeAdapter()

        print("\n" + "=" * 60)
        print("  BIZRA DATA LAKE ADAPTER")
        print("=" * 60)

        print(f"\nMCP URL: {adapter.mcp_url}")
        print(f"Local Available: {adapter.local_available}")

        # Test query
        print("\n1. Testing query...")
        result = await adapter.query("BIZRA architecture", limit=5)
        print(f"   Success: {result.success}")
        print(f"   Results: {result.total_count}")

        # Test PoI
        print("\n2. Testing PoI...")
        attestations = await adapter.get_poi_attestations(limit=5)
        print(f"   Attestations: {len(attestations)}")

        # Test pattern mining
        print("\n3. Testing pattern mining...")
        patterns = await adapter.mine_patterns("ethics")
        print(f"   Patterns found: {len(patterns)}")

        # Statistics
        print("\n4. Statistics:")
        stats = adapter.get_statistics()
        print(f"   Cache size: {stats['cache_size']}")

        print("\n" + "=" * 60)

    asyncio.run(main())
