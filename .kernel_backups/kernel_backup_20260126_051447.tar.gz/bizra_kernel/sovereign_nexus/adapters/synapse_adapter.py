"""
BIZRA Sovereign Nexus - Synapse Adapter
=======================================
Wrapper for Trinity Synapse (Redis-based agent communication).

Provides simplified interface for:
- Agent presence management
- Pub/Sub messaging
- Shared state storage
- Event sourcing
"""

import os
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Set
from enum import Enum

logger = logging.getLogger("nexus.synapse")


class NexusMessageType(Enum):
    """Message types for Nexus operations."""
    # Nexus lifecycle
    NEXUS_ONLINE = "nexus.online"
    NEXUS_HEARTBEAT = "nexus.heartbeat"
    NEXUS_DREAM_START = "nexus.dream.start"
    NEXUS_DREAM_COMPLETE = "nexus.dream.complete"

    # Discipline activation
    DISCIPLINE_ACTIVATED = "discipline.activated"
    DISCIPLINE_BRIDGE_DISCOVERED = "discipline.bridge.discovered"

    # SNR optimization
    SNR_UPDATE = "snr.update"
    SNR_SELF_HEALING = "snr.self_healing"

    # System coordination
    SYSTEM_SYNC = "system.sync"
    SYSTEM_ALERT = "system.alert"


@dataclass
class NexusMessage:
    """A message from the Sovereign Nexus."""
    id: str
    type: NexusMessageType
    payload: Dict[str, Any]
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    correlation_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type.value,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "correlation_id": self.correlation_id,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


MessageHandler = Callable[[NexusMessage], None]


class SynapseAdapter:
    """
    Adapter for Trinity Synapse communication.

    Wraps core.synapse.SynapseBus with Nexus-specific functionality.
    Falls back to local memory if Synapse is unavailable.
    """

    def __init__(
        self,
        nexus_id: str = "sovereign-nexus-0",
        nexus_name: str = "SovereignNexus"
    ):
        self.nexus_id = nexus_id
        self.nexus_name = nexus_name
        self._synapse_bus = None
        self._connected = False
        self._handlers: Dict[NexusMessageType, List[MessageHandler]] = {}
        self._local_state: Dict[str, Any] = {}
        self._message_counter = 0

        # Try to import and connect to real Synapse
        self._initialize_synapse()

    def _initialize_synapse(self) -> None:
        """Initialize connection to Trinity Synapse."""
        try:
            from core.synapse import create_synapse_for_agent, MessageType

            self._synapse_bus = create_synapse_for_agent(
                agent_id=self.nexus_id,
                agent_name=self.nexus_name,
                agent_type="NEXUS"
            )
            self._connected = True
            logger.info(f"Synapse adapter connected: {self.nexus_id}")

        except ImportError:
            logger.warning("core.synapse not available, using local mode")
            self._connected = False
        except Exception as e:
            logger.warning(f"Failed to connect to Synapse: {e}")
            self._connected = False

    @property
    def is_connected(self) -> bool:
        """Check if connected to Synapse."""
        return self._connected

    def _next_message_id(self) -> str:
        self._message_counter += 1
        return f"nexus-msg-{self._message_counter:08d}"

    def connect(self, capabilities: List[str] = None) -> bool:
        """
        Connect to Synapse and register presence.

        Returns True if connected (or local mode active).
        """
        if self._connected and self._synapse_bus:
            try:
                return self._synapse_bus.connect(capabilities or [
                    "sovereign_nexus",
                    "dreaming",
                    "topology",
                    "snr_optimization"
                ])
            except Exception as e:
                logger.error(f"Synapse connection failed: {e}")
                self._connected = False

        # Local mode always "succeeds"
        return True

    def disconnect(self) -> None:
        """Disconnect from Synapse."""
        if self._synapse_bus:
            try:
                self._synapse_bus.disconnect()
            except Exception as e:
                logger.error(f"Synapse disconnect error: {e}")

        self._connected = False
        logger.info("Synapse adapter disconnected")

    def publish(
        self,
        msg_type: NexusMessageType,
        payload: Dict[str, Any],
        correlation_id: Optional[str] = None
    ) -> NexusMessage:
        """
        Publish a message to Synapse.

        Falls back to local logging if Synapse unavailable.
        """
        message = NexusMessage(
            id=self._next_message_id(),
            type=msg_type,
            payload=payload,
            correlation_id=correlation_id,
        )

        if self._connected and self._synapse_bus:
            try:
                # Map to core synapse message type
                from core.synapse import MessageType as CoreMsgType
                self._synapse_bus.publish_broadcast(
                    CoreMsgType.SYSTEM_ANNOUNCEMENT,
                    {
                        "nexus_type": msg_type.value,
                        "nexus_payload": payload,
                        "nexus_id": message.id,
                    }
                )
            except Exception as e:
                logger.error(f"Synapse publish failed: {e}")

        # Always log locally
        logger.debug(f"Published: {msg_type.value}")
        return message

    def publish_heartbeat(self, snr_score: float, dream_active: bool = False) -> None:
        """Publish Nexus heartbeat."""
        self.publish(
            NexusMessageType.NEXUS_HEARTBEAT,
            {
                "snr_score": snr_score,
                "dream_active": dream_active,
                "nexus_id": self.nexus_id,
            }
        )

    def publish_discipline_activation(
        self,
        discipline_name: str,
        layer: int,
        activation_count: int
    ) -> None:
        """Publish discipline activation event."""
        self.publish(
            NexusMessageType.DISCIPLINE_ACTIVATED,
            {
                "discipline": discipline_name,
                "layer": layer,
                "activation_count": activation_count,
            }
        )

    def publish_bridge_discovery(
        self,
        source: str,
        target: str,
        bridge_type: str,
        synergy_concepts: List[str]
    ) -> None:
        """Publish bridge discovery event."""
        self.publish(
            NexusMessageType.DISCIPLINE_BRIDGE_DISCOVERED,
            {
                "source": source,
                "target": target,
                "bridge_type": bridge_type,
                "synergy_concepts": synergy_concepts,
            }
        )

    def publish_snr_update(
        self,
        current_snr: float,
        target_snr: float,
        healing_actions: List[str] = None
    ) -> None:
        """Publish SNR update event."""
        self.publish(
            NexusMessageType.SNR_UPDATE,
            {
                "current_snr": current_snr,
                "target_snr": target_snr,
                "meets_target": current_snr >= target_snr,
                "healing_actions": healing_actions or [],
            }
        )

    def publish_dream_event(
        self,
        event_type: str,  # "start" or "complete"
        dream_id: str,
        payload: Dict[str, Any]
    ) -> None:
        """Publish dreaming event."""
        msg_type = (
            NexusMessageType.NEXUS_DREAM_START
            if event_type == "start"
            else NexusMessageType.NEXUS_DREAM_COMPLETE
        )
        self.publish(msg_type, {"dream_id": dream_id, **payload})

    def on(self, msg_type: NexusMessageType, handler: MessageHandler) -> None:
        """Register a message handler."""
        if msg_type not in self._handlers:
            self._handlers[msg_type] = []
        self._handlers[msg_type].append(handler)

    def set_state(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """
        Store shared state.

        Uses Synapse if available, local dict otherwise.
        """
        if self._connected and self._synapse_bus:
            try:
                self._synapse_bus.set_state(f"nexus:{key}", value, ttl)
            except Exception as e:
                logger.error(f"Synapse set_state failed: {e}")

        # Always store locally as backup
        self._local_state[key] = {
            "value": value,
            "timestamp": datetime.utcnow().isoformat(),
        }

    def get_state(self, key: str, default: Any = None) -> Any:
        """
        Retrieve shared state.

        Uses Synapse if available, local dict otherwise.
        """
        if self._connected and self._synapse_bus:
            try:
                result = self._synapse_bus.get_state(f"nexus:{key}")
                if result is not None:
                    return result
            except Exception as e:
                logger.error(f"Synapse get_state failed: {e}")

        # Fall back to local
        local = self._local_state.get(key)
        return local["value"] if local else default

    def acquire_lock(self, lock_name: str, ttl: int = 30) -> bool:
        """Acquire distributed lock."""
        if self._connected and self._synapse_bus:
            try:
                return self._synapse_bus.acquire_lock(f"nexus:{lock_name}", ttl)
            except Exception as e:
                logger.error(f"Synapse acquire_lock failed: {e}")

        # Local mode: always succeed (single instance)
        return True

    def release_lock(self, lock_name: str) -> bool:
        """Release distributed lock."""
        if self._connected and self._synapse_bus:
            try:
                return self._synapse_bus.release_lock(f"nexus:{lock_name}")
            except Exception as e:
                logger.error(f"Synapse release_lock failed: {e}")

        return True

    def get_online_agents(self) -> List[Dict[str, Any]]:
        """Get list of online agents from Synapse."""
        if self._connected and self._synapse_bus:
            try:
                agents = self._synapse_bus.get_online_agents()
                return [
                    {
                        "id": a.agent_id,
                        "name": a.agent_name,
                        "type": a.agent_type,
                        "status": a.status,
                        "capabilities": a.capabilities,
                    }
                    for a in agents
                ]
            except Exception as e:
                logger.error(f"Synapse get_online_agents failed: {e}")

        return []

    def health_check(self) -> Dict[str, Any]:
        """Check Synapse health."""
        if self._connected and self._synapse_bus:
            try:
                from core.synapse import get_synapse
                return get_synapse().health_check()
            except Exception as e:
                return {"status": "error", "error": str(e)}

        return {"status": "local_mode", "connected": False}


if __name__ == "__main__":
    # Self-test
    adapter = SynapseAdapter()

    print("\n" + "=" * 60)
    print("  BIZRA SYNAPSE ADAPTER")
    print("=" * 60)

    print(f"\nConnected: {adapter.is_connected}")

    # Test publish
    print("\n1. Publishing heartbeat...")
    adapter.publish_heartbeat(snr_score=0.97, dream_active=False)
    print("   Done")

    # Test state
    print("\n2. Testing state storage...")
    adapter.set_state("test_key", {"value": 42})
    result = adapter.get_state("test_key")
    print(f"   Stored: {result}")

    # Test lock
    print("\n3. Testing lock...")
    acquired = adapter.acquire_lock("test_lock")
    print(f"   Acquired: {acquired}")
    released = adapter.release_lock("test_lock")
    print(f"   Released: {released}")

    # Health check
    print("\n4. Health check:")
    health = adapter.health_check()
    print(f"   Status: {health['status']}")

    print("\n" + "=" * 60)
