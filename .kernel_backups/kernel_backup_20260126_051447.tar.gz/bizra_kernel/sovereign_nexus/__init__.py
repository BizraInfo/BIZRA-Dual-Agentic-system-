"""
BIZRA Sovereign Nexus - Unified Control Interface
==================================================
The apex orchestrator for BIZRA Sovereign Intelligence, consolidating
11 components into a unified system with:

- 47-Discipline Topology Engine
- Autonomous Dreaming capability
- SNR self-healing optimization (0.95 Ihsan threshold)

Architecture:
    SovereignNexus (Apex)
    ├── Subsystems
    │   ├── NeuralSubsystem (HypergraphRAG + Multimodal)
    │   ├── SymbolicSubsystem (47-discipline synthesis)
    │   ├── AgenticSubsystem (PAT/SAT orchestration)
    │   └── OptimizationSubsystem (SNR self-healing)
    ├── Adapters
    │   ├── RustBridgeAdapter (Rust FFI wrapper)
    │   ├── SynapseAdapter (Trinity Synapse wrapper)
    │   └── DataLakeAdapter (BIZRA-DATA-LAKE bridge)
    ├── DisciplineTopologyEngine (47-discipline mapping)
    └── AutonomousDreamer (proactive hypothesis generation)

Usage:
    from bizra_kernel.sovereign_nexus import SovereignNexus

    nexus = SovereignNexus(
        heartbeat_hz=147.0,
        ihsan_threshold=0.95,
        snr_target=0.95,
        enable_dreaming=True
    )

    # Run the heartbeat loop
    import asyncio
    asyncio.run(nexus.run_heartbeat_loop())
"""

from .nexus import SovereignNexus
from .topology_engine import DisciplineTopologyEngine, DisciplineLayer, Discipline
from .dreamer import AutonomousDreamer, DreamResult

from .subsystems import (
    NeuralSubsystem,
    SymbolicSubsystem,
    AgenticSubsystem,
    OptimizationSubsystem,
)

from .adapters import (
    RustBridgeAdapter,
    SynapseAdapter,
    DataLakeAdapter,
)

__all__ = [
    # Core
    "SovereignNexus",
    "DisciplineTopologyEngine",
    "DisciplineLayer",
    "Discipline",
    "AutonomousDreamer",
    "DreamResult",
    # Subsystems
    "NeuralSubsystem",
    "SymbolicSubsystem",
    "AgenticSubsystem",
    "OptimizationSubsystem",
    # Adapters
    "RustBridgeAdapter",
    "SynapseAdapter",
    "DataLakeAdapter",
]

__version__ = "1.0.0"
