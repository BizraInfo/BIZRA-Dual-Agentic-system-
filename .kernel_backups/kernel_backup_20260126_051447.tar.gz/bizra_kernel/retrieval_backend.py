"""
BIZRA Retrieval Backend - WARP Hypergraph Integration
======================================================

This module provides the integration point between:
1. XTR-WARP (eXtreme Transformation Retrieval with WARP)
2. BIZRA Hypergraph RAG
3. Unified Memory System (BIZRA-DATA-LAKE)

The retrieval backend enables:
- Cross-tier memory retrieval (M1-M6)
- Hypergraph traversal for knowledge synthesis
- Pattern Flow golden gem retrieval
- PoI (Proof-of-Impact) attestation lookup

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                   RETRIEVAL BACKEND                             │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
    │  │   XTR-WARP      │  │   HYPERGRAPH    │  │   DATA LAKE     │ │
    │  │   ADAPTER       │  │   CONNECTOR     │  │   BRIDGE        │ │
    │  │                 │  │                 │  │                 │ │
    │  │ • Dense vectors │  │ • Node traverse │  │ • M1-M6 tiers   │ │
    │  │ • Sparse tokens │  │ • Edge query    │  │ • Gold layer    │ │
    │  │ • Hybrid search │  │ • Path finding  │  │ • PoI ledger    │ │
    │  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
    │                                                                 │
    │  ┌─────────────────────────────────────────────────────────────┐│
    │  │                    UNIFIED QUERY API                        ││
    │  │  retrieve() → HybridResults with source attribution         ││
    │  └─────────────────────────────────────────────────────────────┘│
    └─────────────────────────────────────────────────────────────────┘

Usage:
    from bizra_kernel.retrieval_backend import RetrievalBackend

    backend = RetrievalBackend()
    results = await backend.retrieve("SAPE architecture", top_k=10)

Part of BIZRA Genesis Deployment
"""

import hashlib
import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

# Import Gold Mine connector (lazy to avoid circular imports)
GoldMineConnector = None


def _get_gold_mine_connector_class():
    """Lazy import of GoldMineConnector to avoid circular imports."""
    global GoldMineConnector
    if GoldMineConnector is None:
        from bizra_kernel.gold_mine_connector import GoldMineConnector as GMC
        GoldMineConnector = GMC
    return GoldMineConnector


# Configuration
DATA_LAKE_PATH = Path(os.getenv("DATA_LAKE_PATH", "/mnt/c/BIZRA-DATA-LAKE"))
DATA_LAKE_MCP_URL = os.getenv("DATA_LAKE_MCP_URL", "https://localhost:8443")
CHROMADB_URL = os.getenv("CHROMADB_URL", "http://localhost:8001")


class MemoryTier(Enum):
    """Unified memory tier mapping between Data Lake (M1-M6) and Dual-Agentic (L1-L5)."""
    M1_TASKMASTER = "M1_TaskMaster"      # L1 Immediate Memory
    M2_SHORT_TERM = "M2_ShortTerm"       # L2 Working Memory
    M3_MEDIUM_TERM = "M3_MediumTerm"     # L3 Episodic Memory
    M4_LONG_TERM = "M4_LongTerm"         # L4 Semantic Memory
    M5_HISTORICAL = "M5_Historical"      # L5 Procedural Memory
    M6_SOVEREIGN = "M6_Sovereign"        # Global Context Layer


class RetrievalSource(Enum):
    """Source of retrieved content."""
    WARP = "warp"             # XTR-WARP dense/sparse retrieval
    HYPERGRAPH = "hypergraph" # Neo4j/NetworkX graph traversal
    DATA_LAKE = "data_lake"   # BIZRA-DATA-LAKE storage
    CHROMADB = "chromadb"     # Vector embeddings
    GOLD_MINE = "gold_mine"   # Gold Mine graph (56k nodes, 88k edges)
    CACHE = "cache"           # Local cache hit


@dataclass
class RetrievalResult:
    """Single retrieval result with source attribution."""
    result_id: str
    content: str
    score: float
    source: RetrievalSource
    tier: MemoryTier
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "result_id": self.result_id,
            "content": self.content[:500] + "..." if len(self.content) > 500 else self.content,
            "score": self.score,
            "source": self.source.value,
            "tier": self.tier.value,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
        }


@dataclass
class HybridResults:
    """Combined results from multiple retrieval sources."""
    query: str
    results: List[RetrievalResult] = field(default_factory=list)
    sources_queried: List[RetrievalSource] = field(default_factory=list)
    total_latency_ms: float = 0.0
    cache_hit: bool = False

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "result_count": len(self.results),
            "results": [r.to_dict() for r in self.results[:10]],  # Top 10
            "sources_queried": [s.value for s in self.sources_queried],
            "total_latency_ms": self.total_latency_ms,
            "cache_hit": self.cache_hit,
        }


class WARPAdapter:
    """
    Adapter for XTR-WARP retrieval system.

    XTR-WARP provides:
    - Dense vector retrieval (semantic similarity)
    - Sparse token retrieval (keyword matching)
    - Hybrid fusion of both approaches
    """

    def __init__(self, warp_path: Optional[Path] = None):
        self.warp_path = warp_path or DATA_LAKE_PATH / "xtr-warp"
        self._index_loaded = False

    def is_available(self) -> bool:
        """Check if WARP index is available."""
        return self.warp_path.exists()

    async def dense_retrieve(
        self,
        query: str,
        top_k: int = 10,
    ) -> List[Tuple[str, float]]:
        """
        Dense vector retrieval using semantic embeddings.

        Returns list of (document_id, score) tuples.
        """
        if not self.is_available():
            return []

        # In production, this would call the actual WARP index
        # For now, return placeholder indicating integration point
        logger.info("WARP dense retrieval: query='%s', top_k=%d", query[:50], top_k)
        return []

    async def sparse_retrieve(
        self,
        query: str,
        top_k: int = 10,
    ) -> List[Tuple[str, float]]:
        """
        Sparse token retrieval using BM25/keyword matching.

        Returns list of (document_id, score) tuples.
        """
        if not self.is_available():
            return []

        logger.info("WARP sparse retrieval: query='%s', top_k=%d", query[:50], top_k)
        return []

    async def hybrid_retrieve(
        self,
        query: str,
        top_k: int = 10,
        dense_weight: float = 0.7,
    ) -> List[Tuple[str, float]]:
        """
        Hybrid retrieval combining dense and sparse results.

        Args:
            query: Search query
            top_k: Number of results
            dense_weight: Weight for dense vs sparse (0-1)
        """
        dense_results = await self.dense_retrieve(query, top_k * 2)
        sparse_results = await self.sparse_retrieve(query, top_k * 2)

        # Fuse results using weighted RRF (Reciprocal Rank Fusion)
        fused = self._rrf_fusion(
            dense_results,
            sparse_results,
            dense_weight=dense_weight,
        )

        return fused[:top_k]

    def _rrf_fusion(
        self,
        list1: List[Tuple[str, float]],
        list2: List[Tuple[str, float]],
        dense_weight: float = 0.7,
        k: int = 60,
    ) -> List[Tuple[str, float]]:
        """Reciprocal Rank Fusion for combining ranked lists."""
        sparse_weight = 1.0 - dense_weight
        scores: Dict[str, float] = {}

        for rank, (doc_id, _) in enumerate(list1):
            scores[doc_id] = scores.get(doc_id, 0) + dense_weight / (k + rank + 1)

        for rank, (doc_id, _) in enumerate(list2):
            scores[doc_id] = scores.get(doc_id, 0) + sparse_weight / (k + rank + 1)

        return sorted(scores.items(), key=lambda x: x[1], reverse=True)


class HypergraphConnector:
    """
    Connector to BIZRA Hypergraph for knowledge graph retrieval.

    Supports:
    - Node traversal
    - Edge queries
    - Path finding between concepts
    - Synergy detection paths
    """

    def __init__(self):
        self._neo4j_available = False
        self._networkx_available = False
        self._check_backends()

    def _check_backends(self) -> None:
        """Check available graph backends."""
        try:
            import networkx
            self._networkx_available = True
        except ImportError:
            pass

        # Neo4j check would go here in production

    def is_available(self) -> bool:
        """Check if hypergraph backend is available."""
        return self._networkx_available or self._neo4j_available

    async def query_nodes(
        self,
        query: str,
        node_types: Optional[List[str]] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Query nodes matching criteria."""
        if not self.is_available():
            return []

        logger.info("Hypergraph node query: '%s', types=%s", query[:50], node_types)
        return []

    async def find_synergy_paths(
        self,
        node_ids: List[str],
        max_hops: int = 3,
    ) -> Dict[str, Any]:
        """Find synergy paths between nodes."""
        if not self.is_available():
            return {"paths": [], "synergies": []}

        logger.info("Finding synergy paths: nodes=%s, max_hops=%d", node_ids[:3], max_hops)
        return {"paths": [], "synergies": []}

    async def get_neighbors(
        self,
        node_id: str,
        edge_types: Optional[List[str]] = None,
        depth: int = 1,
    ) -> List[Dict[str, Any]]:
        """Get neighboring nodes."""
        if not self.is_available():
            return []

        return []


class DataLakeBridge:
    """
    Bridge to BIZRA-DATA-LAKE unified memory system.

    Provides access to:
    - M1-M6 memory tiers
    - Gold layer curated data
    - PoI (Proof-of-Impact) ledger
    - Historical October 2025 KEP artifacts
    """

    def __init__(self):
        self.data_lake_path = DATA_LAKE_PATH
        self.gold_path = DATA_LAKE_PATH / "04_GOLD"
        self.indexed_path = DATA_LAKE_PATH / "03_INDEXED"

    def is_available(self) -> bool:
        """Check if Data Lake is accessible."""
        return self.data_lake_path.exists()

    async def query_tier(
        self,
        tier: MemoryTier,
        query: str,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Query a specific memory tier."""
        if not self.is_available():
            return []

        logger.info("Data Lake tier query: tier=%s, query='%s'", tier.value, query[:50])
        return []

    async def query_poi_ledger(
        self,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Query the Proof-of-Impact ledger."""
        poi_path = self.gold_path / "poi_ledger.jsonl"

        if not poi_path.exists():
            return []

        results = []
        try:
            with open(poi_path, 'r') as f:
                for i, line in enumerate(f):
                    if i >= limit:
                        break
                    if line.strip():
                        try:
                            entry = json.loads(line)
                            # Apply filters if provided
                            if filters:
                                match = all(
                                    entry.get(k) == v
                                    for k, v in filters.items()
                                )
                                if not match:
                                    continue
                            results.append(entry)
                        except json.JSONDecodeError:
                            continue
        except Exception as e:
            logger.error("PoI ledger query error: %s", e)

        return results

    async def get_golden_gems(self) -> List[Dict[str, Any]]:
        """Get Pattern Flow golden gems from data lake."""
        gems_path = self.gold_path / "golden_gems.json"

        if not gems_path.exists():
            return []

        try:
            with open(gems_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error("Golden gems load error: %s", e)
            return []

    def get_statistics(self) -> Dict[str, Any]:
        """Get Data Lake statistics."""
        stats = {
            "available": self.is_available(),
            "gold_layer": self.gold_path.exists(),
            "indexed_layer": self.indexed_path.exists(),
            "nodes": 0,
            "edges": 0,
        }

        if self.indexed_path.exists():
            hypergraph_stats = self.indexed_path / "hypergraph_stats.json"
            if hypergraph_stats.exists():
                try:
                    with open(hypergraph_stats, 'r') as f:
                        hg_stats = json.load(f)
                        stats["nodes"] = hg_stats.get("nodes", 0)
                        stats["edges"] = hg_stats.get("edges", 0)
                except Exception:
                    pass

        return stats


class RetrievalBackend:
    """
    Unified retrieval backend for BIZRA knowledge access.

    Integrates:
    - XTR-WARP for hybrid vector retrieval
    - Hypergraph for knowledge graph traversal
    - Data Lake for unified memory access
    - Gold Mine for knowledge graph retrieval (56k nodes, 88k edges)

    Usage:
        backend = RetrievalBackend()
        results = await backend.retrieve("How does SAPE work?", top_k=10)
    """

    def __init__(self):
        self.warp = WARPAdapter()
        self.hypergraph = HypergraphConnector()
        self.data_lake = DataLakeBridge()

        # Gold Mine connector (lazy initialization)
        self._gold_mine = None
        self._gold_mine_initialized = False

        # Result cache
        self._cache: Dict[str, HybridResults] = {}
        self._cache_ttl_seconds = 300  # 5 minutes

        logger.info(
            "RetrievalBackend initialized: WARP=%s, Hypergraph=%s, DataLake=%s, GoldMine=pending",
            self.warp.is_available(),
            self.hypergraph.is_available(),
            self.data_lake.is_available(),
        )

    @property
    def gold_mine(self):
        """Lazy load Gold Mine connector."""
        if self._gold_mine is None:
            GMC = _get_gold_mine_connector_class()
            self._gold_mine = GMC()
        return self._gold_mine

    async def _ensure_gold_mine_initialized(self) -> bool:
        """Ensure Gold Mine connector is initialized."""
        if self._gold_mine_initialized:
            return self.gold_mine.is_available()
        try:
            await self.gold_mine.initialize()
            self._gold_mine_initialized = True
            logger.info("Gold Mine initialized: %s", self.gold_mine.get_statistics())
            return True
        except Exception as e:
            logger.warning("Gold Mine initialization failed: %s", e)
            return False

    async def retrieve(
        self,
        query: str,
        top_k: int = 10,
        sources: Optional[List[RetrievalSource]] = None,
        tiers: Optional[List[MemoryTier]] = None,
        use_cache: bool = True,
    ) -> HybridResults:
        """
        Unified retrieval across all available backends.

        Args:
            query: Natural language query
            top_k: Maximum results to return
            sources: Specific sources to query (default: all available)
            tiers: Specific memory tiers to query
            use_cache: Whether to use result cache

        Returns:
            HybridResults containing fused results with source attribution
        """
        import time
        start = time.perf_counter()

        # Check cache
        cache_key = hashlib.md5(f"{query}:{top_k}:{sources}:{tiers}".encode()).hexdigest()
        if use_cache and cache_key in self._cache:
            cached = self._cache[cache_key]
            cached.cache_hit = True
            return cached

        # Initialize results
        hybrid = HybridResults(query=query)
        all_results: List[RetrievalResult] = []

        # Determine sources to query
        if sources is None:
            sources = [
                s for s in RetrievalSource
                if self._is_source_available(s)
            ]

        # Query each source
        for source in sources:
            hybrid.sources_queried.append(source)

            if source == RetrievalSource.WARP:
                warp_results = await self._query_warp(query, top_k)
                all_results.extend(warp_results)

            elif source == RetrievalSource.HYPERGRAPH:
                graph_results = await self._query_hypergraph(query, top_k)
                all_results.extend(graph_results)

            elif source == RetrievalSource.DATA_LAKE:
                lake_results = await self._query_data_lake(query, top_k, tiers)
                all_results.extend(lake_results)

            elif source == RetrievalSource.GOLD_MINE:
                gold_mine_results = await self._query_gold_mine(query, top_k)
                all_results.extend(gold_mine_results)

        # Sort by score and deduplicate
        all_results.sort(key=lambda r: r.score, reverse=True)
        seen_ids: set = set()
        unique_results = []
        for r in all_results:
            if r.result_id not in seen_ids:
                seen_ids.add(r.result_id)
                unique_results.append(r)

        hybrid.results = unique_results[:top_k]
        hybrid.total_latency_ms = (time.perf_counter() - start) * 1000

        # Cache results
        if use_cache:
            self._cache[cache_key] = hybrid

        return hybrid

    def _is_source_available(self, source: RetrievalSource) -> bool:
        """Check if a retrieval source is available."""
        if source == RetrievalSource.WARP:
            return self.warp.is_available()
        elif source == RetrievalSource.HYPERGRAPH:
            return self.hypergraph.is_available()
        elif source == RetrievalSource.DATA_LAKE:
            return self.data_lake.is_available()
        elif source == RetrievalSource.GOLD_MINE:
            return self.gold_mine.is_available()
        return False

    async def _query_warp(
        self,
        query: str,
        top_k: int,
    ) -> List[RetrievalResult]:
        """Query WARP backend."""
        warp_results = await self.warp.hybrid_retrieve(query, top_k)

        return [
            RetrievalResult(
                result_id=f"warp_{doc_id}",
                content=f"[WARP Result: {doc_id}]",  # Would fetch actual content
                score=score,
                source=RetrievalSource.WARP,
                tier=MemoryTier.M4_LONG_TERM,
                metadata={"doc_id": doc_id},
            )
            for doc_id, score in warp_results
        ]

    async def _query_hypergraph(
        self,
        query: str,
        top_k: int,
    ) -> List[RetrievalResult]:
        """Query hypergraph backend."""
        nodes = await self.hypergraph.query_nodes(query, limit=top_k)

        return [
            RetrievalResult(
                result_id=f"graph_{node.get('id', i)}",
                content=node.get("content", str(node)),
                score=node.get("score", 0.5),
                source=RetrievalSource.HYPERGRAPH,
                tier=MemoryTier.M3_MEDIUM_TERM,
                metadata=node,
            )
            for i, node in enumerate(nodes)
        ]

    async def _query_data_lake(
        self,
        query: str,
        top_k: int,
        tiers: Optional[List[MemoryTier]] = None,
    ) -> List[RetrievalResult]:
        """Query data lake backend."""
        if tiers is None:
            tiers = [MemoryTier.M4_LONG_TERM, MemoryTier.M6_SOVEREIGN]

        all_results = []
        for tier in tiers:
            tier_results = await self.data_lake.query_tier(tier, query, top_k)
            for i, item in enumerate(tier_results):
                all_results.append(RetrievalResult(
                    result_id=f"lake_{tier.value}_{i}",
                    content=item.get("content", str(item)),
                    score=item.get("score", 0.5),
                    source=RetrievalSource.DATA_LAKE,
                    tier=tier,
                    metadata=item,
                ))

        return all_results

    async def _query_gold_mine(
        self,
        query: str,
        top_k: int,
    ) -> List[RetrievalResult]:
        """
        Query Gold Mine knowledge graph.

        Uses entity-based search to find relevant documents and entities
        from the 56k node / 88k edge graph.
        """
        # Ensure Gold Mine is initialized
        if not await self._ensure_gold_mine_initialized():
            return []

        results = []

        # Extract key terms from query for entity lookup
        query_terms = [term.strip() for term in query.lower().split() if len(term) > 3]

        # Query by each significant term
        seen_ids: set = set()
        for term in query_terms[:5]:  # Limit to 5 terms
            nodes = self.gold_mine.query_by_entity(term, limit=top_k // 2)
            for node in nodes:
                if node.id not in seen_ids:
                    seen_ids.add(node.id)

                    # Calculate relevance score based on match quality
                    label_lower = node.label.lower()
                    if term in label_lower:
                        score = 0.9 if node.kind == "Entity" else 0.8
                    else:
                        score = 0.7

                    results.append(RetrievalResult(
                        result_id=f"goldmine_{node.id}",
                        content=f"[{node.kind}] {node.label}" + (f" (source: {node.source})" if node.source else ""),
                        score=score,
                        source=RetrievalSource.GOLD_MINE,
                        tier=MemoryTier.M4_LONG_TERM,
                        metadata={
                            "node_id": node.id,
                            "node_kind": node.kind,
                            "node_source": node.source,
                        },
                    ))

                    if len(results) >= top_k:
                        break

            if len(results) >= top_k:
                break

        # Sort by score and return top_k
        results.sort(key=lambda r: r.score, reverse=True)
        return results[:top_k]

    def get_statistics(self) -> Dict[str, Any]:
        """Get retrieval backend statistics."""
        stats = {
            "warp": {
                "available": self.warp.is_available(),
            },
            "hypergraph": {
                "available": self.hypergraph.is_available(),
            },
            "data_lake": self.data_lake.get_statistics(),
            "cache_size": len(self._cache),
        }

        # Add Gold Mine stats if available
        if self._gold_mine is not None:
            stats["gold_mine"] = self.gold_mine.get_statistics()
        else:
            stats["gold_mine"] = {"available": self.gold_mine.is_available(), "initialized": False}

        return stats


# Module-level convenience function
_backend: Optional[RetrievalBackend] = None


def get_retrieval_backend() -> RetrievalBackend:
    """Get or create the global retrieval backend instance."""
    global _backend
    if _backend is None:
        _backend = RetrievalBackend()
    return _backend
