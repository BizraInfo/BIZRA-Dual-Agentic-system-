"""
PAT Live Telemetry - Real-Time Metrics Collection & Monitoring
==============================================================
Production-grade telemetry for the PAT enforcement layer.

Provides:
- Real-time SNR tracking with trend analysis
- Gate pass/fail rate monitoring
- Novelty score distribution
- Correction effectiveness metrics
- Alert thresholds and escalation

Integration Points:
- Prometheus metrics export (port 8080/metrics)
- Redis pub/sub for real-time updates
- Evidence receipt correlation
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from collections import deque
from enum import Enum
import asyncio
import json
import time
import statistics


class AlertLevel(Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    ESCALATE = "escalate"


class MetricType(Enum):
    """Types of PAT metrics."""
    SNR_CURRENT = "pat_snr_current"
    SNR_AVERAGE = "pat_snr_average"
    SNR_MINIMUM = "pat_snr_minimum"
    NOVELTY_CURRENT = "pat_novelty_current"
    NOVELTY_AVERAGE = "pat_novelty_average"
    GATE_PASS_RATE = "pat_gate_pass_rate"
    CORRECTION_RATE = "pat_correction_rate"
    DOMAIN_COUNT = "pat_domain_count"
    PRACTITIONER_COVERAGE = "pat_practitioner_coverage"
    LATENCY_MS = "pat_latency_ms"
    RECEIPTS_TOTAL = "pat_receipts_total"
    GATES_PASSED = "pat_gates_passed"
    # Aliases for convenience
    SNR = "pat_snr_current"
    NOVELTY = "pat_novelty_current"
    DOMAINS = "pat_domain_count"


@dataclass
class MetricSample:
    """A single metric sample."""
    metric_type: MetricType
    value: float
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    labels: Dict[str, str] = field(default_factory=dict)

    def to_prometheus(self) -> str:
        """Format as Prometheus metric line."""
        label_str = ",".join([f'{k}="{v}"' for k, v in self.labels.items()])
        if label_str:
            return f'{self.metric_type.value}{{{label_str}}} {self.value}'
        return f'{self.metric_type.value} {self.value}'


@dataclass
class Alert:
    """A telemetry alert."""
    level: AlertLevel
    metric: MetricType
    message: str
    current_value: float
    threshold: float
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> dict:
        return {
            "level": self.level.value,
            "metric": self.metric.value,
            "message": self.message,
            "current_value": self.current_value,
            "threshold": self.threshold,
            "timestamp": self.timestamp,
        }


@dataclass
class TelemetryReport:
    """Comprehensive telemetry report."""
    session_id: str
    period_start: str
    period_end: str
    snr_stats: Dict[str, float]
    novelty_stats: Dict[str, float]
    gate_stats: Dict[str, Any]
    correction_stats: Dict[str, int]
    alerts: List[Alert]
    sample_count: int

    # Convenience properties for direct access
    @property
    def snr_average(self) -> float:
        return self.snr_stats.get('average', 0.0)

    @property
    def snr_min(self) -> float:
        return self.snr_stats.get('min', 0.0)

    @property
    def snr_max(self) -> float:
        return self.snr_stats.get('max', 0.0)

    @property
    def novelty_average(self) -> float:
        return self.novelty_stats.get('average', 0.0)

    @property
    def novelty_min(self) -> float:
        return self.novelty_stats.get('min', 0.0)

    @property
    def novelty_max(self) -> float:
        return self.novelty_stats.get('max', 0.0)

    @property
    def domains_average(self) -> float:
        return self.gate_stats.get('domains_average', 0.0)

    @property
    def domains_max(self) -> int:
        return int(self.gate_stats.get('domains_max', 0))

    @property
    def gates_passed_total(self) -> int:
        return int(self.gate_stats.get('passed', 0))

    @property
    def overall_status(self) -> str:
        if self.snr_average >= 0.98 and self.novelty_average >= 0.75:
            return "OPTIMAL"
        elif self.snr_average >= 0.95:
            return "ACCEPTABLE"
        else:
            return "DEGRADED"

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "period": {"start": self.period_start, "end": self.period_end},
            "snr": self.snr_stats,
            "novelty": self.novelty_stats,
            "gates": self.gate_stats,
            "corrections": self.correction_stats,
            "alerts": [a.to_dict() for a in self.alerts],
            "samples": self.sample_count,
        }


class PATTelemetry:
    """
    PAT Live Telemetry System.

    Real-time monitoring and alerting for PAT enforcement metrics.

    Features:
    - Rolling window statistics (5m, 15m, 1h)
    - Threshold-based alerting
    - Prometheus-compatible export
    - Redis pub/sub integration
    """

    # Alert thresholds
    ALERT_THRESHOLDS = {
        MetricType.SNR_CURRENT: {
            AlertLevel.WARNING: 0.96,
            AlertLevel.CRITICAL: 0.94,
            AlertLevel.ESCALATE: 0.90,
        },
        MetricType.NOVELTY_CURRENT: {
            AlertLevel.WARNING: 0.72,
            AlertLevel.CRITICAL: 0.68,
            AlertLevel.ESCALATE: 0.60,
        },
        MetricType.GATE_PASS_RATE: {
            AlertLevel.WARNING: 0.80,
            AlertLevel.CRITICAL: 0.60,
            AlertLevel.ESCALATE: 0.40,
        },
    }

    # Rolling window sizes
    WINDOW_5M = 300    # 5 minutes in seconds
    WINDOW_15M = 900   # 15 minutes
    WINDOW_1H = 3600   # 1 hour

    def __init__(
        self,
        session_id: Optional[str] = None,
        redis_client: Optional[Any] = None,
        max_samples: int = 10000,
    ):
        """
        Initialize PAT telemetry.

        Args:
            session_id: Session identifier (defaults to 'default')
            redis_client: Optional Redis client for pub/sub
            max_samples: Maximum samples to retain in memory
        """
        self.session_id = session_id or "default"
        self.redis = redis_client
        self.max_samples = max_samples

        # Sample storage (deque for efficient rolling window)
        self.samples: Dict[MetricType, deque] = {
            metric: deque(maxlen=max_samples)
            for metric in MetricType
        }

        # Timestamps for each sample (parallel deques)
        self.timestamps: Dict[MetricType, deque] = {
            metric: deque(maxlen=max_samples)
            for metric in MetricType
        }

        # Alert history
        self.alerts: deque = deque(maxlen=1000)

        # Counters
        self.total_samples = 0
        self.total_alerts = 0

        # Callbacks for real-time notifications
        self.alert_callbacks: List[Callable[[Alert], None]] = []

        # Start time
        self.start_time = datetime.utcnow()

    def record(self, metric_type: MetricType, value: float, labels: Optional[Dict[str, str]] = None) -> None:
        """
        Record a metric sample.

        Args:
            metric_type: Type of metric
            value: Metric value
            labels: Optional labels for the metric
        """
        now = time.time()
        self.samples[metric_type].append(value)
        self.timestamps[metric_type].append(now)
        self.total_samples += 1

        # Check for alert conditions
        self._check_alerts(metric_type, value)

        # Publish to Redis if available
        if self.redis:
            self._publish_to_redis(metric_type, value, labels)

    def record_batch(self, metrics: Dict[MetricType, float]) -> None:
        """Record multiple metrics at once."""
        for metric_type, value in metrics.items():
            self.record(metric_type, value)

    def _check_alerts(self, metric_type: MetricType, value: float) -> None:
        """Check if value triggers any alerts."""
        thresholds = self.ALERT_THRESHOLDS.get(metric_type)
        if not thresholds:
            return

        # Check thresholds in order of severity (most severe first)
        for level in [AlertLevel.ESCALATE, AlertLevel.CRITICAL, AlertLevel.WARNING]:
            threshold = thresholds.get(level)
            if threshold and value < threshold:
                alert = Alert(
                    level=level,
                    metric=metric_type,
                    message=f"{metric_type.value} dropped to {value:.3f} (threshold: {threshold})",
                    current_value=value,
                    threshold=threshold,
                )
                self._emit_alert(alert)
                break  # Only emit the most severe alert

    def _emit_alert(self, alert: Alert) -> None:
        """Emit an alert."""
        self.alerts.append(alert)
        self.total_alerts += 1

        # Call registered callbacks
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception:
                pass  # Don't let callback errors break telemetry

        # Publish to Redis if available
        if self.redis:
            self._publish_alert_to_redis(alert)

    def _publish_to_redis(self, metric_type: MetricType, value: float, labels: Optional[Dict[str, str]] = None) -> None:
        """Publish metric to Redis pub/sub."""
        if not self.redis:
            return

        try:
            channel = f"bizra:telemetry:pat:{metric_type.value}"
            message = json.dumps({
                "session_id": self.session_id,
                "metric": metric_type.value,
                "value": value,
                "labels": labels or {},
                "timestamp": datetime.utcnow().isoformat(),
            })
            self.redis.publish(channel, message)
        except Exception:
            pass  # Graceful degradation

    def _publish_alert_to_redis(self, alert: Alert) -> None:
        """Publish alert to Redis."""
        if not self.redis:
            return

        try:
            channel = f"bizra:alerts:pat:{alert.level.value}"
            self.redis.publish(channel, json.dumps(alert.to_dict()))
        except Exception:
            pass

    def register_alert_callback(self, callback: Callable[[Alert], None]) -> None:
        """Register a callback for alert notifications."""
        self.alert_callbacks.append(callback)

    def get_window_stats(self, metric_type: MetricType, window_seconds: int) -> Dict[str, float]:
        """
        Get statistics for a metric over a time window.

        Args:
            metric_type: Metric to analyze
            window_seconds: Window size in seconds

        Returns:
            Dict with min, max, avg, stddev, count
        """
        cutoff = time.time() - window_seconds
        samples = self.samples[metric_type]
        timestamps = self.timestamps[metric_type]

        # Filter to window
        window_samples = [
            s for s, t in zip(samples, timestamps)
            if t >= cutoff
        ]

        if not window_samples:
            return {"min": 0, "max": 0, "avg": 0, "stddev": 0, "count": 0}

        return {
            "min": min(window_samples),
            "max": max(window_samples),
            "avg": statistics.mean(window_samples),
            "stddev": statistics.stdev(window_samples) if len(window_samples) > 1 else 0,
            "count": len(window_samples),
        }

    def get_snr_trend(self, window_seconds: int = 300) -> str:
        """
        Determine SNR trend over a window.

        Returns: "rising", "stable", or "falling"
        """
        stats_5m = self.get_window_stats(MetricType.SNR_CURRENT, window_seconds)
        samples = list(self.samples[MetricType.SNR_CURRENT])

        if stats_5m["count"] < 3:
            return "stable"

        # Compare first half to second half
        mid = len(samples) // 2
        if mid < 2:
            return "stable"

        recent = samples[-mid:]
        earlier = samples[-2*mid:-mid] if len(samples) >= 2*mid else samples[:mid]

        if not recent or not earlier:
            return "stable"

        recent_avg = statistics.mean(recent)
        earlier_avg = statistics.mean(earlier)

        diff = recent_avg - earlier_avg
        if diff > 0.01:
            return "rising"
        elif diff < -0.01:
            return "falling"
        return "stable"

    def generate_report(self, window_seconds: int = 900) -> TelemetryReport:
        """
        Generate a comprehensive telemetry report.

        Args:
            window_seconds: Report window in seconds

        Returns:
            TelemetryReport with all statistics
        """
        now = datetime.utcnow()
        period_start = (now - timedelta(seconds=window_seconds)).isoformat()

        # SNR statistics
        snr_stats = self.get_window_stats(MetricType.SNR_CURRENT, window_seconds)
        snr_stats["trend"] = self.get_snr_trend(window_seconds)

        # Novelty statistics
        novelty_stats = self.get_window_stats(MetricType.NOVELTY_CURRENT, window_seconds)

        # Gate statistics
        gate_stats = self.get_window_stats(MetricType.GATE_PASS_RATE, window_seconds)

        # Correction statistics
        correction_samples = list(self.samples[MetricType.CORRECTION_RATE])
        correction_stats = {
            "total_corrections": len(correction_samples),
            "avg_rate": statistics.mean(correction_samples) if correction_samples else 0,
        }

        # Recent alerts
        cutoff = time.time() - window_seconds
        recent_alerts = [
            a for a in self.alerts
            if datetime.fromisoformat(a.timestamp).timestamp() >= cutoff
        ]

        return TelemetryReport(
            session_id=self.session_id,
            period_start=period_start,
            period_end=now.isoformat(),
            snr_stats=snr_stats,
            novelty_stats=novelty_stats,
            gate_stats=gate_stats,
            correction_stats=correction_stats,
            alerts=recent_alerts,
            sample_count=self.total_samples,
        )

    def export_prometheus(self) -> str:
        """Export all current metrics in Prometheus format."""
        lines = [
            "# HELP pat_snr_current Current PAT SNR score",
            "# TYPE pat_snr_current gauge",
        ]

        for metric_type in MetricType:
            samples = self.samples[metric_type]
            if samples:
                latest = samples[-1]
                lines.append(f'{metric_type.value}{{session_id="{self.session_id}"}} {latest}')

        # Add summary statistics
        snr_stats = self.get_window_stats(MetricType.SNR_CURRENT, self.WINDOW_5M)
        lines.append(f'pat_snr_5m_avg{{session_id="{self.session_id}"}} {snr_stats["avg"]}')
        lines.append(f'pat_snr_5m_min{{session_id="{self.session_id}"}} {snr_stats["min"]}')

        # Alert counters
        lines.append(f'pat_alerts_total{{session_id="{self.session_id}"}} {self.total_alerts}')

        return "\n".join(lines)

    def get_dashboard_data(self) -> dict:
        """Get data formatted for dashboard display."""
        return {
            "session_id": self.session_id,
            "uptime_seconds": (datetime.utcnow() - self.start_time).total_seconds(),
            "total_samples": self.total_samples,
            "total_alerts": self.total_alerts,
            "snr": {
                "current": self.samples[MetricType.SNR_CURRENT][-1] if self.samples[MetricType.SNR_CURRENT] else 0,
                "trend": self.get_snr_trend(),
                "5m": self.get_window_stats(MetricType.SNR_CURRENT, self.WINDOW_5M),
                "15m": self.get_window_stats(MetricType.SNR_CURRENT, self.WINDOW_15M),
                "1h": self.get_window_stats(MetricType.SNR_CURRENT, self.WINDOW_1H),
            },
            "novelty": {
                "current": self.samples[MetricType.NOVELTY_CURRENT][-1] if self.samples[MetricType.NOVELTY_CURRENT] else 0,
                "5m": self.get_window_stats(MetricType.NOVELTY_CURRENT, self.WINDOW_5M),
            },
            "gates": {
                "pass_rate": self.samples[MetricType.GATE_PASS_RATE][-1] if self.samples[MetricType.GATE_PASS_RATE] else 0,
            },
            "recent_alerts": [a.to_dict() for a in list(self.alerts)[-10:]],
        }


class TelemetryCollector:
    """
    Collector that aggregates telemetry from multiple PAT sessions.

    Used for system-wide monitoring and dashboards.
    """

    def __init__(self):
        self.sessions: Dict[str, PATTelemetry] = {}
        self.global_alerts: deque = deque(maxlen=10000)

    def get_or_create_session(self, session_id: str) -> PATTelemetry:
        """Get or create a telemetry session."""
        if session_id not in self.sessions:
            telemetry = PATTelemetry(session_id)
            telemetry.register_alert_callback(self._on_session_alert)
            self.sessions[session_id] = telemetry
        return self.sessions[session_id]

    def _on_session_alert(self, alert: Alert) -> None:
        """Handle alerts from any session."""
        self.global_alerts.append(alert)

    def get_system_stats(self) -> dict:
        """Get system-wide statistics."""
        active_sessions = len(self.sessions)
        total_samples = sum(t.total_samples for t in self.sessions.values())
        total_alerts = sum(t.total_alerts for t in self.sessions.values())

        # Aggregate SNR across all sessions
        all_snr = []
        for telemetry in self.sessions.values():
            if telemetry.samples[MetricType.SNR_CURRENT]:
                all_snr.append(telemetry.samples[MetricType.SNR_CURRENT][-1])

        return {
            "active_sessions": active_sessions,
            "total_samples": total_samples,
            "total_alerts": total_alerts,
            "system_snr": statistics.mean(all_snr) if all_snr else 0,
            "recent_alerts": [a.to_dict() for a in list(self.global_alerts)[-20:]],
        }

    def export_all_prometheus(self) -> str:
        """Export all sessions in Prometheus format."""
        lines = []
        for session_id, telemetry in self.sessions.items():
            lines.append(telemetry.export_prometheus())
        return "\n".join(lines)


# Global collector instance
_collector: Optional[TelemetryCollector] = None


def get_telemetry_collector() -> TelemetryCollector:
    """Get the global telemetry collector."""
    global _collector
    if _collector is None:
        _collector = TelemetryCollector()
    return _collector


if __name__ == "__main__":
    # Demo the telemetry system
    print("=" * 60)
    print("PAT TELEMETRY DEMO")
    print("=" * 60)

    telemetry = PATTelemetry("demo-session")

    # Register alert callback
    def on_alert(alert: Alert):
        print(f"  ALERT [{alert.level.value.upper()}]: {alert.message}")

    telemetry.register_alert_callback(on_alert)

    # Simulate some metrics
    import random

    print("\nSimulating metrics...")
    for i in range(20):
        # SNR with some variation
        snr = 0.97 + random.uniform(-0.05, 0.02)
        telemetry.record(MetricType.SNR_CURRENT, snr)

        # Novelty
        novelty = 0.78 + random.uniform(-0.1, 0.1)
        telemetry.record(MetricType.NOVELTY_CURRENT, novelty)

        # Gate pass rate
        gate_rate = 0.85 + random.uniform(-0.2, 0.15)
        telemetry.record(MetricType.GATE_PASS_RATE, gate_rate)

    # Generate report
    report = telemetry.generate_report(window_seconds=60)
    print(f"\nTelemetry Report:")
    print(f"  SNR: avg={report.snr_stats['avg']:.3f}, trend={report.snr_stats.get('trend', 'unknown')}")
    print(f"  Novelty: avg={report.novelty_stats['avg']:.3f}")
    print(f"  Gates: avg pass rate={report.gate_stats['avg']:.3f}")
    print(f"  Alerts: {len(report.alerts)}")
    print(f"  Total Samples: {report.sample_count}")

    # Export Prometheus format
    print("\nPrometheus Export (first 500 chars):")
    print(telemetry.export_prometheus()[:500])
