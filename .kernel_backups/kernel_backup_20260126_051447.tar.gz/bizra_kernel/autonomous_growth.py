"""
BIZRA Autonomous Growth Engine - Forest Growth Protocol Phase 1

Orchestrates growth cycles, triggers reproduction, and enforces thresholds.
Implements the biblical seed metaphor: 7 first seeds from Node0.

Features:
- Automatic lifecycle advancement
- Ihsān-gated reproduction (0.95 threshold)
- PoI-triggered state transitions
- Network effect calculation
- Receipt-first evidence generation
"""

import json
import hashlib
import threading
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from pathlib import Path

from .seed_manager import SeedManager, Seed, SeedState, REPRODUCTION_REQUIREMENTS


class GrowthTrigger(Enum):
    """Triggers that can advance seed lifecycle or enable reproduction."""
    POI_THRESHOLD = "poi_threshold"       # 10+ PoI events
    AGE_THRESHOLD = "age_threshold"       # 7+ days old
    IHSAN_THRESHOLD = "ihsan_threshold"   # 0.95+ score
    MANUAL = "manual"                     # Explicit trigger
    COVENANT_ACCEPTED = "covenant_accepted"


@dataclass
class GrowthCycle:
    """Record of a single growth cycle execution."""
    cycle_id: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    seeds_evaluated: int = 0
    seeds_germinated: int = 0
    seeds_advanced: int = 0
    reproduction_events: int = 0
    new_seed_ids: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for storage/receipts."""
        return {
            "cycle_id": self.cycle_id,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "seeds_evaluated": self.seeds_evaluated,
            "seeds_germinated": self.seeds_germinated,
            "seeds_advanced": self.seeds_advanced,
            "reproduction_events": self.reproduction_events,
            "new_seed_ids": self.new_seed_ids,
            "errors": self.errors,
        }


class AutonomousGrowthEngine:
    """
    Orchestrates the BIZRA seed forest growth cycles.

    Responsibilities:
    - Run periodic growth cycles
    - Evaluate seed eligibility for advancement
    - Trigger reproduction when thresholds met
    - Calculate network health metrics
    - Emit evidence receipts
    """

    # First generation limit (biblical metaphor)
    MAX_FIRST_GENERATION = 7

    def __init__(self, seed_manager: SeedManager):
        self._seed_manager = seed_manager
        self._lock = threading.RLock()
        self._cycles: List[GrowthCycle] = []
        self._receipts_dir = Path("docs/evidence/receipts")
        self._receipts_dir.mkdir(parents=True, exist_ok=True)
        self._cycle_count = 0

    def _generate_cycle_id(self) -> str:
        """Generate unique cycle ID."""
        self._cycle_count += 1
        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        return f"CYCLE-{timestamp}-{self._cycle_count:04d}"

    def _emit_receipt(self, event_type: str, cycle: GrowthCycle, details: Dict[str, Any]) -> str:
        """Emit evidence receipt for growth events."""
        receipt_id = hashlib.sha256(
            f"{event_type}:{cycle.cycle_id}:{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()[:16]

        receipt = {
            "receipt_id": receipt_id,
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "cycle_id": cycle.cycle_id,
            "details": details,
            "integrity_hash": hashlib.sha256(
                json.dumps(details, sort_keys=True).encode()
            ).hexdigest(),
        }

        receipt_file = self._receipts_dir / "growth_cycle_receipts.jsonl"
        with open(receipt_file, "a") as f:
            f.write(json.dumps(receipt) + "\n")

        return receipt_id

    def run_growth_cycle(self) -> GrowthCycle:
        """
        Execute a complete growth cycle across all seeds.

        Steps:
        1. Evaluate all DORMANT seeds for germination
        2. Check all seeds for lifecycle advancement
        3. Trigger reproduction for eligible FRUITING/ELDER seeds
        4. Calculate network metrics
        5. Emit cycle receipt

        Returns:
            GrowthCycle record with results
        """
        with self._lock:
            cycle = GrowthCycle(
                cycle_id=self._generate_cycle_id(),
                started_at=datetime.utcnow(),
            )

            all_seeds = self._seed_manager.get_all_seeds()
            cycle.seeds_evaluated = len(all_seeds)

            # Phase 1: Germinate dormant seeds
            for seed in all_seeds:
                if seed.state == SeedState.DORMANT:
                    if self._seed_manager.germinate(seed.seed_id):
                        cycle.seeds_germinated += 1

            # Phase 2: Advance lifecycle where eligible
            for seed in all_seeds:
                triggers = self.evaluate_seed(seed.seed_id)
                if triggers:
                    new_state = self._seed_manager.advance_lifecycle(seed.seed_id)
                    if new_state:
                        cycle.seeds_advanced += 1

            # Phase 3: Reproduction for eligible seeds
            # Refresh list after advancements
            all_seeds = self._seed_manager.get_all_seeds()
            for seed in all_seeds:
                if self._seed_manager.can_reproduce(seed.seed_id):
                    new_seed = self.trigger_reproduction(seed.seed_id)
                    if new_seed:
                        cycle.reproduction_events += 1
                        cycle.new_seed_ids.append(new_seed.seed_id)

            cycle.completed_at = datetime.utcnow()
            self._cycles.append(cycle)

            # Emit cycle receipt
            self._emit_receipt("growth_cycle_completed", cycle, {
                "duration_ms": (cycle.completed_at - cycle.started_at).total_seconds() * 1000,
                "seeds_evaluated": cycle.seeds_evaluated,
                "seeds_germinated": cycle.seeds_germinated,
                "seeds_advanced": cycle.seeds_advanced,
                "reproduction_events": cycle.reproduction_events,
                "new_seeds": cycle.new_seed_ids,
                "forest_metrics": self.get_forest_metrics(),
            })

            return cycle

    def evaluate_seed(self, seed_id: str) -> List[GrowthTrigger]:
        """
        Evaluate which growth triggers are active for a seed.

        Args:
            seed_id: Seed to evaluate

        Returns:
            List of active triggers
        """
        with self._lock:
            seed = self._seed_manager.get_seed(seed_id)
            if not seed:
                return []

            triggers = []

            # Check PoI threshold (10+ events)
            if seed.poi_events >= REPRODUCTION_REQUIREMENTS["min_poi_events"]:
                triggers.append(GrowthTrigger.POI_THRESHOLD)

            # Check Ihsān threshold (0.95+)
            if seed.ihsan_score >= REPRODUCTION_REQUIREMENTS["min_ihsan_score"]:
                triggers.append(GrowthTrigger.IHSAN_THRESHOLD)

            # Check age threshold (7+ days)
            if seed.germinated_at:
                age_days = (datetime.utcnow() - seed.germinated_at).days
                if age_days >= REPRODUCTION_REQUIREMENTS["min_age_days"]:
                    triggers.append(GrowthTrigger.AGE_THRESHOLD)

            # Check covenant
            if seed.covenant_accepted:
                triggers.append(GrowthTrigger.COVENANT_ACCEPTED)

            return triggers

    def trigger_reproduction(self, parent_id: str) -> Optional[Seed]:
        """
        Trigger reproduction for a parent seed.

        Creates a new child seed if parent meets all requirements.
        Enforces first generation limit (7 seeds from Node0).

        Args:
            parent_id: Parent seed ID

        Returns:
            New child Seed if created, None otherwise
        """
        with self._lock:
            if not self._seed_manager.can_reproduce(parent_id):
                return None

            parent = self._seed_manager.get_seed(parent_id)
            if not parent:
                return None

            # Enforce first generation limit for Node0
            if parent.parent_id is None:
                # This is Node0 - check first generation limit
                if len(parent.children) >= self.MAX_FIRST_GENERATION:
                    print(f"[LIMIT REACHED] Node0 has reached max first generation ({self.MAX_FIRST_GENERATION})")
                    return None

            # Create new seed
            new_seed = self._seed_manager.create_seed(parent_id=parent_id)

            # Emit reproduction receipt
            self._emit_receipt("reproduction_event", GrowthCycle(
                cycle_id="REPRO-" + datetime.utcnow().strftime("%Y%m%d%H%M%S"),
                started_at=datetime.utcnow(),
            ), {
                "parent_id": parent_id,
                "child_id": new_seed.seed_id,
                "parent_ihsan": parent.ihsan_score,
                "parent_poi_events": parent.poi_events,
                "parent_children_count": len(parent.children),
                "child_depth": new_seed.depth,
            })

            print(f"[REPRODUCTION] {parent_id} → {new_seed.seed_id} (depth={new_seed.depth})")
            return new_seed

    def calculate_network_effect(self) -> float:
        """
        Calculate the network effect score based on forest health.

        Factors:
        - Total seeds (logarithmic scaling)
        - Average Ihsān score
        - Reproductive potential
        - Depth diversity

        Returns:
            Network effect score (0.0 to 1.0)
        """
        with self._lock:
            stats = self._seed_manager.get_forest_stats()

            if stats["total_seeds"] == 0:
                return 0.0

            # Factor 1: Seed count (log scale, caps at 100 seeds)
            import math
            seed_factor = min(1.0, math.log10(stats["total_seeds"] + 1) / 2)

            # Factor 2: Average Ihsān across all seeds
            all_seeds = self._seed_manager.get_all_seeds()
            if all_seeds:
                avg_ihsan = sum(s.ihsan_score for s in all_seeds) / len(all_seeds)
            else:
                avg_ihsan = 0.0
            ihsan_factor = avg_ihsan

            # Factor 3: Reproductive potential
            repro_count = stats.get("can_reproduce_count", 0)
            repro_factor = min(1.0, repro_count / max(1, stats["total_seeds"]) * 3)

            # Factor 4: Depth diversity (reward deep trees)
            depth_factor = min(1.0, stats.get("max_depth", 0) / 5)

            # Weighted combination
            network_effect = (
                seed_factor * 0.25 +
                ihsan_factor * 0.35 +
                repro_factor * 0.25 +
                depth_factor * 0.15
            )

            return min(1.0, network_effect)

    def get_forest_metrics(self) -> Dict[str, Any]:
        """
        Get comprehensive forest metrics.

        Returns:
            Dictionary with forest health indicators
        """
        with self._lock:
            stats = self._seed_manager.get_forest_stats()
            network_effect = self.calculate_network_effect()

            # Calculate generation distribution
            all_seeds = self._seed_manager.get_all_seeds()
            generation_dist = {}
            for seed in all_seeds:
                gen = seed.depth
                generation_dist[f"gen_{gen}"] = generation_dist.get(f"gen_{gen}", 0) + 1

            # Calculate average metrics
            if all_seeds:
                avg_ihsan = sum(s.ihsan_score for s in all_seeds) / len(all_seeds)
                avg_poi = sum(s.poi_events for s in all_seeds) / len(all_seeds)
                covenant_rate = sum(1 for s in all_seeds if s.covenant_accepted) / len(all_seeds)
            else:
                avg_ihsan = 0.0
                avg_poi = 0.0
                covenant_rate = 0.0

            return {
                "timestamp": datetime.utcnow().isoformat(),
                "total_seeds": stats["total_seeds"],
                "state_distribution": stats["state_distribution"],
                "generation_distribution": generation_dist,
                "network_effect": network_effect,
                "average_ihsan_score": avg_ihsan,
                "average_poi_events": avg_poi,
                "covenant_acceptance_rate": covenant_rate,
                "total_token_balance": stats.get("total_token_balance", 0.0),
                "can_reproduce_count": stats.get("can_reproduce_count", 0),
                "max_depth": stats.get("max_depth", 0),
                "cycles_run": len(self._cycles),
            }

    def get_recent_cycles(self, limit: int = 10) -> List[GrowthCycle]:
        """Get most recent growth cycles."""
        with self._lock:
            return self._cycles[-limit:]

    def initialize_node0(self) -> Seed:
        """
        Initialize Node0 as the root of the forest.

        Creates the first seed (Node0) with special properties:
        - No parent
        - Covenant pre-accepted
        - High initial Ihsān
        - Ready for germination

        Returns:
            Node0 seed
        """
        with self._lock:
            # Check if Node0 already exists
            all_seeds = self._seed_manager.get_all_seeds()
            for seed in all_seeds:
                if seed.parent_id is None:
                    print(f"[NODE0 EXISTS] {seed.seed_id}")
                    return seed

            # Create Node0
            node0 = self._seed_manager.create_seed(parent_id=None)

            # Special Node0 initialization - modify in place since seed is in manager's dict
            node0.covenant_accepted = True
            node0.ihsan_score = 0.98  # High initial score
            node0.poi_events = 15     # Above reproduction threshold
            node0.metadata["is_node0"] = True
            node0.metadata["genesis_timestamp"] = datetime.utcnow().isoformat()

            # Germinate immediately - sets germinated_at
            self._seed_manager.germinate(node0.seed_id)

            # Set germinated_at to 8 days ago to meet age requirement
            node0.germinated_at = datetime.utcnow() - timedelta(days=8)

            # Set state directly to FRUITING (bypass lifecycle checks for Node0 genesis)
            node0.state = SeedState.FRUITING

            # Persist all changes
            self._seed_manager._save_seeds()

            print(f"[NODE0 INITIALIZED] {node0.seed_id} ready to seed the forest")

            self._emit_receipt("node0_genesis", GrowthCycle(
                cycle_id="GENESIS-" + datetime.utcnow().strftime("%Y%m%d%H%M%S"),
                started_at=datetime.utcnow(),
            ), {
                "node0_id": node0.seed_id,
                "initial_ihsan": node0.ihsan_score,
                "initial_poi": node0.poi_events,
                "state": node0.state.value if hasattr(node0.state, 'value') else str(node0.state),
            })

            return node0

    def seed_first_generation(self) -> List[Seed]:
        """
        Create the first 7 seeds from Node0.

        This is the initial forest seeding following the biblical metaphor.
        Requires Node0 to exist and be in FRUITING or ELDER state.

        Returns:
            List of created first-generation seeds
        """
        with self._lock:
            # Find Node0
            all_seeds = self._seed_manager.get_all_seeds()
            node0 = None
            for seed in all_seeds:
                if seed.parent_id is None:
                    node0 = seed
                    break

            if not node0:
                print("[ERROR] Node0 not found. Call initialize_node0() first.")
                return []

            # Refresh node0 from manager to get latest state
            node0 = self._seed_manager.get_seed(node0.seed_id)

            first_gen = []
            existing_children = len(node0.children)
            needed = self.MAX_FIRST_GENERATION - existing_children

            if needed <= 0:
                print(f"[FIRST GEN COMPLETE] Already have {existing_children} first-generation seeds")
                return []

            print(f"[SEEDING] Creating {needed} first-generation seeds from Node0")

            for i in range(needed):
                if self._seed_manager.can_reproduce(node0.seed_id):
                    new_seed = self.trigger_reproduction(node0.seed_id)
                    if new_seed:
                        first_gen.append(new_seed)
                        # Refresh node0
                        node0 = self._seed_manager.get_seed(node0.seed_id)
                else:
                    print(f"[WARNING] Node0 cannot reproduce after {i} seeds")
                    break

            self._emit_receipt("first_generation_seeded", GrowthCycle(
                cycle_id="FIRSTGEN-" + datetime.utcnow().strftime("%Y%m%d%H%M%S"),
                started_at=datetime.utcnow(),
            ), {
                "node0_id": node0.seed_id,
                "seeds_created": len(first_gen),
                "seed_ids": [s.seed_id for s in first_gen],
            })

            return first_gen
