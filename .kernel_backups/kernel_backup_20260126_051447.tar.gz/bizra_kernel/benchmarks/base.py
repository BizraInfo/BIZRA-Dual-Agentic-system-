"""
BIZRA Benchmark Framework - Base Types and Utilities
=====================================================

Core data structures and utilities for the benchmark framework.
"""

from __future__ import annotations

import hashlib
import json
import statistics
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


# ============================================================================
# CONSTANTS
# ============================================================================

BENCHMARK_DATA_PATH = Path(__file__).parent / "test_sets"

# SNR tier thresholds (7.0-9.0 scale)
SNR_TIERS = {
    "T6": (9.0, float("inf"), "Elite"),
    "T5": (8.6, 9.0, "Expert"),
    "T4": (8.2, 8.6, "Strong"),
    "T3": (7.8, 8.2, "Target"),
    "T2": (7.4, 7.8, "Acceptable"),
    "T1": (0.0, 7.4, "Baseline"),
}

# Ihsān dimension weights (from constitution)
IHSAN_WEIGHTS = {
    "correctness": 0.22,
    "safety": 0.22,
    "user_benefit": 0.14,
    "efficiency": 0.12,
    "auditability": 0.12,
    "anti_centralization": 0.08,
    "robustness": 0.06,
    "adl_fairness": 0.04,
}


# ============================================================================
# ENUMS
# ============================================================================

class ExecutionMode(Enum):
    """Execution modes for benchmark comparison."""
    DIRECT = "direct"           # Model → Answer (no BIZRA)
    ROUTED = "routed"           # Router → Model → Answer (merged, no orchestration)
    BIZRA = "bizra"             # SAT → PAT → SAT → Answer (full orchestration)


class QuestionCategory(Enum):
    """Categories for benchmark questions."""
    REASONING = "reasoning"
    KNOWLEDGE = "knowledge"
    SAFETY = "safety"
    ETHICS = "ethics"
    CODING = "coding"
    COMMONSENSE = "commonsense"
    FACTUAL = "factual"
    INSTRUCTION = "instruction"


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class TestQuestion:
    """A single test question for benchmarking."""
    id: str
    question: str
    choices: List[str]
    correct_answer: str              # The correct answer (letter or text)
    category: QuestionCategory
    difficulty: str = "medium"       # easy, medium, hard
    source: str = "custom"           # mmlu, hellaswag, bizra_qa, etc.
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "question": self.question,
            "choices": self.choices,
            "correct_answer": self.correct_answer,
            "category": self.category.value,
            "difficulty": self.difficulty,
            "source": self.source,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TestQuestion":
        return cls(
            id=data["id"],
            question=data["question"],
            choices=data.get("choices", []),
            correct_answer=data["correct_answer"],
            category=QuestionCategory(data.get("category", "knowledge")),
            difficulty=data.get("difficulty", "medium"),
            source=data.get("source", "custom"),
            tags=data.get("tags", []),
        )


@dataclass
class TestSet:
    """A collection of test questions for benchmarking."""
    name: str
    description: str
    version: str
    questions: List[TestQuestion]
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def size(self) -> int:
        return len(self.questions)

    def by_category(self, category: QuestionCategory) -> List[TestQuestion]:
        return [q for q in self.questions if q.category == category]

    def by_difficulty(self, difficulty: str) -> List[TestQuestion]:
        return [q for q in self.questions if q.difficulty == difficulty]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "questions": [q.to_dict() for q in self.questions],
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TestSet":
        return cls(
            name=data["name"],
            description=data["description"],
            version=data.get("version", "1.0.0"),
            questions=[TestQuestion.from_dict(q) for q in data.get("questions", [])],
            metadata=data.get("metadata", {}),
        )


@dataclass
class BenchmarkMetrics:
    """Metrics from a single benchmark run."""
    latencies_ms: List[float] = field(default_factory=list)
    tokens_generated: List[int] = field(default_factory=list)
    tokens_input: List[int] = field(default_factory=list)
    correct_answers: int = 0
    total_questions: int = 0
    errors: int = 0
    timeouts: int = 0

    @property
    def p50_latency(self) -> float:
        if not self.latencies_ms:
            return 0.0
        sorted_lat = sorted(self.latencies_ms)
        idx = max(0, min(int((len(sorted_lat) - 1) * 0.50), len(sorted_lat) - 1))
        return sorted_lat[idx]

    @property
    def p95_latency(self) -> float:
        if not self.latencies_ms:
            return 0.0
        sorted_lat = sorted(self.latencies_ms)
        idx = max(0, min(int((len(sorted_lat) - 1) * 0.95), len(sorted_lat) - 1))
        return sorted_lat[idx]

    @property
    def p99_latency(self) -> float:
        if not self.latencies_ms:
            return 0.0
        sorted_lat = sorted(self.latencies_ms)
        idx = max(0, min(int((len(sorted_lat) - 1) * 0.99), len(sorted_lat) - 1))
        return sorted_lat[idx]

    @property
    def mean_latency(self) -> float:
        return statistics.mean(self.latencies_ms) if self.latencies_ms else 0.0

    @property
    def stddev_latency(self) -> float:
        return statistics.stdev(self.latencies_ms) if len(self.latencies_ms) > 1 else 0.0

    @property
    def accuracy(self) -> float:
        if self.total_questions == 0:
            return 0.0
        return self.correct_answers / self.total_questions

    @property
    def tokens_per_second(self) -> float:
        if not self.latencies_ms or not self.tokens_generated:
            return 0.0
        total_tokens = sum(self.tokens_generated)
        total_time_s = sum(self.latencies_ms) / 1000
        return total_tokens / max(0.001, total_time_s)

    @property
    def token_efficiency(self) -> float:
        """Ratio of useful output tokens to total tokens."""
        if not self.tokens_input or not self.tokens_generated:
            return 0.0
        total_output = sum(self.tokens_generated)
        total_input = sum(self.tokens_input)
        # Efficiency = output / (input + output), higher is better
        return total_output / max(1, total_input + total_output)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "latency_ms": {
                "p50": round(self.p50_latency, 2),
                "p95": round(self.p95_latency, 2),
                "p99": round(self.p99_latency, 2),
                "mean": round(self.mean_latency, 2),
                "stddev": round(self.stddev_latency, 2),
            },
            "accuracy": round(self.accuracy, 4),
            "correct_answers": self.correct_answers,
            "total_questions": self.total_questions,
            "errors": self.errors,
            "timeouts": self.timeouts,
            "tokens_per_second": round(self.tokens_per_second, 2),
            "token_efficiency": round(self.token_efficiency, 4),
        }


@dataclass
class BenchmarkResult:
    """Result of benchmarking a single model or configuration."""
    id: str = field(default_factory=lambda: hashlib.sha256(
        datetime.now(timezone.utc).isoformat().encode()
    ).hexdigest()[:12])
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Identity
    model_name: str = ""
    model_provider: str = ""
    execution_mode: ExecutionMode = ExecutionMode.DIRECT
    test_set_name: str = ""

    # Metrics
    metrics: BenchmarkMetrics = field(default_factory=BenchmarkMetrics)

    # BIZRA-specific metrics (only for BIZRA mode)
    ihsan_score: Optional[float] = None
    snr_score: Optional[float] = None
    sat_consensus_rate: Optional[float] = None
    pat_approval_rate: Optional[float] = None
    fate_escalations: int = 0

    # Meta
    duration_ms: float = 0.0
    config: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)

    @property
    def snr_tier(self) -> str:
        """Calculate SNR tier from score."""
        if self.snr_score is None:
            return "N/A"
        # Convert from 0-1 scale to 7-9 scale
        snr_scaled = 7.0 + max(0, self.snr_score - 0.8) * 10.0
        for tier, (low, high, _) in SNR_TIERS.items():
            if low <= snr_scaled < high:
                return tier
        return "T6" if snr_scaled >= 9.0 else "T1"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "model_name": self.model_name,
            "model_provider": self.model_provider,
            "execution_mode": self.execution_mode.value,
            "test_set_name": self.test_set_name,
            "metrics": self.metrics.to_dict(),
            "bizra_metrics": {
                "ihsan_score": self.ihsan_score,
                "snr_score": self.snr_score,
                "snr_tier": self.snr_tier,
                "sat_consensus_rate": self.sat_consensus_rate,
                "pat_approval_rate": self.pat_approval_rate,
                "fate_escalations": self.fate_escalations,
            },
            "duration_ms": round(self.duration_ms, 2),
            "config": self.config,
            "errors": self.errors,
        }


@dataclass
class BenchmarkReport:
    """Complete benchmark report with multiple results."""
    id: str = field(default_factory=lambda: hashlib.sha256(
        datetime.now(timezone.utc).isoformat().encode()
    ).hexdigest()[:12])
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Report metadata
    title: str = "BIZRA Benchmark Report"
    description: str = ""
    version: str = "1.0.0"

    # Results
    results: List[BenchmarkResult] = field(default_factory=list)

    # Comparison summary (populated for comparison benchmarks)
    comparison_summary: Dict[str, Any] = field(default_factory=dict)

    # Test sets used
    test_sets: List[str] = field(default_factory=list)

    # Meta
    total_duration_ms: float = 0.0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def add_result(self, result: BenchmarkResult) -> None:
        """Add a benchmark result to the report."""
        self.results.append(result)

    def get_by_mode(self, mode: ExecutionMode) -> List[BenchmarkResult]:
        """Get results filtered by execution mode."""
        return [r for r in self.results if r.execution_mode == mode]

    def get_by_model(self, model_name: str) -> List[BenchmarkResult]:
        """Get results filtered by model name."""
        return [r for r in self.results if r.model_name == model_name]

    def compute_comparison_summary(self) -> Dict[str, Any]:
        """Compute comparison statistics across modes."""
        summary: Dict[str, Any] = {
            "modes": {},
            "accuracy_delta": {},
            "latency_overhead": {},
            "best_accuracy": None,
            "fastest_mode": None,
        }

        for mode in ExecutionMode:
            mode_results = self.get_by_mode(mode)
            if mode_results:
                accuracies = [r.metrics.accuracy for r in mode_results]
                latencies = [r.metrics.p95_latency for r in mode_results]

                summary["modes"][mode.value] = {
                    "avg_accuracy": sum(accuracies) / len(accuracies),
                    "avg_p95_latency": sum(latencies) / len(latencies),
                    "num_results": len(mode_results),
                }

        # Calculate deltas relative to DIRECT mode
        if "direct" in summary["modes"]:
            direct_acc = summary["modes"]["direct"]["avg_accuracy"]
            direct_lat = summary["modes"]["direct"]["avg_p95_latency"]

            for mode_name, mode_data in summary["modes"].items():
                if mode_name != "direct":
                    summary["accuracy_delta"][mode_name] = mode_data["avg_accuracy"] - direct_acc
                    if direct_lat > 0:
                        summary["latency_overhead"][mode_name] = mode_data["avg_p95_latency"] / direct_lat

        # Find best performers
        if summary["modes"]:
            best_acc_mode = max(summary["modes"].items(), key=lambda x: x[1]["avg_accuracy"])
            summary["best_accuracy"] = {
                "mode": best_acc_mode[0],
                "value": best_acc_mode[1]["avg_accuracy"],
            }

            fastest_mode = min(summary["modes"].items(), key=lambda x: x[1]["avg_p95_latency"])
            summary["fastest_mode"] = {
                "mode": fastest_mode[0],
                "value": fastest_mode[1]["avg_p95_latency"],
            }

        self.comparison_summary = summary
        return summary

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "title": self.title,
            "description": self.description,
            "version": self.version,
            "results": [r.to_dict() for r in self.results],
            "comparison_summary": self.comparison_summary,
            "test_sets": self.test_sets,
            "total_duration_ms": round(self.total_duration_ms, 2),
            "errors": self.errors,
            "warnings": self.warnings,
        }

    def to_json(self, indent: int = 2) -> str:
        """Export report as JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    def save(self, path: Union[str, Path]) -> None:
        """Save report to file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.to_json(), encoding="utf-8")

    def to_markdown_table(self) -> str:
        """Generate a markdown comparison table."""
        lines = [
            "| Mode | Model | Accuracy | P95 Latency | Ihsān | SNR | Tier |",
            "|------|-------|----------|-------------|-------|-----|------|",
        ]

        for result in sorted(self.results, key=lambda r: r.execution_mode.value):
            ihsan = f"{result.ihsan_score:.3f}" if result.ihsan_score else "N/A"
            snr = f"{result.snr_score:.3f}" if result.snr_score else "N/A"
            lines.append(
                f"| {result.execution_mode.value} | {result.model_name} | "
                f"{result.metrics.accuracy*100:.1f}% | {result.metrics.p95_latency:.0f}ms | "
                f"{ihsan} | {snr} | {result.snr_tier} |"
            )

        return "\n".join(lines)


# ============================================================================
# UTILITIES
# ============================================================================

def load_test_set(name: str) -> TestSet:
    """Load a test set by name from the test_sets directory."""
    path = BENCHMARK_DATA_PATH / f"{name}.json"
    if not path.exists():
        raise FileNotFoundError(f"Test set not found: {path}")

    data = json.loads(path.read_text(encoding="utf-8"))
    return TestSet.from_dict(data)


def list_test_sets() -> List[str]:
    """List available test sets."""
    if not BENCHMARK_DATA_PATH.exists():
        return []
    return [p.stem for p in BENCHMARK_DATA_PATH.glob("*.json")]


def compute_ihsan_score(dimensions: Dict[str, float]) -> float:
    """Compute weighted Ihsān score from dimension values."""
    score = 0.0
    for dim, weight in IHSAN_WEIGHTS.items():
        score += dimensions.get(dim, 0.7) * weight
    return score


def compute_snr(
    useful_tokens: int,
    total_tokens: int,
    confidence: float = 1.0,
    ethical_compliance: float = 1.0,
    tool_directness: float = 1.0,
) -> float:
    """Compute SNR score."""
    if total_tokens == 0:
        return 0.0
    token_efficiency = useful_tokens / total_tokens
    return token_efficiency * confidence * ethical_compliance * tool_directness


def score_to_snr_tier(score: float) -> str:
    """Convert 0-1 score to SNR tier."""
    snr_scaled = 7.0 + max(0, score - 0.8) * 10.0
    for tier, (low, high, _) in SNR_TIERS.items():
        if low <= snr_scaled < high:
            return tier
    return "T6" if snr_scaled >= 9.0 else "T1"
