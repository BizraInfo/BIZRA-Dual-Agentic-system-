"""
BIZRA Benchmark Framework
=========================

Comprehensive evaluation system for measuring:
1. Individual Model Baselines - Each model's standalone performance
2. Merged Without BIZRA - Models combined via simple routing
3. Through BIZRA - Full PAT-SAT dual-agentic orchestration
4. Public Benchmark Comparison - MMLU, HellaSwag, custom QA
5. BIZRA-Specific Metrics - Ihsān, SNR, consensus quality

Package Structure:
    benchmarks/
    ├── __init__.py          - This file
    ├── test_sets/           - Standard benchmark test sets
    │   ├── mmlu_mini.json
    │   ├── hellaswag_mini.json
    │   └── bizra_qa.json
    ├── base.py              - Base classes and types
    ├── model_baseline.py    - Individual model benchmarking
    └── comparison.py        - 3-mode comparison harness

Usage:
    from bizra_kernel.benchmarks import (
        ModelBaselineBenchmark,
        ComparisonBenchmark,
        BenchmarkReport,
        load_test_set,
    )

    # Run individual model baseline
    baseline = ModelBaselineBenchmark()
    results = await baseline.run_all_models()

    # Run comparison benchmark
    comparison = ComparisonBenchmark()
    report = await comparison.compare_all_modes(test_set='mmlu_mini')
"""

from .base import (
    BenchmarkResult,
    BenchmarkMetrics,
    BenchmarkReport,
    TestQuestion,
    TestSet,
    ExecutionMode,
    load_test_set,
    BENCHMARK_DATA_PATH,
)

__all__ = [
    "BenchmarkResult",
    "BenchmarkMetrics",
    "BenchmarkReport",
    "TestQuestion",
    "TestSet",
    "ExecutionMode",
    "load_test_set",
    "BENCHMARK_DATA_PATH",
]

__version__ = "1.0.0"
