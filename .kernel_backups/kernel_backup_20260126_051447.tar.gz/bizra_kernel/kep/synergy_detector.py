"""
Synergy Detector - Cross-Domain Knowledge Synergy Detection
============================================================
From the Blueprint:
    "Detects synergistic relationships between knowledge elements
    across domains using semantic clustering and graph topology."

The detector finds patterns and principles that, when combined,
could produce emergent capabilities (compounds).
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional, Dict, Tuple, Set
from enum import Enum
import hashlib
import logging
import math

from ..abstraction_elevator import (
    AbstractionElevator,
    DomainType,
    Principle,
    Pattern,
    AbstractionLevel,
)
from .kep_safety import get_safety_gate, SafetyResponse
from .kep_receipts import get_kep_receipt_emitter

logger = logging.getLogger(__name__)


@dataclass
class SynergyCandidate:
    """A potential synergistic relationship between knowledge elements."""
    candidate_id: str = ""
    source_id: str = ""
    target_id: str = ""
    source_domain: DomainType = DomainType.TECHNICAL
    target_domain: DomainType = DomainType.TECHNICAL
    source_type: str = "principle"  # principle, pattern, or compound
    target_type: str = "principle"

    # Scores
    similarity_score: float = 0.0      # Semantic embedding similarity
    structural_score: float = 0.0      # Graph topology similarity
    composite_score: float = 0.0       # Weighted combination

    # Synergy hypothesis
    potential_compound: str = ""       # Hypothesized emergent capability
    synergy_type: str = ""            # complementary, reinforcing, transcendent

    # Validation
    ihsan_alignment: float = 0.0
    contradictions_found: List[str] = field(default_factory=list)
    is_valid: bool = False

    # Metadata
    detected_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    detection_path: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "candidate_id": self.candidate_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "source_domain": self.source_domain.value,
            "target_domain": self.target_domain.value,
            "source_type": self.source_type,
            "target_type": self.target_type,
            "similarity_score": self.similarity_score,
            "structural_score": self.structural_score,
            "composite_score": self.composite_score,
            "potential_compound": self.potential_compound,
            "synergy_type": self.synergy_type,
            "ihsan_alignment": self.ihsan_alignment,
            "contradictions_found": self.contradictions_found,
            "is_valid": self.is_valid,
            "detected_at": self.detected_at,
        }


class SynergyType(Enum):
    """Types of synergistic relationships."""
    COMPLEMENTARY = "complementary"  # A provides what B lacks
    REINFORCING = "reinforcing"      # A strengthens B
    TRANSCENDENT = "transcendent"    # A + B creates something entirely new


class SynergyDetector:
    """
    Detects synergistic relationships between knowledge elements.

    Process:
    1. Semantic clustering via embeddings (similarity_score)
    2. Structural analysis via graph traversal (structural_score)
    3. Contradiction filtering (remove incompatible pairs)
    4. Pre-validate Ihsan alignment (>= 0.99)
    5. Emit synergy detection receipt
    """

    # Thresholds
    SYNERGY_THRESHOLD = 0.75
    CROSS_DOMAIN_BOOST = 0.15
    SIMILARITY_WEIGHT = 0.6
    STRUCTURAL_WEIGHT = 0.4
    MIN_IHSAN = 0.99

    def __init__(
        self,
        elevator: Optional[AbstractionElevator] = None,
        hypergraph_connector=None,
        embedding_fn=None,
    ):
        self.elevator = elevator or AbstractionElevator()
        self.hypergraph = hypergraph_connector
        self._embedding_fn = embedding_fn or self._mock_embedding
        self._embedding_cache: Dict[str, List[float]] = {}

        # Synergy tracking
        self.detected_synergies: Dict[str, SynergyCandidate] = {}
        self.pending_synthesis: List[SynergyCandidate] = []
        self._synergy_counter = 0

        logger.info("SynergyDetector initialized with threshold %.2f", self.SYNERGY_THRESHOLD)

    def _next_synergy_id(self) -> str:
        """Generate next synergy candidate ID."""
        self._synergy_counter += 1
        return f"SYN-{self._synergy_counter:05d}"

    def _mock_embedding(self, text: str) -> List[float]:
        """Mock embedding function for testing (replace with actual embeddings)."""
        import random
        # Create deterministic pseudo-embedding based on text hash
        seed = int(hashlib.md5(text.encode()).hexdigest()[:8], 16)
        random.seed(seed)
        return [random.random() for _ in range(384)]

    def _get_embedding(self, text: str) -> List[float]:
        """Get embedding for text, with caching."""
        cache_key = hashlib.md5(text.encode()).hexdigest()
        if cache_key not in self._embedding_cache:
            self._embedding_cache[cache_key] = self._embedding_fn(text)
        return self._embedding_cache[cache_key]

    def _cosine_similarity(self, vec_a: List[float], vec_b: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        dot_product = sum(a * b for a, b in zip(vec_a, vec_b))
        norm_a = math.sqrt(sum(a * a for a in vec_a))
        norm_b = math.sqrt(sum(b * b for b in vec_b))

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return dot_product / (norm_a * norm_b)

    def _calculate_similarity_score(
        self,
        source: Principle,
        target: Principle,
    ) -> float:
        """Calculate semantic similarity between two principles."""
        source_embedding = self._get_embedding(source.statement)
        target_embedding = self._get_embedding(target.statement)
        return self._cosine_similarity(source_embedding, target_embedding)

    def _calculate_structural_score(
        self,
        source: Principle,
        target: Principle,
    ) -> float:
        """
        Calculate structural similarity via graph analysis.

        Uses:
        - Shared source patterns
        - Common domains
        - Graph path length (via hypergraph if available)
        """
        # Shared source patterns
        source_patterns = set(source.source_patterns)
        target_patterns = set(target.source_patterns)
        shared_patterns = source_patterns & target_patterns
        pattern_overlap = (
            len(shared_patterns) / max(1, len(source_patterns | target_patterns))
        )

        # Domain overlap
        source_domains = set(source.domains)
        target_domains = set(target.domains)
        shared_domains = source_domains & target_domains
        domain_overlap = len(shared_domains) / max(1, len(source_domains | target_domains))

        # Graph path score (if hypergraph available)
        path_score = 0.0
        if self.hypergraph is not None:
            try:
                path_length = self._find_graph_path_length(
                    source.principle_id, target.principle_id
                )
                # Closer paths = higher score (max at 1 hop, diminishes)
                path_score = 1.0 / (1 + path_length) if path_length >= 0 else 0.0
            except Exception as e:
                logger.warning("Graph path calculation failed: %s", e)

        # Weighted combination
        if self.hypergraph is not None:
            return 0.4 * pattern_overlap + 0.3 * domain_overlap + 0.3 * path_score
        else:
            return 0.6 * pattern_overlap + 0.4 * domain_overlap

    def _find_graph_path_length(self, source_id: str, target_id: str) -> int:
        """Find shortest path length in hypergraph (BFS)."""
        if self.hypergraph is None:
            return -1

        # Use hypergraph's synergy path finding if available
        try:
            results = self.hypergraph.find_synergy_paths([source_id, target_id], max_hops=3)
            return len(results.get("path", [])) if results else -1
        except (AttributeError, Exception):
            return -1

    def _check_contradictions(
        self,
        source: Principle,
        target: Principle,
    ) -> List[str]:
        """Check for logical contradictions between principles."""
        contradictions = []

        # Check explicit exceptions
        for exception in source.exceptions:
            if any(
                keyword in target.statement.lower()
                for keyword in exception.lower().split()
            ):
                contradictions.append(
                    f"Source exception '{exception}' may conflict with target"
                )

        for exception in target.exceptions:
            if any(
                keyword in source.statement.lower()
                for keyword in exception.lower().split()
            ):
                contradictions.append(
                    f"Target exception '{exception}' may conflict with source"
                )

        # Check for opposing constraints
        opposing_pairs = [
            ("centralized", "decentralized"),
            ("mutable", "immutable"),
            ("optional", "mandatory"),
            ("synchronous", "asynchronous"),
        ]

        source_lower = source.statement.lower()
        target_lower = target.statement.lower()

        for word1, word2 in opposing_pairs:
            if (word1 in source_lower and word2 in target_lower) or \
               (word2 in source_lower and word1 in target_lower):
                contradictions.append(
                    f"Potential opposition: '{word1}' vs '{word2}'"
                )

        return contradictions

    def _estimate_ihsan_alignment(
        self,
        source: Principle,
        target: Principle,
    ) -> float:
        """Estimate Ihsan alignment for the potential compound."""
        # Average of source and target alignments
        base_alignment = (source.ihsan_alignment + target.ihsan_alignment) / 2

        # Boost for cross-domain synergy (promotes decentralization)
        if source.domains != target.domains:
            base_alignment += 0.02

        # Penalize if either is below threshold
        if source.ihsan_alignment < self.MIN_IHSAN or target.ihsan_alignment < self.MIN_IHSAN:
            base_alignment *= 0.9

        return min(1.0, base_alignment)

    def _hypothesize_compound(
        self,
        source: Principle,
        target: Principle,
        similarity: float,
        structural: float,
    ) -> Tuple[str, str]:
        """
        Hypothesize what emergent capability could arise from combining principles.

        Returns (hypothesis, synergy_type)
        """
        # Determine synergy type based on scores
        if similarity > 0.8:
            synergy_type = SynergyType.REINFORCING.value
            hypothesis = (
                f"Reinforced capability: '{source.name}' strengthened by "
                f"'{target.name}' for enhanced {source.domains[0].value if source.domains else 'general'} outcomes"
            )
        elif structural > 0.5 and similarity < 0.5:
            synergy_type = SynergyType.TRANSCENDENT.value
            hypothesis = (
                f"Emergent capability: Combining '{source.name}' with '{target.name}' "
                f"may enable new cross-domain ({source.domains[0].value if source.domains else 'X'}"
                f"-{target.domains[0].value if target.domains else 'Y'}) applications"
            )
        else:
            synergy_type = SynergyType.COMPLEMENTARY.value
            hypothesis = (
                f"Complementary capability: '{source.name}' provides foundation, "
                f"'{target.name}' extends applicability"
            )

        return hypothesis, synergy_type

    def detect_synergies(
        self,
        min_ihsan: float = 0.99,
        max_results: int = 50,
    ) -> List[SynergyCandidate]:
        """
        Detect synergies across all principles in the elevator.

        Process:
        1. Get all principles
        2. Calculate pairwise scores
        3. Filter by threshold and contradictions
        4. Pre-validate Ihsan alignment
        5. Emit receipts
        """
        # Check safety gate
        safety = get_safety_gate()
        response = safety.check_synergy_detection()
        if response != SafetyResponse.CONTINUE:
            logger.warning("Synergy detection blocked by safety gate: %s", response)
            return []

        principles = list(self.elevator.principles.values())
        if len(principles) < 2:
            logger.info("Not enough principles for synergy detection")
            return []

        candidates = []
        seen_pairs: Set[Tuple[str, str]] = set()
        emitter = get_kep_receipt_emitter()

        for i, source in enumerate(principles):
            for target in principles[i + 1:]:
                # Skip same-id pairs
                if source.principle_id == target.principle_id:
                    continue

                # Skip already seen (in either direction)
                pair_key = tuple(sorted([source.principle_id, target.principle_id]))
                if pair_key in seen_pairs:
                    continue
                seen_pairs.add(pair_key)

                # Calculate scores
                similarity = self._calculate_similarity_score(source, target)
                structural = self._calculate_structural_score(source, target)

                # Composite score
                composite = (
                    self.SIMILARITY_WEIGHT * similarity +
                    self.STRUCTURAL_WEIGHT * structural
                )

                # Cross-domain boost
                is_cross_domain = source.domains != target.domains
                if is_cross_domain:
                    composite += self.CROSS_DOMAIN_BOOST

                # Check threshold
                if composite < self.SYNERGY_THRESHOLD:
                    continue

                # Check contradictions
                contradictions = self._check_contradictions(source, target)
                if len(contradictions) > 2:  # Too many contradictions
                    continue

                # Estimate Ihsan alignment
                ihsan_alignment = self._estimate_ihsan_alignment(source, target)
                if ihsan_alignment < min_ihsan:
                    continue

                # Hypothesize compound
                hypothesis, synergy_type = self._hypothesize_compound(
                    source, target, similarity, structural
                )

                # Create candidate
                candidate = SynergyCandidate(
                    candidate_id=self._next_synergy_id(),
                    source_id=source.principle_id,
                    target_id=target.principle_id,
                    source_domain=source.domains[0] if source.domains else DomainType.TECHNICAL,
                    target_domain=target.domains[0] if target.domains else DomainType.TECHNICAL,
                    source_type="principle",
                    target_type="principle",
                    similarity_score=similarity,
                    structural_score=structural,
                    composite_score=composite,
                    potential_compound=hypothesis,
                    synergy_type=synergy_type,
                    ihsan_alignment=ihsan_alignment,
                    contradictions_found=contradictions,
                    is_valid=len(contradictions) == 0,
                )

                candidates.append(candidate)
                self.detected_synergies[candidate.candidate_id] = candidate

                # Emit receipt
                emitter.emit_synergy_detection(
                    source_id=source.principle_id,
                    target_id=target.principle_id,
                    source_domain=candidate.source_domain.value,
                    target_domain=candidate.target_domain.value,
                    similarity_score=similarity,
                    structural_score=structural,
                    composite_score=composite,
                    potential_compound=hypothesis,
                    ihsan_alignment=ihsan_alignment,
                    passed_threshold=True,
                    detection_method="hybrid_semantic_structural",
                    graph_path_length=0,
                )

                # Record for rate limiting
                safety.record_synergy_detection()

                if len(candidates) >= max_results:
                    break

            if len(candidates) >= max_results:
                break

        # Sort by composite score
        candidates.sort(key=lambda c: c.composite_score, reverse=True)

        # Add valid candidates to pending synthesis queue
        self.pending_synthesis.extend(
            [c for c in candidates if c.is_valid]
        )

        logger.info(
            "Detected %d synergy candidates (%d valid for synthesis)",
            len(candidates),
            len([c for c in candidates if c.is_valid])
        )

        return candidates

    def get_cross_domain_candidates(
        self,
        min_score: float = 0.8,
    ) -> List[SynergyCandidate]:
        """Get high-value cross-domain synergy candidates."""
        return [
            c for c in self.detected_synergies.values()
            if c.source_domain != c.target_domain
            and c.composite_score >= min_score
            and c.is_valid
        ]

    def get_pending_synthesis(self) -> List[SynergyCandidate]:
        """Get candidates ready for compound synthesis."""
        return list(self.pending_synthesis)

    def mark_synthesized(self, candidate_id: str) -> None:
        """Mark a synergy as synthesized (remove from pending)."""
        self.pending_synthesis = [
            c for c in self.pending_synthesis
            if c.candidate_id != candidate_id
        ]

    def get_statistics(self) -> dict:
        """Get synergy detection statistics."""
        candidates = list(self.detected_synergies.values())
        valid = [c for c in candidates if c.is_valid]
        cross_domain = [c for c in candidates if c.source_domain != c.target_domain]

        return {
            "total_detected": len(candidates),
            "valid_candidates": len(valid),
            "cross_domain_count": len(cross_domain),
            "pending_synthesis": len(self.pending_synthesis),
            "avg_composite_score": (
                sum(c.composite_score for c in candidates) / max(1, len(candidates))
            ),
            "avg_ihsan_alignment": (
                sum(c.ihsan_alignment for c in candidates) / max(1, len(candidates))
            ),
            "synergy_types": {
                "complementary": len([c for c in candidates if c.synergy_type == "complementary"]),
                "reinforcing": len([c for c in candidates if c.synergy_type == "reinforcing"]),
                "transcendent": len([c for c in candidates if c.synergy_type == "transcendent"]),
            },
        }
