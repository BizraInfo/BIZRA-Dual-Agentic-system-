"""
KEP Safety Module - Constitutional Constraints for Runaway Prevention
======================================================================
From the Blueprint:
    "The explosion is CONTROLLED: Constitutional limits prevent unbounded
    growth while enabling rapid recursive improvement within safe boundaries."

This module implements the 7-layer safety stack that gates all KEP operations.
CRITICAL: Ihsan >= 0.95 is a HARD BLOCK - maintain flexibility for practical use.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional, Callable, Awaitable, Dict, List
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class SafetyViolationType(Enum):
    """Types of safety violations that trigger system responses."""
    IHSAN_BELOW_THRESHOLD = "ihsan_below_threshold"
    IHSAN_EMERGENCY_DROP = "ihsan_emergency_drop"
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
    MAX_ITERATIONS_EXCEEDED = "max_iterations_exceeded"
    SAT_CONSENSUS_FAILED = "sat_consensus_failed"
    COOLDOWN_VIOLATION = "cooldown_violation"
    LEARNING_RATE_OVERFLOW = "learning_rate_overflow"


class SafetyResponse(Enum):
    """How the system responds to safety violations."""
    CONTINUE = "continue"           # Safe to proceed
    THROTTLE = "throttle"           # Slow down operations
    BLOCK = "block"                 # Block current operation
    HALT = "halt"                   # Emergency system halt
    ESCALATE = "escalate"           # Escalate to human review


@dataclass
class KEPSafetyLimits:
    """
    Constitutional safety limits - HARDCODED values.

    WARNING: Changing these values can enable runaway knowledge explosion.
    Modifications require full SAT 5/5 consensus + human review.
    """
    # Ihsan constraints (balanced for practical flexibility)
    IHSAN_MINIMUM: float = 0.95
    IHSAN_TARGET: float = 0.97
    EMERGENCY_IHSAN_DROP: float = 0.05  # 5% drop triggers halt

    # Learning rate constraints
    MIN_LEARNING_RATE: float = 0.05
    MAX_LEARNING_RATE: float = 2.0
    EXPLOSION_LEARNING_RATE: float = 5.0  # Only during validated explosion mode
    ABSOLUTE_MAX_RATE: float = 10.0  # Hard ceiling even in explosion

    # Iteration limits
    MAX_LOOP_ITERATIONS: int = 1000  # Per feedback loop
    MAX_DISCOVERY_BATCH: int = 10  # Max compounds synthesized per batch

    # Rate limits (per hour)
    MAX_COMPOUNDS_PER_HOUR: int = 50
    MAX_SYNERGIES_PER_HOUR: int = 200
    MAX_ELEVATIONS_PER_HOUR: int = 100

    # Consensus requirements
    MIN_SAT_CONSENSUS: int = 3  # Out of 5
    EXPLOSION_SAT_CONSENSUS: int = 4  # For explosion mode entry
    AXIOM_SAT_CONSENSUS: int = 5  # For new axiom creation

    # Timing constraints
    EXPLOSION_COOLDOWN_HOURS: int = 1
    MIN_SYNERGY_INTERVAL_SECONDS: int = 1

    # Dampening parameters
    BOUNDARY_DAMPENING_FACTOR: float = 0.8  # Slowdown near limits
    DAMPENING_THRESHOLD: float = 0.9  # 90% of limit triggers dampening


@dataclass
class SafetyState:
    """Tracks the current safety state of the KEP system."""
    current_ihsan: float = 0.0
    previous_ihsan: float = 0.0
    compounds_this_hour: int = 0
    synergies_this_hour: int = 0
    elevations_this_hour: int = 0
    current_learning_rate: float = 0.1
    loop_iteration_counts: Dict[str, int] = field(default_factory=dict)
    last_explosion_exit: Optional[datetime] = None
    is_explosion_mode: bool = False
    last_hour_reset: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    violations_log: List[tuple] = field(default_factory=list)


class KEPSafetyGate:
    """
    7-Layer Safety Stack for KEP Operations.

    Layer 1: Ihsan Gate (0.95 threshold) - HARD BLOCK
    Layer 2: SAT Consensus (3/5 validators) - GOVERNANCE
    Layer 3: FATE Escalation (auto-escalate) - HUMAN REVIEW
    Layer 4: Receipt Evidence (append-only) - AUDIT TRAIL
    Layer 5: Rate Limiting (per-hour caps) - THROTTLE
    Layer 6: Dampening (boundary approach) - SOFT LIMIT
    Layer 7: Emergency Halt (Ihsan drop) - KILL SWITCH
    """

    def __init__(
        self,
        limits: Optional[KEPSafetyLimits] = None,
        sat_verify_callback: Optional[Callable[[str, int], Awaitable[bool]]] = None,
        fate_escalate_callback: Optional[Callable[[str, dict], Awaitable[str]]] = None,
        emit_receipt_callback: Optional[Callable[[dict], Awaitable[str]]] = None,
    ):
        self.limits = limits or KEPSafetyLimits()
        self.state = SafetyState()

        # Callbacks for integration with broader system
        self._sat_verify = sat_verify_callback
        self._fate_escalate = fate_escalate_callback
        self._emit_receipt = emit_receipt_callback

        logger.info(
            "KEP Safety Gate initialized with Ihsan threshold %.3f",
            self.limits.IHSAN_MINIMUM
        )

    def _reset_hourly_counters_if_needed(self) -> None:
        """Reset hourly counters if an hour has passed."""
        now = datetime.now(timezone.utc)
        if (now - self.state.last_hour_reset).total_seconds() >= 3600:
            self.state.compounds_this_hour = 0
            self.state.synergies_this_hour = 0
            self.state.elevations_this_hour = 0
            self.state.last_hour_reset = now

    def update_ihsan(self, new_ihsan: float) -> SafetyResponse:
        """
        Update the system-wide Ihsan score and check for emergency conditions.

        Layer 1 + Layer 7: Ihsan Gate + Emergency Halt
        """
        self.state.previous_ihsan = self.state.current_ihsan
        self.state.current_ihsan = new_ihsan

        # Layer 7: Check for emergency Ihsan drop
        if self.state.previous_ihsan > 0:
            drop = self.state.previous_ihsan - new_ihsan
            if drop >= self.limits.EMERGENCY_IHSAN_DROP:
                self._log_violation(
                    SafetyViolationType.IHSAN_EMERGENCY_DROP,
                    f"Ihsan dropped by {drop:.3f} (threshold: {self.limits.EMERGENCY_IHSAN_DROP})"
                )
                return SafetyResponse.HALT

        # Layer 1: Hard Ihsan threshold
        if new_ihsan < self.limits.IHSAN_MINIMUM:
            self._log_violation(
                SafetyViolationType.IHSAN_BELOW_THRESHOLD,
                f"Ihsan {new_ihsan:.3f} < {self.limits.IHSAN_MINIMUM}"
            )
            return SafetyResponse.BLOCK

        return SafetyResponse.CONTINUE

    def check_compound_synthesis(self) -> SafetyResponse:
        """
        Check if compound synthesis is allowed.

        Layer 5: Rate Limiting
        """
        self._reset_hourly_counters_if_needed()

        # Check rate limit
        if self.state.compounds_this_hour >= self.limits.MAX_COMPOUNDS_PER_HOUR:
            self._log_violation(
                SafetyViolationType.RATE_LIMIT_EXCEEDED,
                f"Compound limit reached: {self.state.compounds_this_hour}/{self.limits.MAX_COMPOUNDS_PER_HOUR}/hr"
            )
            return SafetyResponse.THROTTLE

        # Layer 6: Dampening near limit
        usage_ratio = self.state.compounds_this_hour / self.limits.MAX_COMPOUNDS_PER_HOUR
        if usage_ratio >= self.limits.DAMPENING_THRESHOLD:
            return SafetyResponse.THROTTLE

        return SafetyResponse.CONTINUE

    def check_synergy_detection(self) -> SafetyResponse:
        """Check if synergy detection is allowed."""
        self._reset_hourly_counters_if_needed()

        if self.state.synergies_this_hour >= self.limits.MAX_SYNERGIES_PER_HOUR:
            self._log_violation(
                SafetyViolationType.RATE_LIMIT_EXCEEDED,
                f"Synergy limit reached: {self.state.synergies_this_hour}/{self.limits.MAX_SYNERGIES_PER_HOUR}/hr"
            )
            return SafetyResponse.THROTTLE

        return SafetyResponse.CONTINUE

    def check_learning_rate(self, proposed_rate: float) -> tuple[SafetyResponse, float]:
        """
        Validate and potentially clamp proposed learning rate.

        Returns (response, clamped_rate)
        """
        # Determine max allowed rate based on mode
        max_rate = (
            self.limits.EXPLOSION_LEARNING_RATE
            if self.state.is_explosion_mode
            else self.limits.MAX_LEARNING_RATE
        )

        # Absolute ceiling
        max_rate = min(max_rate, self.limits.ABSOLUTE_MAX_RATE)

        # Clamp rate
        clamped_rate = max(
            self.limits.MIN_LEARNING_RATE,
            min(proposed_rate, max_rate)
        )

        if proposed_rate > max_rate:
            self._log_violation(
                SafetyViolationType.LEARNING_RATE_OVERFLOW,
                f"Proposed rate {proposed_rate:.2f} exceeds max {max_rate:.2f}"
            )
            return SafetyResponse.THROTTLE, clamped_rate

        return SafetyResponse.CONTINUE, clamped_rate

    def check_loop_iteration(self, loop_name: str) -> SafetyResponse:
        """
        Check if a feedback loop can continue iterating.

        Layer 4: Iteration Limits
        """
        count = self.state.loop_iteration_counts.get(loop_name, 0)

        if count >= self.limits.MAX_LOOP_ITERATIONS:
            self._log_violation(
                SafetyViolationType.MAX_ITERATIONS_EXCEEDED,
                f"Loop '{loop_name}' reached {count} iterations"
            )
            return SafetyResponse.BLOCK

        return SafetyResponse.CONTINUE

    def check_explosion_entry(self) -> SafetyResponse:
        """
        Check if system can enter explosion mode.

        Requires:
        - Cooldown period satisfied
        - Ihsan >= target
        - SAT 4/5 consensus (via callback)
        """
        # Check cooldown
        if self.state.last_explosion_exit is not None:
            cooldown_end = self.state.last_explosion_exit + timedelta(
                hours=self.limits.EXPLOSION_COOLDOWN_HOURS
            )
            if datetime.now(timezone.utc) < cooldown_end:
                self._log_violation(
                    SafetyViolationType.COOLDOWN_VIOLATION,
                    f"Explosion cooldown active until {cooldown_end.isoformat()}"
                )
                return SafetyResponse.BLOCK

        # Check Ihsan target
        if self.state.current_ihsan < self.limits.IHSAN_TARGET:
            return SafetyResponse.BLOCK

        return SafetyResponse.CONTINUE

    async def request_sat_consensus(
        self,
        operation: str,
        required_votes: Optional[int] = None,
    ) -> SafetyResponse:
        """
        Request SAT consensus for an operation.

        Layer 2: SAT Governance
        """
        if self._sat_verify is None:
            logger.warning("SAT verify callback not configured, defaulting to BLOCK")
            return SafetyResponse.BLOCK

        votes_needed = required_votes or self.limits.MIN_SAT_CONSENSUS

        try:
            approved = await self._sat_verify(operation, votes_needed)
            if not approved:
                self._log_violation(
                    SafetyViolationType.SAT_CONSENSUS_FAILED,
                    f"SAT consensus failed for '{operation}' (needed {votes_needed}/5)"
                )
                return SafetyResponse.ESCALATE
            return SafetyResponse.CONTINUE
        except Exception as e:
            logger.error("SAT consensus check failed: %s", e)
            return SafetyResponse.BLOCK

    async def escalate_to_fate(self, reason: str, context: dict) -> str:
        """
        Escalate an issue via FATE for human review.

        Layer 3: FATE Escalation
        """
        if self._fate_escalate is None:
            logger.warning("FATE escalate callback not configured")
            return "FATE_NOT_CONFIGURED"

        try:
            escalation_id = await self._fate_escalate(reason, context)
            return escalation_id
        except Exception as e:
            logger.error("FATE escalation failed: %s", e)
            return f"FATE_ERROR_{e}"

    def record_compound_synthesis(self) -> None:
        """Record a successful compound synthesis."""
        self._reset_hourly_counters_if_needed()
        self.state.compounds_this_hour += 1

    def record_synergy_detection(self) -> None:
        """Record a synergy detection."""
        self._reset_hourly_counters_if_needed()
        self.state.synergies_this_hour += 1

    def record_loop_iteration(self, loop_name: str) -> None:
        """Record a loop iteration."""
        self.state.loop_iteration_counts[loop_name] = (
            self.state.loop_iteration_counts.get(loop_name, 0) + 1
        )

    def reset_loop_counter(self, loop_name: str) -> None:
        """Reset a specific loop counter."""
        self.state.loop_iteration_counts[loop_name] = 0

    def enter_explosion_mode(self) -> None:
        """Enter explosion mode (after all checks pass)."""
        self.state.is_explosion_mode = True
        logger.warning("KEP: Entering EXPLOSION MODE")

    def exit_explosion_mode(self) -> None:
        """Exit explosion mode."""
        self.state.is_explosion_mode = False
        self.state.last_explosion_exit = datetime.now(timezone.utc)
        logger.info("KEP: Exiting explosion mode, cooldown started")

    def _log_violation(self, violation_type: SafetyViolationType, message: str) -> None:
        """Log a safety violation."""
        timestamp = datetime.now(timezone.utc).isoformat()
        self.state.violations_log.append((timestamp, violation_type, message))
        logger.warning("KEP Safety Violation [%s]: %s", violation_type.value, message)

    def get_safety_status(self) -> dict:
        """Get current safety status for monitoring."""
        return {
            "ihsan": {
                "current": self.state.current_ihsan,
                "threshold": self.limits.IHSAN_MINIMUM,
                "target": self.limits.IHSAN_TARGET,
                "healthy": self.state.current_ihsan >= self.limits.IHSAN_MINIMUM,
            },
            "rate_limits": {
                "compounds_this_hour": self.state.compounds_this_hour,
                "compounds_max": self.limits.MAX_COMPOUNDS_PER_HOUR,
                "synergies_this_hour": self.state.synergies_this_hour,
                "synergies_max": self.limits.MAX_SYNERGIES_PER_HOUR,
            },
            "learning_rate": {
                "current": self.state.current_learning_rate,
                "max_normal": self.limits.MAX_LEARNING_RATE,
                "max_explosion": self.limits.EXPLOSION_LEARNING_RATE,
            },
            "mode": {
                "is_explosion": self.state.is_explosion_mode,
                "cooldown_active": (
                    self.state.last_explosion_exit is not None
                    and (datetime.now(timezone.utc) - self.state.last_explosion_exit).total_seconds()
                    < self.limits.EXPLOSION_COOLDOWN_HOURS * 3600
                ),
            },
            "recent_violations": self.state.violations_log[-10:],
        }


# Singleton-like function for global safety gate
_global_safety_gate: Optional[KEPSafetyGate] = None


def get_safety_gate() -> KEPSafetyGate:
    """Get or create the global KEP safety gate."""
    global _global_safety_gate
    if _global_safety_gate is None:
        _global_safety_gate = KEPSafetyGate()
    return _global_safety_gate


def set_safety_gate(gate: KEPSafetyGate) -> None:
    """Set the global KEP safety gate (for testing/DI)."""
    global _global_safety_gate
    _global_safety_gate = gate
