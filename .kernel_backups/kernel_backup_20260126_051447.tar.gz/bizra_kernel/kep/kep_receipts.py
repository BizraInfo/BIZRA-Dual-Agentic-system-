"""
KEP Receipt Schemas - Evidence Trail for Knowledge Explosion Operations
========================================================================
From the Blueprint:
    "Receipt-Native Architecture: All decisions emit structured receipts
    with receipt_id, timestamp, task_summary, rejection_codes,
    escalation_level, and integrity_hash (SHA-256)."

This module defines receipt schemas specific to KEP operations:
- CompoundDiscoveryReceipt
- SynergyDetectionReceipt
- ExplosionModeReceipt
- LearningAccelerationReceipt
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from enum import Enum
import hashlib
import json
import os
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class KEPReceiptType(Enum):
    """Types of KEP-specific receipts."""
    SYNERGY_DETECTION = "synergy_detection"
    COMPOUND_DISCOVERY = "compound_discovery"
    EXPLOSION_MODE_ENTRY = "explosion_mode_entry"
    EXPLOSION_MODE_EXIT = "explosion_mode_exit"
    LEARNING_ACCELERATION = "learning_acceleration"
    FEEDBACK_LOOP_CYCLE = "feedback_loop_cycle"
    SAFETY_VIOLATION = "safety_violation"


@dataclass
class SynergyDetectionReceipt:
    """Receipt for cross-domain synergy detection."""
    schema: str = "bizra-kep-synergy-v1"
    receipt_type: str = KEPReceiptType.SYNERGY_DETECTION.value
    receipt_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Synergy details
    source_id: str = ""
    target_id: str = ""
    source_domain: str = ""
    target_domain: str = ""
    similarity_score: float = 0.0
    structural_score: float = 0.0
    composite_score: float = 0.0
    potential_compound: str = ""

    # Validation
    ihsan_alignment: float = 0.0
    passed_threshold: bool = False
    threshold_used: float = 0.75

    # Audit
    detection_method: str = ""
    graph_path_length: int = 0
    integrity_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "receipt_type": self.receipt_type,
            "receipt_id": self.receipt_id,
            "timestamp": self.timestamp,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "source_domain": self.source_domain,
            "target_domain": self.target_domain,
            "similarity_score": self.similarity_score,
            "structural_score": self.structural_score,
            "composite_score": self.composite_score,
            "potential_compound": self.potential_compound,
            "ihsan_alignment": self.ihsan_alignment,
            "passed_threshold": self.passed_threshold,
            "threshold_used": self.threshold_used,
            "detection_method": self.detection_method,
            "graph_path_length": self.graph_path_length,
            "integrity_hash": self.integrity_hash,
        }


@dataclass
class CompoundDiscoveryReceipt:
    """Receipt for compound knowledge synthesis."""
    schema: str = "bizra-kep-compound-v1"
    receipt_type: str = KEPReceiptType.COMPOUND_DISCOVERY.value
    receipt_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Compound details
    compound_id: str = ""
    compound_name: str = ""
    emergent_capability: str = ""
    synthesis_type: str = ""  # additive, multiplicative, transcendent
    source_principles: List[str] = field(default_factory=list)
    domains_bridged: List[str] = field(default_factory=list)

    # Validation chain
    ihsan_alignment: float = 0.0
    sat_votes_for: int = 0
    sat_votes_against: int = 0
    sat_consensus_reached: bool = False
    required_consensus: int = 3

    # Source synergy
    synergy_receipt_id: str = ""

    # Audit
    synthesis_latency_ms: int = 0
    integrity_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "receipt_type": self.receipt_type,
            "receipt_id": self.receipt_id,
            "timestamp": self.timestamp,
            "compound_id": self.compound_id,
            "compound_name": self.compound_name,
            "emergent_capability": self.emergent_capability,
            "synthesis_type": self.synthesis_type,
            "source_principles": self.source_principles,
            "domains_bridged": self.domains_bridged,
            "ihsan_alignment": self.ihsan_alignment,
            "sat_votes_for": self.sat_votes_for,
            "sat_votes_against": self.sat_votes_against,
            "sat_consensus_reached": self.sat_consensus_reached,
            "required_consensus": self.required_consensus,
            "synergy_receipt_id": self.synergy_receipt_id,
            "synthesis_latency_ms": self.synthesis_latency_ms,
            "integrity_hash": self.integrity_hash,
        }


@dataclass
class ExplosionModeReceipt:
    """Receipt for explosion mode entry/exit."""
    schema: str = "bizra-kep-explosion-v1"
    receipt_type: str = ""  # Set based on entry/exit
    receipt_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Mode details
    is_entry: bool = True  # True for entry, False for exit

    # State at transition
    knowledge_mass: int = 0
    discovery_velocity: float = 0.0
    synergy_density: float = 0.0
    learning_rate_multiplier: float = 1.0
    ihsan_average: float = 0.0

    # Trigger conditions (for entry)
    mass_threshold_met: bool = False
    velocity_threshold_met: bool = False
    synergy_threshold_met: bool = False
    ihsan_threshold_met: bool = False
    all_conditions_met: bool = False

    # SAT approval (entry requires 4/5)
    sat_votes_for: int = 0
    sat_votes_against: int = 0
    sat_consensus_reached: bool = False

    # Duration (for exit)
    duration_seconds: int = 0
    compounds_synthesized: int = 0
    synergies_discovered: int = 0

    # Audit
    integrity_hash: str = ""

    def __post_init__(self):
        self.receipt_type = (
            KEPReceiptType.EXPLOSION_MODE_ENTRY.value
            if self.is_entry
            else KEPReceiptType.EXPLOSION_MODE_EXIT.value
        )

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "receipt_type": self.receipt_type,
            "receipt_id": self.receipt_id,
            "timestamp": self.timestamp,
            "is_entry": self.is_entry,
            "knowledge_mass": self.knowledge_mass,
            "discovery_velocity": self.discovery_velocity,
            "synergy_density": self.synergy_density,
            "learning_rate_multiplier": self.learning_rate_multiplier,
            "ihsan_average": self.ihsan_average,
            "mass_threshold_met": self.mass_threshold_met,
            "velocity_threshold_met": self.velocity_threshold_met,
            "synergy_threshold_met": self.synergy_threshold_met,
            "ihsan_threshold_met": self.ihsan_threshold_met,
            "all_conditions_met": self.all_conditions_met,
            "sat_votes_for": self.sat_votes_for,
            "sat_votes_against": self.sat_votes_against,
            "sat_consensus_reached": self.sat_consensus_reached,
            "duration_seconds": self.duration_seconds,
            "compounds_synthesized": self.compounds_synthesized,
            "synergies_discovered": self.synergies_discovered,
            "integrity_hash": self.integrity_hash,
        }


@dataclass
class LearningAccelerationReceipt:
    """Receipt for learning rate changes."""
    schema: str = "bizra-kep-acceleration-v1"
    receipt_type: str = KEPReceiptType.LEARNING_ACCELERATION.value
    receipt_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Rate details
    previous_rate: float = 0.0
    new_rate: float = 0.0
    rate_delta: float = 0.0
    rate_multiplier: float = 1.0

    # Factors
    knowledge_mass: int = 0
    mass_factor: float = 0.0
    discovery_velocity: float = 0.0
    velocity_factor: float = 0.0
    success_streak: int = 0
    streak_bonus: float = 0.0

    # Safety
    was_clamped: bool = False
    clamp_reason: str = ""
    ihsan_at_change: float = 0.0

    # Mode
    is_explosion_mode: bool = False

    # Audit
    integrity_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "receipt_type": self.receipt_type,
            "receipt_id": self.receipt_id,
            "timestamp": self.timestamp,
            "previous_rate": self.previous_rate,
            "new_rate": self.new_rate,
            "rate_delta": self.rate_delta,
            "rate_multiplier": self.rate_multiplier,
            "knowledge_mass": self.knowledge_mass,
            "mass_factor": self.mass_factor,
            "discovery_velocity": self.discovery_velocity,
            "velocity_factor": self.velocity_factor,
            "success_streak": self.success_streak,
            "streak_bonus": self.streak_bonus,
            "was_clamped": self.was_clamped,
            "clamp_reason": self.clamp_reason,
            "ihsan_at_change": self.ihsan_at_change,
            "is_explosion_mode": self.is_explosion_mode,
            "integrity_hash": self.integrity_hash,
        }


@dataclass
class FeedbackLoopReceipt:
    """Receipt for feedback loop cycle completion."""
    schema: str = "bizra-kep-feedback-v1"
    receipt_type: str = KEPReceiptType.FEEDBACK_LOOP_CYCLE.value
    receipt_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Loop identification
    loop_name: str = ""
    loop_type: str = ""  # sape_elevation, abstraction, compound_discovery, learning
    iteration_number: int = 0

    # Cycle metrics
    input_count: int = 0
    output_count: int = 0
    gain_achieved: float = 0.0
    target_gain: float = 1.0

    # Time
    cycle_latency_ms: int = 0

    # Safety
    ihsan_pre_cycle: float = 0.0
    ihsan_post_cycle: float = 0.0
    safety_check_passed: bool = True

    # Audit
    integrity_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "receipt_type": self.receipt_type,
            "receipt_id": self.receipt_id,
            "timestamp": self.timestamp,
            "loop_name": self.loop_name,
            "loop_type": self.loop_type,
            "iteration_number": self.iteration_number,
            "input_count": self.input_count,
            "output_count": self.output_count,
            "gain_achieved": self.gain_achieved,
            "target_gain": self.target_gain,
            "cycle_latency_ms": self.cycle_latency_ms,
            "ihsan_pre_cycle": self.ihsan_pre_cycle,
            "ihsan_post_cycle": self.ihsan_post_cycle,
            "safety_check_passed": self.safety_check_passed,
            "integrity_hash": self.integrity_hash,
        }


class KEPReceiptEmitter:
    """Emitter for KEP-specific receipts."""

    def __init__(self, output_dir: str = "docs/evidence/receipts/kep"):
        self.output_dir = output_dir
        self._counter = 0
        self._ensure_output_dir()

    def _ensure_output_dir(self) -> None:
        """Ensure output directory exists."""
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)

    def _next_id(self, prefix: str) -> str:
        """Generate next receipt ID."""
        self._counter += 1
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        return f"{prefix}-{timestamp}-{self._counter:06d}"

    def _calculate_hash(self, data: dict) -> str:
        """Calculate SHA-256 integrity hash."""
        # Remove existing hash if present
        data_copy = {k: v for k, v in data.items() if k != "integrity_hash"}
        content = json.dumps(data_copy, sort_keys=True)
        hash_bytes = hashlib.sha256(content.encode()).digest()
        return f"sha256:{hash_bytes.hex()}"

    def _persist(self, receipt_id: str, data: dict) -> None:
        """Persist receipt to file."""
        filename = f"{receipt_id}.json"
        filepath = Path(self.output_dir) / filename

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            logger.info("KEP receipt emitted: %s", receipt_id)
        except Exception as e:
            logger.error("Failed to persist KEP receipt %s: %s", receipt_id, e)

    def emit_synergy_detection(
        self,
        source_id: str,
        target_id: str,
        source_domain: str,
        target_domain: str,
        similarity_score: float,
        structural_score: float,
        composite_score: float,
        potential_compound: str,
        ihsan_alignment: float,
        passed_threshold: bool,
        detection_method: str = "hybrid",
        graph_path_length: int = 0,
    ) -> SynergyDetectionReceipt:
        """Emit a synergy detection receipt."""
        receipt = SynergyDetectionReceipt(
            receipt_id=self._next_id("SYN"),
            source_id=source_id,
            target_id=target_id,
            source_domain=source_domain,
            target_domain=target_domain,
            similarity_score=similarity_score,
            structural_score=structural_score,
            composite_score=composite_score,
            potential_compound=potential_compound,
            ihsan_alignment=ihsan_alignment,
            passed_threshold=passed_threshold,
            detection_method=detection_method,
            graph_path_length=graph_path_length,
        )

        data = receipt.to_dict()
        receipt.integrity_hash = self._calculate_hash(data)
        data["integrity_hash"] = receipt.integrity_hash

        self._persist(receipt.receipt_id, data)
        return receipt

    def emit_compound_discovery(
        self,
        compound_id: str,
        compound_name: str,
        emergent_capability: str,
        synthesis_type: str,
        source_principles: List[str],
        domains_bridged: List[str],
        ihsan_alignment: float,
        sat_votes_for: int,
        sat_votes_against: int,
        synergy_receipt_id: str,
        synthesis_latency_ms: int = 0,
    ) -> CompoundDiscoveryReceipt:
        """Emit a compound discovery receipt."""
        receipt = CompoundDiscoveryReceipt(
            receipt_id=self._next_id("COMP"),
            compound_id=compound_id,
            compound_name=compound_name,
            emergent_capability=emergent_capability,
            synthesis_type=synthesis_type,
            source_principles=source_principles,
            domains_bridged=domains_bridged,
            ihsan_alignment=ihsan_alignment,
            sat_votes_for=sat_votes_for,
            sat_votes_against=sat_votes_against,
            sat_consensus_reached=sat_votes_for >= 3,
            synergy_receipt_id=synergy_receipt_id,
            synthesis_latency_ms=synthesis_latency_ms,
        )

        data = receipt.to_dict()
        receipt.integrity_hash = self._calculate_hash(data)
        data["integrity_hash"] = receipt.integrity_hash

        self._persist(receipt.receipt_id, data)
        return receipt

    def emit_explosion_mode(
        self,
        is_entry: bool,
        knowledge_mass: int,
        discovery_velocity: float,
        synergy_density: float,
        learning_rate_multiplier: float,
        ihsan_average: float,
        sat_votes_for: int = 0,
        sat_votes_against: int = 0,
        duration_seconds: int = 0,
        compounds_synthesized: int = 0,
        synergies_discovered: int = 0,
        conditions: Optional[Dict[str, bool]] = None,
    ) -> ExplosionModeReceipt:
        """Emit an explosion mode entry/exit receipt."""
        conditions = conditions or {}

        receipt = ExplosionModeReceipt(
            receipt_id=self._next_id("EXP"),
            is_entry=is_entry,
            knowledge_mass=knowledge_mass,
            discovery_velocity=discovery_velocity,
            synergy_density=synergy_density,
            learning_rate_multiplier=learning_rate_multiplier,
            ihsan_average=ihsan_average,
            mass_threshold_met=conditions.get("mass", False),
            velocity_threshold_met=conditions.get("velocity", False),
            synergy_threshold_met=conditions.get("synergy", False),
            ihsan_threshold_met=conditions.get("ihsan", False),
            all_conditions_met=all(conditions.values()) if conditions else False,
            sat_votes_for=sat_votes_for,
            sat_votes_against=sat_votes_against,
            sat_consensus_reached=sat_votes_for >= 4,
            duration_seconds=duration_seconds,
            compounds_synthesized=compounds_synthesized,
            synergies_discovered=synergies_discovered,
        )

        data = receipt.to_dict()
        receipt.integrity_hash = self._calculate_hash(data)
        data["integrity_hash"] = receipt.integrity_hash

        self._persist(receipt.receipt_id, data)
        return receipt

    def emit_learning_acceleration(
        self,
        previous_rate: float,
        new_rate: float,
        knowledge_mass: int,
        mass_factor: float,
        discovery_velocity: float,
        velocity_factor: float,
        success_streak: int,
        streak_bonus: float,
        was_clamped: bool,
        clamp_reason: str,
        ihsan_at_change: float,
        is_explosion_mode: bool,
    ) -> LearningAccelerationReceipt:
        """Emit a learning acceleration receipt."""
        receipt = LearningAccelerationReceipt(
            receipt_id=self._next_id("ACCEL"),
            previous_rate=previous_rate,
            new_rate=new_rate,
            rate_delta=new_rate - previous_rate,
            rate_multiplier=new_rate / previous_rate if previous_rate > 0 else 1.0,
            knowledge_mass=knowledge_mass,
            mass_factor=mass_factor,
            discovery_velocity=discovery_velocity,
            velocity_factor=velocity_factor,
            success_streak=success_streak,
            streak_bonus=streak_bonus,
            was_clamped=was_clamped,
            clamp_reason=clamp_reason,
            ihsan_at_change=ihsan_at_change,
            is_explosion_mode=is_explosion_mode,
        )

        data = receipt.to_dict()
        receipt.integrity_hash = self._calculate_hash(data)
        data["integrity_hash"] = receipt.integrity_hash

        self._persist(receipt.receipt_id, data)
        return receipt

    def emit_feedback_loop(
        self,
        loop_name: str,
        loop_type: str,
        iteration_number: int,
        input_count: int,
        output_count: int,
        gain_achieved: float,
        target_gain: float,
        cycle_latency_ms: int,
        ihsan_pre_cycle: float,
        ihsan_post_cycle: float,
        safety_check_passed: bool,
    ) -> FeedbackLoopReceipt:
        """Emit a feedback loop cycle receipt."""
        receipt = FeedbackLoopReceipt(
            receipt_id=self._next_id("LOOP"),
            loop_name=loop_name,
            loop_type=loop_type,
            iteration_number=iteration_number,
            input_count=input_count,
            output_count=output_count,
            gain_achieved=gain_achieved,
            target_gain=target_gain,
            cycle_latency_ms=cycle_latency_ms,
            ihsan_pre_cycle=ihsan_pre_cycle,
            ihsan_post_cycle=ihsan_post_cycle,
            safety_check_passed=safety_check_passed,
        )

        data = receipt.to_dict()
        receipt.integrity_hash = self._calculate_hash(data)
        data["integrity_hash"] = receipt.integrity_hash

        self._persist(receipt.receipt_id, data)
        return receipt


# Global emitter instance
_global_emitter: Optional[KEPReceiptEmitter] = None


def get_kep_receipt_emitter() -> KEPReceiptEmitter:
    """Get or create the global KEP receipt emitter."""
    global _global_emitter
    if _global_emitter is None:
        _global_emitter = KEPReceiptEmitter()
    return _global_emitter
