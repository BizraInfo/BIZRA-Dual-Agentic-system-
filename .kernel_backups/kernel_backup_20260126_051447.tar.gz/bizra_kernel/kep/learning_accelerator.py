"""
Learning Rate Accelerator - Adaptive Learning Based on Knowledge Mass
======================================================================
From the Blueprint:
    "Dynamically adjusts learning rate based on knowledge mass and
    success patterns. Enables explosion mode when all conditions met."

The accelerator implements a self-reinforcing feedback loop:
    More knowledge -> Higher rate -> More knowledge (bounded by safety)
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict
from enum import Enum
import logging

from ..abstraction_elevator import AbstractionElevator
from .kep_safety import get_safety_gate, SafetyResponse, KEPSafetyLimits
from .kep_receipts import get_kep_receipt_emitter

logger = logging.getLogger(__name__)


@dataclass
class LearningState:
    """Current state of the learning system."""
    # Knowledge metrics
    instance_count: int = 0
    pattern_count: int = 0
    principle_count: int = 0
    compound_count: int = 0
    knowledge_mass: int = 0  # Weighted sum

    # Velocity metrics
    compounds_last_hour: int = 0
    synergies_last_hour: int = 0
    discovery_velocity: float = 0.0  # compounds/hour

    # Success tracking
    synthesis_attempts: int = 0
    synthesis_successes: int = 0
    success_rate: float = 0.0
    success_streak: int = 0

    # Synergy metrics
    active_synergies: int = 0
    possible_synergy_pairs: int = 0
    synergy_density: float = 0.0

    # Ihsan
    system_ihsan_average: float = 0.0

    # Current rate
    current_learning_rate: float = 0.1
    rate_multiplier: float = 1.0

    # Mode
    is_explosion_mode: bool = False
    explosion_start: Optional[datetime] = None

    def to_dict(self) -> dict:
        return {
            "instance_count": self.instance_count,
            "pattern_count": self.pattern_count,
            "principle_count": self.principle_count,
            "compound_count": self.compound_count,
            "knowledge_mass": self.knowledge_mass,
            "compounds_last_hour": self.compounds_last_hour,
            "synergies_last_hour": self.synergies_last_hour,
            "discovery_velocity": self.discovery_velocity,
            "synthesis_attempts": self.synthesis_attempts,
            "synthesis_successes": self.synthesis_successes,
            "success_rate": self.success_rate,
            "success_streak": self.success_streak,
            "active_synergies": self.active_synergies,
            "synergy_density": self.synergy_density,
            "system_ihsan_average": self.system_ihsan_average,
            "current_learning_rate": self.current_learning_rate,
            "rate_multiplier": self.rate_multiplier,
            "is_explosion_mode": self.is_explosion_mode,
        }


class ExplosionCondition(Enum):
    """Conditions required for explosion mode."""
    KNOWLEDGE_MASS = "knowledge_mass"      # >= 500
    DISCOVERY_VELOCITY = "discovery_velocity"  # >= 5/hr
    SYNERGY_DENSITY = "synergy_density"    # >= 0.25
    IHSAN_HEALTH = "ihsan_health"          # >= 0.992


@dataclass
class ExplosionTriggerThresholds:
    """Thresholds for explosion mode entry."""
    # From the plan:
    # Knowledge Mass: >= 50 principles across >= 5 domains
    # Cross-Domain Synergies: >= 3 active synergistic pattern pairs
    # Discovery Velocity: >= 2 new compounds per hour
    # Ihsan Health: System-wide average >= 0.992

    knowledge_mass: int = 500  # Weighted: inst + 5*pat + 25*prin + 100*comp
    min_principles: int = 50
    min_domains: int = 5
    discovery_velocity: float = 2.0  # compounds/hour
    synergy_density: float = 0.15  # 3+ active synergies
    min_active_synergies: int = 3
    ihsan_average: float = 0.992


class LearningAccelerator:
    """
    Adaptive learning rate controller for KEP.

    Formula:
        rate = base_rate * (1 + mass_factor * knowledge_mass)
                        * (1 + velocity_factor * discovery_velocity)
                        + streak_bonus * success_streak

    Bounded: MIN_RATE <= rate <= MAX_RATE (or EXPLOSION_RATE if explosion mode)
    """

    # Base parameters
    BASE_RATE = 0.1
    MIN_RATE = 0.05
    MAX_RATE = 2.0
    EXPLOSION_RATE = 5.0

    # Factor weights
    MASS_FACTOR = 0.001          # Per unit of knowledge mass
    VELOCITY_FACTOR = 0.1        # Per compound/hour
    STREAK_BONUS = 0.02          # Per success in streak

    # Knowledge mass weights
    INSTANCE_WEIGHT = 1
    PATTERN_WEIGHT = 5
    PRINCIPLE_WEIGHT = 25
    COMPOUND_WEIGHT = 100

    def __init__(
        self,
        elevator: Optional[AbstractionElevator] = None,
        thresholds: Optional[ExplosionTriggerThresholds] = None,
    ):
        self.elevator = elevator or AbstractionElevator()
        self.thresholds = thresholds or ExplosionTriggerThresholds()
        self.state = LearningState()

        # Compound tracking for velocity
        self._compound_timestamps: List[datetime] = []

        logger.info("LearningAccelerator initialized with base rate %.2f", self.BASE_RATE)

    def _calculate_knowledge_mass(self) -> int:
        """Calculate weighted knowledge mass from elevator."""
        stats = self.elevator.get_statistics()

        # Get counts
        instance_count = stats.get("total_instances", 0)
        pattern_count = stats.get("total_patterns", 0)
        principle_count = stats.get("total_principles", 0)

        # Compound count from state (not in elevator stats)
        compound_count = self.state.compound_count

        # Weighted sum
        mass = (
            self.INSTANCE_WEIGHT * instance_count +
            self.PATTERN_WEIGHT * pattern_count +
            self.PRINCIPLE_WEIGHT * principle_count +
            self.COMPOUND_WEIGHT * compound_count
        )

        # Update state
        self.state.instance_count = instance_count
        self.state.pattern_count = pattern_count
        self.state.principle_count = principle_count
        self.state.knowledge_mass = mass

        return mass

    def _calculate_discovery_velocity(self) -> float:
        """Calculate compounds per hour based on recent history."""
        now = datetime.now(timezone.utc)
        one_hour_ago = now - timedelta(hours=1)

        # Filter to last hour
        recent = [ts for ts in self._compound_timestamps if ts > one_hour_ago]
        self._compound_timestamps = recent  # Prune old entries

        velocity = len(recent)  # compounds in last hour
        self.state.compounds_last_hour = velocity
        self.state.discovery_velocity = float(velocity)

        return float(velocity)

    def _calculate_synergy_density(
        self,
        active_synergies: int,
        principle_count: int,
    ) -> float:
        """Calculate synergy density (active synergies / possible pairs)."""
        if principle_count < 2:
            return 0.0

        # Possible pairs = n * (n-1) / 2
        possible_pairs = principle_count * (principle_count - 1) // 2
        self.state.possible_synergy_pairs = possible_pairs
        self.state.active_synergies = active_synergies

        if possible_pairs == 0:
            return 0.0

        density = active_synergies / possible_pairs
        self.state.synergy_density = density

        return density

    def _calculate_system_ihsan(self) -> float:
        """Calculate average Ihsan across all principles."""
        principles = list(self.elevator.principles.values())
        if not principles:
            return 0.0

        total = sum(p.ihsan_alignment for p in principles)
        average = total / len(principles)
        self.state.system_ihsan_average = average

        return average

    def calculate_learning_rate(
        self,
        active_synergies: int = 0,
    ) -> float:
        """
        Calculate the current learning rate based on system state.

        Returns the clamped rate and updates internal state.
        """
        # Gather metrics
        knowledge_mass = self._calculate_knowledge_mass()
        discovery_velocity = self._calculate_discovery_velocity()
        synergy_density = self._calculate_synergy_density(
            active_synergies, self.state.principle_count
        )

        # Calculate base rate with factors
        rate = self.BASE_RATE

        # Mass factor
        mass_contribution = self.MASS_FACTOR * knowledge_mass
        rate *= (1 + mass_contribution)

        # Velocity factor
        velocity_contribution = self.VELOCITY_FACTOR * discovery_velocity
        rate *= (1 + velocity_contribution)

        # Streak bonus (additive)
        streak_contribution = self.STREAK_BONUS * self.state.success_streak
        rate += streak_contribution

        # Determine max rate based on mode
        safety = get_safety_gate()
        if self.state.is_explosion_mode:
            max_rate = self.EXPLOSION_RATE
        else:
            max_rate = self.MAX_RATE

        # Safety gate check (may further clamp)
        response, clamped_rate = safety.check_learning_rate(rate)

        # Apply clamping
        final_rate = max(self.MIN_RATE, min(rate, max_rate, clamped_rate))

        # Emit receipt if rate changed significantly
        if abs(final_rate - self.state.current_learning_rate) > 0.01:
            emitter = get_kep_receipt_emitter()
            emitter.emit_learning_acceleration(
                previous_rate=self.state.current_learning_rate,
                new_rate=final_rate,
                knowledge_mass=knowledge_mass,
                mass_factor=mass_contribution,
                discovery_velocity=discovery_velocity,
                velocity_factor=velocity_contribution,
                success_streak=self.state.success_streak,
                streak_bonus=streak_contribution,
                was_clamped=(final_rate < rate),
                clamp_reason="rate_limit" if final_rate < rate else "",
                ihsan_at_change=self.state.system_ihsan_average,
                is_explosion_mode=self.state.is_explosion_mode,
            )

        # Update state
        self.state.current_learning_rate = final_rate
        self.state.rate_multiplier = final_rate / self.BASE_RATE

        logger.debug(
            "Learning rate: %.3f (mass: %d, velocity: %.1f, streak: %d)",
            final_rate, knowledge_mass, discovery_velocity, self.state.success_streak
        )

        return final_rate

    def check_explosion_trigger(
        self,
        active_synergies: int = 0,
    ) -> Dict[ExplosionCondition, bool]:
        """
        Check if all explosion trigger conditions are met.

        Returns dict mapping each condition to whether it's satisfied.
        """
        # Update metrics
        self._calculate_knowledge_mass()
        self._calculate_discovery_velocity()
        self._calculate_synergy_density(active_synergies, self.state.principle_count)
        self._calculate_system_ihsan()

        # Check each condition
        conditions = {
            ExplosionCondition.KNOWLEDGE_MASS: (
                self.state.knowledge_mass >= self.thresholds.knowledge_mass and
                self.state.principle_count >= self.thresholds.min_principles
            ),
            ExplosionCondition.DISCOVERY_VELOCITY: (
                self.state.discovery_velocity >= self.thresholds.discovery_velocity
            ),
            ExplosionCondition.SYNERGY_DENSITY: (
                self.state.active_synergies >= self.thresholds.min_active_synergies
            ),
            ExplosionCondition.IHSAN_HEALTH: (
                self.state.system_ihsan_average >= self.thresholds.ihsan_average
            ),
        }

        return conditions

    def can_enter_explosion_mode(
        self,
        active_synergies: int = 0,
    ) -> bool:
        """Check if system can enter explosion mode."""
        conditions = self.check_explosion_trigger(active_synergies)

        # All conditions must be met
        if not all(conditions.values()):
            return False

        # Safety gate must allow
        safety = get_safety_gate()
        response = safety.check_explosion_entry()

        return response == SafetyResponse.CONTINUE

    async def enter_explosion_mode(
        self,
        active_synergies: int = 0,
    ) -> bool:
        """
        Attempt to enter explosion mode.

        Requires:
        - All trigger conditions met
        - Safety gate approval
        - SAT 4/5 consensus (via safety gate)
        """
        conditions = self.check_explosion_trigger(active_synergies)

        if not all(conditions.values()):
            logger.info(
                "Explosion mode denied: conditions not met - %s",
                {k.value: v for k, v in conditions.items()}
            )
            return False

        safety = get_safety_gate()

        # Check safety gate (includes cooldown)
        response = safety.check_explosion_entry()
        if response != SafetyResponse.CONTINUE:
            logger.info("Explosion mode denied by safety gate: %s", response)
            return False

        # Request SAT consensus (4/5 required)
        sat_response = await safety.request_sat_consensus(
            "explosion_mode_entry",
            required_votes=4,
        )

        if sat_response != SafetyResponse.CONTINUE:
            logger.info("Explosion mode denied by SAT consensus")
            return False

        # Enter explosion mode
        self.state.is_explosion_mode = True
        self.state.explosion_start = datetime.now(timezone.utc)
        safety.enter_explosion_mode()

        # Emit receipt
        emitter = get_kep_receipt_emitter()
        emitter.emit_explosion_mode(
            is_entry=True,
            knowledge_mass=self.state.knowledge_mass,
            discovery_velocity=self.state.discovery_velocity,
            synergy_density=self.state.synergy_density,
            learning_rate_multiplier=self.state.rate_multiplier,
            ihsan_average=self.state.system_ihsan_average,
            sat_votes_for=4,
            sat_votes_against=1,
            conditions={k.value: v for k, v in conditions.items()},
        )

        logger.warning(
            "EXPLOSION MODE ENTERED - mass: %d, velocity: %.1f, ihsan: %.3f",
            self.state.knowledge_mass,
            self.state.discovery_velocity,
            self.state.system_ihsan_average,
        )

        return True

    def exit_explosion_mode(
        self,
        compounds_synthesized: int = 0,
        synergies_discovered: int = 0,
    ) -> None:
        """Exit explosion mode."""
        if not self.state.is_explosion_mode:
            return

        duration_seconds = 0
        if self.state.explosion_start:
            duration_seconds = int(
                (datetime.now(timezone.utc) - self.state.explosion_start).total_seconds()
            )

        safety = get_safety_gate()
        safety.exit_explosion_mode()

        # Emit receipt
        emitter = get_kep_receipt_emitter()
        emitter.emit_explosion_mode(
            is_entry=False,
            knowledge_mass=self.state.knowledge_mass,
            discovery_velocity=self.state.discovery_velocity,
            synergy_density=self.state.synergy_density,
            learning_rate_multiplier=self.state.rate_multiplier,
            ihsan_average=self.state.system_ihsan_average,
            duration_seconds=duration_seconds,
            compounds_synthesized=compounds_synthesized,
            synergies_discovered=synergies_discovered,
        )

        self.state.is_explosion_mode = False
        self.state.explosion_start = None

        logger.info(
            "Explosion mode exited - duration: %ds, compounds: %d",
            duration_seconds, compounds_synthesized
        )

    def record_synthesis_attempt(self, success: bool) -> None:
        """Record a synthesis attempt for tracking."""
        self.state.synthesis_attempts += 1

        if success:
            self.state.synthesis_successes += 1
            self.state.success_streak += 1
            self.state.compound_count += 1
            self._compound_timestamps.append(datetime.now(timezone.utc))
        else:
            self.state.success_streak = 0

        # Update success rate
        self.state.success_rate = (
            self.state.synthesis_successes / max(1, self.state.synthesis_attempts)
        )

    def get_state(self) -> LearningState:
        """Get current learning state."""
        return self.state

    def get_statistics(self) -> dict:
        """Get accelerator statistics."""
        return {
            "state": self.state.to_dict(),
            "thresholds": {
                "knowledge_mass": self.thresholds.knowledge_mass,
                "discovery_velocity": self.thresholds.discovery_velocity,
                "synergy_density": self.thresholds.synergy_density,
                "ihsan_average": self.thresholds.ihsan_average,
            },
            "rate_config": {
                "base_rate": self.BASE_RATE,
                "min_rate": self.MIN_RATE,
                "max_rate": self.MAX_RATE,
                "explosion_rate": self.EXPLOSION_RATE,
                "mass_factor": self.MASS_FACTOR,
                "velocity_factor": self.VELOCITY_FACTOR,
                "streak_bonus": self.STREAK_BONUS,
            },
        }
