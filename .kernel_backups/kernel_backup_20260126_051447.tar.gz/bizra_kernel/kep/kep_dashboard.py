"""
KEP Dashboard - Real-time Metrics and Monitoring
=================================================
From the Blueprint:
    "Real-time metrics for explosion progress."

Provides comprehensive monitoring of the KEP system including:
- Knowledge mass tracking
- Discovery velocity
- Synergy density
- Learning rate multiplier
- Explosion mode progress
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Dict, List, Any
from enum import Enum
import logging

from ..abstraction_elevator import AbstractionElevator
from .synergy_detector import SynergyDetector
from .compound_discovery import CompoundDiscoveryEngine
from .learning_accelerator import LearningAccelerator, ExplosionTriggerThresholds
from .feedback_composer import FeedbackLoopComposer, LoopType
from .kep_safety import get_safety_gate

logger = logging.getLogger(__name__)


class MetricStatus(Enum):
    """Status of a metric relative to its threshold."""
    BELOW = "below"
    AT_THRESHOLD = "at_threshold"
    ABOVE = "above"
    CRITICAL = "critical"


@dataclass
class Metric:
    """A single monitored metric."""
    name: str
    value: float
    threshold: float
    unit: str = ""
    status: MetricStatus = MetricStatus.BELOW
    description: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "value": self.value,
            "threshold": self.threshold,
            "unit": self.unit,
            "status": self.status.value,
            "description": self.description,
            "progress": min(1.0, self.value / max(0.001, self.threshold)),
        }


@dataclass
class ExplosionProgress:
    """Progress toward explosion mode."""
    overall_progress: float = 0.0  # 0.0 to 1.0
    conditions_met: int = 0
    total_conditions: int = 4
    condition_details: Dict[str, bool] = field(default_factory=dict)
    estimated_time_to_explosion: Optional[str] = None
    is_explosion_mode: bool = False
    explosion_duration_seconds: int = 0

    def to_dict(self) -> dict:
        return {
            "overall_progress": self.overall_progress,
            "conditions_met": self.conditions_met,
            "total_conditions": self.total_conditions,
            "condition_details": self.condition_details,
            "estimated_time_to_explosion": self.estimated_time_to_explosion,
            "is_explosion_mode": self.is_explosion_mode,
            "explosion_duration_seconds": self.explosion_duration_seconds,
        }


class KEPDashboard:
    """
    Dashboard for monitoring KEP system metrics.

    Key Metrics:
    | Metric | Formula | Explosion Threshold |
    |--------|---------|---------------------|
    | Knowledge Mass | instances + 5*patterns + 25*principles + 100*compounds | >= 500 |
    | Discovery Velocity | compounds/hour | >= 5/hr |
    | Synergy Density | active_synergies / possible_pairs | >= 0.25 |
    | Learning Rate Multiplier | current_rate / base_rate | >= 3x |
    """

    # Thresholds from plan
    KNOWLEDGE_MASS_THRESHOLD = 500
    DISCOVERY_VELOCITY_THRESHOLD = 5.0
    SYNERGY_DENSITY_THRESHOLD = 0.25
    LEARNING_RATE_THRESHOLD = 3.0
    IHSAN_THRESHOLD = 0.992

    def __init__(
        self,
        elevator: Optional[AbstractionElevator] = None,
        synergy_detector: Optional[SynergyDetector] = None,
        compound_engine: Optional[CompoundDiscoveryEngine] = None,
        accelerator: Optional[LearningAccelerator] = None,
        composer: Optional[FeedbackLoopComposer] = None,
    ):
        self.elevator = elevator
        self.synergy_detector = synergy_detector
        self.compound_engine = compound_engine
        self.accelerator = accelerator
        self.composer = composer

        # Historical data for trends
        self._metric_history: Dict[str, List[tuple]] = {
            "knowledge_mass": [],
            "discovery_velocity": [],
            "synergy_density": [],
            "learning_rate": [],
            "ihsan_average": [],
        }
        self._max_history_points = 100

        logger.info("KEPDashboard initialized")

    def _record_metric(self, name: str, value: float) -> None:
        """Record a metric value for historical tracking."""
        if name in self._metric_history:
            history = self._metric_history[name]
            history.append((datetime.now(timezone.utc).isoformat(), value))
            # Keep only last N points
            if len(history) > self._max_history_points:
                self._metric_history[name] = history[-self._max_history_points:]

    def _get_metric_status(self, value: float, threshold: float) -> MetricStatus:
        """Determine metric status based on value vs threshold."""
        ratio = value / max(0.001, threshold)
        if ratio >= 1.0:
            return MetricStatus.ABOVE
        elif ratio >= 0.9:
            return MetricStatus.AT_THRESHOLD
        elif ratio < 0.5:
            return MetricStatus.CRITICAL if ratio < 0.25 else MetricStatus.BELOW
        return MetricStatus.BELOW

    def get_knowledge_mass_metric(self) -> Metric:
        """Get knowledge mass metric."""
        if self.accelerator:
            state = self.accelerator.get_state()
            value = state.knowledge_mass
        elif self.elevator:
            stats = self.elevator.get_statistics()
            value = (
                stats.get("total_instances", 0) +
                5 * stats.get("total_patterns", 0) +
                25 * stats.get("total_principles", 0)
            )
        else:
            value = 0

        self._record_metric("knowledge_mass", value)

        return Metric(
            name="Knowledge Mass",
            value=value,
            threshold=self.KNOWLEDGE_MASS_THRESHOLD,
            unit="units",
            status=self._get_metric_status(value, self.KNOWLEDGE_MASS_THRESHOLD),
            description="Weighted sum: instances + 5*patterns + 25*principles + 100*compounds",
        )

    def get_discovery_velocity_metric(self) -> Metric:
        """Get discovery velocity metric."""
        if self.accelerator:
            state = self.accelerator.get_state()
            value = state.discovery_velocity
        else:
            value = 0.0

        self._record_metric("discovery_velocity", value)

        return Metric(
            name="Discovery Velocity",
            value=value,
            threshold=self.DISCOVERY_VELOCITY_THRESHOLD,
            unit="compounds/hr",
            status=self._get_metric_status(value, self.DISCOVERY_VELOCITY_THRESHOLD),
            description="New compounds synthesized per hour",
        )

    def get_synergy_density_metric(self) -> Metric:
        """Get synergy density metric."""
        if self.synergy_detector:
            stats = self.synergy_detector.get_statistics()
            valid = stats.get("valid_candidates", 0)
            total = stats.get("total_detected", 0) or 1

            # Calculate based on active synergies
            if self.elevator:
                principle_count = len(self.elevator.principles)
                possible_pairs = principle_count * (principle_count - 1) // 2
                value = valid / max(1, possible_pairs)
            else:
                value = valid / total
        else:
            value = 0.0

        self._record_metric("synergy_density", value)

        return Metric(
            name="Synergy Density",
            value=value,
            threshold=self.SYNERGY_DENSITY_THRESHOLD,
            unit="ratio",
            status=self._get_metric_status(value, self.SYNERGY_DENSITY_THRESHOLD),
            description="Active synergies / possible pairs",
        )

    def get_learning_rate_metric(self) -> Metric:
        """Get learning rate multiplier metric."""
        if self.accelerator:
            state = self.accelerator.get_state()
            value = state.rate_multiplier
        else:
            value = 1.0

        self._record_metric("learning_rate", value)

        return Metric(
            name="Learning Rate Multiplier",
            value=value,
            threshold=self.LEARNING_RATE_THRESHOLD,
            unit="x",
            status=self._get_metric_status(value, self.LEARNING_RATE_THRESHOLD),
            description="Current rate / base rate",
        )

    def get_ihsan_metric(self) -> Metric:
        """Get system-wide Ihsan average metric."""
        if self.elevator:
            principles = list(self.elevator.principles.values())
            if principles:
                value = sum(p.ihsan_alignment for p in principles) / len(principles)
            else:
                value = 0.99
        else:
            value = 0.99

        self._record_metric("ihsan_average", value)

        return Metric(
            name="System Ihsan Average",
            value=value,
            threshold=self.IHSAN_THRESHOLD,
            unit="score",
            status=self._get_metric_status(value, self.IHSAN_THRESHOLD),
            description="Average Ihsan alignment across all principles",
        )

    def get_all_metrics(self) -> Dict[str, Metric]:
        """Get all dashboard metrics."""
        return {
            "knowledge_mass": self.get_knowledge_mass_metric(),
            "discovery_velocity": self.get_discovery_velocity_metric(),
            "synergy_density": self.get_synergy_density_metric(),
            "learning_rate": self.get_learning_rate_metric(),
            "ihsan_average": self.get_ihsan_metric(),
        }

    def get_explosion_progress(self) -> ExplosionProgress:
        """Calculate progress toward explosion mode."""
        metrics = self.get_all_metrics()

        # Calculate individual condition progress
        condition_progress = {
            "knowledge_mass": min(1.0, metrics["knowledge_mass"].value / self.KNOWLEDGE_MASS_THRESHOLD),
            "discovery_velocity": min(1.0, metrics["discovery_velocity"].value / self.DISCOVERY_VELOCITY_THRESHOLD),
            "synergy_density": min(1.0, metrics["synergy_density"].value / self.SYNERGY_DENSITY_THRESHOLD),
            "ihsan_health": min(1.0, metrics["ihsan_average"].value / self.IHSAN_THRESHOLD),
        }

        # Count conditions met
        condition_details = {
            "knowledge_mass": condition_progress["knowledge_mass"] >= 1.0,
            "discovery_velocity": condition_progress["discovery_velocity"] >= 1.0,
            "synergy_density": condition_progress["synergy_density"] >= 1.0,
            "ihsan_health": condition_progress["ihsan_health"] >= 1.0,
        }

        conditions_met = sum(condition_details.values())

        # Overall progress (average of all conditions)
        overall_progress = sum(condition_progress.values()) / len(condition_progress)

        # Check if in explosion mode
        is_explosion = False
        explosion_duration = 0
        if self.accelerator:
            state = self.accelerator.get_state()
            is_explosion = state.is_explosion_mode
            if state.explosion_start:
                explosion_duration = int(
                    (datetime.now(timezone.utc) - state.explosion_start).total_seconds()
                )

        return ExplosionProgress(
            overall_progress=overall_progress,
            conditions_met=conditions_met,
            total_conditions=4,
            condition_details=condition_details,
            is_explosion_mode=is_explosion,
            explosion_duration_seconds=explosion_duration,
        )

    def get_safety_status(self) -> Dict[str, Any]:
        """Get current safety status."""
        safety = get_safety_gate()
        return safety.get_safety_status()

    def get_loop_status(self) -> Dict[str, Any]:
        """Get feedback loop status."""
        if self.composer:
            return self.composer.get_statistics()
        return {"loops": {}, "is_running": False}

    def get_compound_status(self) -> Dict[str, Any]:
        """Get compound discovery status."""
        if self.compound_engine:
            return self.compound_engine.get_statistics()
        return {"total_compounds": 0}

    def get_synergy_status(self) -> Dict[str, Any]:
        """Get synergy detection status."""
        if self.synergy_detector:
            return self.synergy_detector.get_statistics()
        return {"total_detected": 0}

    def get_full_dashboard(self) -> Dict[str, Any]:
        """Get complete dashboard data."""
        metrics = self.get_all_metrics()

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "metrics": {k: v.to_dict() for k, v in metrics.items()},
            "explosion_progress": self.get_explosion_progress().to_dict(),
            "safety": self.get_safety_status(),
            "loops": self.get_loop_status(),
            "compounds": self.get_compound_status(),
            "synergies": self.get_synergy_status(),
            "history": {
                k: v[-10:] for k, v in self._metric_history.items()  # Last 10 points
            },
        }

    def get_prometheus_metrics(self) -> str:
        """Generate Prometheus-format metrics."""
        metrics = self.get_all_metrics()
        explosion = self.get_explosion_progress()

        lines = [
            "# HELP bizra_kep_knowledge_mass Weighted knowledge mass",
            "# TYPE bizra_kep_knowledge_mass gauge",
            f"bizra_kep_knowledge_mass {metrics['knowledge_mass'].value}",
            "",
            "# HELP bizra_kep_discovery_velocity Compounds per hour",
            "# TYPE bizra_kep_discovery_velocity gauge",
            f"bizra_kep_discovery_velocity {metrics['discovery_velocity'].value}",
            "",
            "# HELP bizra_kep_synergy_count Active synergy count",
            "# TYPE bizra_kep_synergy_count gauge",
        ]

        if self.synergy_detector:
            stats = self.synergy_detector.get_statistics()
            lines.append(f"bizra_kep_synergy_count {stats.get('valid_candidates', 0)}")
        else:
            lines.append("bizra_kep_synergy_count 0")

        lines.extend([
            "",
            "# HELP bizra_kep_compound_count Total compounds synthesized",
            "# TYPE bizra_kep_compound_count counter",
        ])

        if self.compound_engine:
            stats = self.compound_engine.get_statistics()
            lines.append(f"bizra_kep_compound_count {stats.get('total_compounds', 0)}")
        else:
            lines.append("bizra_kep_compound_count 0")

        lines.extend([
            "",
            "# HELP bizra_kep_learning_rate Current learning rate",
            "# TYPE bizra_kep_learning_rate gauge",
        ])

        if self.accelerator:
            state = self.accelerator.get_state()
            lines.append(f"bizra_kep_learning_rate {state.current_learning_rate}")
        else:
            lines.append("bizra_kep_learning_rate 0.1")

        lines.extend([
            "",
            "# HELP bizra_kep_explosion_mode Whether system is in explosion mode",
            "# TYPE bizra_kep_explosion_mode gauge",
            f"bizra_kep_explosion_mode {1 if explosion.is_explosion_mode else 0}",
            "",
            "# HELP bizra_kep_explosion_progress Progress toward explosion mode",
            "# TYPE bizra_kep_explosion_progress gauge",
            f"bizra_kep_explosion_progress {explosion.overall_progress}",
            "",
            "# HELP bizra_kep_ihsan_average System Ihsan average",
            "# TYPE bizra_kep_ihsan_average gauge",
            f"bizra_kep_ihsan_average {metrics['ihsan_average'].value}",
        ])

        # Add loop metrics
        if self.composer:
            stats = self.composer.get_statistics()
            lines.extend([
                "",
                "# HELP bizra_kep_loop_iterations Total loop iterations",
                "# TYPE bizra_kep_loop_iterations counter",
                f"bizra_kep_loop_iterations {stats.get('total_iterations', 0)}",
            ])

        return "\n".join(lines)

    def print_dashboard(self) -> str:
        """Generate a text-based dashboard view."""
        metrics = self.get_all_metrics()
        explosion = self.get_explosion_progress()

        def progress_bar(value: float, width: int = 20) -> str:
            filled = int(value * width)
            bar = "=" * filled + "-" * (width - filled)
            return f"[{bar}]"

        lines = [
            "=" * 60,
            "          KNOWLEDGE EXPLOSION POINT DASHBOARD",
            "=" * 60,
            "",
            "KEY METRICS:",
            "-" * 40,
        ]

        for name, metric in metrics.items():
            bar = progress_bar(min(1.0, metric.value / max(0.001, metric.threshold)))
            status_icon = {
                MetricStatus.ABOVE: "[OK]",
                MetricStatus.AT_THRESHOLD: "[~]",
                MetricStatus.BELOW: "[ ]",
                MetricStatus.CRITICAL: "[!]",
            }.get(metric.status, "[ ]")

            lines.append(
                f"  {metric.name:25} {bar} {metric.value:8.2f} / {metric.threshold:.2f} {metric.unit:12} {status_icon}"
            )

        lines.extend([
            "",
            "EXPLOSION PROGRESS:",
            "-" * 40,
            f"  Overall: {progress_bar(explosion.overall_progress, 30)} {explosion.overall_progress * 100:.1f}%",
            f"  Conditions Met: {explosion.conditions_met}/{explosion.total_conditions}",
        ])

        for condition, met in explosion.condition_details.items():
            icon = "[x]" if met else "[ ]"
            lines.append(f"    {icon} {condition}")

        if explosion.is_explosion_mode:
            lines.extend([
                "",
                "*** EXPLOSION MODE ACTIVE ***",
                f"  Duration: {explosion.explosion_duration_seconds}s",
            ])

        lines.extend([
            "",
            "=" * 60,
        ])

        return "\n".join(lines)
