"""
Compound Discovery Engine - Emergent Capability Synthesis
==========================================================
From the Blueprint:
    "Creates emergent capabilities by synthesizing multiple principles.
    Synthesis types: additive (P1 + P2), multiplicative (P1 * P2),
    transcendent (P1 X P2 = entirely new capability)."

This engine takes validated synergies and synthesizes them into
compound knowledge with emergent capabilities.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional, Dict, Callable, Awaitable
from enum import Enum
import hashlib
import logging
import time

from ..abstraction_elevator import (
    AbstractionElevator,
    DomainType,
    Principle,
    AbstractionLevel,
)
from .synergy_detector import SynergyCandidate, SynergyDetector
from .kep_safety import get_safety_gate, SafetyResponse, KEPSafetyLimits
from .kep_receipts import get_kep_receipt_emitter

logger = logging.getLogger(__name__)


class SynthesisType(Enum):
    """Types of synthesis for compound creation."""
    ADDITIVE = "additive"        # P1 + P2 = combined capability
    MULTIPLICATIVE = "mult"      # P1 * P2 = amplified capability
    TRANSCENDENT = "transcend"   # P1 X P2 = entirely new capability


@dataclass
class CompoundKnowledge:
    """A compound created from synthesizing multiple principles."""
    compound_id: str = ""
    name: str = ""
    statement: str = ""
    emergent_capability: str = ""
    synthesis_type: SynthesisType = SynthesisType.ADDITIVE

    # Source information
    source_principles: List[str] = field(default_factory=list)
    source_synergy_id: str = ""
    domains_bridged: List[DomainType] = field(default_factory=list)

    # Validation
    ihsan_alignment: float = 0.0
    sat_votes_for: int = 0
    sat_votes_against: int = 0
    sat_approved: bool = False
    validation_receipts: List[str] = field(default_factory=list)

    # Metadata
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    synthesis_latency_ms: int = 0

    # Evidence strength (inherited from sources)
    evidence_strength: float = 0.0

    def to_dict(self) -> dict:
        return {
            "compound_id": self.compound_id,
            "name": self.name,
            "statement": self.statement,
            "emergent_capability": self.emergent_capability,
            "synthesis_type": self.synthesis_type.value,
            "source_principles": self.source_principles,
            "source_synergy_id": self.source_synergy_id,
            "domains_bridged": [d.value for d in self.domains_bridged],
            "ihsan_alignment": self.ihsan_alignment,
            "sat_votes_for": self.sat_votes_for,
            "sat_votes_against": self.sat_votes_against,
            "sat_approved": self.sat_approved,
            "validation_receipts": self.validation_receipts,
            "created_at": self.created_at,
            "synthesis_latency_ms": self.synthesis_latency_ms,
            "evidence_strength": self.evidence_strength,
        }


class CompoundDiscoveryEngine:
    """
    Engine for synthesizing compound knowledge from synergies.

    Process:
    1. Load source principles from synergy candidate
    2. Generate synthesis hypothesis
    3. Ihsan gate validation (FAIL-CLOSED at 0.99)
    4. SAT consensus validation (3/5)
    5. Register compound with elevator
    6. Emit discovery receipt
    """

    MIN_IHSAN = 0.99
    REQUIRED_SAT_CONSENSUS = 3  # Out of 5

    def __init__(
        self,
        elevator: Optional[AbstractionElevator] = None,
        synergy_detector: Optional[SynergyDetector] = None,
        sat_verify_callback: Optional[Callable[[str, dict], Awaitable[tuple]]] = None,
        llm_synthesize_callback: Optional[Callable[[str, str], Awaitable[str]]] = None,
    ):
        self.elevator = elevator or AbstractionElevator()
        self.synergy_detector = synergy_detector
        self._sat_verify = sat_verify_callback
        self._llm_synthesize = llm_synthesize_callback

        # Compound storage
        self.compounds: Dict[str, CompoundKnowledge] = {}
        self._compound_counter = 0

        logger.info("CompoundDiscoveryEngine initialized")

    def _next_compound_id(self) -> str:
        """Generate next compound ID."""
        self._compound_counter += 1
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d")
        return f"CMPD-{timestamp}-{self._compound_counter:05d}"

    def _determine_synthesis_type(self, synergy: SynergyCandidate) -> SynthesisType:
        """Determine the appropriate synthesis type based on synergy characteristics."""
        if synergy.synergy_type == "transcendent":
            return SynthesisType.TRANSCENDENT
        elif synergy.synergy_type == "reinforcing":
            return SynthesisType.MULTIPLICATIVE
        else:
            return SynthesisType.ADDITIVE

    def _generate_compound_name(
        self,
        source: Principle,
        target: Principle,
        synthesis_type: SynthesisType,
    ) -> str:
        """Generate a name for the compound."""
        if synthesis_type == SynthesisType.TRANSCENDENT:
            return f"Transcendent:{source.name}+{target.name}"
        elif synthesis_type == SynthesisType.MULTIPLICATIVE:
            return f"Amplified:{source.name}x{target.name}"
        else:
            return f"Combined:{source.name}&{target.name}"

    def _synthesize_statement(
        self,
        source: Principle,
        target: Principle,
        synthesis_type: SynthesisType,
        emergent_capability: str,
    ) -> str:
        """
        Synthesize a compound statement from source principles.

        If LLM callback is available, uses it. Otherwise, falls back to template.
        """
        # Template-based synthesis (fallback)
        if synthesis_type == SynthesisType.TRANSCENDENT:
            statement = (
                f"By synthesizing '{source.statement}' with '{target.statement}', "
                f"a new capability emerges: {emergent_capability}"
            )
        elif synthesis_type == SynthesisType.MULTIPLICATIVE:
            statement = (
                f"The principle '{source.statement}' is amplified when combined with "
                f"'{target.statement}', enabling: {emergent_capability}"
            )
        else:
            statement = (
                f"Combining '{source.statement}' and '{target.statement}' "
                f"provides: {emergent_capability}"
            )

        return statement

    async def _synthesize_with_llm(
        self,
        source: Principle,
        target: Principle,
    ) -> Optional[str]:
        """Use LLM to generate sophisticated synthesis (if callback available)."""
        if self._llm_synthesize is None:
            return None

        prompt = f"""
You are synthesizing two principles into an emergent compound capability.

Source Principle: {source.name}
Statement: {source.statement}
Domains: {[d.value for d in source.domains]}

Target Principle: {target.name}
Statement: {target.statement}
Domains: {[d.value for d in target.domains]}

Generate a concise statement (2-3 sentences) describing the emergent capability
that arises from combining these principles. Focus on what NEW capability
emerges that neither principle alone provides.
"""

        try:
            result = await self._llm_synthesize(prompt, "compound_synthesis")
            return result
        except Exception as e:
            logger.warning("LLM synthesis failed: %s", e)
            return None

    def _estimate_ihsan_alignment(
        self,
        source: Principle,
        target: Principle,
        synthesis_type: SynthesisType,
    ) -> float:
        """Estimate Ihsan alignment for the compound."""
        # Base from source principles
        base = min(source.ihsan_alignment, target.ihsan_alignment)

        # Type-based adjustment
        if synthesis_type == SynthesisType.TRANSCENDENT:
            # Transcendent synthesis is riskier, slight penalty
            base *= 0.98
        elif synthesis_type == SynthesisType.MULTIPLICATIVE:
            # Multiplicative is moderate risk
            base *= 0.99

        # Cross-domain bonus (promotes anti-centralization)
        if source.domains != target.domains:
            base = min(1.0, base + 0.01)

        return base

    def _calculate_evidence_strength(
        self,
        source: Principle,
        target: Principle,
    ) -> float:
        """Calculate evidence strength for the compound."""
        # Geometric mean of source strengths (conservative)
        return (source.evidence_strength * target.evidence_strength) ** 0.5

    async def _request_sat_consensus(
        self,
        compound: CompoundKnowledge,
        source: Principle,
        target: Principle,
    ) -> tuple[int, int]:
        """
        Request SAT consensus for compound synthesis.

        Returns (votes_for, votes_against)
        """
        if self._sat_verify is None:
            # No SAT callback - cannot proceed (fail-closed)
            logger.warning("SAT verify callback not configured, blocking synthesis")
            return 0, 5

        context = {
            "compound_name": compound.name,
            "source_principle": source.name,
            "target_principle": target.name,
            "synthesis_type": compound.synthesis_type.value,
            "ihsan_alignment": compound.ihsan_alignment,
            "emergent_capability": compound.emergent_capability,
        }

        try:
            votes_for, votes_against = await self._sat_verify(
                f"compound_synthesis:{compound.compound_id}",
                context,
            )
            return votes_for, votes_against
        except Exception as e:
            logger.error("SAT consensus request failed: %s", e)
            return 0, 5  # Fail-closed

    async def synthesize_compound(
        self,
        synergy: SynergyCandidate,
    ) -> Optional[CompoundKnowledge]:
        """
        Synthesize a compound from a synergy candidate.

        FAIL-CLOSED: Rejects if Ihsan < 0.99 or SAT consensus < 3/5
        """
        start_time = time.time()

        # Safety gate check
        safety = get_safety_gate()
        response = safety.check_compound_synthesis()
        if response != SafetyResponse.CONTINUE:
            logger.warning("Compound synthesis blocked by safety gate: %s", response)
            return None

        # Load source principles
        source = self.elevator.principles.get(synergy.source_id)
        target = self.elevator.principles.get(synergy.target_id)

        if source is None or target is None:
            logger.error(
                "Source or target principle not found: %s, %s",
                synergy.source_id, synergy.target_id
            )
            return None

        # Determine synthesis type
        synthesis_type = self._determine_synthesis_type(synergy)

        # Generate compound details
        compound_id = self._next_compound_id()
        name = self._generate_compound_name(source, target, synthesis_type)

        # Try LLM synthesis first, fall back to template
        llm_statement = await self._synthesize_with_llm(source, target)
        if llm_statement:
            emergent_capability = llm_statement
        else:
            emergent_capability = synergy.potential_compound

        statement = self._synthesize_statement(
            source, target, synthesis_type, emergent_capability
        )

        # Calculate Ihsan alignment
        ihsan_alignment = self._estimate_ihsan_alignment(source, target, synthesis_type)

        # FAIL-CLOSED: Check Ihsan threshold
        if ihsan_alignment < self.MIN_IHSAN:
            logger.warning(
                "Compound %s rejected: Ihsan %.3f < %.3f threshold",
                compound_id, ihsan_alignment, self.MIN_IHSAN
            )
            return None

        # Update safety gate with new Ihsan
        safety.update_ihsan(ihsan_alignment)

        # Calculate evidence strength
        evidence_strength = self._calculate_evidence_strength(source, target)

        # Create preliminary compound
        compound = CompoundKnowledge(
            compound_id=compound_id,
            name=name,
            statement=statement,
            emergent_capability=emergent_capability,
            synthesis_type=synthesis_type,
            source_principles=[source.principle_id, target.principle_id],
            source_synergy_id=synergy.candidate_id,
            domains_bridged=list(set(source.domains + target.domains)),
            ihsan_alignment=ihsan_alignment,
            evidence_strength=evidence_strength,
        )

        # Request SAT consensus
        votes_for, votes_against = await self._request_sat_consensus(
            compound, source, target
        )

        compound.sat_votes_for = votes_for
        compound.sat_votes_against = votes_against
        compound.sat_approved = votes_for >= self.REQUIRED_SAT_CONSENSUS

        # FAIL-CLOSED: Check SAT consensus
        if not compound.sat_approved:
            logger.warning(
                "Compound %s rejected: SAT consensus %d/%d < %d required",
                compound_id, votes_for, 5, self.REQUIRED_SAT_CONSENSUS
            )
            return None

        # Calculate synthesis latency
        compound.synthesis_latency_ms = int((time.time() - start_time) * 1000)

        # Store compound
        self.compounds[compound_id] = compound

        # Emit receipt
        emitter = get_kep_receipt_emitter()
        receipt = emitter.emit_compound_discovery(
            compound_id=compound_id,
            compound_name=name,
            emergent_capability=emergent_capability,
            synthesis_type=synthesis_type.value,
            source_principles=[source.principle_id, target.principle_id],
            domains_bridged=[d.value for d in compound.domains_bridged],
            ihsan_alignment=ihsan_alignment,
            sat_votes_for=votes_for,
            sat_votes_against=votes_against,
            synergy_receipt_id=synergy.candidate_id,
            synthesis_latency_ms=compound.synthesis_latency_ms,
        )

        compound.validation_receipts.append(receipt.receipt_id)

        # Record for rate limiting
        safety.record_compound_synthesis()

        # Mark synergy as synthesized
        if self.synergy_detector:
            self.synergy_detector.mark_synthesized(synergy.candidate_id)

        logger.info(
            "Compound synthesized: %s (%s) - Ihsan %.3f, SAT %d/5",
            compound_id, synthesis_type.value, ihsan_alignment, votes_for
        )

        return compound

    async def synthesize_batch(
        self,
        synergies: Optional[List[SynergyCandidate]] = None,
        max_compounds: int = 10,
    ) -> List[CompoundKnowledge]:
        """
        Synthesize compounds from multiple synergies.

        If synergies not provided, uses pending synergies from detector.
        """
        if synergies is None and self.synergy_detector:
            synergies = self.synergy_detector.get_pending_synthesis()

        if not synergies:
            return []

        compounds = []
        safety = get_safety_gate()

        for synergy in synergies[:max_compounds]:
            # Check if we can continue
            response = safety.check_compound_synthesis()
            if response == SafetyResponse.THROTTLE:
                logger.info("Batch synthesis throttled after %d compounds", len(compounds))
                break
            elif response == SafetyResponse.BLOCK:
                logger.warning("Batch synthesis blocked by safety gate")
                break

            try:
                compound = await self.synthesize_compound(synergy)
                if compound:
                    compounds.append(compound)
            except Exception as e:
                logger.error("Failed to synthesize compound from %s: %s", synergy.candidate_id, e)

        logger.info("Batch synthesis completed: %d compounds created", len(compounds))
        return compounds

    def get_compound(self, compound_id: str) -> Optional[CompoundKnowledge]:
        """Get a compound by ID."""
        return self.compounds.get(compound_id)

    def get_compounds_by_domain(
        self,
        domain: DomainType,
    ) -> List[CompoundKnowledge]:
        """Get all compounds that bridge a specific domain."""
        return [
            c for c in self.compounds.values()
            if domain in c.domains_bridged
        ]

    def get_compounds_by_type(
        self,
        synthesis_type: SynthesisType,
    ) -> List[CompoundKnowledge]:
        """Get all compounds of a specific synthesis type."""
        return [
            c for c in self.compounds.values()
            if c.synthesis_type == synthesis_type
        ]

    def get_statistics(self) -> dict:
        """Get compound discovery statistics."""
        compounds = list(self.compounds.values())

        return {
            "total_compounds": len(compounds),
            "by_type": {
                "additive": len([c for c in compounds if c.synthesis_type == SynthesisType.ADDITIVE]),
                "multiplicative": len([c for c in compounds if c.synthesis_type == SynthesisType.MULTIPLICATIVE]),
                "transcendent": len([c for c in compounds if c.synthesis_type == SynthesisType.TRANSCENDENT]),
            },
            "avg_ihsan_alignment": (
                sum(c.ihsan_alignment for c in compounds) / max(1, len(compounds))
            ),
            "avg_evidence_strength": (
                sum(c.evidence_strength for c in compounds) / max(1, len(compounds))
            ),
            "domains_bridged": list(set(
                d.value for c in compounds for d in c.domains_bridged
            )),
            "avg_synthesis_latency_ms": (
                sum(c.synthesis_latency_ms for c in compounds) / max(1, len(compounds))
            ),
        }
