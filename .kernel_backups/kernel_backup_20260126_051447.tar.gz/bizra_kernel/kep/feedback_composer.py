"""
Feedback Loop Composer - Orchestration of Self-Reinforcing Cycles
==================================================================
From the Blueprint:
    "Orchestrates multiple feedback loops into coherent self-reinforcement."

4 Self-Reinforcing Loops:
1. SAPE Elevation Loop: Pattern -> Elevated Pattern -> Faster Verification (gain: 1.5)
2. Abstraction Loop: Instance -> Pattern -> Principle -> Cross-Domain Transfer (gain: 2.0)
3. Compound Discovery Loop: Synergy -> Compound -> New Synergies (gain: 3.0)
4. Learning Acceleration Loop: Knowledge Mass -> Higher Rate -> More Knowledge (gain: 1.2)
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, List, Dict, Callable, Awaitable
from enum import Enum
import asyncio
import logging
import time

from ..abstraction_elevator import AbstractionElevator
from ..sape_engine import SAPEEngine
from .synergy_detector import SynergyDetector
from .compound_discovery import CompoundDiscoveryEngine
from .learning_accelerator import LearningAccelerator
from .kep_safety import get_safety_gate, SafetyResponse
from .kep_receipts import get_kep_receipt_emitter

logger = logging.getLogger(__name__)


class LoopType(Enum):
    """Types of feedback loops in the KEP system."""
    SAPE_ELEVATION = "sape_elevation"
    ABSTRACTION = "abstraction"
    COMPOUND_DISCOVERY = "compound_discovery"
    LEARNING_ACCELERATION = "learning_acceleration"


@dataclass
class LoopConfig:
    """Configuration for a feedback loop."""
    loop_type: LoopType
    name: str
    target_gain: float  # Expected output/input ratio
    max_iterations: int = 1000
    min_ihsan: float = 0.99
    enabled: bool = True


@dataclass
class LoopResult:
    """Result of a single loop iteration."""
    loop_type: LoopType
    iteration: int
    input_count: int
    output_count: int
    gain_achieved: float
    latency_ms: int
    ihsan_pre: float
    ihsan_post: float
    success: bool
    message: str = ""


class FeedbackLoopComposer:
    """
    Orchestrates the 4 self-reinforcing feedback loops.

    Each loop transforms inputs into outputs with a target gain:
    - SAPE: patterns -> elevated patterns (gain 1.5)
    - Abstraction: instances -> principles (gain 2.0)
    - Compound: synergies -> compounds (gain 3.0)
    - Learning: knowledge mass -> higher rate (gain 1.2)

    The loops are Ihsan-gated to prevent runaway.
    """

    DEFAULT_CONFIGS = {
        LoopType.SAPE_ELEVATION: LoopConfig(
            loop_type=LoopType.SAPE_ELEVATION,
            name="SAPE Elevation Loop",
            target_gain=1.5,
            max_iterations=100,
        ),
        LoopType.ABSTRACTION: LoopConfig(
            loop_type=LoopType.ABSTRACTION,
            name="Abstraction Loop",
            target_gain=2.0,
            max_iterations=200,
        ),
        LoopType.COMPOUND_DISCOVERY: LoopConfig(
            loop_type=LoopType.COMPOUND_DISCOVERY,
            name="Compound Discovery Loop",
            target_gain=3.0,
            max_iterations=50,
        ),
        LoopType.LEARNING_ACCELERATION: LoopConfig(
            loop_type=LoopType.LEARNING_ACCELERATION,
            name="Learning Acceleration Loop",
            target_gain=1.2,
            max_iterations=1000,
        ),
    }

    def __init__(
        self,
        elevator: Optional[AbstractionElevator] = None,
        sape_engine: Optional[SAPEEngine] = None,
        synergy_detector: Optional[SynergyDetector] = None,
        compound_engine: Optional[CompoundDiscoveryEngine] = None,
        learning_accelerator: Optional[LearningAccelerator] = None,
        configs: Optional[Dict[LoopType, LoopConfig]] = None,
    ):
        self.elevator = elevator or AbstractionElevator()
        self.sape_engine = sape_engine or SAPEEngine()
        self.synergy_detector = synergy_detector or SynergyDetector(self.elevator)
        self.compound_engine = compound_engine or CompoundDiscoveryEngine(
            self.elevator, self.synergy_detector
        )
        self.learning_accelerator = learning_accelerator or LearningAccelerator(self.elevator)

        # Configurations
        self.configs = configs or dict(self.DEFAULT_CONFIGS)

        # Tracking
        self.iteration_counts: Dict[LoopType, int] = {lt: 0 for lt in LoopType}
        self.cumulative_gains: Dict[LoopType, float] = {lt: 0.0 for lt in LoopType}
        self.last_results: Dict[LoopType, LoopResult] = {}

        # Running state
        self._running = False
        self._stop_requested = False

        logger.info("FeedbackLoopComposer initialized with %d loop configs", len(self.configs))

    def _get_system_ihsan(self) -> float:
        """Get current system-wide Ihsan average."""
        principles = list(self.elevator.principles.values())
        if not principles:
            return 0.99  # Default if no data
        return sum(p.ihsan_alignment for p in principles) / len(principles)

    async def _run_sape_elevation_loop(self) -> LoopResult:
        """
        SAPE Elevation Loop: Detect repeated sequences and elevate to optimized shortcuts.

        Input: Verification sequences
        Output: Elevated patterns
        Target gain: 1.5
        """
        config = self.configs[LoopType.SAPE_ELEVATION]
        iteration = self.iteration_counts[LoopType.SAPE_ELEVATION]
        start_time = time.time()
        ihsan_pre = self._get_system_ihsan()

        # Input: Count of elevation candidates
        candidates = self.sape_engine.get_elevation_candidates()
        input_count = len(candidates)

        # Process: Check for patterns that need elevation
        elevated_count = 0
        for sequence, count in candidates:
            if count >= self.sape_engine.ELEVATION_THRESHOLD:
                pattern = self.sape_engine.observe_sequence(sequence)
                if pattern:
                    elevated_count += 1

        # Output: Number of elevated patterns
        output_count = elevated_count

        # Calculate gain
        gain = output_count / max(1, input_count)

        ihsan_post = self._get_system_ihsan()
        latency_ms = int((time.time() - start_time) * 1000)

        result = LoopResult(
            loop_type=LoopType.SAPE_ELEVATION,
            iteration=iteration,
            input_count=input_count,
            output_count=output_count,
            gain_achieved=gain,
            latency_ms=latency_ms,
            ihsan_pre=ihsan_pre,
            ihsan_post=ihsan_post,
            success=True,
            message=f"Elevated {elevated_count} patterns from {input_count} candidates",
        )

        return result

    async def _run_abstraction_loop(self) -> LoopResult:
        """
        Abstraction Loop: Generalize instances to patterns to principles.

        Input: New instances
        Output: Elevated principles
        Target gain: 2.0
        """
        config = self.configs[LoopType.ABSTRACTION]
        iteration = self.iteration_counts[LoopType.ABSTRACTION]
        start_time = time.time()
        ihsan_pre = self._get_system_ihsan()

        # Input: Count instances
        input_count = len(self.elevator.instances)

        # Process: Auto-elevate patterns to principles
        new_principles = self.elevator.auto_elevate()

        # Output: New principles created
        output_count = len(new_principles)

        # Calculate gain (principles generated / prior state)
        gain = output_count / max(1, input_count // 10)  # Normalized

        ihsan_post = self._get_system_ihsan()
        latency_ms = int((time.time() - start_time) * 1000)

        result = LoopResult(
            loop_type=LoopType.ABSTRACTION,
            iteration=iteration,
            input_count=input_count,
            output_count=output_count,
            gain_achieved=gain,
            latency_ms=latency_ms,
            ihsan_pre=ihsan_pre,
            ihsan_post=ihsan_post,
            success=True,
            message=f"Elevated {output_count} principles from {input_count} instances",
        )

        return result

    async def _run_compound_discovery_loop(self) -> LoopResult:
        """
        Compound Discovery Loop: Synthesize synergies into compounds.

        Input: Detected synergies
        Output: Synthesized compounds
        Target gain: 3.0
        """
        config = self.configs[LoopType.COMPOUND_DISCOVERY]
        iteration = self.iteration_counts[LoopType.COMPOUND_DISCOVERY]
        start_time = time.time()
        ihsan_pre = self._get_system_ihsan()

        # Input: Detect new synergies
        synergies = self.synergy_detector.detect_synergies(max_results=20)
        input_count = len(synergies)

        # Process: Synthesize valid synergies into compounds
        pending = self.synergy_detector.get_pending_synthesis()
        compounds = await self.compound_engine.synthesize_batch(pending[:10])

        # Output: Number of compounds
        output_count = len(compounds)

        # Record success/failure for learning accelerator
        for _ in compounds:
            self.learning_accelerator.record_synthesis_attempt(success=True)

        failed = len(pending[:10]) - len(compounds)
        for _ in range(failed):
            self.learning_accelerator.record_synthesis_attempt(success=False)

        # Calculate gain
        gain = output_count / max(1, input_count)

        ihsan_post = self._get_system_ihsan()
        latency_ms = int((time.time() - start_time) * 1000)

        result = LoopResult(
            loop_type=LoopType.COMPOUND_DISCOVERY,
            iteration=iteration,
            input_count=input_count,
            output_count=output_count,
            gain_achieved=gain,
            latency_ms=latency_ms,
            ihsan_pre=ihsan_pre,
            ihsan_post=ihsan_post,
            success=True,
            message=f"Synthesized {output_count} compounds from {input_count} synergies",
        )

        return result

    async def _run_learning_acceleration_loop(self) -> LoopResult:
        """
        Learning Acceleration Loop: Adjust rate based on knowledge mass.

        Input: Current knowledge state
        Output: Updated learning rate
        Target gain: 1.2
        """
        config = self.configs[LoopType.LEARNING_ACCELERATION]
        iteration = self.iteration_counts[LoopType.LEARNING_ACCELERATION]
        start_time = time.time()
        ihsan_pre = self._get_system_ihsan()

        # Input: Current state
        state_before = self.learning_accelerator.get_state()
        input_count = state_before.knowledge_mass

        # Process: Calculate new rate
        active_synergies = len(self.synergy_detector.detected_synergies)
        new_rate = self.learning_accelerator.calculate_learning_rate(active_synergies)

        # Output: Rate multiplier achieved
        state_after = self.learning_accelerator.get_state()
        output_count = int(state_after.rate_multiplier * 100)  # Percentage

        # Calculate gain (rate improvement)
        rate_before = state_before.current_learning_rate
        gain = new_rate / max(0.01, rate_before)

        ihsan_post = self._get_system_ihsan()
        latency_ms = int((time.time() - start_time) * 1000)

        result = LoopResult(
            loop_type=LoopType.LEARNING_ACCELERATION,
            iteration=iteration,
            input_count=input_count,
            output_count=output_count,
            gain_achieved=gain,
            latency_ms=latency_ms,
            ihsan_pre=ihsan_pre,
            ihsan_post=ihsan_post,
            success=True,
            message=f"Learning rate: {rate_before:.3f} -> {new_rate:.3f} ({gain:.2f}x)",
        )

        return result

    async def run_loop_iteration(self, loop_type: LoopType) -> Optional[LoopResult]:
        """
        Run a single iteration of a specific feedback loop.

        Returns None if blocked by safety gate.
        """
        config = self.configs.get(loop_type)
        if config is None or not config.enabled:
            return None

        # Safety gate check
        safety = get_safety_gate()
        response = safety.check_loop_iteration(loop_type.value)

        if response == SafetyResponse.BLOCK:
            logger.warning("Loop %s blocked by safety gate", loop_type.value)
            return None

        # Ihsan check
        current_ihsan = self._get_system_ihsan()
        if current_ihsan < config.min_ihsan:
            logger.warning(
                "Loop %s blocked: Ihsan %.3f < %.3f",
                loop_type.value, current_ihsan, config.min_ihsan
            )
            return None

        # Iteration limit check
        if self.iteration_counts[loop_type] >= config.max_iterations:
            logger.warning("Loop %s at max iterations", loop_type.value)
            return None

        # Run the appropriate loop
        try:
            if loop_type == LoopType.SAPE_ELEVATION:
                result = await self._run_sape_elevation_loop()
            elif loop_type == LoopType.ABSTRACTION:
                result = await self._run_abstraction_loop()
            elif loop_type == LoopType.COMPOUND_DISCOVERY:
                result = await self._run_compound_discovery_loop()
            elif loop_type == LoopType.LEARNING_ACCELERATION:
                result = await self._run_learning_acceleration_loop()
            else:
                return None

            # Update tracking
            self.iteration_counts[loop_type] += 1
            self.cumulative_gains[loop_type] += result.gain_achieved
            self.last_results[loop_type] = result
            safety.record_loop_iteration(loop_type.value)

            # Emit receipt
            emitter = get_kep_receipt_emitter()
            emitter.emit_feedback_loop(
                loop_name=config.name,
                loop_type=loop_type.value,
                iteration_number=self.iteration_counts[loop_type],
                input_count=result.input_count,
                output_count=result.output_count,
                gain_achieved=result.gain_achieved,
                target_gain=config.target_gain,
                cycle_latency_ms=result.latency_ms,
                ihsan_pre_cycle=result.ihsan_pre,
                ihsan_post_cycle=result.ihsan_post,
                safety_check_passed=True,
            )

            return result

        except Exception as e:
            logger.error("Loop %s iteration failed: %s", loop_type.value, e)
            return None

    async def run_all_loops_once(self) -> Dict[LoopType, Optional[LoopResult]]:
        """Run a single iteration of all enabled loops."""
        results = {}

        for loop_type in LoopType:
            result = await self.run_loop_iteration(loop_type)
            results[loop_type] = result

        return results

    async def run_feedback_cycle(
        self,
        max_cycles: int = 10,
        min_total_gain: float = 1.0,
    ) -> List[Dict[LoopType, Optional[LoopResult]]]:
        """
        Run multiple feedback cycles until gain drops or max cycles reached.

        A cycle consists of running all loops once.
        """
        self._running = True
        self._stop_requested = False
        all_results = []

        for cycle in range(max_cycles):
            if self._stop_requested:
                logger.info("Feedback cycle stop requested")
                break

            # Run all loops
            cycle_results = await self.run_all_loops_once()
            all_results.append(cycle_results)

            # Calculate total gain for this cycle
            total_gain = sum(
                r.gain_achieved for r in cycle_results.values()
                if r is not None
            )

            logger.info(
                "Feedback cycle %d/%d completed - total gain: %.2f",
                cycle + 1, max_cycles, total_gain
            )

            # Stop if gain too low (diminishing returns)
            if total_gain < min_total_gain:
                logger.info("Stopping feedback cycles: gain %.2f < %.2f", total_gain, min_total_gain)
                break

            # Small delay between cycles
            await asyncio.sleep(0.1)

        self._running = False
        return all_results

    def stop(self) -> None:
        """Request stop of running feedback cycles."""
        self._stop_requested = True

    def is_running(self) -> bool:
        """Check if feedback cycles are currently running."""
        return self._running

    def reset_counters(self, loop_type: Optional[LoopType] = None) -> None:
        """Reset iteration counters and gains."""
        if loop_type:
            self.iteration_counts[loop_type] = 0
            self.cumulative_gains[loop_type] = 0.0
            get_safety_gate().reset_loop_counter(loop_type.value)
        else:
            for lt in LoopType:
                self.iteration_counts[lt] = 0
                self.cumulative_gains[lt] = 0.0
                get_safety_gate().reset_loop_counter(lt.value)

    def get_statistics(self) -> dict:
        """Get composer statistics."""
        return {
            "loops": {
                lt.value: {
                    "enabled": self.configs.get(lt, LoopConfig(lt, "", 1.0)).enabled,
                    "iterations": self.iteration_counts[lt],
                    "cumulative_gain": self.cumulative_gains[lt],
                    "avg_gain": (
                        self.cumulative_gains[lt] / max(1, self.iteration_counts[lt])
                    ),
                    "target_gain": self.configs.get(lt, LoopConfig(lt, "", 1.0)).target_gain,
                    "last_result": (
                        self.last_results[lt].message
                        if lt in self.last_results else None
                    ),
                }
                for lt in LoopType
            },
            "is_running": self._running,
            "total_iterations": sum(self.iteration_counts.values()),
            "total_cumulative_gain": sum(self.cumulative_gains.values()),
        }
