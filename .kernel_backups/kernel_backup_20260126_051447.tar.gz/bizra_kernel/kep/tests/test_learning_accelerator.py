"""
Tests for the Learning Rate Accelerator component.
"""

import pytest
from ..learning_accelerator import (
    LearningAccelerator,
    LearningState,
    ExplosionCondition,
    ExplosionTriggerThresholds,
)
from ...abstraction_elevator import (
    AbstractionElevator,
    DomainType,
    Principle,
    AbstractionLevel,
)


@pytest.fixture
def elevator_with_many_principles():
    """Create an elevator with many principles for testing."""
    elevator = AbstractionElevator()

    # Add principles across multiple domains
    domains = [DomainType.TECHNICAL, DomainType.ETHICAL, DomainType.ECONOMIC,
               DomainType.SOCIAL, DomainType.TEMPORAL, DomainType.CAUSAL]

    for i in range(60):
        domain = domains[i % len(domains)]
        elevator.principles[f"PRIN-{i:03d}"] = Principle(
            principle_id=f"PRIN-{i:03d}",
            name=f"Principle {i}",
            statement=f"Test principle {i} for domain {domain.value}",
            abstraction_level=AbstractionLevel.PRINCIPLE,
            source_patterns=[],
            domains=[domain],
            constraints=[],
            exceptions=[],
            evidence_strength=0.8,
            ihsan_alignment=0.995,
        )

    return elevator


@pytest.fixture
def accelerator(elevator_with_many_principles):
    """Create a learning accelerator."""
    return LearningAccelerator(elevator=elevator_with_many_principles)


class TestLearningAccelerator:
    """Tests for LearningAccelerator class."""

    def test_initialization(self, accelerator):
        """Test accelerator initializes correctly."""
        assert accelerator is not None
        assert accelerator.BASE_RATE == 0.1
        assert accelerator.MIN_RATE == 0.05
        assert accelerator.MAX_RATE == 2.0
        assert accelerator.EXPLOSION_RATE == 5.0

    def test_learning_state_structure(self, accelerator):
        """Test learning state has required fields."""
        state = accelerator.get_state()

        assert isinstance(state, LearningState)
        assert hasattr(state, "knowledge_mass")
        assert hasattr(state, "discovery_velocity")
        assert hasattr(state, "current_learning_rate")
        assert hasattr(state, "is_explosion_mode")

    def test_calculate_learning_rate(self, accelerator):
        """Test learning rate calculation."""
        rate = accelerator.calculate_learning_rate()

        assert rate >= accelerator.MIN_RATE
        assert rate <= accelerator.MAX_RATE

    def test_knowledge_mass_calculation(self, accelerator):
        """Test knowledge mass is calculated correctly."""
        # The accelerator should calculate mass from elevator
        accelerator.calculate_learning_rate()
        state = accelerator.get_state()

        # With 60 principles, mass should include principle weight
        expected_min = 60 * accelerator.PRINCIPLE_WEIGHT
        assert state.knowledge_mass >= expected_min

    def test_rate_increases_with_mass(self, accelerator):
        """Test that rate increases with knowledge mass."""
        initial_rate = accelerator.calculate_learning_rate()

        # Add more instances to increase mass
        for i in range(100):
            accelerator.elevator.record_instance(
                DomainType.TECHNICAL,
                f"Instance {i}",
                ["feature1", "feature2"],
                "outcome",
            )

        new_rate = accelerator.calculate_learning_rate()

        # Rate should increase (or stay same if at max)
        assert new_rate >= initial_rate

    def test_rate_bounded_by_max(self, accelerator):
        """Test that rate never exceeds maximum."""
        # Force very high mass
        accelerator.state.compound_count = 10000

        rate = accelerator.calculate_learning_rate()
        assert rate <= accelerator.MAX_RATE


class TestExplosionConditions:
    """Tests for explosion mode trigger conditions."""

    def test_check_explosion_trigger(self, accelerator):
        """Test explosion trigger condition checking."""
        conditions = accelerator.check_explosion_trigger(active_synergies=5)

        assert ExplosionCondition.KNOWLEDGE_MASS in conditions
        assert ExplosionCondition.DISCOVERY_VELOCITY in conditions
        assert ExplosionCondition.SYNERGY_DENSITY in conditions
        assert ExplosionCondition.IHSAN_HEALTH in conditions

    def test_explosion_requires_all_conditions(self, accelerator):
        """Test that explosion mode requires all 4 conditions."""
        # With default state, not all conditions should be met
        can_enter = accelerator.can_enter_explosion_mode(active_synergies=0)

        # Likely false without sufficient mass/velocity
        assert isinstance(can_enter, bool)

    def test_explosion_thresholds(self, accelerator):
        """Test explosion trigger thresholds."""
        thresholds = accelerator.thresholds

        assert thresholds.knowledge_mass == 500
        assert thresholds.discovery_velocity == 2.0
        assert thresholds.min_active_synergies == 3
        assert thresholds.ihsan_average == 0.992


class TestSuccessTracking:
    """Tests for synthesis success tracking."""

    def test_record_synthesis_success(self, accelerator):
        """Test recording successful synthesis."""
        accelerator.record_synthesis_attempt(success=True)

        state = accelerator.get_state()
        assert state.synthesis_attempts == 1
        assert state.synthesis_successes == 1
        assert state.success_streak == 1

    def test_record_synthesis_failure(self, accelerator):
        """Test recording failed synthesis."""
        accelerator.record_synthesis_attempt(success=False)

        state = accelerator.get_state()
        assert state.synthesis_attempts == 1
        assert state.synthesis_successes == 0
        assert state.success_streak == 0

    def test_success_streak_resets_on_failure(self, accelerator):
        """Test that success streak resets on failure."""
        # Build up a streak
        for _ in range(5):
            accelerator.record_synthesis_attempt(success=True)

        assert accelerator.state.success_streak == 5

        # Failure should reset
        accelerator.record_synthesis_attempt(success=False)
        assert accelerator.state.success_streak == 0

    def test_streak_bonus_affects_rate(self, accelerator):
        """Test that success streak provides rate bonus."""
        rate_before = accelerator.calculate_learning_rate()

        # Build up streak
        for _ in range(10):
            accelerator.record_synthesis_attempt(success=True)

        rate_after = accelerator.calculate_learning_rate()

        # Rate should increase due to streak bonus
        assert rate_after >= rate_before


class TestStatistics:
    """Tests for accelerator statistics."""

    def test_get_statistics(self, accelerator):
        """Test statistics generation."""
        accelerator.calculate_learning_rate()

        stats = accelerator.get_statistics()

        assert "state" in stats
        assert "thresholds" in stats
        assert "rate_config" in stats

    def test_state_to_dict(self, accelerator):
        """Test state serialization."""
        state = accelerator.get_state()
        state_dict = state.to_dict()

        assert "knowledge_mass" in state_dict
        assert "discovery_velocity" in state_dict
        assert "current_learning_rate" in state_dict


class TestIhsanFloorNeverBreached:
    """Property-based tests for Ihsan floor."""

    @pytest.mark.parametrize("ihsan_score", [0.0, 0.5, 0.98, 0.989, 0.99, 0.995, 1.0])
    def test_ihsan_floor_respected(self, ihsan_score, accelerator):
        """System Ihsān average must be >= 0.992 for explosion mode."""
        # Modify ALL principles' Ihsan to see effect on average
        for pid in accelerator.elevator.principles.keys():
            accelerator.elevator.principles[pid].ihsan_alignment = ihsan_score

        conditions = accelerator.check_explosion_trigger()

        if ihsan_score < 0.992:
            # When all principles are below 0.992, average is below threshold
            assert not conditions[ExplosionCondition.IHSAN_HEALTH]
        else:
            # When all principles are >= 0.992, average meets threshold
            assert conditions[ExplosionCondition.IHSAN_HEALTH]
