"""
Tests for the Compound Discovery Engine component.
"""

import pytest
import asyncio
from ..compound_discovery import (
    CompoundDiscoveryEngine,
    CompoundKnowledge,
    SynthesisType,
)
from ..synergy_detector import SynergyDetector, SynergyCandidate
from ...abstraction_elevator import (
    AbstractionElevator,
    DomainType,
    Principle,
    AbstractionLevel,
)


@pytest.fixture
def elevator_with_principles():
    """Create an elevator with test principles."""
    elevator = AbstractionElevator()

    elevator.principles["PRIN-001"] = Principle(
        principle_id="PRIN-001",
        name="Immutable Records",
        statement="All verified impacts are preserved immutably",
        abstraction_level=AbstractionLevel.PRINCIPLE,
        source_patterns=["PAT-001"],
        domains=[DomainType.TECHNICAL],
        constraints=[],
        exceptions=[],
        evidence_strength=0.9,
        ihsan_alignment=0.995,
    )

    elevator.principles["PRIN-002"] = Principle(
        principle_id="PRIN-002",
        name="Transparent Auditing",
        statement="All operations must be auditable and transparent",
        abstraction_level=AbstractionLevel.PRINCIPLE,
        source_patterns=["PAT-002"],
        domains=[DomainType.ETHICAL],
        constraints=[],
        exceptions=[],
        evidence_strength=0.85,
        ihsan_alignment=0.995,
    )

    return elevator


@pytest.fixture
def synergy_candidate():
    """Create a test synergy candidate."""
    return SynergyCandidate(
        candidate_id="SYN-TEST-001",
        source_id="PRIN-001",
        target_id="PRIN-002",
        source_domain=DomainType.TECHNICAL,
        target_domain=DomainType.ETHICAL,
        source_type="principle",
        target_type="principle",
        similarity_score=0.85,
        structural_score=0.7,
        composite_score=0.9,
        potential_compound="Cross-domain auditability with immutable records",
        synergy_type="complementary",
        ihsan_alignment=0.995,
        contradictions_found=[],
        is_valid=True,
    )


@pytest.fixture
def discovery_engine(elevator_with_principles):
    """Create a compound discovery engine."""

    async def mock_sat_verify(operation: str, context: dict):
        # Mock SAT consensus: 4 votes for, 1 against
        return 4, 1

    return CompoundDiscoveryEngine(
        elevator=elevator_with_principles,
        sat_verify_callback=mock_sat_verify,
    )


class TestCompoundDiscoveryEngine:
    """Tests for CompoundDiscoveryEngine class."""

    def test_initialization(self, discovery_engine):
        """Test engine initializes correctly."""
        assert discovery_engine is not None
        assert discovery_engine.MIN_IHSAN == 0.99
        assert discovery_engine.REQUIRED_SAT_CONSENSUS == 3

    @pytest.mark.asyncio
    async def test_synthesize_compound(self, discovery_engine, synergy_candidate):
        """Test compound synthesis from synergy."""
        compound = await discovery_engine.synthesize_compound(synergy_candidate)

        assert compound is not None
        assert isinstance(compound, CompoundKnowledge)
        assert compound.compound_id.startswith("CMPD-")
        assert compound.ihsan_alignment >= 0.99
        assert compound.sat_approved

    @pytest.mark.asyncio
    async def test_synthesis_requires_ihsan(self, discovery_engine, synergy_candidate):
        """Test that synthesis fails if Ihsan is too low."""
        # Lower the source principles' Ihsan below threshold
        discovery_engine.elevator.principles["PRIN-001"].ihsan_alignment = 0.85
        discovery_engine.elevator.principles["PRIN-002"].ihsan_alignment = 0.85

        compound = await discovery_engine.synthesize_compound(synergy_candidate)

        # Should fail due to low Ihsan
        assert compound is None

    @pytest.mark.asyncio
    async def test_synthesis_requires_sat_consensus(self, elevator_with_principles, synergy_candidate):
        """Test that synthesis fails without SAT consensus."""

        async def mock_sat_reject(operation: str, context: dict):
            # Mock SAT rejection: 2 votes for, 3 against
            return 2, 3

        engine = CompoundDiscoveryEngine(
            elevator=elevator_with_principles,
            sat_verify_callback=mock_sat_reject,
        )

        compound = await engine.synthesize_compound(synergy_candidate)

        # Should fail due to lack of SAT consensus
        assert compound is None

    def test_compound_structure(self, discovery_engine):
        """Test compound knowledge structure."""
        compound = CompoundKnowledge(
            compound_id="CMPD-001",
            name="Test Compound",
            statement="Test statement",
            emergent_capability="Test capability",
            synthesis_type=SynthesisType.ADDITIVE,
            source_principles=["PRIN-001", "PRIN-002"],
            domains_bridged=[DomainType.TECHNICAL, DomainType.ETHICAL],
            ihsan_alignment=0.995,
            evidence_strength=0.9,
        )

        assert compound.compound_id == "CMPD-001"
        assert len(compound.source_principles) == 2
        assert len(compound.domains_bridged) == 2

    @pytest.mark.asyncio
    async def test_get_compounds_by_domain(self, discovery_engine, synergy_candidate):
        """Test retrieval of compounds by domain."""
        await discovery_engine.synthesize_compound(synergy_candidate)

        tech_compounds = discovery_engine.get_compounds_by_domain(DomainType.TECHNICAL)
        ethical_compounds = discovery_engine.get_compounds_by_domain(DomainType.ETHICAL)

        # The compound bridges both domains
        assert len(tech_compounds) >= 0 or len(ethical_compounds) >= 0

    @pytest.mark.asyncio
    async def test_get_compounds_by_type(self, discovery_engine, synergy_candidate):
        """Test retrieval of compounds by synthesis type."""
        await discovery_engine.synthesize_compound(synergy_candidate)

        additive = discovery_engine.get_compounds_by_type(SynthesisType.ADDITIVE)
        mult = discovery_engine.get_compounds_by_type(SynthesisType.MULTIPLICATIVE)
        trans = discovery_engine.get_compounds_by_type(SynthesisType.TRANSCENDENT)

        # At least one category should have the compound
        total = len(additive) + len(mult) + len(trans)
        assert total >= 0  # May be 0 if synthesis failed


class TestSynthesisTypes:
    """Tests for different synthesis types."""

    def test_synthesis_type_enum(self):
        """Test synthesis type enumeration."""
        assert SynthesisType.ADDITIVE.value == "additive"
        assert SynthesisType.MULTIPLICATIVE.value == "mult"
        assert SynthesisType.TRANSCENDENT.value == "transcend"

    @pytest.mark.asyncio
    async def test_synthesis_type_selection(self, discovery_engine, synergy_candidate):
        """Test that synthesis type is selected appropriately."""
        # Complementary synergy should produce additive compound
        synergy_candidate.synergy_type = "complementary"
        compound = await discovery_engine.synthesize_compound(synergy_candidate)

        if compound:
            assert compound.synthesis_type == SynthesisType.ADDITIVE

    @pytest.mark.asyncio
    async def test_transcendent_synthesis(self, discovery_engine, synergy_candidate):
        """Test transcendent synthesis type."""
        synergy_candidate.synergy_type = "transcendent"
        compound = await discovery_engine.synthesize_compound(synergy_candidate)

        if compound:
            assert compound.synthesis_type == SynthesisType.TRANSCENDENT


class TestCompoundValidation:
    """Tests for compound validation."""

    @pytest.mark.asyncio
    async def test_validation_receipts(self, discovery_engine, synergy_candidate):
        """Test that synthesis produces validation receipts."""
        compound = await discovery_engine.synthesize_compound(synergy_candidate)

        if compound:
            # Should have at least one validation receipt
            assert len(compound.validation_receipts) >= 1

    @pytest.mark.asyncio
    async def test_evidence_strength_calculation(self, discovery_engine, synergy_candidate):
        """Test evidence strength is calculated from sources."""
        compound = await discovery_engine.synthesize_compound(synergy_candidate)

        if compound:
            # Evidence strength should be derived from source principles
            source_strengths = [
                discovery_engine.elevator.principles["PRIN-001"].evidence_strength,
                discovery_engine.elevator.principles["PRIN-002"].evidence_strength,
            ]
            # Geometric mean is used
            expected = (source_strengths[0] * source_strengths[1]) ** 0.5
            assert abs(compound.evidence_strength - expected) < 0.01

    def test_statistics(self, discovery_engine):
        """Test statistics generation."""
        stats = discovery_engine.get_statistics()

        assert "total_compounds" in stats
        assert "by_type" in stats
        assert "avg_ihsan_alignment" in stats
        assert "avg_evidence_strength" in stats


class TestBatchSynthesis:
    """Tests for batch compound synthesis."""

    @pytest.mark.asyncio
    async def test_synthesize_batch_empty(self, discovery_engine):
        """Test batch synthesis with no synergies."""
        compounds = await discovery_engine.synthesize_batch(synergies=[])
        assert compounds == []

    @pytest.mark.asyncio
    async def test_synthesize_batch_multiple(self, discovery_engine, synergy_candidate):
        """Test batch synthesis with multiple synergies."""
        # Create multiple synergies
        synergy2 = SynergyCandidate(
            candidate_id="SYN-TEST-002",
            source_id="PRIN-001",
            target_id="PRIN-002",
            source_domain=DomainType.TECHNICAL,
            target_domain=DomainType.ETHICAL,
            similarity_score=0.8,
            structural_score=0.6,
            composite_score=0.85,
            potential_compound="Another capability",
            synergy_type="reinforcing",
            ihsan_alignment=0.995,
            is_valid=True,
        )

        compounds = await discovery_engine.synthesize_batch(
            synergies=[synergy_candidate, synergy2],
            max_compounds=10,
        )

        # Should synthesize at least some
        assert isinstance(compounds, list)
