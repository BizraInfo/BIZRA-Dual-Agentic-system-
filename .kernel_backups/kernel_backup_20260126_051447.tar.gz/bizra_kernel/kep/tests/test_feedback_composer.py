"""
Tests for the Feedback Loop Composer component.
"""

import pytest
import asyncio
from ..feedback_composer import (
    FeedbackLoopComposer,
    LoopType,
    LoopConfig,
    LoopResult,
)
from ...abstraction_elevator import AbstractionElevator
from ...sape_engine import SAPEEngine


@pytest.fixture
def elevator():
    """Create a test elevator."""
    return AbstractionElevator()


@pytest.fixture
def sape_engine():
    """Create a test SAPE engine."""
    return SAPEEngine()


@pytest.fixture
def composer(elevator, sape_engine):
    """Create a feedback loop composer."""
    return FeedbackLoopComposer(
        elevator=elevator,
        sape_engine=sape_engine,
    )


class TestFeedbackLoopComposer:
    """Tests for FeedbackLoopComposer class."""

    def test_initialization(self, composer):
        """Test composer initializes correctly."""
        assert composer is not None
        assert len(composer.configs) == 4  # 4 loop types

    def test_default_configs(self, composer):
        """Test default loop configurations."""
        configs = composer.configs

        assert LoopType.SAPE_ELEVATION in configs
        assert LoopType.ABSTRACTION in configs
        assert LoopType.COMPOUND_DISCOVERY in configs
        assert LoopType.LEARNING_ACCELERATION in configs

    def test_loop_config_structure(self, composer):
        """Test loop configuration structure."""
        config = composer.configs[LoopType.SAPE_ELEVATION]

        assert isinstance(config, LoopConfig)
        assert config.loop_type == LoopType.SAPE_ELEVATION
        assert config.target_gain > 0
        assert config.max_iterations > 0

    def test_target_gains(self, composer):
        """Test expected target gains for each loop."""
        assert composer.configs[LoopType.SAPE_ELEVATION].target_gain == 1.5
        assert composer.configs[LoopType.ABSTRACTION].target_gain == 2.0
        assert composer.configs[LoopType.COMPOUND_DISCOVERY].target_gain == 3.0
        assert composer.configs[LoopType.LEARNING_ACCELERATION].target_gain == 1.2


class TestLoopIteration:
    """Tests for individual loop iterations."""

    @pytest.mark.asyncio
    async def test_run_sape_elevation_loop(self, composer):
        """Test running SAPE elevation loop."""
        result = await composer.run_loop_iteration(LoopType.SAPE_ELEVATION)

        if result:
            assert isinstance(result, LoopResult)
            assert result.loop_type == LoopType.SAPE_ELEVATION

    @pytest.mark.asyncio
    async def test_run_abstraction_loop(self, composer):
        """Test running abstraction loop."""
        result = await composer.run_loop_iteration(LoopType.ABSTRACTION)

        if result:
            assert isinstance(result, LoopResult)
            assert result.loop_type == LoopType.ABSTRACTION

    @pytest.mark.asyncio
    async def test_run_learning_acceleration_loop(self, composer):
        """Test running learning acceleration loop."""
        result = await composer.run_loop_iteration(LoopType.LEARNING_ACCELERATION)

        if result:
            assert isinstance(result, LoopResult)
            assert result.loop_type == LoopType.LEARNING_ACCELERATION

    @pytest.mark.asyncio
    async def test_loop_result_structure(self, composer):
        """Test loop result has required fields."""
        result = await composer.run_loop_iteration(LoopType.LEARNING_ACCELERATION)

        if result:
            assert hasattr(result, "iteration")
            assert hasattr(result, "input_count")
            assert hasattr(result, "output_count")
            assert hasattr(result, "gain_achieved")
            assert hasattr(result, "latency_ms")
            assert hasattr(result, "ihsan_pre")
            assert hasattr(result, "ihsan_post")
            assert hasattr(result, "success")


class TestLoopTracking:
    """Tests for loop iteration tracking."""

    @pytest.mark.asyncio
    async def test_iteration_count_increments(self, composer):
        """Test that iteration counts increment."""
        # Ensure Ihsan is above threshold so loop can run
        for pid in composer.elevator.principles.keys():
            composer.elevator.principles[pid].ihsan_alignment = 0.995

        initial = composer.iteration_counts[LoopType.LEARNING_ACCELERATION]

        result = await composer.run_loop_iteration(LoopType.LEARNING_ACCELERATION)

        # If result is None, the loop was blocked (which is valid)
        if result is not None:
            final = composer.iteration_counts[LoopType.LEARNING_ACCELERATION]
            assert final == initial + 1

    @pytest.mark.asyncio
    async def test_cumulative_gain_tracking(self, composer):
        """Test cumulative gain is tracked."""
        initial = composer.cumulative_gains[LoopType.LEARNING_ACCELERATION]

        result = await composer.run_loop_iteration(LoopType.LEARNING_ACCELERATION)

        if result:
            final = composer.cumulative_gains[LoopType.LEARNING_ACCELERATION]
            assert final == initial + result.gain_achieved

    def test_reset_counters(self, composer):
        """Test counter reset functionality."""
        composer.iteration_counts[LoopType.SAPE_ELEVATION] = 50
        composer.cumulative_gains[LoopType.SAPE_ELEVATION] = 100.0

        composer.reset_counters(LoopType.SAPE_ELEVATION)

        assert composer.iteration_counts[LoopType.SAPE_ELEVATION] == 0
        assert composer.cumulative_gains[LoopType.SAPE_ELEVATION] == 0.0

    def test_reset_all_counters(self, composer):
        """Test resetting all counters."""
        for lt in LoopType:
            composer.iteration_counts[lt] = 50
            composer.cumulative_gains[lt] = 100.0

        composer.reset_counters()

        for lt in LoopType:
            assert composer.iteration_counts[lt] == 0
            assert composer.cumulative_gains[lt] == 0.0


class TestFeedbackCycle:
    """Tests for full feedback cycles."""

    @pytest.mark.asyncio
    async def test_run_all_loops_once(self, composer):
        """Test running all loops in one cycle."""
        results = await composer.run_all_loops_once()

        assert isinstance(results, dict)
        assert len(results) == 4  # 4 loop types

    @pytest.mark.asyncio
    async def test_run_feedback_cycle(self, composer):
        """Test running multiple feedback cycles."""
        results = await composer.run_feedback_cycle(max_cycles=2)

        assert isinstance(results, list)
        assert len(results) <= 2

    @pytest.mark.asyncio
    async def test_feedback_cycle_stops_on_low_gain(self, composer):
        """Test that cycles stop when gain is too low."""
        results = await composer.run_feedback_cycle(
            max_cycles=100,
            min_total_gain=100.0,  # Very high threshold
        )

        # Should stop early due to low gain
        assert len(results) < 100


class TestRunningState:
    """Tests for composer running state."""

    def test_initial_not_running(self, composer):
        """Test composer starts not running."""
        assert not composer.is_running()

    @pytest.mark.asyncio
    async def test_running_during_cycle(self, composer):
        """Test running state during cycle execution."""
        # Start cycle in background
        cycle_task = asyncio.create_task(
            composer.run_feedback_cycle(max_cycles=1)
        )

        # Give it time to start
        await asyncio.sleep(0.01)

        # Check state while possibly running
        # (may already be done for simple cycles)
        running = composer.is_running()

        await cycle_task

        # Should not be running after completion
        assert not composer.is_running()

    def test_stop_request(self, composer):
        """Test stop request functionality."""
        composer._running = True
        composer.stop()

        assert composer._stop_requested


class TestStatistics:
    """Tests for composer statistics."""

    @pytest.mark.asyncio
    async def test_get_statistics(self, composer):
        """Test statistics generation."""
        await composer.run_loop_iteration(LoopType.LEARNING_ACCELERATION)

        stats = composer.get_statistics()

        assert "loops" in stats
        assert "is_running" in stats
        assert "total_iterations" in stats
        assert "total_cumulative_gain" in stats

    @pytest.mark.asyncio
    async def test_loop_statistics(self, composer):
        """Test per-loop statistics."""
        await composer.run_loop_iteration(LoopType.LEARNING_ACCELERATION)

        stats = composer.get_statistics()
        loop_stats = stats["loops"][LoopType.LEARNING_ACCELERATION.value]

        assert "enabled" in loop_stats
        assert "iterations" in loop_stats
        assert "cumulative_gain" in loop_stats
        assert "target_gain" in loop_stats


class TestDisabledLoops:
    """Tests for disabled loop handling."""

    def test_disable_loop(self, composer):
        """Test disabling a loop."""
        composer.configs[LoopType.SAPE_ELEVATION].enabled = False

        assert not composer.configs[LoopType.SAPE_ELEVATION].enabled

    @pytest.mark.asyncio
    async def test_disabled_loop_skipped(self, composer):
        """Test that disabled loops are skipped."""
        composer.configs[LoopType.SAPE_ELEVATION].enabled = False

        result = await composer.run_loop_iteration(LoopType.SAPE_ELEVATION)

        assert result is None
