"""
Tests for the Synergy Detector component.
"""

import pytest
from ..synergy_detector import SynergyDetector, SynergyCandidate, SynergyType
from ...abstraction_elevator import (
    AbstractionElevator,
    DomainType,
    Principle,
    AbstractionLevel,
)


@pytest.fixture
def elevator_with_principles():
    """Create an elevator with test principles."""
    elevator = AbstractionElevator()

    # Add some test principles across different domains
    elevator.principles["PRIN-TEST-001"] = Principle(
        principle_id="PRIN-TEST-001",
        name="Technical Reliability",
        statement="Systems should be reliable and fault-tolerant",
        abstraction_level=AbstractionLevel.PRINCIPLE,
        source_patterns=["PAT-001"],
        domains=[DomainType.TECHNICAL],
        constraints=[],
        exceptions=[],
        evidence_strength=0.8,
        ihsan_alignment=0.99,
    )

    elevator.principles["PRIN-TEST-002"] = Principle(
        principle_id="PRIN-TEST-002",
        name="Ethical Transparency",
        statement="All decisions should be transparent and auditable",
        abstraction_level=AbstractionLevel.PRINCIPLE,
        source_patterns=["PAT-002"],
        domains=[DomainType.ETHICAL],
        constraints=[],
        exceptions=[],
        evidence_strength=0.85,
        ihsan_alignment=0.995,
    )

    elevator.principles["PRIN-TEST-003"] = Principle(
        principle_id="PRIN-TEST-003",
        name="Economic Efficiency",
        statement="Resources should be allocated efficiently",
        abstraction_level=AbstractionLevel.PRINCIPLE,
        source_patterns=["PAT-003"],
        domains=[DomainType.ECONOMIC],
        constraints=[],
        exceptions=[],
        evidence_strength=0.75,
        ihsan_alignment=0.99,
    )

    return elevator


@pytest.fixture
def detector(elevator_with_principles):
    """Create a synergy detector with test elevator."""
    return SynergyDetector(elevator=elevator_with_principles)


class TestSynergyDetector:
    """Tests for SynergyDetector class."""

    def test_initialization(self, detector):
        """Test detector initializes correctly."""
        assert detector is not None
        assert detector.SYNERGY_THRESHOLD == 0.75
        assert detector.CROSS_DOMAIN_BOOST == 0.15

    def test_detect_synergies(self, detector):
        """Test synergy detection finds candidates."""
        synergies = detector.detect_synergies()

        assert isinstance(synergies, list)
        # Should find at least some synergies with 3 principles
        assert len(synergies) >= 0

    def test_cross_domain_boost(self, detector):
        """Cross-domain synergies should receive score boost."""
        synergies = detector.detect_synergies()

        cross_domain = [
            s for s in synergies
            if s.source_domain != s.target_domain
        ]

        # All cross-domain synergies that passed threshold
        # should have scores that include the boost
        for s in cross_domain:
            # The composite score includes the cross-domain boost
            assert s.composite_score >= detector.SYNERGY_THRESHOLD

    def test_ihsan_filtering(self, detector):
        """Synergies below Ihsan threshold should be filtered."""
        synergies = detector.detect_synergies(min_ihsan=0.999)

        # All returned synergies should meet the Ihsan threshold
        for s in synergies:
            assert s.ihsan_alignment >= 0.99

    def test_synergy_candidate_structure(self, detector):
        """Test that synergy candidates have required fields."""
        synergies = detector.detect_synergies(max_results=5)

        for s in synergies:
            assert isinstance(s, SynergyCandidate)
            assert s.candidate_id != ""
            assert s.source_id != ""
            assert s.target_id != ""
            assert 0 <= s.similarity_score <= 1
            assert 0 <= s.structural_score <= 1
            assert s.composite_score >= 0

    def test_get_cross_domain_candidates(self, detector):
        """Test retrieval of cross-domain candidates."""
        # First detect synergies
        detector.detect_synergies()

        # Get cross-domain candidates
        candidates = detector.get_cross_domain_candidates(min_score=0.0)

        for c in candidates:
            assert c.source_domain != c.target_domain

    def test_pending_synthesis_queue(self, detector):
        """Test that valid synergies are added to pending synthesis."""
        detector.detect_synergies()

        pending = detector.get_pending_synthesis()
        assert isinstance(pending, list)

        # All pending synergies should be valid
        for s in pending:
            assert s.is_valid

    def test_mark_synthesized(self, detector):
        """Test marking synergies as synthesized."""
        detector.detect_synergies()

        pending_before = len(detector.get_pending_synthesis())
        if pending_before > 0:
            # Mark the first one as synthesized
            first_id = detector.pending_synthesis[0].candidate_id
            detector.mark_synthesized(first_id)

            pending_after = len(detector.get_pending_synthesis())
            assert pending_after == pending_before - 1

    def test_statistics(self, detector):
        """Test statistics generation."""
        detector.detect_synergies()

        stats = detector.get_statistics()

        assert "total_detected" in stats
        assert "valid_candidates" in stats
        assert "cross_domain_count" in stats
        assert "pending_synthesis" in stats
        assert "synergy_types" in stats


class TestSynergyFiltering:
    """Tests for synergy filtering and validation."""

    def test_contradiction_detection(self, detector):
        """Test that contradictions are detected."""
        # Add contradicting principles
        detector.elevator.principles["PRIN-CONTRA-1"] = Principle(
            principle_id="PRIN-CONTRA-1",
            name="Centralized Control",
            statement="Systems should be centralized for efficiency",
            abstraction_level=AbstractionLevel.PRINCIPLE,
            source_patterns=[],
            domains=[DomainType.TECHNICAL],
            constraints=[],
            exceptions=["decentralized systems"],
            evidence_strength=0.7,
            ihsan_alignment=0.99,
        )

        detector.elevator.principles["PRIN-CONTRA-2"] = Principle(
            principle_id="PRIN-CONTRA-2",
            name="Decentralized Systems",
            statement="Systems must be decentralized to prevent single points of failure",
            abstraction_level=AbstractionLevel.PRINCIPLE,
            source_patterns=[],
            domains=[DomainType.TECHNICAL],
            constraints=[],
            exceptions=[],
            evidence_strength=0.7,
            ihsan_alignment=0.99,
        )

        synergies = detector.detect_synergies()

        # Find the synergy between the contradicting principles
        contra_synergy = None
        for s in synergies:
            if ("PRIN-CONTRA-1" in [s.source_id, s.target_id] and
                "PRIN-CONTRA-2" in [s.source_id, s.target_id]):
                contra_synergy = s
                break

        # Should have contradictions detected
        if contra_synergy:
            assert len(contra_synergy.contradictions_found) > 0


class TestSynergyScoring:
    """Tests for synergy scoring calculations."""

    def test_similarity_score_bounds(self, detector):
        """Test that similarity scores are bounded 0-1."""
        synergies = detector.detect_synergies()

        for s in synergies:
            assert 0 <= s.similarity_score <= 1

    def test_structural_score_bounds(self, detector):
        """Test that structural scores are bounded 0-1."""
        synergies = detector.detect_synergies()

        for s in synergies:
            assert 0 <= s.structural_score <= 1

    def test_composite_score_formula(self, detector):
        """Test composite score follows expected formula."""
        synergies = detector.detect_synergies()

        for s in synergies:
            expected_base = (
                detector.SIMILARITY_WEIGHT * s.similarity_score +
                detector.STRUCTURAL_WEIGHT * s.structural_score
            )

            # Cross-domain boost
            if s.source_domain != s.target_domain:
                expected_base += detector.CROSS_DOMAIN_BOOST

            # Allow small floating point tolerance
            assert abs(s.composite_score - expected_base) < 0.01
