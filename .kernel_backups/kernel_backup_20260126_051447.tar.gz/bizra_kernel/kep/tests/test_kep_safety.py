"""
Tests for the KEP Safety module.
"""

import pytest
from ..kep_safety import (
    KEPSafetyGate,
    KEPSafetyLimits,
    SafetyState,
    SafetyResponse,
    SafetyViolationType,
    get_safety_gate,
    set_safety_gate,
)


@pytest.fixture
def safety_gate():
    """Create a fresh safety gate for testing."""
    return KEPSafetyGate()


@pytest.fixture
def custom_limits():
    """Create custom safety limits for testing."""
    return KEPSafetyLimits(
        IHSAN_MINIMUM=0.99,
        MAX_COMPOUNDS_PER_HOUR=10,
        MAX_SYNERGIES_PER_HOUR=20,
        MAX_LOOP_ITERATIONS=100,
    )


class TestKEPSafetyLimits:
    """Tests for safety limits constants."""

    def test_default_limits(self):
        """Test default safety limits."""
        limits = KEPSafetyLimits()

        assert limits.IHSAN_MINIMUM == 0.99
        assert limits.IHSAN_TARGET == 0.992
        assert limits.MAX_LEARNING_RATE == 2.0
        assert limits.EXPLOSION_LEARNING_RATE == 5.0
        assert limits.ABSOLUTE_MAX_RATE == 10.0
        assert limits.MAX_COMPOUNDS_PER_HOUR == 50
        assert limits.MIN_SAT_CONSENSUS == 3
        assert limits.EXPLOSION_SAT_CONSENSUS == 4

    def test_ihsan_minimum_never_lowered(self):
        """Verify Ihsan minimum is hardcoded at 0.99."""
        limits = KEPSafetyLimits()
        # This is a hardcoded value that should never change
        assert limits.IHSAN_MINIMUM == 0.99


class TestKEPSafetyGate:
    """Tests for KEPSafetyGate class."""

    def test_initialization(self, safety_gate):
        """Test safety gate initializes correctly."""
        assert safety_gate is not None
        assert safety_gate.state.current_ihsan == 0.0

    def test_update_ihsan_continue(self, safety_gate):
        """Test normal Ihsan update allows continuation."""
        response = safety_gate.update_ihsan(0.995)
        assert response == SafetyResponse.CONTINUE

    def test_update_ihsan_block(self, safety_gate):
        """Test low Ihsan blocks operations."""
        response = safety_gate.update_ihsan(0.98)
        assert response == SafetyResponse.BLOCK

    def test_emergency_ihsan_drop(self, safety_gate):
        """Test emergency halt on rapid Ihsan drop."""
        # Set initial high Ihsan
        safety_gate.update_ihsan(0.995)

        # Rapid drop should trigger halt
        response = safety_gate.update_ihsan(0.94)  # 5.5% drop
        assert response == SafetyResponse.HALT

    def test_check_compound_synthesis(self, safety_gate):
        """Test compound synthesis rate limiting."""
        # First check should pass
        response = safety_gate.check_compound_synthesis()
        assert response == SafetyResponse.CONTINUE

    def test_check_compound_synthesis_throttle(self, custom_limits):
        """Test compound synthesis throttled at limit."""
        gate = KEPSafetyGate(limits=custom_limits)

        # Exhaust the limit
        for _ in range(10):
            gate.record_compound_synthesis()

        response = gate.check_compound_synthesis()
        assert response == SafetyResponse.THROTTLE

    def test_check_synergy_detection(self, safety_gate):
        """Test synergy detection rate limiting."""
        response = safety_gate.check_synergy_detection()
        assert response == SafetyResponse.CONTINUE

    def test_check_learning_rate(self, safety_gate):
        """Test learning rate validation."""
        # Normal rate should pass
        response, rate = safety_gate.check_learning_rate(1.5)
        assert response == SafetyResponse.CONTINUE
        assert rate == 1.5

    def test_check_learning_rate_clamped(self, safety_gate):
        """Test excessive learning rate is clamped."""
        response, rate = safety_gate.check_learning_rate(100.0)
        assert response == SafetyResponse.THROTTLE
        assert rate <= safety_gate.limits.ABSOLUTE_MAX_RATE

    def test_check_loop_iteration(self, custom_limits):
        """Test loop iteration limits."""
        gate = KEPSafetyGate(limits=custom_limits)

        # Should pass initially
        response = gate.check_loop_iteration("test_loop")
        assert response == SafetyResponse.CONTINUE

        # Exhaust iterations
        for _ in range(100):
            gate.record_loop_iteration("test_loop")

        response = gate.check_loop_iteration("test_loop")
        assert response == SafetyResponse.BLOCK


class TestExplosionMode:
    """Tests for explosion mode transitions."""

    def test_check_explosion_entry(self, safety_gate):
        """Test explosion entry check."""
        # Update Ihsan to target level
        safety_gate.update_ihsan(0.995)

        response = safety_gate.check_explosion_entry()
        # Should pass Ihsan check (cooldown not an issue for fresh gate)
        assert response == SafetyResponse.CONTINUE

    def test_explosion_cooldown(self, safety_gate):
        """Test explosion mode cooldown."""
        safety_gate.update_ihsan(0.995)
        safety_gate.enter_explosion_mode()
        safety_gate.exit_explosion_mode()

        # Immediately trying to re-enter should fail
        response = safety_gate.check_explosion_entry()
        assert response == SafetyResponse.BLOCK

    def test_enter_explosion_mode(self, safety_gate):
        """Test entering explosion mode."""
        safety_gate.update_ihsan(0.995)
        safety_gate.enter_explosion_mode()

        assert safety_gate.state.is_explosion_mode

    def test_exit_explosion_mode(self, safety_gate):
        """Test exiting explosion mode."""
        safety_gate.update_ihsan(0.995)
        safety_gate.enter_explosion_mode()
        safety_gate.exit_explosion_mode()

        assert not safety_gate.state.is_explosion_mode
        assert safety_gate.state.last_explosion_exit is not None


class TestViolationLogging:
    """Tests for safety violation logging."""

    def test_violations_logged(self, safety_gate):
        """Test that violations are logged."""
        # Trigger a violation
        safety_gate.update_ihsan(0.85)

        assert len(safety_gate.state.violations_log) >= 1

    def test_violation_details(self, safety_gate):
        """Test violation log contains details."""
        safety_gate.update_ihsan(0.85)

        if safety_gate.state.violations_log:
            timestamp, violation_type, message = safety_gate.state.violations_log[0]
            assert timestamp is not None
            assert violation_type == SafetyViolationType.IHSAN_BELOW_THRESHOLD
            assert "0.85" in message or "0.99" in message


class TestSafetyStatus:
    """Tests for safety status reporting."""

    def test_get_safety_status(self, safety_gate):
        """Test safety status generation."""
        safety_gate.update_ihsan(0.995)

        status = safety_gate.get_safety_status()

        assert "ihsan" in status
        assert "rate_limits" in status
        assert "learning_rate" in status
        assert "mode" in status
        assert "recent_violations" in status

    def test_status_ihsan_health(self, safety_gate):
        """Test Ihsan health in status."""
        safety_gate.update_ihsan(0.995)

        status = safety_gate.get_safety_status()
        assert status["ihsan"]["healthy"]

        safety_gate.update_ihsan(0.85)
        status = safety_gate.get_safety_status()
        assert not status["ihsan"]["healthy"]


class TestGlobalSafetyGate:
    """Tests for global safety gate singleton."""

    def test_get_safety_gate(self):
        """Test global safety gate retrieval."""
        gate = get_safety_gate()
        assert gate is not None

    def test_set_safety_gate(self):
        """Test setting custom global gate."""
        custom_gate = KEPSafetyGate(limits=KEPSafetyLimits(MAX_COMPOUNDS_PER_HOUR=5))
        set_safety_gate(custom_gate)

        retrieved = get_safety_gate()
        assert retrieved.limits.MAX_COMPOUNDS_PER_HOUR == 5

        # Reset for other tests
        set_safety_gate(KEPSafetyGate())


class TestHourlyCounterReset:
    """Tests for hourly counter reset logic."""

    def test_counters_reset_after_hour(self, safety_gate):
        """Test that counters reset after an hour."""
        from datetime import datetime, timezone, timedelta

        # Record some activity
        safety_gate.record_compound_synthesis()
        safety_gate.record_synergy_detection()

        assert safety_gate.state.compounds_this_hour == 1
        assert safety_gate.state.synergies_this_hour == 1

        # Simulate hour passing
        safety_gate.state.last_hour_reset = datetime.now(timezone.utc) - timedelta(hours=2)

        # This should trigger reset
        safety_gate._reset_hourly_counters_if_needed()

        assert safety_gate.state.compounds_this_hour == 0
        assert safety_gate.state.synergies_this_hour == 0
