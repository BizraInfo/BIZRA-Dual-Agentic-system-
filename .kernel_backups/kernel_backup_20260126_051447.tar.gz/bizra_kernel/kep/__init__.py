"""
Knowledge Explosion Point (KEP) System
======================================

A self-reinforcing loop for rapid recursive improvement leading to a
Knowledge Explosion Point where knowledge growth becomes exponential
through synergy detection, compound discovery, and learning acceleration.

Built on top of the OTA infrastructure with constitutional safety guarantees.

Components:
-----------
- SynergyDetector: Cross-domain knowledge synergy detection
- CompoundDiscoveryEngine: Emergent capability synthesis
- LearningAccelerator: Adaptive learning rate controller
- FeedbackLoopComposer: 4-loop orchestration
- KEPDashboard: Metrics and monitoring
- KEPSafetyGate: 7-layer runaway prevention

Usage:
------
```python
from bizra_kernel.kep import (
    SynergyDetector,
    CompoundDiscoveryEngine,
    LearningAccelerator,
    FeedbackLoopComposer,
    KEPDashboard,
    get_safety_gate,
)

# Initialize components
from bizra_kernel.abstraction_elevator import AbstractionElevator

elevator = AbstractionElevator()
detector = SynergyDetector(elevator)
engine = CompoundDiscoveryEngine(elevator, detector)
accelerator = LearningAccelerator(elevator)
composer = FeedbackLoopComposer(
    elevator=elevator,
    synergy_detector=detector,
    compound_engine=engine,
    learning_accelerator=accelerator,
)
dashboard = KEPDashboard(
    elevator=elevator,
    synergy_detector=detector,
    compound_engine=engine,
    accelerator=accelerator,
    composer=composer,
)

# Detect synergies
synergies = detector.detect_synergies()

# Synthesize compounds
compounds = await engine.synthesize_batch()

# Run feedback cycles
results = await composer.run_feedback_cycle(max_cycles=10)

# Check dashboard
print(dashboard.print_dashboard())
```

Safety Guarantees:
------------------
- Ihsan >= 0.99 HARD BLOCK (never lowered)
- SAT 3/5 consensus for compounds
- SAT 4/5 consensus for explosion mode entry
- Rate limiting (50 compounds/hr max)
- 7-layer safety stack

Explosion Trigger Conditions:
-----------------------------
1. Knowledge Mass >= 500 (weighted sum)
2. Discovery Velocity >= 5 compounds/hour
3. Synergy Density >= 0.25
4. Ihsan Health >= 0.992 (system average)
"""

from .kep_safety import (
    KEPSafetyGate,
    KEPSafetyLimits,
    SafetyState,
    SafetyResponse,
    SafetyViolationType,
    get_safety_gate,
    set_safety_gate,
)

from .kep_receipts import (
    KEPReceiptType,
    SynergyDetectionReceipt,
    CompoundDiscoveryReceipt,
    ExplosionModeReceipt,
    LearningAccelerationReceipt,
    FeedbackLoopReceipt,
    KEPReceiptEmitter,
    get_kep_receipt_emitter,
)

from .synergy_detector import (
    SynergyCandidate,
    SynergyType,
    SynergyDetector,
)

from .compound_discovery import (
    SynthesisType,
    CompoundKnowledge,
    CompoundDiscoveryEngine,
)

from .learning_accelerator import (
    LearningState,
    ExplosionCondition,
    ExplosionTriggerThresholds,
    LearningAccelerator,
)

from .feedback_composer import (
    LoopType,
    LoopConfig,
    LoopResult,
    FeedbackLoopComposer,
)

from .kep_dashboard import (
    MetricStatus,
    Metric,
    ExplosionProgress,
    KEPDashboard,
)

__all__ = [
    # Safety
    "KEPSafetyGate",
    "KEPSafetyLimits",
    "SafetyState",
    "SafetyResponse",
    "SafetyViolationType",
    "get_safety_gate",
    "set_safety_gate",
    # Receipts
    "KEPReceiptType",
    "SynergyDetectionReceipt",
    "CompoundDiscoveryReceipt",
    "ExplosionModeReceipt",
    "LearningAccelerationReceipt",
    "FeedbackLoopReceipt",
    "KEPReceiptEmitter",
    "get_kep_receipt_emitter",
    # Synergy
    "SynergyCandidate",
    "SynergyType",
    "SynergyDetector",
    # Compound
    "SynthesisType",
    "CompoundKnowledge",
    "CompoundDiscoveryEngine",
    # Learning
    "LearningState",
    "ExplosionCondition",
    "ExplosionTriggerThresholds",
    "LearningAccelerator",
    # Feedback
    "LoopType",
    "LoopConfig",
    "LoopResult",
    "FeedbackLoopComposer",
    # Dashboard
    "MetricStatus",
    "Metric",
    "ExplosionProgress",
    "KEPDashboard",
]

__version__ = "1.0.0"
