"""
BIZRA Genesis Sync
==================
Synchronizes genesis block to BIZRA-DATA-LAKE for network-wide access.

The genesis block is the immutable foundation of the BIZRA network.
This module ensures it is available at all canonical locations:
1. BIZRA-TaskMaster (Source of Truth)
2. BIZRA-DATA-LAKE (Network Access)
3. Local Codebase (Development Reference)

Usage:
    from bizra_kernel.genesis_sync import sync_genesis, load_genesis

    # Sync to all locations
    receipt = sync_genesis()

    # Load genesis from canonical source
    genesis = load_genesis()
"""

import os
import json
import hashlib
import shutil
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# GENESIS LOCATIONS (Dependency Injection for Testability)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class GenesisLocations:
    """
    Paths to genesis files and related directories.

    Using this dataclass enables clean dependency injection for testing
    without patching module-level globals.
    """
    taskmaster: Path
    data_lake: Path
    local: Path
    backup_dir: Path
    local_archive: Path

    def ensure_directories(self) -> None:
        """Create all required directories."""
        self.data_lake.parent.mkdir(parents=True, exist_ok=True)
        self.local.parent.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.local_archive.mkdir(parents=True, exist_ok=True)


# Default locations (production paths)
DEFAULT_LOCATIONS = GenesisLocations(
    taskmaster=Path("/mnt/c/BIZRA-TaskMaster/bizra_taskmaster/genesis/genesis.json"),
    data_lake=Path("/mnt/c/BIZRA-DATA-LAKE/00_GENESIS/genesis.json"),
    local=Path(__file__).parent.parent / "docs" / "evidence" / "genesis_block.json",
    backup_dir=Path("/mnt/c/BIZRA-DATA-LAKE/00_GENESIS/backups"),
    local_archive=Path(__file__).parent.parent / "docs" / "evidence" / "genesis_archive",
)


def get_locations_from_env() -> GenesisLocations:
    """Get locations from environment variables or use defaults."""
    return GenesisLocations(
        taskmaster=Path(os.getenv("BIZRA_GENESIS_TASKMASTER", str(DEFAULT_LOCATIONS.taskmaster))),
        data_lake=Path(os.getenv("BIZRA_GENESIS_DATALAKE", str(DEFAULT_LOCATIONS.data_lake))),
        local=Path(os.getenv("BIZRA_GENESIS_LOCAL", str(DEFAULT_LOCATIONS.local))),
        backup_dir=Path(os.getenv("BIZRA_GENESIS_BACKUP", str(DEFAULT_LOCATIONS.backup_dir))),
        local_archive=Path(os.getenv("BIZRA_GENESIS_ARCHIVE", str(DEFAULT_LOCATIONS.local_archive))),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# EXCEPTIONS
# ═══════════════════════════════════════════════════════════════════════════════

class GenesisTamperError(Exception):
    """
    Raised when genesis integrity is compromised.

    Genesis is SCRIPTURE, not configuration.
    It is written once, never overwritten, never merged, never reconciled.
    """
    pass


class GenesisExistsError(Exception):
    """
    Raised when attempting to write genesis to a location that already has one.

    Genesis must be append-only. Any mismatch triggers tamper alert.
    """
    pass


class GenesisSignatureError(Exception):
    """
    Raised when genesis signature verification fails.

    A genesis without valid signature should never be trusted.
    """
    pass


# ═══════════════════════════════════════════════════════════════════════════════
# LEGACY PATH ALIASES (for backward compatibility)
# ═══════════════════════════════════════════════════════════════════════════════
# NOTE: Prefer using GenesisLocations for new code and tests.

TASKMASTER_GENESIS = DEFAULT_LOCATIONS.taskmaster
DATA_LAKE_GENESIS = DEFAULT_LOCATIONS.data_lake
LOCAL_GENESIS = DEFAULT_LOCATIONS.local
BACKUP_DIR = DEFAULT_LOCATIONS.backup_dir
LOCAL_GENESIS_ARCHIVE = DEFAULT_LOCATIONS.local_archive


# ═══════════════════════════════════════════════════════════════════════════════
# GENESIS SIGNATURE OPERATIONS
# ═══════════════════════════════════════════════════════════════════════════════

def sign_genesis(genesis: Dict[str, Any]) -> Dict[str, Any]:
    """
    Sign the genesis block with Node0's private key.

    Args:
        genesis: Genesis data (signature field will be replaced)

    Returns:
        Genesis with cryptographic signature
    """
    try:
        from bizra_kernel.node0_identity import Node0Identity

        identity = Node0Identity.load_or_create()

        if not identity.has_private_key:
            raise GenesisSignatureError("Cannot sign - private key not available")

        if identity.is_restricted:
            raise GenesisSignatureError("Cannot sign - system in restricted mode")

        # Sign genesis
        signature_info = identity.sign_genesis(genesis)
        genesis["signature"] = signature_info

        logger.info(f"Genesis signed with Node0 identity: {signature_info['pubkey_fingerprint'][:16]}...")
        return genesis

    except ImportError:
        logger.warning("node0_identity module not available - signing skipped")
        return genesis


def verify_genesis_signature(genesis: Dict[str, Any]) -> Dict[str, Any]:
    """
    Verify genesis block signature.

    CRITICAL: An unsigned or badly signed genesis should NOT be trusted.

    Returns:
        Verification result
    """
    try:
        from bizra_kernel.node0_identity import Node0Identity

        identity = Node0Identity.load_or_create()
        return identity.verify_genesis(genesis)

    except ImportError:
        logger.warning("node0_identity module not available - signature verification skipped")
        return {
            "verified": True,
            "permissive_mode": True,
            "message": "Signature verification not available",
        }


# ═══════════════════════════════════════════════════════════════════════════════
# GENESIS LOADING
# ═══════════════════════════════════════════════════════════════════════════════

def load_genesis(
    source: str = "taskmaster",
    verify_signature: bool = True,
    strict_signature: bool = False,
    locations: Optional[GenesisLocations] = None,
) -> Dict[str, Any]:
    """
    Load genesis block from specified source.

    Args:
        source: "taskmaster" (default), "data_lake", or "local"
        verify_signature: If True, verify cryptographic signature
        strict_signature: If True, raise error on invalid signature
        locations: GenesisLocations for dependency injection (uses DEFAULT_LOCATIONS if None)

    Returns:
        Genesis block as dictionary

    Raises:
        FileNotFoundError: If genesis file not found
        json.JSONDecodeError: If genesis file is invalid JSON
        GenesisSignatureError: If strict and signature invalid
    """
    locs = locations or DEFAULT_LOCATIONS

    paths = {
        "taskmaster": locs.taskmaster,
        "data_lake": locs.data_lake,
        "local": locs.local,
    }

    path = paths.get(source, locs.taskmaster)

    if not path.exists():
        raise FileNotFoundError(f"Genesis file not found at: {path}")

    logger.info(f"Loading genesis from: {path}")

    with open(path, "r", encoding="utf-8") as f:
        genesis = json.load(f)

    # Verify signature if requested
    if verify_signature and "signature" in genesis:
        sig_result = verify_genesis_signature(genesis)

        if not sig_result.get("verified"):
            error_msg = f"Genesis signature verification failed: {sig_result.get('error', 'unknown')}"
            logger.error(error_msg)

            if strict_signature:
                raise GenesisSignatureError(error_msg)
        else:
            logger.info(f"Genesis signature verified: {sig_result.get('message', 'OK')}")
    elif verify_signature and "signature" not in genesis:
        logger.warning("Genesis has no signature - consider signing it")

    return genesis


def get_genesis_hash(genesis: Dict[str, Any]) -> str:
    """Compute SHA-256 hash of genesis block."""
    canonical = json.dumps(genesis, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def validate_genesis(genesis: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate genesis block structure.

    Returns:
        Validation result with status and any issues found
    """
    issues = []

    # Required fields
    required_root = ["version", "name", "timestamp", "node_id", "genesis_block"]
    for field in required_root:
        if field not in genesis:
            issues.append(f"Missing required field: {field}")

    # Genesis block specific checks
    if "genesis_block" in genesis:
        gb = genesis["genesis_block"]

        if gb.get("block_number") != 0:
            issues.append(f"Genesis block_number must be 0, got: {gb.get('block_number')}")

        parent_hash = gb.get("parent_hash", "")
        if not parent_hash.startswith("0x000"):
            issues.append(f"Genesis parent_hash must start with 0x000, got: {parent_hash[:10]}...")

    # Policy checks
    if "policy" in genesis:
        policy = genesis["policy"]
        if not policy.get("riba_forbidden"):
            issues.append("Policy must forbid riba")
        if not policy.get("gharar_forbidden"):
            issues.append("Policy must forbid gharar")

    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "genesis_hash": get_genesis_hash(genesis),
        "validated_at": datetime.now(timezone.utc).isoformat(),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# GENESIS SYNC
# ═══════════════════════════════════════════════════════════════════════════════

def sync_genesis(
    update_hardware_covenant: bool = False,
    hardware_fingerprint: Optional[str] = None,
    hardware_specs: Optional[Dict[str, str]] = None,
    tiered_covenant: Optional[Dict[str, Any]] = None,
    force_initial: bool = False,
    locations: Optional[GenesisLocations] = None,
) -> Dict[str, Any]:
    """
    Sync genesis block to all canonical locations.

    CRITICAL RULES (Genesis is SCRIPTURE, not configuration):
    - Genesis is written ONCE
    - Genesis is NEVER overwritten
    - Genesis is NEVER merged or reconciled
    - Any mismatch triggers TAMPER ALERT, not overwrite

    Args:
        update_hardware_covenant: If True, add/update hardware covenant before sync
        hardware_fingerprint: SHA-256 fingerprint from hardware_fingerprint module
        hardware_specs: Hardware specifications dict
        tiered_covenant: Full tiered covenant structure (tier_1, tier_2, tier_3)
        force_initial: If True, allow initial write even if file exists (USE WITH CAUTION)
        locations: GenesisLocations for dependency injection (uses DEFAULT_LOCATIONS if None)

    Returns:
        Sync receipt with results

    Raises:
        GenesisExistsError: If genesis already exists at target and differs
        GenesisTamperError: If existing genesis is corrupted or invalid
    """
    locs = locations or DEFAULT_LOCATIONS
    logger.info("Starting genesis sync (ONE-WAY, APPEND-ONLY)...")

    # 1. Read from TaskMaster (source of truth)
    if not locs.taskmaster.exists():
        return {
            "success": False,
            "error": f"Source genesis not found at: {locs.taskmaster}",
            "synced_at": datetime.now(timezone.utc).isoformat(),
        }

    genesis = load_genesis("taskmaster", locations=locs)

    # 2. Validate integrity
    validation = validate_genesis(genesis)
    if not validation["valid"]:
        return {
            "success": False,
            "error": f"Genesis validation failed: {validation['issues']}",
            "synced_at": datetime.now(timezone.utc).isoformat(),
        }

    source_hash = get_genesis_hash(genesis)

    # 3. Optionally update hardware covenant (ONLY if not already present)
    if update_hardware_covenant and hardware_fingerprint:
        if "hardware_covenant" in genesis and not force_initial:
            logger.warning("Hardware covenant already exists - skipping update (immutable)")
        else:
            genesis["hardware_covenant"] = {
                "fingerprint": hardware_fingerprint,
                "hardware_class": hardware_specs.get("hardware_class", "Unknown") if hardware_specs else "Unknown",
                "specifications": hardware_specs or {},
                "tiered_covenant": tiered_covenant or {},
                "attestation": "This hardware IS Node0 - the genesis block of BIZRA network",
                "covenant_date": datetime.now(timezone.utc).isoformat(),
                "operator": genesis.get("operator", "momo_architect_founder"),
                # Authority model
                "authority_mode": "ORIGIN_ONLY",
                "delegation_allowed": True,
                "transfer_allowed": False,
            }

            # Write back to source
            with open(locs.taskmaster, "w", encoding="utf-8") as f:
                json.dump(genesis, f, indent=2, ensure_ascii=False)

            source_hash = get_genesis_hash(genesis)
            logger.info("Hardware covenant added to genesis")

    # 4. Sync to Data Lake (ONE-WAY, APPEND-ONLY)
    sync_results = []

    try:
        locs.data_lake.parent.mkdir(parents=True, exist_ok=True)

        # CRITICAL: Check if genesis already exists
        if locs.data_lake.exists():
            existing_genesis = json.loads(locs.data_lake.read_text(encoding="utf-8"))
            existing_hash = get_genesis_hash(existing_genesis)

            if existing_hash == source_hash:
                # Already synced with identical content
                sync_results.append({
                    "location": str(locs.data_lake),
                    "status": "already_synced",
                    "message": "Genesis already exists with identical hash",
                    "hash": existing_hash[:16] + "...",
                })
                logger.info("Data Lake genesis already matches source - no action needed")
            else:
                # TAMPER ALERT: Hashes don't match!
                error_msg = (
                    f"GENESIS TAMPER ALERT! Data Lake genesis hash mismatch.\n"
                    f"  Source hash:   {source_hash[:32]}...\n"
                    f"  Existing hash: {existing_hash[:32]}...\n"
                    f"Genesis is SCRIPTURE - it cannot be modified or reconciled."
                )
                logger.error(error_msg)

                if not force_initial:
                    raise GenesisTamperError(error_msg)

                # Force mode: backup and overwrite (EMERGENCY ONLY)
                backup_name = f"genesis_TAMPERED_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                locs.backup_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(locs.data_lake, locs.backup_dir / backup_name)
                logger.warning(f"EMERGENCY: Backed up tampered genesis to: {backup_name}")

                with open(locs.data_lake, "w", encoding="utf-8") as f:
                    json.dump(genesis, f, indent=2, ensure_ascii=False)

                sync_results.append({
                    "location": str(locs.data_lake),
                    "status": "force_overwritten",
                    "warning": "Genesis was force-overwritten (tamper detected)",
                    "backup": str(locs.backup_dir / backup_name),
                })
        else:
            # First-time sync - write genesis
            with open(locs.data_lake, "w", encoding="utf-8") as f:
                json.dump(genesis, f, indent=2, ensure_ascii=False)

            sync_results.append({
                "location": str(locs.data_lake),
                "status": "synced",
                "size_bytes": locs.data_lake.stat().st_size,
                "message": "Initial genesis write to Data Lake",
            })
            logger.info(f"Genesis written to Data Lake: {locs.data_lake}")

    except GenesisTamperError:
        raise  # Re-raise tamper errors
    except Exception as e:
        sync_results.append({
            "location": str(locs.data_lake),
            "status": "failed",
            "error": str(e),
        })
        logger.error(f"Failed to sync to Data Lake: {e}")

    # 5. Sync to local codebase (APPEND-ONLY - archive on mismatch)
    try:
        locs.local.parent.mkdir(parents=True, exist_ok=True)

        if locs.local.exists():
            existing_genesis = json.loads(locs.local.read_text(encoding="utf-8"))
            existing_hash = get_genesis_hash(existing_genesis)

            if existing_hash == source_hash:
                sync_results.append({
                    "location": str(locs.local),
                    "status": "already_synced",
                    "message": "Local genesis already matches source",
                })
            else:
                # APPEND-ONLY: Archive old, don't overwrite
                # This preserves evidence of any changes
                locs.local_archive.mkdir(parents=True, exist_ok=True)
                archive_name = f"genesis_block_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                archive_path = locs.local_archive / archive_name

                # Archive the existing (potentially tampered) file
                shutil.copy2(locs.local, archive_path)
                logger.warning(f"Local genesis archived to: {archive_name}")

                # Emit tamper receipt
                tamper_receipt = {
                    "receipt_type": "GENESIS_LOCAL_MISMATCH",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source_hash": source_hash[:16] + "...",
                    "existing_hash": existing_hash[:16] + "...",
                    "archived_to": str(archive_path),
                    "action": "archived_and_replaced",
                }
                tamper_receipt_path = locs.local_archive / f"tamper_receipt_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                with open(tamper_receipt_path, "w") as f:
                    json.dump(tamper_receipt, f, indent=2)

                # Now write the correct genesis
                with open(locs.local, "w", encoding="utf-8") as f:
                    json.dump(genesis, f, indent=2, ensure_ascii=False)

                sync_results.append({
                    "location": str(locs.local),
                    "status": "updated_with_archive",
                    "message": "Local genesis updated (old version archived)",
                    "archive": str(archive_path),
                    "tamper_receipt": str(tamper_receipt_path),
                })
        else:
            with open(locs.local, "w", encoding="utf-8") as f:
                json.dump(genesis, f, indent=2, ensure_ascii=False)
            sync_results.append({
                "location": str(locs.local),
                "status": "synced",
                "size_bytes": locs.local.stat().st_size,
            })
            logger.info(f"Synced to local: {locs.local}")

    except Exception as e:
        sync_results.append({
            "location": str(locs.local),
            "status": "failed",
            "error": str(e),
        })
        logger.error(f"Failed to sync to local: {e}")

    # 6. Generate sync receipt
    # Status categories for accurate reporting
    SUCCESS_STATUSES = {
        "synced",
        "already_synced",
        "updated",
        "updated_with_archive",
        "force_overwritten",
    }

    receipt = {
        "receipt_id": f"GENESIS-SYNC-{hashlib.sha256(str(datetime.now()).encode()).hexdigest()[:12]}",
        "synced_at": datetime.now(timezone.utc).isoformat(),
        "source": str(locs.taskmaster),
        "genesis_hash": source_hash,
        "genesis_hash_short": source_hash[:16],
        "locations_synced": [r for r in sync_results if r["status"] in SUCCESS_STATUSES],
        "locations_failed": [r for r in sync_results if r["status"] == "failed"],
        "hardware_covenant_present": "hardware_covenant" in genesis,
        "success": all(r["status"] != "failed" for r in sync_results),
        "append_only_enforced": True,
    }

    logger.info(f"Genesis sync complete: {receipt['receipt_id']}")
    return receipt


def get_sync_status(locations: Optional[GenesisLocations] = None) -> Dict[str, Any]:
    """
    Check sync status across all canonical locations.

    Args:
        locations: GenesisLocations for dependency injection (uses DEFAULT_LOCATIONS if None)

    Returns:
        Status report showing which locations are in sync
    """
    locs = locations or DEFAULT_LOCATIONS

    status = {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "locations": {},
        "in_sync": True,
        "reference_hash": None,
    }

    location_paths = {
        "taskmaster": locs.taskmaster,
        "data_lake": locs.data_lake,
        "local": locs.local,
    }

    hashes = {}

    for name, path in location_paths.items():
        if path.exists():
            try:
                genesis = json.loads(path.read_text(encoding="utf-8"))
                genesis_hash = get_genesis_hash(genesis)
                hashes[name] = genesis_hash

                status["locations"][name] = {
                    "exists": True,
                    "path": str(path),
                    "hash": genesis_hash[:16] + "...",
                    "size_bytes": path.stat().st_size,
                    "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
                    "has_hardware_covenant": "hardware_covenant" in genesis,
                }
            except Exception as e:
                status["locations"][name] = {
                    "exists": True,
                    "path": str(path),
                    "error": str(e),
                }
        else:
            status["locations"][name] = {
                "exists": False,
                "path": str(path),
            }
            status["in_sync"] = False

    # Check if all existing locations have same hash
    if hashes:
        unique_hashes = set(hashes.values())
        status["in_sync"] = len(unique_hashes) == 1
        status["reference_hash"] = hashes.get("taskmaster", list(hashes.values())[0])[:16] + "..."

    return status


# ═══════════════════════════════════════════════════════════════════════════════
# HARDWARE COVENANT MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════════

def add_hardware_covenant(fingerprint: str, specs: Dict[str, str]) -> Dict[str, Any]:
    """
    Add hardware covenant to genesis block.

    Args:
        fingerprint: SHA-256 hardware fingerprint
        specs: Hardware specifications (cpu, gpu, ram, etc.)

    Returns:
        Result of the operation
    """
    from bizra_kernel.hardware_fingerprint import generate_fingerprint

    # Verify fingerprint matches current hardware
    current = generate_fingerprint()
    if current["fingerprint"] != fingerprint:
        return {
            "success": False,
            "error": "Fingerprint does not match current hardware",
            "provided": fingerprint[:16] + "...",
            "current": current["fingerprint"][:16] + "...",
        }

    # Sync with hardware covenant
    return sync_genesis(
        update_hardware_covenant=True,
        hardware_fingerprint=fingerprint,
        hardware_specs=specs,
    )


def verify_hardware_covenant(
    enforce_restricted_mode: bool = True,
    require_tier2_attestation: bool = True,
    locations: Optional[GenesisLocations] = None,
) -> Dict[str, Any]:
    """
    Verify current hardware matches the genesis block covenant.

    CRITICAL: Tier-1 failure activates RESTRICTED MODE.
    CRITICAL: Tier-2 mismatch requires valid attestation.

    Args:
        enforce_restricted_mode: If True, enter restricted mode on Tier-1 fail
        require_tier2_attestation: If True, Tier-2 mismatch needs attestation
        locations: GenesisLocations for dependency injection (uses DEFAULT_LOCATIONS if None)

    Returns:
        Verification result
    """
    from bizra_kernel.hardware_fingerprint import generate_fingerprint, verify_fingerprint

    try:
        genesis = load_genesis(verify_signature=True, locations=locations)
    except FileNotFoundError:
        return {
            "verified": False,
            "error": "Genesis block not found",
            "permissive_mode": True,
        }

    covenant = genesis.get("hardware_covenant")

    if not covenant:
        logger.warning("Genesis has no hardware covenant - running in permissive mode")
        return {
            "verified": True,
            "permissive_mode": True,
            "message": "No hardware covenant in genesis - permissive mode enabled",
        }

    expected_fingerprint = covenant.get("fingerprint")
    if not expected_fingerprint:
        return {
            "verified": True,
            "permissive_mode": True,
            "message": "Hardware covenant has no fingerprint - permissive mode enabled",
        }

    # Get expected tiered covenant
    expected_tiered = covenant.get("tiered_covenant", {})

    # Verify against current hardware
    result = verify_fingerprint(expected_fingerprint, expected_tiered)
    result["covenant_date"] = covenant.get("covenant_date")
    result["hardware_class"] = covenant.get("hardware_class")

    # CRITICAL: Handle Tier-1 failure
    if not result.get("verified"):
        logger.error("=" * 60)
        logger.error("  TIER-1 HARDWARE MISMATCH DETECTED")
        logger.error("=" * 60)
        logger.error("  This is NOT Node0!")

        if enforce_restricted_mode:
            try:
                from bizra_kernel.node0_identity import Node0Identity
                identity = Node0Identity.load_or_create()
                identity.enter_restricted_mode(
                    f"Tier-1 hardware mismatch: {result.get('message', 'unknown')}"
                )
                result["restricted_mode_activated"] = True
            except ImportError:
                logger.error("Cannot activate restricted mode - module not available")
                result["restricted_mode_activated"] = False

        return result

    # Handle Tier-2 mismatch (requires attestation)
    tier_2_result = result.get("tier_results", {}).get("tier_2_mutable", {})

    if not tier_2_result.get("passed", True) and require_tier2_attestation:
        # Check for valid attestation
        expected_t2_hash = expected_tiered.get("tier_2_mutable", {}).get("hash")
        current_fp = generate_fingerprint()
        current_t2_hash = current_fp.get("tiered_covenant", {}).get("tier_2_mutable", {}).get("hash")

        try:
            from bizra_kernel.node0_identity import Node0Identity
            identity = Node0Identity.load_or_create()

            attestation_result = identity.verify_tier2_attestation(
                current_t2_hash,
                expected_t2_hash,
            )

            if not attestation_result.get("verified"):
                result["tier2_attestation_required"] = True
                result["tier2_attestation_missing"] = True
                result["warnings"].append(
                    "Tier-2 hardware change detected but no valid attestation found. "
                    "Create attestation with: identity.create_tier2_attestation(...)"
                )
            else:
                result["tier2_attestation_valid"] = True
                result["tier2_attestation"] = attestation_result.get("attestation")

        except ImportError:
            result["warnings"].append("Tier-2 attestation verification not available")

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    parser = argparse.ArgumentParser(description="BIZRA Genesis Sync")
    parser.add_argument("--sync", action="store_true", help="Sync genesis to all locations")
    parser.add_argument("--status", action="store_true", help="Check sync status")
    parser.add_argument("--verify", action="store_true", help="Verify hardware covenant")
    parser.add_argument("--add-covenant", action="store_true", help="Add hardware covenant to genesis")

    args = parser.parse_args()

    if args.sync:
        print("\n" + "=" * 60)
        print("  BIZRA GENESIS SYNC")
        print("=" * 60 + "\n")

        result = sync_genesis()
        print(json.dumps(result, indent=2))

    elif args.status:
        print("\n" + "=" * 60)
        print("  BIZRA GENESIS SYNC STATUS")
        print("=" * 60 + "\n")

        status = get_sync_status()
        print(json.dumps(status, indent=2))

    elif args.verify:
        print("\n" + "=" * 60)
        print("  BIZRA HARDWARE COVENANT VERIFICATION")
        print("=" * 60 + "\n")

        result = verify_hardware_covenant()
        print(json.dumps(result, indent=2))

    elif args.add_covenant:
        print("\n" + "=" * 60)
        print("  ADDING HARDWARE COVENANT TO GENESIS")
        print("=" * 60 + "\n")

        from bizra_kernel.hardware_fingerprint import generate_fingerprint

        fp = generate_fingerprint()
        print(f"Generated fingerprint: {fp['fingerprint'][:32]}...")

        specs = {
            "hardware_class": "MSI Titan GT77 HX",
            "cpu": fp["components"].get("cpu", "Unknown"),
            "gpu": fp["components"].get("gpu", "Unknown"),
            "ram": fp["components"].get("ram", "Unknown"),
        }

        result = add_hardware_covenant(fp["fingerprint"], specs)
        print(json.dumps(result, indent=2))

    else:
        # Default: show status
        status = get_sync_status()
        print("\nGenesis Sync Status:")
        print("-" * 40)

        for name, loc in status["locations"].items():
            exists = "EXISTS" if loc.get("exists") else "MISSING"
            covenant = " [+covenant]" if loc.get("has_hardware_covenant") else ""
            print(f"  {name:12}: {exists}{covenant}")

        print(f"\n  In Sync: {status['in_sync']}")
        if status["reference_hash"]:
            print(f"  Hash: {status['reference_hash']}")
