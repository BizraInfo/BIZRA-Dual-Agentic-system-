"""
BIZRA Resource Indexer v1.2
===========================
The Total Environment Census Engine. Maps hardware, software, and data
to establish the Sovereign Resource Pool.
"""

import os
import sys
import json
import time
import platform
import subprocess
import psutil
from datetime import datetime, timedelta
from typing import Dict, List, Any

class ResourceIndexer:
    def __init__(self):
        self.timestamp = datetime.now().isoformat()
        self.inventory_path = "evidence/resource_pool.json"

    def scan_hardware(self) -> Dict[str, Any]:
        """Deep hardware telemetry scan."""
        hw = {
            "cpu": {
                "brand": platform.processor(),
                "cores": psutil.cpu_count(logical=False),
                "threads": psutil.cpu_count(logical=True),
                "frequency_mhz": psutil.cpu_freq().max if psutil.cpu_freq() else "Unknown"
            },
            "memory": {
                "total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
                "swap_total_gb": round(psutil.swap_memory().total / (1024**3), 2)
            },
            "storage": [],
            "system": {}
        }

        # Disk Telemetry
        for part in psutil.disk_partitions():
            if 'fixed' in part.opts or 'rw' in part.opts:
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    hw["storage"].append({
                        "device": part.device,
                        "mount": part.mountpoint,
                        "total_gb": round(usage.total / (1024**3), 2),
                        "used_gb": round(usage.used / (1024**3), 2),
                        "fstype": part.fstype
                    })
                except PermissionError:
                    continue

        # Windows-specific deep scan
        if platform.system() == "Windows":
            try:
                # System SKU / Model (Using systeminfo as fallback)
                try:
                    sku = subprocess.check_output("systeminfo /s localhost | findstr /B /C:\"System Model\"", shell=True).decode().split(':')[1].strip()
                except:
                    sku = subprocess.check_output("wmic computersystem get model", shell=True).decode().split('\n')[1].strip()
                hw["system"]["model"] = sku
                # GPU Check (NVIDIA focus)
                try:
                    gpu_info = subprocess.check_output("nvidia-smi --query-gpu=name,memory.total --format=csv,noheader", shell=True).decode().strip()
                    hw["system"]["gpu"] = gpu_info
                except:
                    hw["system"]["gpu"] = "Non-NVIDIA or Driver Missing"
            except:
                hw["system"]["model"] = f"Generic {platform.system()} Workstation"

        return hw

    def scan_software(self) -> Dict[str, Any]:
        """Map installed software and runtimes."""
        sw = {
            "runtimes": {},
            "applications": []
        }

        # Check common runtimes
        runtimes = ["python", "node", "rustc", "go", "docker"]
        for rt in runtimes:
            try:
                ver = subprocess.check_output(f"{rt} --version", shell=True, stderr=subprocess.STDOUT).decode().strip()
                sw["runtimes"][rt] = ver
            except:
                sw["runtimes"][rt] = "Not Detected"

        # Windows Packages (Abbreviated to avoid massive list)
        if platform.system() == "Windows":
            try:
                # Use Bypass and NoProfile to avoid interactive prompts
                cmd = "powershell -ExecutionPolicy Bypass -NoProfile \"Get-Package | Select-Object Name, Version -First 20 | ConvertTo-Json\""
                raw = subprocess.check_output(cmd, shell=True).decode()
                if raw.strip():
                    packages = json.loads(raw)
                    sw["applications"] = packages
            except:
                sw["applications"] = ["Scanner Offline"]

        return sw

    def index_data(self, root_paths: List[str], years: int = 3, max_depth: int = 3) -> Dict[str, Any]:
        """Recursive mapping of work history with depth limiting for speed."""
        cutoff_date = datetime.now() - timedelta(days=years * 365)
        data_stats = {
            "total_files": 0,
            "total_size_gb": 0.0,
            "modified_in_range": 0,
            "top_extensions": {}
        }
        
        # High-value targets
        targets = []
        for rp in root_paths:
            if rp == "C:\\":
                targets.extend([
                    "C:\\Users", 
                    "C:\\BIZRA-Dual-Agentic-system--main",
                    "C:\\BIZRA-NODE0",
                    "C:\\BIZRA-TaskMaster",
                    "C:\\BIZRA-DATA-LAKE"
                ])
            else:
                targets.append(rp)

        skip_dirs = {"Windows", "Program Files", "Program Files (x86)", "AppData", "node_modules", ".git", ".venv"}

        for root_path in targets:
            if not os.path.exists(root_path): continue
            
            base_sep_count = root_path.count(os.sep)
            
            for root, dirs, files in os.walk(root_path):
                # Depth control
                if root.count(os.sep) - base_sep_count > max_depth:
                    del dirs[:] # Stop recursing deeper
                    continue
                    
                dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith('.')]
                
                for file in files:
                    try:
                        file_path = os.path.join(root, file)
                        stat = os.lstat(file_path)
                        data_stats["total_files"] += 1
                        data_stats["total_size_gb"] += stat.st_size / (1024**3)
                        mtime = datetime.fromtimestamp(stat.st_mtime)
                        if mtime > cutoff_date:
                            data_stats["modified_in_range"] += 1
                        ext = os.path.splitext(file)[1].lower()
                        if ext:
                            data_stats["top_extensions"][ext] = data_stats["top_extensions"].get(ext, 0) + 1
                    except:
                        continue
                if data_stats["total_files"] > 100000: break

        data_stats["total_size_gb"] = round(data_stats["total_size_gb"], 2)
        return data_stats

    def perform_full_census(self) -> Dict[str, Any]:
        """Run all scanners and merge results."""
        wsl_path = r"\\wsl.localhost\Ubuntu\home"
        census = {
            "timestamp": self.timestamp,
            "hardware": self.scan_hardware(),
            "software": self.scan_software(),
            "data_universe": self.index_data(["C:\\", wsl_path], max_depth=4)
        }
        os.makedirs(os.path.dirname(self.inventory_path), exist_ok=True)
        with open(self.inventory_path, "w") as f:
            json.dump(census, f, indent=4)
        return census

if __name__ == "__main__":
    indexer = ResourceIndexer()
    results = indexer.perform_full_census()
    print(f"IndexComplete|Files:{results['data_universe']['total_files']}|Size:{results['data_universe']['total_size_gb']}GB")
