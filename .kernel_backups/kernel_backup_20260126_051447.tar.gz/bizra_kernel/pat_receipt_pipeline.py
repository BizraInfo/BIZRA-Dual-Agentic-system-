"""
PAT Production Receipt Pipeline - Evidence-First Receipt Generation System

Generates, validates, and persists all PAT-related receipts with full
integrity verification and evidence chain management.

BIZRA PAT System Component
Receipt Integrity: SHA-256 | Append-Only Storage
"""

import hashlib
import json
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import asyncio


class ReceiptType(Enum):
    """Types of PAT receipts."""
    PAT_ORCHESTRATION = "pat_orchestration"
    PAT_VALIDATION = "pat_validation"
    PAT_GATE = "pat_gate"
    PAT_CITATION = "pat_citation"
    PAT_NOVELTY = "pat_novelty"
    PAT_TELEMETRY = "pat_telemetry"
    PAT_DOMAIN = "pat_domain"
    PAT_PRACTITIONER = "pat_practitioner"
    PAT_RESPONSE = "pat_response"
    PAT_PEAK = "pat_peak"


class ReceiptStatus(Enum):
    """Receipt validation status."""
    VALID = "valid"
    PENDING = "pending"
    FAILED = "failed"
    CORRUPTED = "corrupted"


@dataclass
class ReceiptMetadata:
    """Metadata for receipt generation."""
    session_id: str
    timestamp: str = ""
    version: str = "1.0.0"
    system: str = "pat"
    node_id: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
        if not self.node_id:
            self.node_id = self._get_node_id()

    def _get_node_id(self) -> str:
        """Get or generate node identifier."""
        node_file = Path("bizra_network/node_id.txt")
        if node_file.exists():
            return node_file.read_text().strip()[:16]
        return hashlib.sha256(os.urandom(32)).hexdigest()[:16]


@dataclass
class PATReceipt:
    """
    PAT Evidence Receipt - Immutable proof of operation.

    All PAT operations emit receipts for:
    - Auditability
    - Evidence chains
    - Compliance verification
    - Performance tracking
    """
    receipt_id: str
    receipt_type: ReceiptType
    timestamp: str
    session_id: str
    operation: str
    status: ReceiptStatus
    data: Dict[str, Any]
    evidence_chain: List[str] = field(default_factory=list)
    integrity_hash: str = ""
    parent_receipt_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.integrity_hash:
            self.integrity_hash = self._compute_hash()

    def _compute_hash(self) -> str:
        """Compute SHA-256 integrity hash."""
        content = {
            "receipt_id": self.receipt_id,
            "receipt_type": self.receipt_type.value if isinstance(self.receipt_type, ReceiptType) else self.receipt_type,
            "timestamp": self.timestamp,
            "session_id": self.session_id,
            "operation": self.operation,
            "data": self.data,
            "evidence_chain": self.evidence_chain,
            "parent_receipt_id": self.parent_receipt_id,
        }
        return hashlib.sha256(
            json.dumps(content, sort_keys=True).encode()
        ).hexdigest()

    def verify(self) -> bool:
        """Verify receipt integrity."""
        expected_hash = self._compute_hash()
        return self.integrity_hash == expected_hash

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "receipt_id": self.receipt_id,
            "receipt_type": self.receipt_type.value if isinstance(self.receipt_type, ReceiptType) else self.receipt_type,
            "timestamp": self.timestamp,
            "session_id": self.session_id,
            "operation": self.operation,
            "status": self.status.value if isinstance(self.status, ReceiptStatus) else self.status,
            "data": self.data,
            "evidence_chain": self.evidence_chain,
            "integrity_hash": self.integrity_hash,
            "parent_receipt_id": self.parent_receipt_id,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PATReceipt":
        """Create receipt from dictionary."""
        return cls(
            receipt_id=data["receipt_id"],
            receipt_type=ReceiptType(data["receipt_type"]) if isinstance(data["receipt_type"], str) else data["receipt_type"],
            timestamp=data["timestamp"],
            session_id=data["session_id"],
            operation=data["operation"],
            status=ReceiptStatus(data["status"]) if isinstance(data["status"], str) else data["status"],
            data=data["data"],
            evidence_chain=data.get("evidence_chain", []),
            integrity_hash=data.get("integrity_hash", ""),
            parent_receipt_id=data.get("parent_receipt_id"),
            metadata=data.get("metadata", {}),
        )


class PATReceiptPipeline:
    """
    Production Receipt Pipeline for PAT System.

    Handles:
    - Receipt generation with unique IDs
    - Integrity hash computation
    - Evidence chain management
    - Persistent storage (append-only)
    - Chain validation
    - Prometheus metrics export
    """

    RECEIPT_DIR = "docs/evidence/receipts/pat"
    CHAIN_FILE = "docs/evidence/receipts/pat/evidence_chain.jsonl"

    def __init__(self, session_id: str, receipt_dir: Optional[str] = None):
        """Initialize receipt pipeline."""
        self.session_id = session_id
        self.receipt_dir = Path(receipt_dir or self.RECEIPT_DIR)
        self.receipt_dir.mkdir(parents=True, exist_ok=True)

        self.metadata = ReceiptMetadata(session_id=session_id)
        self._evidence_chain: List[str] = []
        self._receipts: List[PATReceipt] = []

        # Load existing chain if available
        self._load_chain()

    def _load_chain(self):
        """Load existing evidence chain."""
        chain_file = Path(self.CHAIN_FILE)
        if chain_file.exists():
            try:
                with open(chain_file, 'r') as f:
                    for line in f:
                        if line.strip():
                            data = json.loads(line)
                            self._evidence_chain.append(data.get('receipt_id', ''))
            except Exception:
                pass

    def _generate_receipt_id(self, receipt_type: ReceiptType) -> str:
        """Generate unique receipt ID."""
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S%f')[:18]
        type_prefix = receipt_type.value.replace('pat_', '')[:4]
        random_suffix = hashlib.sha256(os.urandom(8)).hexdigest()[:8]
        return f"pat-{type_prefix}-{timestamp}-{random_suffix}"

    def generate_receipt(
        self,
        receipt_type: ReceiptType,
        operation: str,
        data: Dict[str, Any],
        status: ReceiptStatus = ReceiptStatus.VALID,
        parent_receipt_id: Optional[str] = None,
    ) -> PATReceipt:
        """
        Generate a new PAT receipt.

        Args:
            receipt_type: Type of PAT receipt
            operation: Description of the operation
            data: Operation-specific data
            status: Receipt status
            parent_receipt_id: Optional parent receipt for chaining

        Returns:
            Generated PATReceipt
        """
        receipt_id = self._generate_receipt_id(receipt_type)

        # Build evidence chain
        evidence_chain = list(self._evidence_chain[-10:])  # Last 10 receipts
        if parent_receipt_id:
            evidence_chain.append(parent_receipt_id)

        receipt = PATReceipt(
            receipt_id=receipt_id,
            receipt_type=receipt_type,
            timestamp=datetime.now().isoformat(),
            session_id=self.session_id,
            operation=operation,
            status=status,
            data=data,
            evidence_chain=evidence_chain,
            parent_receipt_id=parent_receipt_id,
            metadata={
                "version": self.metadata.version,
                "system": self.metadata.system,
                "node_id": self.metadata.node_id,
            }
        )

        # Add to local chain
        self._evidence_chain.append(receipt_id)
        self._receipts.append(receipt)

        return receipt

    async def persist_receipt(self, receipt: PATReceipt) -> str:
        """
        Persist receipt to storage (append-only).

        Args:
            receipt: The receipt to persist

        Returns:
            Path to stored receipt
        """
        # Verify integrity before persisting
        if not receipt.verify():
            raise ValueError(f"Receipt {receipt.receipt_id} failed integrity check")

        # Generate filename
        date_prefix = receipt.timestamp[:10].replace('-', '')
        filename = f"{date_prefix}_{receipt.receipt_id}.json"
        filepath = self.receipt_dir / filename

        # Write receipt
        with open(filepath, 'w') as f:
            json.dump(receipt.to_dict(), f, indent=2)

        # Append to chain file
        chain_file = Path(self.CHAIN_FILE)
        chain_file.parent.mkdir(parents=True, exist_ok=True)
        with open(chain_file, 'a') as f:
            chain_entry = {
                "receipt_id": receipt.receipt_id,
                "receipt_type": receipt.receipt_type.value,
                "timestamp": receipt.timestamp,
                "integrity_hash": receipt.integrity_hash,
            }
            f.write(json.dumps(chain_entry) + "\n")

        return str(filepath)

    async def generate_and_persist(
        self,
        receipt_type: ReceiptType,
        operation: str,
        data: Dict[str, Any],
        status: ReceiptStatus = ReceiptStatus.VALID,
        parent_receipt_id: Optional[str] = None,
    ) -> PATReceipt:
        """Generate and immediately persist a receipt."""
        receipt = self.generate_receipt(
            receipt_type=receipt_type,
            operation=operation,
            data=data,
            status=status,
            parent_receipt_id=parent_receipt_id,
        )
        await self.persist_receipt(receipt)
        return receipt

    # Specialized receipt generators

    async def emit_orchestration_receipt(
        self,
        query: str,
        mode: str,
        snr_score: float,
        novelty_score: float,
        domain_count: int,
        gates_passed: int,
        gates_total: int,
        overall_pass: bool,
        processing_time_ms: float,
    ) -> PATReceipt:
        """Emit PAT orchestration receipt."""
        return await self.generate_and_persist(
            receipt_type=ReceiptType.PAT_ORCHESTRATION,
            operation="pat_peak_orchestration",
            data={
                "query_summary": query[:200] if query else "",
                "mode": mode,
                "scores": {
                    "snr": snr_score,
                    "novelty": novelty_score,
                },
                "domains": domain_count,
                "gates": {
                    "passed": gates_passed,
                    "total": gates_total,
                },
                "overall_pass": overall_pass,
                "processing_time_ms": processing_time_ms,
            },
            status=ReceiptStatus.VALID if overall_pass else ReceiptStatus.FAILED,
        )

    async def emit_gate_receipt(
        self,
        gate_id: str,
        gate_name: str,
        status: str,
        score: float,
        checks: List[str],
        corrections: List[str],
        parent_receipt_id: Optional[str] = None,
    ) -> PATReceipt:
        """Emit validation gate receipt."""
        return await self.generate_and_persist(
            receipt_type=ReceiptType.PAT_GATE,
            operation=f"gate_{gate_id}",
            data={
                "gate_id": gate_id,
                "gate_name": gate_name,
                "status": status,
                "score": score,
                "checks": checks,
                "corrections_applied": corrections,
            },
            status=ReceiptStatus.VALID if status in ["passed", "corrected"] else ReceiptStatus.FAILED,
            parent_receipt_id=parent_receipt_id,
        )

    async def emit_citation_receipt(
        self,
        total_citations: int,
        valid_citations: int,
        domains_covered: int,
        average_relevance: float,
        meets_requirements: bool,
        evidence_chain: List[str],
    ) -> PATReceipt:
        """Emit citation validation receipt."""
        return await self.generate_and_persist(
            receipt_type=ReceiptType.PAT_CITATION,
            operation="citation_validation",
            data={
                "total_citations": total_citations,
                "valid_citations": valid_citations,
                "validity_ratio": valid_citations / total_citations if total_citations > 0 else 0,
                "domains_covered": domains_covered,
                "average_relevance": average_relevance,
                "meets_requirements": meets_requirements,
                "citation_evidence": evidence_chain[:20],  # Limit to 20
            },
            status=ReceiptStatus.VALID if meets_requirements else ReceiptStatus.FAILED,
        )

    async def emit_novelty_receipt(
        self,
        original_novelty: float,
        boosted_novelty: float,
        boost_applied: bool,
        rare_paths_found: int,
        domains_involved: List[str],
    ) -> PATReceipt:
        """Emit novelty boost receipt."""
        return await self.generate_and_persist(
            receipt_type=ReceiptType.PAT_NOVELTY,
            operation="novelty_boost" if boost_applied else "novelty_check",
            data={
                "original_novelty": original_novelty,
                "boosted_novelty": boosted_novelty,
                "boost_applied": boost_applied,
                "boost_delta": boosted_novelty - original_novelty,
                "rare_paths_found": rare_paths_found,
                "domains_involved": domains_involved,
                "threshold": 0.75,
                "meets_threshold": boosted_novelty >= 0.75,
            },
            status=ReceiptStatus.VALID if boosted_novelty >= 0.75 else ReceiptStatus.FAILED,
        )

    async def emit_telemetry_receipt(
        self,
        snr_average: float,
        snr_min: float,
        snr_max: float,
        novelty_average: float,
        domains_average: float,
        window_seconds: int,
        sample_count: int,
    ) -> PATReceipt:
        """Emit telemetry snapshot receipt."""
        return await self.generate_and_persist(
            receipt_type=ReceiptType.PAT_TELEMETRY,
            operation="telemetry_snapshot",
            data={
                "snr": {
                    "average": snr_average,
                    "min": snr_min,
                    "max": snr_max,
                },
                "novelty_average": novelty_average,
                "domains_average": domains_average,
                "window_seconds": window_seconds,
                "sample_count": sample_count,
                "timestamp": datetime.now().isoformat(),
            },
            status=ReceiptStatus.VALID,
        )

    async def emit_peak_receipt(
        self,
        mode: str,
        thresholds: Dict[str, float],
        scores: Dict[str, float],
        gates: Dict[str, str],
        sections: Dict[str, bool],
        overall_pass: bool,
    ) -> PATReceipt:
        """Emit complete PAT Peak receipt."""
        return await self.generate_and_persist(
            receipt_type=ReceiptType.PAT_PEAK,
            operation="pat_peak_execution",
            data={
                "mode": mode,
                "thresholds": thresholds,
                "scores": scores,
                "gates": gates,
                "response_sections": sections,
                "overall_pass": overall_pass,
                "all_sections_present": all(sections.values()),
                "all_gates_passed": all(s in ["passed", "corrected"] for s in gates.values()),
            },
            status=ReceiptStatus.VALID if overall_pass else ReceiptStatus.FAILED,
        )

    # Chain validation

    def validate_chain(self) -> Dict[str, Any]:
        """Validate the entire evidence chain."""
        valid_count = 0
        invalid_count = 0
        errors = []

        for receipt in self._receipts:
            if receipt.verify():
                valid_count += 1
            else:
                invalid_count += 1
                errors.append(f"Receipt {receipt.receipt_id} failed integrity check")

        return {
            "total_receipts": len(self._receipts),
            "valid": valid_count,
            "invalid": invalid_count,
            "chain_length": len(self._evidence_chain),
            "errors": errors,
            "is_valid": invalid_count == 0,
        }

    def get_chain_summary(self) -> Dict[str, Any]:
        """Get summary of the evidence chain."""
        type_counts = {}
        status_counts = {}

        for receipt in self._receipts:
            rtype = receipt.receipt_type.value if isinstance(receipt.receipt_type, ReceiptType) else str(receipt.receipt_type)
            type_counts[rtype] = type_counts.get(rtype, 0) + 1

            rstatus = receipt.status.value if isinstance(receipt.status, ReceiptStatus) else str(receipt.status)
            status_counts[rstatus] = status_counts.get(rstatus, 0) + 1

        return {
            "session_id": self.session_id,
            "total_receipts": len(self._receipts),
            "chain_length": len(self._evidence_chain),
            "by_type": type_counts,
            "by_status": status_counts,
            "first_receipt": self._evidence_chain[0] if self._evidence_chain else None,
            "last_receipt": self._evidence_chain[-1] if self._evidence_chain else None,
        }

    def export_prometheus_metrics(self) -> str:
        """Export receipt metrics in Prometheus format."""
        lines = [
            "# HELP pat_receipts_total Total PAT receipts generated",
            "# TYPE pat_receipts_total counter",
        ]

        type_counts = {}
        status_counts = {}

        for receipt in self._receipts:
            rtype = receipt.receipt_type.value if isinstance(receipt.receipt_type, ReceiptType) else str(receipt.receipt_type)
            type_counts[rtype] = type_counts.get(rtype, 0) + 1

            rstatus = receipt.status.value if isinstance(receipt.status, ReceiptStatus) else str(receipt.status)
            status_counts[rstatus] = status_counts.get(rstatus, 0) + 1

        for rtype, count in type_counts.items():
            lines.append(f'pat_receipts_total{{type="{rtype}"}} {count}')

        lines.extend([
            "",
            "# HELP pat_receipt_status_total PAT receipts by status",
            "# TYPE pat_receipt_status_total counter",
        ])

        for status, count in status_counts.items():
            lines.append(f'pat_receipt_status_total{{status="{status}"}} {count}')

        lines.extend([
            "",
            f"# HELP pat_evidence_chain_length Current evidence chain length",
            f"# TYPE pat_evidence_chain_length gauge",
            f"pat_evidence_chain_length {len(self._evidence_chain)}",
        ])

        return "\n".join(lines)


# Global pipeline instance management
_pipelines: Dict[str, PATReceiptPipeline] = {}


def get_receipt_pipeline(session_id: str) -> PATReceiptPipeline:
    """Get or create receipt pipeline for session."""
    if session_id not in _pipelines:
        _pipelines[session_id] = PATReceiptPipeline(session_id)
    return _pipelines[session_id]


async def emit_pat_receipt(
    session_id: str,
    receipt_type: ReceiptType,
    operation: str,
    data: Dict[str, Any],
    status: ReceiptStatus = ReceiptStatus.VALID,
) -> PATReceipt:
    """Convenience function to emit a PAT receipt."""
    pipeline = get_receipt_pipeline(session_id)
    return await pipeline.generate_and_persist(
        receipt_type=receipt_type,
        operation=operation,
        data=data,
        status=status,
    )


if __name__ == "__main__":
    import asyncio

    async def test_pipeline():
        print("=== PAT Receipt Pipeline Test ===\n")

        pipeline = PATReceiptPipeline("test-session-001")

        # Test orchestration receipt
        receipt1 = await pipeline.emit_orchestration_receipt(
            query="Test cross-domain analysis query",
            mode="STANDARD",
            snr_score=0.985,
            novelty_score=0.82,
            domain_count=4,
            gates_passed=5,
            gates_total=5,
            overall_pass=True,
            processing_time_ms=1250.5,
        )
        print(f"1. Orchestration Receipt: {receipt1.receipt_id}")
        print(f"   Integrity: {'VALID' if receipt1.verify() else 'INVALID'}")

        # Test gate receipt
        receipt2 = await pipeline.emit_gate_receipt(
            gate_id="gate_3",
            gate_name="Post-Synthesis Validation",
            status="passed",
            score=0.98,
            checks=["snr_check", "novelty_check", "coverage_check"],
            corrections=[],
            parent_receipt_id=receipt1.receipt_id,
        )
        print(f"2. Gate Receipt: {receipt2.receipt_id}")
        print(f"   Parent: {receipt2.parent_receipt_id}")

        # Test citation receipt
        receipt3 = await pipeline.emit_citation_receipt(
            total_citations=12,
            valid_citations=10,
            domains_covered=4,
            average_relevance=0.85,
            meets_requirements=True,
            evidence_chain=["cite-001", "cite-002", "cite-003"],
        )
        print(f"3. Citation Receipt: {receipt3.receipt_id}")

        # Test novelty receipt
        receipt4 = await pipeline.emit_novelty_receipt(
            original_novelty=0.68,
            boosted_novelty=0.82,
            boost_applied=True,
            rare_paths_found=3,
            domains_involved=["mathematics", "philosophy", "computer_science"],
        )
        print(f"4. Novelty Receipt: {receipt4.receipt_id}")

        # Validate chain
        print("\n=== Chain Validation ===")
        validation = pipeline.validate_chain()
        print(f"Total Receipts: {validation['total_receipts']}")
        print(f"Valid: {validation['valid']}")
        print(f"Chain Valid: {validation['is_valid']}")

        # Get summary
        print("\n=== Chain Summary ===")
        summary = pipeline.get_chain_summary()
        print(f"Session: {summary['session_id']}")
        print(f"By Type: {summary['by_type']}")
        print(f"By Status: {summary['by_status']}")

        # Export metrics
        print("\n=== Prometheus Metrics ===")
        metrics = pipeline.export_prometheus_metrics()
        print(metrics)

    asyncio.run(test_pipeline())
