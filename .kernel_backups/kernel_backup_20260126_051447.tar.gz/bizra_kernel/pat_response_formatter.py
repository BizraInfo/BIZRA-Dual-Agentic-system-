"""
PAT Response Formatter - 6-Section Structure Enforcement
========================================================
Enforces the mandatory 6-section response structure for PAT outputs.

Sections:
1. Executive Synthesis (max 5 bullets, claim-tagged)
2. Domain Cross-Pollination Map
3. Elite Practitioner Anchoring
4. Novel Insight Synthesis
5. Validation Evidence Trail
6. Actionable Recommendations
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any
import re


@dataclass
class ClaimTagged:
    """A claim with its tag and content."""
    tag: str
    content: str
    evidence: Optional[str] = None

    def format(self) -> str:
        """Format as markdown with tag."""
        evidence_suffix = f" (evidence: {self.evidence})" if self.evidence else ""
        return f"[{self.tag}] {self.content}{evidence_suffix}"


@dataclass
class DomainConnection:
    """A connection between domains."""
    source: str
    target: str
    synthesis_point: str
    connection_type: str


@dataclass
class PractitionerEntry:
    """A practitioner entry for the anchoring section."""
    name: str
    domain: str
    tier: str
    relevance: float
    specializations: List[str]


@dataclass
class ResponseSection:
    """A section of the PAT response."""
    id: str
    name: str
    content: str
    is_valid: bool = True
    validation_errors: List[str] = field(default_factory=list)


@dataclass
class PATFormattedResponse:
    """Complete formatted PAT response."""
    sections: Dict[str, ResponseSection]
    raw_markdown: str
    is_valid: bool
    validation_errors: List[str]
    claim_tag_count: Dict[str, int]
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> dict:
        return {
            "sections": {k: {"content": v.content, "valid": v.is_valid}
                        for k, v in self.sections.items()},
            "is_valid": self.is_valid,
            "validation_errors": self.validation_errors,
            "claim_tag_count": self.claim_tag_count,
            "timestamp": self.timestamp,
        }


class PATResponseFormatter:
    """
    Formats and validates PAT responses according to the 6-section structure.

    Enforces:
    - All 6 sections present
    - Claims are tagged
    - Evidence trail complete
    """

    REQUIRED_SECTIONS = [
        ("executive_synthesis", "Executive Synthesis"),
        ("domain_cross_pollination_map", "Domain Cross-Pollination Map"),
        ("elite_practitioner_anchoring", "Elite Practitioner Anchoring"),
        ("novel_insight_synthesis", "Novel Insight Synthesis"),
        ("validation_evidence_trail", "Validation Evidence Trail"),
        ("actionable_recommendations", "Actionable Recommendations"),
    ]

    CLAIM_TAGS = ["MEASURED", "IMPLEMENTED", "DERIVED", "DESIGNED",
                  "TARGET", "HYPOTHESIS", "METAPHOR", "NOVEL", "CROSS_DOMAIN"]

    MAX_EXECUTIVE_BULLETS = 5

    def __init__(self):
        """Initialize formatter."""
        self.templates = self._load_templates()

    def _load_templates(self) -> Dict[str, str]:
        """Load section templates."""
        return {
            "executive_synthesis": """## Executive Synthesis

{bullets}
""",
            "domain_cross_pollination_map": """## Domain Cross-Pollination Map

**Domains Engaged:** {domains}

**Cross-Domain Connections:**
{connections}

**Synthesis Points:**
{synthesis}
""",
            "elite_practitioner_anchoring": """## Elite Practitioner Anchoring

| Domain | Practitioner | Tier | Relevance | Key Contributions |
| ------ | ------------ | ---- | --------- | ----------------- |
{practitioner_rows}
""",
            "novel_insight_synthesis": """## Novel Insight Synthesis

**Novelty Score:** {novelty_score:.3f}

{insight_content}
""",
            "validation_evidence_trail": """## Validation Evidence Trail

| Gate | Status | Score | Checks |
| ---- | ------ | ----- | ------ |
{gate_rows}

**Overall Scores:**
- SNR: {snr_score:.3f}
- Novelty: {novelty_score:.3f}
- Ihsān: {ihsan_score:.3f}

**Receipt ID:** `{receipt_id}`
""",
            "actionable_recommendations": """## Actionable Recommendations

### What We Know
{what_we_know}

### What We Assume
{what_we_assume}

### What We Should Test Next
{what_we_test}
""",
        }

    def format_executive_synthesis(
        self,
        claims: List[ClaimTagged]
    ) -> ResponseSection:
        """Format the executive synthesis section."""
        if len(claims) > self.MAX_EXECUTIVE_BULLETS:
            claims = claims[:self.MAX_EXECUTIVE_BULLETS]

        bullets = "\n".join([f"- {claim.format()}" for claim in claims])

        content = self.templates["executive_synthesis"].format(bullets=bullets)

        validation_errors = []
        if len(claims) == 0:
            validation_errors.append("Executive synthesis has no claims")
        if not any(c.tag in self.CLAIM_TAGS for c in claims):
            validation_errors.append("Claims not properly tagged")

        return ResponseSection(
            id="executive_synthesis",
            name="Executive Synthesis",
            content=content,
            is_valid=len(validation_errors) == 0,
            validation_errors=validation_errors,
        )

    def format_domain_map(
        self,
        domains: List[str],
        connections: List[DomainConnection],
        synthesis_points: List[str]
    ) -> ResponseSection:
        """Format the domain cross-pollination map section."""
        domains_str = ", ".join(domains)

        connections_str = "\n".join([
            f"- **{c.source}** → **{c.target}**: {c.synthesis_point} ({c.connection_type})"
            for c in connections
        ])

        synthesis_str = "\n".join([f"- {s}" for s in synthesis_points])

        content = self.templates["domain_cross_pollination_map"].format(
            domains=domains_str,
            connections=connections_str or "- No cross-domain connections identified",
            synthesis=synthesis_str or "- No synthesis points identified",
        )

        validation_errors = []
        if len(domains) < 3:
            validation_errors.append(f"Only {len(domains)} domains, need 3+")

        return ResponseSection(
            id="domain_cross_pollination_map",
            name="Domain Cross-Pollination Map",
            content=content,
            is_valid=len(validation_errors) == 0,
            validation_errors=validation_errors,
        )

    def format_practitioner_anchoring(
        self,
        practitioners: Dict[str, List[PractitionerEntry]]
    ) -> ResponseSection:
        """Format the elite practitioner anchoring section."""
        rows = []
        for domain, entries in practitioners.items():
            for p in entries:
                specs = ", ".join(p.specializations[:2])
                rows.append(
                    f"| {domain} | {p.name} | {p.tier} | {p.relevance:.2f} | {specs} |"
                )

        practitioner_rows = "\n".join(rows) if rows else "| - | - | - | - | - |"

        content = self.templates["elite_practitioner_anchoring"].format(
            practitioner_rows=practitioner_rows
        )

        validation_errors = []
        total_practitioners = sum(len(p) for p in practitioners.values())
        if total_practitioners < 9:  # 3 domains * 3 practitioners
            validation_errors.append(
                f"Only {total_practitioners} practitioners, need 9+ (3 per domain)"
            )

        return ResponseSection(
            id="elite_practitioner_anchoring",
            name="Elite Practitioner Anchoring",
            content=content,
            is_valid=len(validation_errors) == 0,
            validation_errors=validation_errors,
        )

    def format_novel_insight(
        self,
        novelty_score: float,
        insight_content: str
    ) -> ResponseSection:
        """Format the novel insight synthesis section."""
        content = self.templates["novel_insight_synthesis"].format(
            novelty_score=novelty_score,
            insight_content=insight_content,
        )

        validation_errors = []
        if novelty_score < 0.75:
            validation_errors.append(f"Novelty {novelty_score:.3f} below 0.75 threshold")

        return ResponseSection(
            id="novel_insight_synthesis",
            name="Novel Insight Synthesis",
            content=content,
            is_valid=len(validation_errors) == 0,
            validation_errors=validation_errors,
        )

    def format_validation_evidence(
        self,
        gate_results: List[Dict[str, Any]],
        snr_score: float,
        novelty_score: float,
        ihsan_score: float,
        receipt_id: str
    ) -> ResponseSection:
        """Format the validation evidence trail section."""
        gate_rows = []
        for g in gate_results:
            checks = ", ".join(g.get("checks_passed", []))[:30]
            gate_rows.append(
                f"| {g.get('gate_name', 'Unknown')[:15]} | "
                f"{g.get('status', 'unknown')} | "
                f"{g.get('score', 0):.2f} | {checks} |"
            )

        gate_rows_str = "\n".join(gate_rows) if gate_rows else "| - | - | - | - |"

        content = self.templates["validation_evidence_trail"].format(
            gate_rows=gate_rows_str,
            snr_score=snr_score,
            novelty_score=novelty_score,
            ihsan_score=ihsan_score,
            receipt_id=receipt_id,
        )

        validation_errors = []
        if snr_score < 0.98:
            validation_errors.append(f"SNR {snr_score:.3f} below 0.98 threshold")
        if novelty_score < 0.75:
            validation_errors.append(f"Novelty {novelty_score:.3f} below 0.75 threshold")

        return ResponseSection(
            id="validation_evidence_trail",
            name="Validation Evidence Trail",
            content=content,
            is_valid=len(validation_errors) == 0,
            validation_errors=validation_errors,
        )

    def format_recommendations(
        self,
        what_we_know: List[str],
        what_we_assume: List[str],
        what_we_test: List[str]
    ) -> ResponseSection:
        """Format the actionable recommendations section."""
        know_str = "\n".join([f"- {k}" for k in what_we_know]) or "- TBD"
        assume_str = "\n".join([f"- {a}" for a in what_we_assume]) or "- TBD"
        test_str = "\n".join([f"- {t}" for t in what_we_test]) or "- TBD"

        content = self.templates["actionable_recommendations"].format(
            what_we_know=know_str,
            what_we_assume=assume_str,
            what_we_test=test_str,
        )

        return ResponseSection(
            id="actionable_recommendations",
            name="Actionable Recommendations",
            content=content,
            is_valid=True,
            validation_errors=[],
        )

    def format_complete_response(
        self,
        executive_claims: List[ClaimTagged],
        domains: List[str],
        connections: List[DomainConnection],
        synthesis_points: List[str],
        practitioners: Dict[str, List[PractitionerEntry]],
        novelty_score: float,
        insight_content: str,
        gate_results: List[Dict[str, Any]],
        snr_score: float,
        ihsan_score: float,
        receipt_id: str,
        what_we_know: List[str],
        what_we_assume: List[str],
        what_we_test: List[str],
    ) -> PATFormattedResponse:
        """
        Format a complete PAT response with all 6 sections.

        Returns:
            PATFormattedResponse with all sections and validation status
        """
        sections = {}

        # Section 1: Executive Synthesis
        sections["executive_synthesis"] = self.format_executive_synthesis(executive_claims)

        # Section 2: Domain Cross-Pollination Map
        sections["domain_cross_pollination_map"] = self.format_domain_map(
            domains, connections, synthesis_points
        )

        # Section 3: Elite Practitioner Anchoring
        sections["elite_practitioner_anchoring"] = self.format_practitioner_anchoring(
            practitioners
        )

        # Section 4: Novel Insight Synthesis
        sections["novel_insight_synthesis"] = self.format_novel_insight(
            novelty_score, insight_content
        )

        # Section 5: Validation Evidence Trail
        sections["validation_evidence_trail"] = self.format_validation_evidence(
            gate_results, snr_score, novelty_score, ihsan_score, receipt_id
        )

        # Section 6: Actionable Recommendations
        sections["actionable_recommendations"] = self.format_recommendations(
            what_we_know, what_we_assume, what_we_test
        )

        # Combine into full markdown
        raw_markdown = "\n".join([s.content for s in sections.values()])

        # Collect validation errors
        all_errors = []
        for section in sections.values():
            all_errors.extend(section.validation_errors)

        # Count claim tags
        claim_counts = self._count_claim_tags(raw_markdown)

        return PATFormattedResponse(
            sections=sections,
            raw_markdown=raw_markdown,
            is_valid=len(all_errors) == 0,
            validation_errors=all_errors,
            claim_tag_count=claim_counts,
        )

    def _count_claim_tags(self, content: str) -> Dict[str, int]:
        """Count claim tag occurrences."""
        return {
            tag: len(re.findall(rf'\[{tag}\]', content, re.IGNORECASE))
            for tag in self.CLAIM_TAGS
        }

    def validate_response(self, content: str) -> Dict[str, Any]:
        """
        Validate an existing response against PAT structure requirements.

        Args:
            content: Response content to validate

        Returns:
            Validation result with section status and errors
        """
        errors = []
        section_status = {}

        # Check for each required section
        for section_id, section_name in self.REQUIRED_SECTIONS:
            # Look for section header
            pattern = rf'##\s*{re.escape(section_name)}'
            if re.search(pattern, content, re.IGNORECASE):
                section_status[section_id] = "present"
            else:
                section_status[section_id] = "missing"
                errors.append(f"Missing section: {section_name}")

        # Check for claim tags
        has_tags = any(f"[{tag}]" in content.upper() for tag in self.CLAIM_TAGS)
        if not has_tags:
            errors.append("No claim tags found")

        # Check for evidence trail elements
        if "receipt_id" not in content.lower() and "receipt" not in content.lower():
            errors.append("No receipt ID in evidence trail")

        return {
            "is_valid": len(errors) == 0,
            "section_status": section_status,
            "validation_errors": errors,
            "claim_tag_count": self._count_claim_tags(content),
            "sections_present": sum(1 for s in section_status.values() if s == "present"),
            "sections_required": len(self.REQUIRED_SECTIONS),
        }

    def extract_sections(self, content: str) -> Dict[str, str]:
        """
        Extract sections from a formatted response.

        Args:
            content: Full response content

        Returns:
            Dict mapping section_id to section content
        """
        sections = {}

        for section_id, section_name in self.REQUIRED_SECTIONS:
            pattern = rf'##\s*{re.escape(section_name)}(.*?)(?=##|$)'
            match = re.search(pattern, content, re.IGNORECASE | re.DOTALL)
            if match:
                sections[section_id] = match.group(1).strip()
            else:
                sections[section_id] = ""

        return sections


if __name__ == "__main__":
    # Test the formatter
    formatter = PATResponseFormatter()

    # Create test data
    claims = [
        ClaimTagged("MEASURED", "SNR achieved 0.98 in validation tests", "gate_3"),
        ClaimTagged("IMPLEMENTED", "5-gate validation system operational"),
        ClaimTagged("NOVEL", "Cross-domain synthesis reveals new optimization path"),
    ]

    domains = ["mathematics", "computer_science", "philosophy"]

    connections = [
        DomainConnection("mathematics", "computer_science", "Formal proofs enable verification", "derivation"),
        DomainConnection("philosophy", "computer_science", "Ethics guides AI alignment", "application"),
    ]

    practitioners = {
        "mathematics": [
            PractitionerEntry("Terence Tao", "mathematics", "top_1%", 0.95, ["analysis", "primes"]),
        ],
        "computer_science": [
            PractitionerEntry("Leslie Lamport", "computer_science", "top_1%", 0.92, ["distributed"]),
        ],
        "philosophy": [
            PractitionerEntry("Derek Parfit", "philosophy", "top_1%", 0.88, ["ethics"]),
        ],
    }

    response = formatter.format_complete_response(
        executive_claims=claims,
        domains=domains,
        connections=connections,
        synthesis_points=["Mathematics enables formal verification of AI systems"],
        practitioners=practitioners,
        novelty_score=0.82,
        insight_content="The synthesis reveals that formal methods from mathematics...",
        gate_results=[{"gate_name": "Gate 1", "status": "passed", "score": 0.95, "checks_passed": ["domains"]}],
        snr_score=0.98,
        ihsan_score=0.96,
        receipt_id="test-receipt-001",
        what_we_know=["5-gate validation works"],
        what_we_assume=["Cross-domain synthesis improves quality"],
        what_we_test=["Long-term stability of novelty detection"],
    )

    print("Formatted Response:")
    print("=" * 60)
    print(response.raw_markdown)
    print("=" * 60)
    print(f"Valid: {response.is_valid}")
    print(f"Errors: {response.validation_errors}")
    print(f"Claim tags: {response.claim_tag_count}")
