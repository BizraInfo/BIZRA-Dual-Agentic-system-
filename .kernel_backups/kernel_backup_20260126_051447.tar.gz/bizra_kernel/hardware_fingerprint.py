"""
BIZRA Hardware Fingerprint Generator
=====================================
Creates unique SHA-256 fingerprint from hardware identifiers.
This fingerprint provides SUPPORTING EVIDENCE for Node0 identity.

IMPORTANT: The TRUE Node0 identity is the Ed25519 PUBLIC KEY.
Hardware fingerprint provides:
- Proof-of-location (this specific machine)
- Anomaly detection (hardware changes)
- Supporting evidence for the cryptographic identity

The MSI Titan GT77 HX IS Node0 - not just running BIZRA, but CLAIMED by BIZRA.

Trust Model:
- Node0 identity = Ed25519 public key (from node0_identity.py)
- Hardware covenant = proof-of-location + anomaly detector
- Genesis signature = cryptographic proof of origin

Usage:
    from bizra_kernel.hardware_fingerprint import generate_fingerprint
    fp = generate_fingerprint()
    print(fp["fingerprint"])  # SHA-256 hash (supporting evidence)
"""

import hashlib
import platform
import subprocess
import re
import socket
import uuid
import logging
from datetime import datetime, timezone
from typing import Dict, Optional, List, Any

logger = logging.getLogger(__name__)


def _run_command(command: List[str], shell: bool = False) -> str:
    """Run a command and return output, or empty string on failure."""
    try:
        if shell:
            result = subprocess.run(
                command[0] if len(command) == 1 else " ".join(command),
                shell=True,
                capture_output=True,
                text=True,
                timeout=10
            )
        else:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=10
            )
        return result.stdout.strip() if result.returncode == 0 else ""
    except Exception as e:
        logger.debug(f"Command failed: {command} - {e}")
        return ""


def get_cpu_id() -> str:
    """
    Get CPU identifier (model + processor ID).

    Windows: wmic cpu get processorid, name
    Linux: /proc/cpuinfo
    """
    system = platform.system()

    if system == "Windows":
        # Get processor ID
        proc_id = _run_command(["wmic", "cpu", "get", "processorid"])
        proc_id = proc_id.replace("ProcessorId", "").strip().split("\n")[0].strip()

        # Get CPU name
        cpu_name = _run_command(["wmic", "cpu", "get", "name"])
        cpu_name = cpu_name.replace("Name", "").strip().split("\n")[0].strip()

        return f"{cpu_name}|{proc_id}" if proc_id else cpu_name

    elif system == "Linux":
        # Check if running under WSL
        if "microsoft" in platform.release().lower():
            # WSL - try PowerShell route
            ps_cmd = "powershell.exe -Command \"Get-WmiObject Win32_Processor | Select-Object -ExpandProperty ProcessorId\""
            proc_id = _run_command([ps_cmd], shell=True)
            if proc_id:
                ps_name = "powershell.exe -Command \"Get-WmiObject Win32_Processor | Select-Object -ExpandProperty Name\""
                cpu_name = _run_command([ps_name], shell=True)
                return f"{cpu_name}|{proc_id}" if cpu_name else proc_id

        # Standard Linux
        try:
            with open("/proc/cpuinfo", "r") as f:
                cpuinfo = f.read()

            model = ""
            for line in cpuinfo.split("\n"):
                if "model name" in line.lower():
                    model = line.split(":")[1].strip()
                    break

            return model or platform.processor()
        except Exception:
            return platform.processor()

    return platform.processor()


def get_gpu_id() -> str:
    """
    Get GPU identifier (model + VRAM).

    Uses nvidia-smi for NVIDIA GPUs.
    """
    # Try nvidia-smi first
    nvidia_output = _run_command(
        ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"]
    )
    if nvidia_output:
        return nvidia_output.replace("\n", "|")

    # Try Windows WMI
    system = platform.system()
    if system == "Windows":
        gpu_info = _run_command(["wmic", "path", "win32_videocontroller", "get", "name"])
        gpu_info = gpu_info.replace("Name", "").strip()
        if gpu_info:
            return gpu_info.split("\n")[0].strip()

    # Try WSL PowerShell
    if "microsoft" in platform.release().lower():
        ps_cmd = "powershell.exe -Command \"Get-WmiObject Win32_VideoController | Select-Object -ExpandProperty Name\""
        gpu_info = _run_command([ps_cmd], shell=True)
        if gpu_info:
            return gpu_info.strip()

    return "unknown_gpu"


def get_ram_signature() -> str:
    """
    Get RAM configuration signature.

    Format: {total_gb}GB|{module_count}modules|{speed}MHz
    """
    system = platform.system()

    if system == "Windows":
        # Get total RAM
        total = _run_command(["wmic", "computersystem", "get", "totalphysicalmemory"])
        total = total.replace("TotalPhysicalMemory", "").strip().split("\n")[0].strip()

        try:
            total_gb = int(int(total) / (1024**3))
        except Exception:
            total_gb = 0

        # Get module info
        speed = _run_command(["wmic", "memorychip", "get", "speed"])
        speeds = [s.strip() for s in speed.replace("Speed", "").strip().split("\n") if s.strip()]
        module_count = len(speeds)
        avg_speed = int(sum(int(s) for s in speeds if s.isdigit()) / max(len(speeds), 1)) if speeds else 0

        return f"{total_gb}GB|{module_count}modules|{avg_speed}MHz"

    elif system == "Linux":
        if "microsoft" in platform.release().lower():
            # WSL
            ps_total = "powershell.exe -Command \"(Get-WmiObject Win32_ComputerSystem).TotalPhysicalMemory\""
            total = _run_command([ps_total], shell=True)
            try:
                total_gb = int(int(total.strip()) / (1024**3))
            except Exception:
                total_gb = 0
            return f"{total_gb}GB|WSL"

        # Standard Linux
        try:
            with open("/proc/meminfo", "r") as f:
                meminfo = f.read()

            for line in meminfo.split("\n"):
                if "MemTotal" in line:
                    mem_kb = int(line.split()[1])
                    total_gb = mem_kb // (1024**2)
                    return f"{total_gb}GB"
        except Exception:
            pass

    return "unknown_ram"


def get_mac_address() -> str:
    """
    Get primary network MAC address.

    Returns the first non-loopback MAC address found.
    """
    # Method 1: uuid.getnode() - works cross-platform
    mac = uuid.getnode()
    mac_str = ':'.join(('%012x' % mac)[i:i+2] for i in range(0, 12, 2))

    # Verify it's a real MAC (not randomly generated)
    if (mac >> 40) % 2:
        # Bit is set - might be random, try other methods
        system = platform.system()

        if system == "Windows":
            output = _run_command(["getmac", "/fo", "csv", "/nh"])
            if output:
                # Parse first MAC from output
                match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', output)
                if match:
                    return match.group(0)

        elif system == "Linux":
            # Try ip link
            output = _run_command(["ip", "link"])
            if output:
                match = re.search(r'link/ether ([0-9a-f:]{17})', output)
                if match:
                    return match.group(1)

    return mac_str


def get_disk_serial() -> str:
    """
    Get primary disk serial number (optional, for enhanced fingerprinting).
    """
    system = platform.system()

    if system == "Windows":
        output = _run_command(["wmic", "diskdrive", "get", "serialnumber"])
        serial = output.replace("SerialNumber", "").strip().split("\n")[0].strip()
        return serial if serial else "unknown"

    elif system == "Linux":
        if "microsoft" in platform.release().lower():
            ps_cmd = "powershell.exe -Command \"Get-WmiObject Win32_DiskDrive | Select-Object -First 1 -ExpandProperty SerialNumber\""
            serial = _run_command([ps_cmd], shell=True)
            return serial.strip() if serial else "wsl_disk"

        # Try lsblk
        output = _run_command(["lsblk", "-o", "SERIAL", "-n"])
        if output:
            serials = [s.strip() for s in output.split("\n") if s.strip()]
            return serials[0] if serials else "unknown"

    return "unknown"


def get_hostname() -> str:
    """Get the system hostname."""
    return socket.gethostname()


def generate_fingerprint(include_disk: bool = False) -> Dict[str, Any]:
    """
    Generate complete hardware fingerprint with TIERED COVENANT structure.

    The tiered approach prevents accidental self-exile of Node0:
    - Tier 1 (Root): CPU, GPU, Platform - STRICT, hard fail on mismatch
    - Tier 2 (Mutable): RAM, Storage, MAC - WARN + require attestation
    - Tier 3 (Contextual): BIOS, OS, WSL - LOG ONLY

    Args:
        include_disk: Include disk serial in tier_2 (more unique but changes if disk is replaced)

    Returns:
        Dict containing:
        - fingerprint: SHA-256 hash of tier_1 (immutable root)
        - tiered_covenant: All three tiers with individual hashes
        - generated_at: ISO timestamp
        - platform_info: Platform details
    """
    logger.info("Generating tiered hardware covenant...")

    # Tier 1: Root (STRICT - hard fail on mismatch)
    # These components define the physical identity of Node0
    tier_1_root = {
        "cpu_fingerprint": get_cpu_id(),
        "gpu_fingerprint": get_gpu_id(),
        "platform_signature": f"{platform.system()}-{platform.machine()}",
    }

    # Tier 2: Mutable (WARN + require attestation)
    # These can change with upgrades but should be monitored
    tier_2_mutable = {
        "ram_signature": get_ram_signature(),
        "mac_address": get_mac_address(),
        "hostname": get_hostname(),
    }

    if include_disk:
        tier_2_mutable["storage_signature"] = get_disk_serial()

    # Tier 3: Contextual (LOG ONLY)
    # Environmental context that may vary
    tier_3_contextual = {
        "os_fingerprint": f"{platform.system()}-{platform.release()}",
        "os_version": platform.version(),
        "processor_arch": platform.processor(),
        "wsl_context": "true" if "microsoft" in platform.release().lower() else "false",
    }

    # Platform info (reference only, not hashed)
    platform_info = {
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
    }

    # Generate tier-specific hashes
    def hash_tier(tier_data: Dict[str, str]) -> str:
        canonical = "|".join(f"{k}:{v}" for k, v in sorted(tier_data.items()))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    tier_1_hash = hash_tier(tier_1_root)
    tier_2_hash = hash_tier(tier_2_mutable)
    tier_3_hash = hash_tier(tier_3_contextual)

    # The ROOT fingerprint (tier_1) is the primary identity
    fingerprint = tier_1_hash

    logger.info(f"Root fingerprint (tier_1): {fingerprint[:16]}...")

    return {
        "fingerprint": fingerprint,  # Primary identity = tier_1 hash
        "tiered_covenant": {
            "tier_1_root": {
                "components": tier_1_root,
                "hash": tier_1_hash,
                "strict": True,
                "on_mismatch": "HARD_FAIL",
            },
            "tier_2_mutable": {
                "components": tier_2_mutable,
                "hash": tier_2_hash,
                "strict": False,
                "on_mismatch": "WARN_REQUIRE_ATTESTATION",
            },
            "tier_3_contextual": {
                "components": tier_3_contextual,
                "hash": tier_3_hash,
                "strict": False,
                "on_mismatch": "LOG_ONLY",
            },
        },
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "platform_info": platform_info,
        # Legacy compatibility
        "components": {**tier_1_root, **tier_2_mutable},
    }


def verify_fingerprint(
    expected: str,
    expected_tiered: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Verify current hardware against expected fingerprint using TIERED verification.

    Verification Rules:
    - Tier 1 mismatch → HARD FAIL (not Node0)
    - Tier 2 mismatch → WARN + REQUIRE ATTESTATION (Node0 with changes)
    - Tier 3 mismatch → LOG ONLY (Node0, environmental change)

    Args:
        expected: Expected SHA-256 fingerprint (tier_1 hash)
        expected_tiered: Optional full tiered covenant for detailed verification

    Returns:
        Dict with verification result including tier-by-tier analysis
    """
    current = generate_fingerprint()
    current_tiered = current["tiered_covenant"]

    # Tier 1 verification (STRICT - determines Node0 identity)
    tier_1_match = current["fingerprint"] == expected

    result = {
        "verified": tier_1_match,
        "tier_results": {
            "tier_1_root": {
                "passed": tier_1_match,
                "action": "PASS" if tier_1_match else "HARD_FAIL",
                "current_hash": current["fingerprint"][:16] + "...",
                "expected_hash": expected[:16] + "...",
            },
            "tier_2_mutable": {"passed": True, "action": "NOT_CHECKED"},
            "tier_3_contextual": {"passed": True, "action": "NOT_CHECKED"},
        },
        "current_fingerprint": current["fingerprint"],
        "expected_fingerprint": expected,
        "warnings": [],
        "logs": [],
    }

    if tier_1_match:
        result["message"] = "Hardware verification PASSED - This IS Node0"
        result["match_type"] = "exact_root"

        # Detailed tier verification if expected_tiered provided
        if expected_tiered:
            # Tier 2 check (WARN)
            expected_t2_hash = expected_tiered.get("tier_2_mutable", {}).get("hash")
            current_t2_hash = current_tiered["tier_2_mutable"]["hash"]

            if expected_t2_hash and expected_t2_hash != current_t2_hash:
                result["tier_results"]["tier_2_mutable"] = {
                    "passed": False,
                    "action": "WARN_REQUIRE_ATTESTATION",
                    "current_hash": current_t2_hash[:16] + "...",
                    "expected_hash": expected_t2_hash[:16] + "...",
                }
                result["warnings"].append(
                    "Tier 2 mismatch: RAM/Storage/MAC may have changed. "
                    "Node0 identity confirmed, but attestation recommended."
                )
            else:
                result["tier_results"]["tier_2_mutable"]["passed"] = True
                result["tier_results"]["tier_2_mutable"]["action"] = "PASS"

            # Tier 3 check (LOG ONLY)
            expected_t3_hash = expected_tiered.get("tier_3_contextual", {}).get("hash")
            current_t3_hash = current_tiered["tier_3_contextual"]["hash"]

            if expected_t3_hash and expected_t3_hash != current_t3_hash:
                result["tier_results"]["tier_3_contextual"] = {
                    "passed": True,  # Always passes (log only)
                    "action": "LOG_ONLY",
                    "current_hash": current_t3_hash[:16] + "...",
                    "expected_hash": expected_t3_hash[:16] + "...",
                }
                result["logs"].append(
                    "Tier 3 change detected: OS/BIOS/WSL context may have changed. "
                    "This is expected after system updates."
                )
            else:
                result["tier_results"]["tier_3_contextual"]["passed"] = True
                result["tier_results"]["tier_3_contextual"]["action"] = "PASS"
    else:
        result["message"] = "Hardware verification FAILED - This is NOT the genesis node"
        result["match_type"] = "mismatch"
        result["tier_results"]["tier_1_root"]["action"] = "HARD_FAIL"

    return result


def format_fingerprint_report(fp: Dict[str, Any]) -> str:
    """Format fingerprint data as a human-readable report."""
    lines = [
        "=" * 60,
        "  BIZRA HARDWARE FINGERPRINT REPORT",
        "=" * 60,
        "",
        f"Fingerprint: {fp['fingerprint']}",
        f"Generated:   {fp['generated_at']}",
        "",
        "Hardware Components:",
        "-" * 40,
    ]

    for key, value in sorted(fp["components"].items()):
        lines.append(f"  {key:12}: {value}")

    lines.extend([
        "",
        "Platform Information:",
        "-" * 40,
    ])

    for key, value in sorted(fp["platform_info"].items()):
        lines.append(f"  {key:12}: {value}")

    lines.extend([
        "",
        "=" * 60,
    ])

    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("\n" + "=" * 60)
    print("  BIZRA NODE0 HARDWARE FINGERPRINT GENERATOR")
    print("=" * 60)

    fp = generate_fingerprint()
    print(format_fingerprint_report(fp))

    # Output for genesis.json
    print("\nFor genesis.json hardware_covenant:")
    print("-" * 40)
    print(f'"fingerprint": "{fp["fingerprint"]}"')
