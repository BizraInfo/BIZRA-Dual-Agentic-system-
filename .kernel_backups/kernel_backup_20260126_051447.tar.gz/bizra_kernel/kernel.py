"""
SystemProtocolKernel v2.0 — The Ethical Microkernel
====================================================
From the Blueprint:
  The PAB's SystemProtocolKernel is not a middleware—it is the
  ethical microkernel that sits between Layer 3 (Execution) and
  Layer 4 (Cognitive), enforcing Ihsān thresholds, protocol hashing,
  and SAPE elevation.

This is the central orchestrator that:
1. Creates protocol-hashed sessions
2. Runs the 9-probe verification on all outputs
3. Computes Ihsān vectors and enforces thresholds
4. Tracks SNR and elevates patterns via SAPE
5. Escalates to FATE protocol when thresholds fail
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any
import json
import hashlib

from .ihsan_vector import IhsanVector, IhsanDimension, IHSAN_THRESHOLD
from .session_manager import SessionManager, Session, SessionState
from .verifier import MultiStageVerifier, VerificationResult
from .snr_tracker import SNRTracker, SNRMetrics, estimate_useful_tokens
from .sape_engine import SAPEEngine, ElevatedPattern
from .identity import get_identity
from .got_orchestrator import GoTOrchestrator, RelationType
from .model_hub import SovereignModelHub, ModelRequest


@dataclass
class KernelConfig:
    """Configuration for the SystemProtocolKernel."""
    protocol_version: str = "2.0.0"
    ihsan_threshold: float = 0.99
    snr_target: float = 0.95
    sape_elevation_threshold: int = 3
    fate_circuit_breaker_ms: int = 100
    enable_verification: bool = True
    enable_sape: bool = True
    enable_snr_tracking: bool = True
    
    def to_dict(self) -> dict:
        return {
            "protocol_version": self.protocol_version,
            "ihsan_threshold": self.ihsan_threshold,
            "snr_target": self.snr_target,
            "sape_elevation_threshold": self.sape_elevation_threshold,
            "fate_circuit_breaker_ms": self.fate_circuit_breaker_ms,
            "enable_verification": self.enable_verification,
            "enable_sape": self.enable_sape,
            "enable_snr_tracking": self.enable_snr_tracking,
        }
    
    def hash(self) -> str:
        """Compute SHA256 hash of kernel configuration."""
        canonical = json.dumps(self.to_dict(), sort_keys=True)
        return hashlib.sha256(canonical.encode()).hexdigest()


@dataclass
class ExecutionResult:
    """Result of kernel-managed execution."""
    session_id: str
    response: str
    agent: str
    ihsan_vector: IhsanVector
    verification: VerificationResult
    snr_metrics: SNRMetrics
    elevated_pattern: Optional[ElevatedPattern]
    latency_ms: int
    passed: bool
    fate_escalated: bool
    protocol_hash: str


class SystemProtocolKernel:
    """
    The Ethical Microkernel — Layer 3.5 of APEX Architecture.
    
    Orchestrates all agent execution with:
    - Protocol hashing for traceability
    - Ihsān enforcement for ethics
    - 9-probe verification for correctness
    - SNR tracking for efficiency
    - SAPE for continuous optimization
    """
    
    VERSION = "2.0.0"
    
    def __init__(self, config: Optional[KernelConfig] = None):
        self.config = config or KernelConfig()
        self.session_manager = SessionManager()
        self.verifier = MultiStageVerifier()
        self.snr_tracker = SNRTracker()
        self.sape_engine = SAPEEngine()
        self.model_hub = SovereignModelHub()
        self.got_clusters: Dict[str, GoTOrchestrator] = {}
        
        # FATE escalation callback (can be overridden)
        self.fate_callback: Optional[Callable[[Session, str], None]] = None
        
        # Protocol hash for this kernel instance
        self.protocol_hash = self.config.hash()
    
    def execute(
        self,
        agent: str,
        query: str,
        response: str,
        knowledge_context: str = "",
        token_count: int = 0,
        latency_ms: int = 0,
        user_id: str = "momo",  # Dedicated identity anchor
    ) -> ExecutionResult:
        """
        Execute a kernel-managed agent interaction.
        
        This is the main entry point that:
        1. Creates a protocol-hashed session
        2. Runs verification
        3. Computes Ihsān score
        4. Tracks SNR
        5. Checks for SAPE elevation
        6. Returns complete execution result
        """
        # 1. Create session
        session = self.session_manager.create_session(agent, query, user_id)
        
        # 2. Run 9-probe verification
        if self.config.enable_verification:
            verification = self.verifier.verify(
                query=query,
                response=response,
                agent_role=agent,
                knowledge_context=knowledge_context,
                token_count=token_count,
                latency_ms=latency_ms,
            )
        else:
            verification = VerificationResult(
                probe_results=[],
                overall_passed=True,
                composite_score=1.0,
                failing_probes=[],
            )
        
        # 3. Compute Ihsān vector
        ihsan_vec = IhsanVector.from_agent_response(
            response=response,
            latency_ms=latency_ms,
            token_count=token_count,
            rag_used=bool(knowledge_context),
            agent_role=agent,
        )
        
        # Incorporate verification results into Ihsān
        ihsan_vec.set_score(
            IhsanDimension.CORRECTNESS,
            verification.composite_score
        )
        
        # 4. Track SNR
        useful_tokens = estimate_useful_tokens(response)
        snr_metrics = SNRMetrics(
            total_tokens=token_count or len(response.split()),
            useful_tokens=useful_tokens,
            confidence_score=verification.composite_score,
            ethical_compliance=ihsan_vec.composite_score,
            tool_directness=0.9,  # Heuristic; could be computed
            latency_ms=latency_ms,
            agent_role=agent,
        )
        
        if self.config.enable_snr_tracking:
            self.snr_tracker.record(snr_metrics)
        
        # 5. Check for SAPE elevation
        elevated_pattern = None
        if self.config.enable_sape:
            # Build verification sequence from probe results
            sequence = [
                f"{probe.probe_type.value}:{'pass' if probe.passed else 'fail'}"
                for probe in verification.probe_results
            ]
            elevated_pattern = self.sape_engine.observe_sequence(sequence)
        
        # 6. Determine if execution passed
        passed = (
            ihsan_vec.passes_threshold
            and verification.overall_passed
        )
        
        # 7. Handle FATE escalation if needed
        fate_escalated = False
        if not passed:
            fate_escalated = True
            session.pause_for_fate(
                f"Ihsān: {ihsan_vec.composite_score:.3f}, "
                f"Verification: {verification.composite_score:.3f}"
            )
            if self.fate_callback:
                self.fate_callback(
                    session,
                    f"Execution failed: Ihsān={ihsan_vec.composite_score:.3f}"
                )
        else:
            session.complete(response, ihsan_vec)
        
        # 8. Build execution result
        return ExecutionResult(
            session_id=session.session_id,
            response=response,
            agent=agent,
            ihsan_vector=ihsan_vec,
            verification=verification,
            snr_metrics=snr_metrics,
            elevated_pattern=elevated_pattern,
            latency_ms=latency_ms,
            passed=passed,
            fate_escalated=fate_escalated,
            protocol_hash=self.protocol_hash,
        )
    
    def perform_interdisciplinary_reasoning(
        self,
        session_id: str,
        proposals: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Peak Masterpiece Integration:
        Synthesize multi-agent proposals into a unified Graph of Thoughts (GoT).
        Applying RelationType mapping, SAPE elevation, and returning a receipt.
        """
        # Reuse existing cluster if present, else create
        got = self.got_clusters.get(session_id) or GoTOrchestrator(session_id)
        self.got_clusters[session_id] = got
        
        nodes = []
        for prop in proposals:
            content = prop.get("content", "")
            lens = prop.get("lens", "generic")
            snr = prop.get("snr", 0.0)
            # SAPE guardrail: drop proposals that trip threat probes
            threat_score, _, threat_flags = self.sape_engine.probe_threat(content)
            if threat_flags and threat_score < 0.9:
                continue
            # Sapient guardrail: skip clearly empty proposals
            if not content.strip():
                continue
            node = got.add_thought(content=content, lens=lens, snr=snr)
            nodes.append(node)
            
        # Strategy: Link all subsequent nodes to the first one as 'Supports' 
        # unless a contradiction/generalization is detected (heuristic)
        if len(nodes) > 1:
            prime = nodes[0]
            for other in nodes[1:]:
                rel = RelationType.SUPPORTS
                lower = other.content.lower()
                if "contrast" in lower or "however" in lower:
                    rel = RelationType.CONTRADICTS
                elif "overall" in lower or "systemic" in lower:
                    rel = RelationType.GENERALIZES
                got.link_thoughts(other.id, prime.id, rel)
        
        elevation = got.elevate_sape()
        receipt = got.summarize()
        receipt["elevation"] = elevation
        return receipt

    async def execute_local_inference(
        self,
        task: str,
        complexity: str = "medium"
    ) -> ExecutionResult:
        """
        Executes a task locally through the Sovereign Model Hub.
        """
        # Create session upfront so we can key GoT clusters and routing hints
        session = self.session_manager.create_session(agent="LocalInference", message=task)
        context = {"complexity": complexity}
        if self.got_clusters.get(session.session_id):
            context["giant_hint"] = "strategic"
            context["routing_hint_source"] = "got_cluster"
        req = ModelRequest(task=task, context=context)
        response = await self.model_hub.execute_sovereign_task(req)
        
        # 2. Real-time Verification
        verification = self.verifier.verify(
            query=task,
            response=response.content,
            agent_role="LocalInference",
            knowledge_context="",
            token_count=len(response.content) // 4,
            latency_ms=int(response.metadata.get("latency", 0) * 1000)
        )
        
        # 3. Real-time Ihsān Computation
        ihsan_vec = IhsanVector.from_agent_response(
            response=response.content,
            latency_ms=int(response.metadata.get("latency", 0) * 1000),
            token_count=len(response.content) // 4,
            rag_used=False,
            agent_role="LocalInference"
        )
        ihsan_vec.set_score(IhsanDimension.CORRECTNESS, verification.composite_score)
        
        snr_metrics = SNRMetrics(
            total_tokens=len(response.content) // 4,
            useful_tokens=estimate_useful_tokens(response.content),
            confidence_score=verification.composite_score,
            ethical_compliance=ihsan_vec.composite_score,
            tool_directness=1.0,
            latency_ms=int(response.metadata.get("latency", 0) * 1000),
            agent_role="LocalInference"
        )
        
        # Complete session via manager (includes Ihsan threshold gating)
        self.session_manager.complete_session(session.session_id, response.content, ihsan_vec)
        
        # Attach GoT receipt if available and clean up cluster
        got = self.got_clusters.pop(session.session_id, None)
        got_receipt = got.summarize() if got else None

        return ExecutionResult(
            session_id=session.session_id,
            response=response.content,
            agent=f"Local:{response.model_used}",
            ihsan_vector=ihsan_vec,
            verification=verification,
            snr_metrics=snr_metrics,
            elevated_pattern=got_receipt,
            latency_ms=int(response.metadata.get("latency", 0) * 1000),
            passed=ihsan_vec.passes_threshold and verification.overall_passed,
            fate_escalated=not (ihsan_vec.passes_threshold and verification.overall_passed),
            protocol_hash=self.config.hash(),
        )
    
    def get_status(self) -> dict:
        """Get comprehensive kernel status."""
        session_stats = self.session_manager.get_statistics()
        snr_stats = self.snr_tracker.get_statistics()
        sape_stats = self.sape_engine.get_statistics()
        
        return {
            "kernel_version": self.VERSION,
            "protocol_hash": self.protocol_hash,
            "config": self.config.to_dict(),
            "sessions": session_stats,
            "snr": snr_stats,
            "sape": sape_stats,
            "health": {
                "ihsan_compliant": session_stats.get("avg_ihsan_score", 0) >= self.config.ihsan_threshold,
                "snr_target_met": snr_stats.get("average_snr", 0) >= self.config.snr_target,
                "fate_escalations": session_stats.get("paused_for_fate", 0),
            },
            "sovereignty": get_identity().to_dict(),
        }
    
    def register_fate_callback(
        self,
        callback: Callable[[Session, str], None]
    ) -> None:
        """Register a callback for FATE escalations."""
        self.fate_callback = callback
    
    def to_poi_receipt(self) -> dict:
        """Generate a PoI receipt for the kernel's current state."""
        status = self.get_status()
        return {
            "receipt_type": "kernel_state",
            "kernel_version": self.VERSION,
            "protocol_hash": self.protocol_hash,
            "timestamp": datetime.utcnow().isoformat(),
            "ihsan_average": status["sessions"].get("avg_ihsan_score", 0),
            "snr_average": status["snr"].get("average_snr", 0),
            "sape_elevations": status["sape"].get("elevated_patterns", 0),
            "health_status": status["health"],
        }


# Singleton instance for global access
_kernel_instance: Optional[SystemProtocolKernel] = None


def get_kernel() -> SystemProtocolKernel:
    """Get the global kernel instance."""
    global _kernel_instance
    if _kernel_instance is None:
        _kernel_instance = SystemProtocolKernel()
    return _kernel_instance


def reset_kernel(config: Optional[KernelConfig] = None) -> SystemProtocolKernel:
    """Reset the global kernel with optional new configuration."""
    global _kernel_instance
    _kernel_instance = SystemProtocolKernel(config)
    return _kernel_instance
