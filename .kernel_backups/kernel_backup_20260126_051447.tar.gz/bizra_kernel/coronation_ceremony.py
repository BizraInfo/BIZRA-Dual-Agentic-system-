"""
BIZRA Node0 Coronation Ceremony
================================
The capstone module that unifies all Node0 sovereignty components.

This ceremony transforms an MSI Titan laptop from "running BIZRA software"
to "BEING Node0 of the BIZRA network" - a cryptographic coronation.

Components Unified:
- Hardware Fingerprint (tiered covenant)
- Ed25519 Cryptographic Identity
- Genesis Signing
- Append-only Sync
- Immutable Receipt Generation

Usage:
    from bizra_kernel.coronation_ceremony import execute_coronation

    receipt = execute_coronation(dry_run=False)
    print(f"Node0 Coronated: {receipt['coronation_id']}")

Standing on Shoulders of Giants:
- TPM/HSM key custody patterns
- Certificate transparency (append-only)
- Hardware attestation (Android SafetyNet, Apple DeviceCheck)
- Byzantine fault tolerance (3/5 consensus)

بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ
In the name of Allah, the Most Gracious, the Most Merciful
"""

import json
import hashlib
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# CORONATION RECEIPT STRUCTURE
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class CoronationReceipt:
    """
    Immutable record of the Node0 coronation ceremony.

    This receipt is cryptographic proof that:
    1. Hardware was verified at coronation time
    2. Genesis was signed by Node0's private key
    3. Genesis was synced to all canonical locations
    4. The ceremony completed successfully
    """
    coronation_id: str
    timestamp: str

    # Identity
    node0_pubkey_fingerprint: str
    node0_pubkey_pem: str

    # Hardware Covenant
    hardware_fingerprint: str
    hardware_tier1_hash: str
    hardware_tier2_hash: str
    hardware_tier3_hash: str
    hardware_verified: bool

    # Genesis
    genesis_hash: str
    genesis_signed: bool
    genesis_signature_algorithm: str

    # Sync
    sync_locations: list
    sync_success: bool

    # Ceremony
    ceremony_complete: bool
    dry_run: bool

    # Integrity
    receipt_hash: str = ""

    def compute_hash(self) -> str:
        """Compute SHA-256 hash of receipt (excluding receipt_hash field)."""
        data = asdict(self)
        data.pop("receipt_hash", None)
        canonical = json.dumps(data, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


# ═══════════════════════════════════════════════════════════════════════════════
# CORONATION CEREMONY
# ═══════════════════════════════════════════════════════════════════════════════

def execute_coronation(
    dry_run: bool = True,
    strict_hardware: bool = True,
    force_resign: bool = False,
) -> Dict[str, Any]:
    """
    Execute the Node0 Coronation Ceremony.

    This is the capstone operation that:
    1. Verifies hardware covenant (Tier-1 must match)
    2. Loads/creates Node0 cryptographic identity
    3. Signs the genesis block with Ed25519
    4. Syncs to all canonical locations
    5. Produces an immutable coronation receipt

    Args:
        dry_run: If True, verify but don't modify genesis (default: True for safety)
        strict_hardware: If True, fail on Tier-1 mismatch (default: True)
        force_resign: If True, resign even if already signed (default: False)

    Returns:
        Coronation receipt as dictionary

    Raises:
        CoronationError: If ceremony cannot complete
    """
    from bizra_kernel.hardware_fingerprint import generate_fingerprint, verify_fingerprint
    from bizra_kernel.node0_identity import Node0Identity
    from bizra_kernel.genesis_sync import (
        load_genesis, sync_genesis, get_genesis_hash,
        GenesisLocations, DEFAULT_LOCATIONS,
    )

    logger.info("=" * 70)
    logger.info("  BIZRA NODE0 CORONATION CEREMONY")
    logger.info("=" * 70)
    logger.info(f"  Mode: {'DRY RUN (no changes)' if dry_run else 'LIVE (will modify genesis)'}")
    logger.info("=" * 70)

    ceremony_start = datetime.now(timezone.utc)
    errors = []
    warnings = []

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 1: Hardware Verification
    # ─────────────────────────────────────────────────────────────────────────
    logger.info("\n[PHASE 1] Hardware Covenant Verification")

    try:
        hardware_fp = generate_fingerprint()
        logger.info(f"  ✓ Hardware fingerprint generated: {hardware_fp['fingerprint'][:32]}...")

        tier1_hash = hardware_fp["tiered_covenant"]["tier_1_root"]["hash"]
        tier2_hash = hardware_fp["tiered_covenant"]["tier_2_mutable"]["hash"]
        tier3_hash = hardware_fp["tiered_covenant"]["tier_3_contextual"]["hash"]

        logger.info(f"  ✓ Tier-1 (Root):       {tier1_hash[:24]}...")
        logger.info(f"  ✓ Tier-2 (Mutable):    {tier2_hash[:24]}...")
        logger.info(f"  ✓ Tier-3 (Contextual): {tier3_hash[:24]}...")

        hardware_verified = True

    except Exception as e:
        logger.error(f"  ✗ Hardware fingerprint failed: {e}")
        errors.append(f"Hardware fingerprint generation failed: {e}")
        hardware_fp = {"fingerprint": "ERROR", "tiered_covenant": {}}
        tier1_hash = tier2_hash = tier3_hash = "ERROR"
        hardware_verified = False

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 2: Cryptographic Identity
    # ─────────────────────────────────────────────────────────────────────────
    logger.info("\n[PHASE 2] Node0 Cryptographic Identity")

    try:
        identity = Node0Identity.load_or_create()

        if identity.has_private_key:
            logger.info(f"  ✓ Node0 identity loaded")
            logger.info(f"  ✓ Public key fingerprint: {identity.public_key_fingerprint[:32]}...")
            logger.info(f"  ✓ Key directory: {identity.key_dir}")
        else:
            logger.warning("  ⚠ No private key available - cannot sign")
            warnings.append("No private key available")

        if identity.is_restricted:
            logger.error("  ✗ Identity is in RESTRICTED MODE - cannot proceed")
            errors.append("Node0 identity is in restricted mode")

    except Exception as e:
        logger.error(f"  ✗ Identity load failed: {e}")
        errors.append(f"Identity load failed: {e}")
        identity = None

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 3: Genesis Loading and Verification
    # ─────────────────────────────────────────────────────────────────────────
    logger.info("\n[PHASE 3] Genesis Block")

    try:
        genesis = load_genesis(source="taskmaster", verify_signature=False)
        genesis_hash = get_genesis_hash(genesis)

        logger.info(f"  ✓ Genesis loaded from TaskMaster")
        logger.info(f"  ✓ Genesis hash: {genesis_hash[:32]}...")
        logger.info(f"  ✓ Version: {genesis.get('version', 'N/A')}")
        logger.info(f"  ✓ Name: {genesis.get('name', 'N/A')}")

        # Check if already signed
        existing_sig = genesis.get("signature", {})
        already_signed = (
            existing_sig.get("signature") and
            not existing_sig.get("signature", "").startswith("FILL")
        )

        if already_signed:
            logger.info(f"  ✓ Genesis is ALREADY SIGNED")
            logger.info(f"    Algorithm: {existing_sig.get('algorithm', 'N/A')}")
            logger.info(f"    Signed at: {existing_sig.get('signed_at', 'N/A')}")

            if not force_resign:
                logger.info("  → Skipping re-signing (use force_resign=True to override)")
        else:
            logger.info("  ⚠ Genesis is UNSIGNED")

        # Check hardware covenant
        hw_covenant = genesis.get("hardware_covenant", {})
        if hw_covenant:
            expected_fp = hw_covenant.get("fingerprint", "")
            logger.info(f"  ✓ Hardware covenant present: {expected_fp[:24]}...")

            # Verify current hardware matches covenant
            if hardware_verified and expected_fp:
                if hardware_fp["fingerprint"] == expected_fp:
                    logger.info("  ✓ Current hardware MATCHES genesis covenant")
                else:
                    if strict_hardware:
                        logger.error("  ✗ Hardware MISMATCH - coronation blocked")
                        errors.append("Hardware fingerprint does not match genesis covenant")
                    else:
                        logger.warning("  ⚠ Hardware mismatch (non-strict mode)")
                        warnings.append("Hardware fingerprint mismatch")
        else:
            logger.warning("  ⚠ No hardware covenant in genesis")
            warnings.append("Genesis has no hardware covenant")

    except FileNotFoundError as e:
        logger.error(f"  ✗ Genesis not found: {e}")
        errors.append(f"Genesis not found: {e}")
        genesis = None
        genesis_hash = "ERROR"
        already_signed = False
    except Exception as e:
        logger.error(f"  ✗ Genesis load failed: {e}")
        errors.append(f"Genesis load failed: {e}")
        genesis = None
        genesis_hash = "ERROR"
        already_signed = False

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 4: Genesis Signing
    # ─────────────────────────────────────────────────────────────────────────
    logger.info("\n[PHASE 4] Genesis Signing")

    genesis_signed = already_signed
    signed_this_run = False  # Track if we sign during THIS ceremony
    signature_algorithm = "Ed25519"

    if errors:
        logger.error("  ✗ Cannot sign - errors in previous phases")
    elif dry_run:
        logger.info("  → DRY RUN: Would sign genesis here")
        logger.info("    Run with dry_run=False to execute signing")
    elif already_signed and not force_resign:
        logger.info("  → Already signed, skipping")
    elif identity and identity.has_private_key and genesis:
        try:
            # Sign the genesis
            signature_info = identity.sign_genesis(genesis)
            genesis["signature"] = signature_info
            genesis_signed = True

            genesis_signed = True
            signed_this_run = True  # We signed during THIS ceremony

            logger.info("  ✓ Genesis SIGNED successfully")
            logger.info(f"    Algorithm: {signature_info['algorithm']}")
            logger.info(f"    Genesis Hash: {signature_info['genesis_hash'][:32]}...")
            logger.info(f"    Signature: {signature_info['signature'][:32]}...")

            # Write back to TaskMaster
            taskmaster_path = DEFAULT_LOCATIONS.taskmaster
            with open(taskmaster_path, "w", encoding="utf-8") as f:
                json.dump(genesis, f, indent=2, ensure_ascii=False)

            logger.info(f"  ✓ Signed genesis written to: {taskmaster_path}")

            # Update genesis hash after signing
            genesis_hash = get_genesis_hash(genesis)

        except Exception as e:
            logger.error(f"  ✗ Signing failed: {e}")
            errors.append(f"Signing failed: {e}")
    else:
        logger.error("  ✗ Cannot sign - missing identity or genesis")

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 5: Genesis Sync
    # ─────────────────────────────────────────────────────────────────────────
    logger.info("\n[PHASE 5] Genesis Synchronization")

    sync_locations = []
    sync_success = False

    if errors:
        logger.error("  ✗ Cannot sync - errors in previous phases")
    elif dry_run:
        logger.info("  → DRY RUN: Would sync to all locations here")
        sync_locations = ["(dry run - no sync)"]
    else:
        try:
            # If we signed the genesis during THIS ceremony, use force_initial to backup and update
            # This is a legitimate update (coronation), not tampering
            if signed_this_run:
                logger.info("  → Genesis was signed this ceremony - using force_initial mode")
                logger.info("    (Old unsigned/differently-signed versions will be backed up)")

            sync_result = sync_genesis(force_initial=signed_this_run)

            sync_success = sync_result.get("success", False)
            sync_locations = [
                loc.get("location", "unknown")
                for loc in sync_result.get("locations_synced", [])
            ]

            if sync_success:
                logger.info("  ✓ Genesis synced successfully")
                for loc in sync_result.get("locations_synced", []):
                    status = loc.get("status", "unknown")
                    path = loc.get("location", "unknown")
                    logger.info(f"    [{status}] {path}")
            else:
                logger.warning(f"  ⚠ Sync completed with issues")
                for loc in sync_result.get("locations_failed", []):
                    logger.error(f"    [FAILED] {loc.get('location')}: {loc.get('error')}")

        except Exception as e:
            logger.error(f"  ✗ Sync failed: {e}")
            errors.append(f"Sync failed: {e}")

    # ─────────────────────────────────────────────────────────────────────────
    # PHASE 6: Generate Coronation Receipt
    # ─────────────────────────────────────────────────────────────────────────
    logger.info("\n[PHASE 6] Coronation Receipt Generation")

    ceremony_complete = len(errors) == 0 and (dry_run or (genesis_signed and sync_success))

    # Generate coronation ID
    coronation_data = f"{ceremony_start.isoformat()}{identity.public_key_fingerprint if identity else 'NO_IDENTITY'}"
    coronation_id = f"CORONATION-{hashlib.sha256(coronation_data.encode()).hexdigest()[:16].upper()}"

    receipt = CoronationReceipt(
        coronation_id=coronation_id,
        timestamp=ceremony_start.isoformat(),

        node0_pubkey_fingerprint=identity.public_key_fingerprint if identity else "NO_IDENTITY",
        node0_pubkey_pem=identity.public_key_pem if identity else "",

        hardware_fingerprint=hardware_fp.get("fingerprint", "ERROR"),
        hardware_tier1_hash=tier1_hash,
        hardware_tier2_hash=tier2_hash,
        hardware_tier3_hash=tier3_hash,
        hardware_verified=hardware_verified,

        genesis_hash=genesis_hash,
        genesis_signed=genesis_signed,
        genesis_signature_algorithm=signature_algorithm,

        sync_locations=sync_locations,
        sync_success=sync_success or dry_run,

        ceremony_complete=ceremony_complete,
        dry_run=dry_run,
    )

    # Compute integrity hash
    receipt.receipt_hash = receipt.compute_hash()

    # Convert to dict
    receipt_dict = asdict(receipt)
    receipt_dict["errors"] = errors
    receipt_dict["warnings"] = warnings

    # Store receipt
    if not dry_run and ceremony_complete:
        receipt_path = Path(__file__).parent.parent / "docs" / "evidence" / "coronation_receipts"
        receipt_path.mkdir(parents=True, exist_ok=True)
        receipt_file = receipt_path / f"{coronation_id}.json"

        with open(receipt_file, "w", encoding="utf-8") as f:
            json.dump(receipt_dict, f, indent=2)

        logger.info(f"  ✓ Receipt stored: {receipt_file}")

    # ─────────────────────────────────────────────────────────────────────────
    # CEREMONY COMPLETE
    # ─────────────────────────────────────────────────────────────────────────
    logger.info("\n" + "=" * 70)

    if ceremony_complete:
        if dry_run:
            logger.info("  DRY RUN COMPLETE - No changes made")
            logger.info("  Run with dry_run=False to execute coronation")
        else:
            logger.info("  ✅ NODE0 CORONATION COMPLETE")
            logger.info(f"  Coronation ID: {coronation_id}")
            logger.info(f"  Public Key:    {receipt.node0_pubkey_fingerprint[:32]}...")
            logger.info(f"  Genesis Hash:  {receipt.genesis_hash[:32]}...")
    else:
        logger.error("  ❌ CORONATION FAILED")
        for error in errors:
            logger.error(f"    - {error}")

    logger.info("=" * 70)

    return receipt_dict


def verify_coronation(coronation_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Verify that a coronation is still valid.

    Checks:
    1. Node0 identity matches coronation receipt
    2. Hardware covenant still valid
    3. Genesis signature still valid
    4. All sync locations in agreement

    Args:
        coronation_id: Specific coronation to verify (or latest if None)

    Returns:
        Verification result
    """
    from bizra_kernel.hardware_fingerprint import generate_fingerprint
    from bizra_kernel.node0_identity import Node0Identity
    from bizra_kernel.genesis_sync import load_genesis, get_sync_status, verify_genesis_signature

    logger.info("Verifying coronation...")

    result = {
        "verified": False,
        "checks": {},
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    # 1. Load and verify identity
    try:
        identity = Node0Identity.load_or_create()
        result["checks"]["identity"] = {
            "passed": identity.has_private_key and not identity.is_restricted,
            "fingerprint": identity.public_key_fingerprint[:32] + "..." if identity.public_key_fingerprint else "N/A",
            "restricted": identity.is_restricted,
        }
    except Exception as e:
        result["checks"]["identity"] = {"passed": False, "error": str(e)}

    # 2. Verify hardware
    try:
        fp = generate_fingerprint()
        genesis = load_genesis(verify_signature=False)
        expected = genesis.get("hardware_covenant", {}).get("fingerprint", "")

        result["checks"]["hardware"] = {
            "passed": fp["fingerprint"] == expected,
            "current": fp["fingerprint"][:32] + "...",
            "expected": expected[:32] + "..." if expected else "N/A",
        }
    except Exception as e:
        result["checks"]["hardware"] = {"passed": False, "error": str(e)}

    # 3. Verify genesis signature
    try:
        genesis = load_genesis(verify_signature=True, strict_signature=True)
        sig_result = verify_genesis_signature(genesis)

        result["checks"]["signature"] = {
            "passed": sig_result.get("verified", False),
            "message": sig_result.get("message", sig_result.get("error", "N/A")),
        }
    except Exception as e:
        result["checks"]["signature"] = {"passed": False, "error": str(e)}

    # 4. Verify sync status
    try:
        sync_status = get_sync_status()
        result["checks"]["sync"] = {
            "passed": sync_status.get("in_sync", False),
            "locations": list(sync_status.get("locations", {}).keys()),
        }
    except Exception as e:
        result["checks"]["sync"] = {"passed": False, "error": str(e)}

    # Overall verification
    all_passed = all(
        check.get("passed", False)
        for check in result["checks"].values()
    )
    result["verified"] = all_passed

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse

    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
    )

    parser = argparse.ArgumentParser(
        description="BIZRA Node0 Coronation Ceremony",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Dry run (verify without changes)
  python -m bizra_kernel.coronation_ceremony --dry-run

  # Execute coronation (signs genesis, syncs to all locations)
  python -m bizra_kernel.coronation_ceremony --execute

  # Force re-sign even if already signed
  python -m bizra_kernel.coronation_ceremony --execute --force-resign

  # Verify existing coronation
  python -m bizra_kernel.coronation_ceremony --verify
        """
    )

    parser.add_argument(
        "--dry-run", "-n",
        action="store_true",
        default=True,
        help="Verify without making changes (default)"
    )
    parser.add_argument(
        "--execute", "-x",
        action="store_true",
        help="Execute coronation (signs and syncs)"
    )
    parser.add_argument(
        "--force-resign", "-f",
        action="store_true",
        help="Force re-signing even if already signed"
    )
    parser.add_argument(
        "--verify", "-v",
        action="store_true",
        help="Verify existing coronation"
    )
    parser.add_argument(
        "--non-strict",
        action="store_true",
        help="Allow coronation with hardware mismatch (dangerous)"
    )

    args = parser.parse_args()

    if args.verify:
        result = verify_coronation()
        print(json.dumps(result, indent=2))
    else:
        dry_run = not args.execute
        receipt = execute_coronation(
            dry_run=dry_run,
            strict_hardware=not args.non_strict,
            force_resign=args.force_resign,
        )

        if not dry_run:
            print("\nCoronation Receipt:")
            print(json.dumps(receipt, indent=2))
