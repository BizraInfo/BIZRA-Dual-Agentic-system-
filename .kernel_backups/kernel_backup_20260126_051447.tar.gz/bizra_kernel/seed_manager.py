"""
BIZRA Seed Manager - Autonomous Forest Growth Protocol Phase 1

Manages seed lifecycle, parent-child relationships, and covenant inheritance.
Seeds progress through: DORMANT → GERMINATING → SAPLING → MATURE → FRUITING → ELDER

Integration Points:
- Node0Identity for signing seed certificates
- IhsanReceipt for PoI event receipts
- RecursiveNode for network topology
"""

import os
import json
import hashlib
import threading
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, List, Dict, Any
from pathlib import Path


class SeedState(Enum):
    """Seed lifecycle states following biblical seed metaphor."""
    DORMANT = "dormant"          # Created but inactive
    GERMINATING = "germinating"  # Initial growth phase
    SAPLING = "sapling"          # Early active phase
    MATURE = "mature"            # Full operational
    FRUITING = "fruiting"        # Can reproduce
    ELDER = "elder"              # Network elder (governance)


# Lifecycle progression order
LIFECYCLE_ORDER = [
    SeedState.DORMANT,
    SeedState.GERMINATING,
    SeedState.SAPLING,
    SeedState.MATURE,
    SeedState.FRUITING,
    SeedState.ELDER,
]


@dataclass
class Seed:
    """
    A seed in the BIZRA autonomous forest.

    Seeds inherit covenants from parents and can reproduce
    when meeting Ihsān threshold (0.95) and PoI requirements (10+).
    """
    seed_id: str                                    # SHA-256 derived from parent + salt
    parent_id: Optional[str]                        # None for Node0
    state: SeedState = SeedState.DORMANT
    ihsan_score: float = 0.0                        # Current Ihsān score
    poi_events: int = 0                             # Proof-of-Impact count
    created_at: datetime = field(default_factory=datetime.utcnow)
    germinated_at: Optional[datetime] = None
    covenant_accepted: bool = False
    children: List[str] = field(default_factory=list)  # Child seed IDs
    token_balance: float = 0.0                      # Off-chain BZR balance
    depth: int = 0                                  # Generation depth (0 = Node0)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize seed to dictionary for storage."""
        return {
            "seed_id": self.seed_id,
            "parent_id": self.parent_id,
            "state": self.state.value,
            "ihsan_score": self.ihsan_score,
            "poi_events": self.poi_events,
            "created_at": self.created_at.isoformat(),
            "germinated_at": self.germinated_at.isoformat() if self.germinated_at else None,
            "covenant_accepted": self.covenant_accepted,
            "children": self.children,
            "token_balance": self.token_balance,
            "depth": self.depth,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Seed":
        """Deserialize seed from dictionary."""
        return cls(
            seed_id=data["seed_id"],
            parent_id=data.get("parent_id"),
            state=SeedState(data.get("state", "dormant")),
            ihsan_score=data.get("ihsan_score", 0.0),
            poi_events=data.get("poi_events", 0),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else datetime.utcnow(),
            germinated_at=datetime.fromisoformat(data["germinated_at"]) if data.get("germinated_at") else None,
            covenant_accepted=data.get("covenant_accepted", False),
            children=data.get("children", []),
            token_balance=data.get("token_balance", 0.0),
            depth=data.get("depth", 0),
            metadata=data.get("metadata", {}),
        )


# Reproduction requirements - strict Ihsān gating
REPRODUCTION_REQUIREMENTS = {
    "min_ihsan_score": 0.95,    # Ihsān threshold
    "min_poi_events": 10,       # Proof-of-Impact minimum
    "min_age_days": 7,          # Minimum age to reproduce
    "covenant_required": True,   # Must accept covenant
    "max_children": 7,          # Biblical seed metaphor (7 first seeds)
}


class SeedManager:
    """
    Manages the BIZRA seed forest with lifecycle control and reproduction.

    Features:
    - Thread-safe operations
    - Persistent storage to disk
    - Covenant inheritance
    - PoI event tracking
    - Ihsān score gating
    """

    def __init__(self, storage_dir: str = "bizra_network/seeds"):
        self._lock = threading.RLock()
        self._seeds: Dict[str, Seed] = {}
        self._storage_dir = Path(storage_dir)
        self._storage_dir.mkdir(parents=True, exist_ok=True)
        self._receipts_dir = Path("docs/evidence/receipts")
        self._receipts_dir.mkdir(parents=True, exist_ok=True)
        self._load_seeds()

    def _load_seeds(self) -> None:
        """Load existing seeds from storage."""
        manifest_path = self._storage_dir / "seeds_manifest.json"
        if manifest_path.exists():
            with open(manifest_path, "r") as f:
                data = json.load(f)
                for seed_data in data.get("seeds", []):
                    seed = Seed.from_dict(seed_data)
                    self._seeds[seed.seed_id] = seed

    def _save_seeds(self) -> None:
        """Persist all seeds to storage."""
        manifest_path = self._storage_dir / "seeds_manifest.json"
        data = {
            "version": "1.0.0",
            "updated_at": datetime.utcnow().isoformat(),
            "seed_count": len(self._seeds),
            "seeds": [seed.to_dict() for seed in self._seeds.values()],
        }
        with open(manifest_path, "w") as f:
            json.dump(data, f, indent=2)

    def _generate_seed_id(self, parent_id: Optional[str]) -> str:
        """Generate SHA-256 derived seed ID from parent + salt."""
        import uuid
        salt = uuid.uuid4().hex[:8]
        base = f"{parent_id}:{salt}" if parent_id else f"NODE0:{salt}"
        full_hash = hashlib.sha256(base.encode()).hexdigest()
        return f"SEED-{full_hash[:16].upper()}"

    def _emit_receipt(self, event_type: str, seed_id: str, details: Dict[str, Any]) -> str:
        """Emit evidence receipt for lifecycle events."""
        receipt_id = hashlib.sha256(
            f"{event_type}:{seed_id}:{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()[:16]

        receipt = {
            "receipt_id": receipt_id,
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "seed_id": seed_id,
            "details": details,
            "integrity_hash": hashlib.sha256(
                json.dumps(details, sort_keys=True).encode()
            ).hexdigest(),
        }

        # Append to receipts file
        receipt_file = self._receipts_dir / "seed_lifecycle_receipts.jsonl"
        with open(receipt_file, "a") as f:
            f.write(json.dumps(receipt) + "\n")

        return receipt_id

    def create_seed(self, parent_id: Optional[str] = None) -> Seed:
        """
        Create a new seed with optional parent lineage.

        Args:
            parent_id: Parent seed ID (None for Node0/root seed)

        Returns:
            New Seed instance in DORMANT state
        """
        with self._lock:
            seed_id = self._generate_seed_id(parent_id)

            # Calculate depth from parent
            depth = 0
            if parent_id and parent_id in self._seeds:
                parent = self._seeds[parent_id]
                depth = parent.depth + 1
                # Inherit covenant from parent
                covenant_accepted = parent.covenant_accepted
            else:
                covenant_accepted = False

            seed = Seed(
                seed_id=seed_id,
                parent_id=parent_id,
                state=SeedState.DORMANT,
                depth=depth,
                covenant_accepted=covenant_accepted,
            )

            self._seeds[seed_id] = seed

            # Update parent's children list
            if parent_id and parent_id in self._seeds:
                self._seeds[parent_id].children.append(seed_id)

            self._save_seeds()

            # Emit creation receipt
            self._emit_receipt("seed_created", seed_id, {
                "parent_id": parent_id,
                "depth": depth,
                "covenant_inherited": covenant_accepted,
            })

            return seed

    def germinate(self, seed_id: str) -> bool:
        """
        Transition seed from DORMANT to GERMINATING state.

        Args:
            seed_id: Seed to germinate

        Returns:
            True if germination successful, False otherwise
        """
        with self._lock:
            if seed_id not in self._seeds:
                return False

            seed = self._seeds[seed_id]

            if seed.state != SeedState.DORMANT:
                return False

            seed.state = SeedState.GERMINATING
            seed.germinated_at = datetime.utcnow()

            self._save_seeds()

            self._emit_receipt("seed_germinated", seed_id, {
                "previous_state": SeedState.DORMANT.value,
                "new_state": SeedState.GERMINATING.value,
                "germinated_at": seed.germinated_at.isoformat(),
            })

            return True

    def advance_lifecycle(self, seed_id: str) -> Optional[SeedState]:
        """
        Advance seed to next lifecycle state if eligible.

        Args:
            seed_id: Seed to advance

        Returns:
            New state if advanced, None if not eligible
        """
        with self._lock:
            if seed_id not in self._seeds:
                return None

            seed = self._seeds[seed_id]
            current_idx = LIFECYCLE_ORDER.index(seed.state)

            # Already at final state
            if current_idx >= len(LIFECYCLE_ORDER) - 1:
                return None

            # Check advancement requirements
            if not self._check_advancement_requirements(seed, current_idx):
                return None

            previous_state = seed.state
            seed.state = LIFECYCLE_ORDER[current_idx + 1]

            self._save_seeds()

            self._emit_receipt("lifecycle_advanced", seed_id, {
                "previous_state": previous_state.value,
                "new_state": seed.state.value,
                "ihsan_score": seed.ihsan_score,
                "poi_events": seed.poi_events,
            })

            return seed.state

    def _check_advancement_requirements(self, seed: Seed, current_idx: int) -> bool:
        """Check if seed meets requirements to advance lifecycle."""
        # DORMANT → GERMINATING: Just needs to exist
        if current_idx == 0:
            return True

        # GERMINATING → SAPLING: Need some activity
        if current_idx == 1:
            return seed.poi_events >= 1

        # SAPLING → MATURE: Need consistent activity
        if current_idx == 2:
            return seed.poi_events >= 5 and seed.ihsan_score >= 0.8

        # MATURE → FRUITING: Need excellence (reproduction ready)
        if current_idx == 3:
            return (
                seed.poi_events >= REPRODUCTION_REQUIREMENTS["min_poi_events"]
                and seed.ihsan_score >= REPRODUCTION_REQUIREMENTS["min_ihsan_score"]
                and seed.covenant_accepted
            )

        # FRUITING → ELDER: Network governance
        if current_idx == 4:
            return (
                len(seed.children) >= 3
                and seed.poi_events >= 50
                and seed.ihsan_score >= 0.98
            )

        return False

    def can_reproduce(self, seed_id: str) -> bool:
        """
        Check if seed can create offspring.

        Requirements:
        - State is FRUITING or ELDER
        - Ihsān score >= 0.95
        - PoI events >= 10
        - Covenant accepted
        - Children count < max_children (7)
        - Age >= 7 days
        """
        with self._lock:
            if seed_id not in self._seeds:
                return False

            seed = self._seeds[seed_id]

            # Must be in FRUITING or ELDER state
            if seed.state not in [SeedState.FRUITING, SeedState.ELDER]:
                return False

            # Check Ihsān threshold
            if seed.ihsan_score < REPRODUCTION_REQUIREMENTS["min_ihsan_score"]:
                return False

            # Check PoI threshold
            if seed.poi_events < REPRODUCTION_REQUIREMENTS["min_poi_events"]:
                return False

            # Check covenant
            if REPRODUCTION_REQUIREMENTS["covenant_required"] and not seed.covenant_accepted:
                return False

            # Check max children
            if len(seed.children) >= REPRODUCTION_REQUIREMENTS["max_children"]:
                return False

            # Check age (only if germinated)
            if seed.germinated_at:
                age_days = (datetime.utcnow() - seed.germinated_at).days
                if age_days < REPRODUCTION_REQUIREMENTS["min_age_days"]:
                    return False

            return True

    def record_poi_event(self, seed_id: str, event: Dict[str, Any]) -> bool:
        """
        Record a Proof-of-Impact event for a seed.

        Args:
            seed_id: Seed that performed the action
            event: Event details (type, impact, etc.)

        Returns:
            True if recorded, False if seed not found
        """
        with self._lock:
            if seed_id not in self._seeds:
                return False

            seed = self._seeds[seed_id]
            seed.poi_events += 1

            # Update Ihsān score based on event quality
            impact_score = event.get("impact_score", 0.01)
            seed.ihsan_score = min(1.0, seed.ihsan_score + impact_score * 0.1)

            self._save_seeds()

            self._emit_receipt("poi_event", seed_id, {
                "event_type": event.get("type", "unknown"),
                "impact_score": impact_score,
                "total_poi_events": seed.poi_events,
                "new_ihsan_score": seed.ihsan_score,
            })

            return True

    def accept_covenant(self, seed_id: str) -> bool:
        """
        Record covenant acceptance for a seed.

        Args:
            seed_id: Seed accepting the covenant

        Returns:
            True if accepted, False if seed not found
        """
        with self._lock:
            if seed_id not in self._seeds:
                return False

            seed = self._seeds[seed_id]
            seed.covenant_accepted = True

            self._save_seeds()

            self._emit_receipt("covenant_accepted", seed_id, {
                "accepted_at": datetime.utcnow().isoformat(),
            })

            return True

    def get_lineage(self, seed_id: str) -> List[Seed]:
        """
        Get full lineage from seed back to Node0.

        Args:
            seed_id: Starting seed

        Returns:
            List of seeds from Node0 to seed_id (inclusive)
        """
        with self._lock:
            lineage = []
            current_id = seed_id

            while current_id and current_id in self._seeds:
                seed = self._seeds[current_id]
                lineage.insert(0, seed)
                current_id = seed.parent_id

            return lineage

    def get_seed(self, seed_id: str) -> Optional[Seed]:
        """Get seed by ID."""
        with self._lock:
            return self._seeds.get(seed_id)

    def get_all_seeds(self) -> List[Seed]:
        """Get all seeds in the forest."""
        with self._lock:
            return list(self._seeds.values())

    def get_forest_stats(self) -> Dict[str, Any]:
        """Get statistics about the seed forest."""
        with self._lock:
            state_counts = {state.value: 0 for state in SeedState}
            total_poi = 0
            total_tokens = 0.0
            max_depth = 0

            for seed in self._seeds.values():
                state_counts[seed.state.value] += 1
                total_poi += seed.poi_events
                total_tokens += seed.token_balance
                max_depth = max(max_depth, seed.depth)

            return {
                "total_seeds": len(self._seeds),
                "state_distribution": state_counts,
                "total_poi_events": total_poi,
                "total_token_balance": total_tokens,
                "max_depth": max_depth,
                "can_reproduce_count": sum(
                    1 for sid in self._seeds if self.can_reproduce(sid)
                ),
            }

    def update_token_balance(self, seed_id: str, amount: float) -> bool:
        """
        Update off-chain BZR token balance for a seed.

        Args:
            seed_id: Seed ID
            amount: Amount to add (can be negative)

        Returns:
            True if updated, False if seed not found or balance would go negative
        """
        with self._lock:
            if seed_id not in self._seeds:
                return False

            seed = self._seeds[seed_id]
            new_balance = seed.token_balance + amount

            if new_balance < 0:
                return False

            seed.token_balance = new_balance
            self._save_seeds()

            self._emit_receipt("token_transfer", seed_id, {
                "amount": amount,
                "new_balance": new_balance,
            })

            return True
