#!/usr/bin/env python3
"""
BIZRA Multimodal Perception Layer
=================================

State-of-the-art multimodal AI capabilities:
- Vision: Image analysis via qwen3-vl-8b
- Voice: Audio transcription via Whisper
- Unified context: Cross-modal understanding

BIZRA: The seed of human freedom from algorithmic manipulation.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import uuid

logger = logging.getLogger("bizra.multimodal")


# ============================================================
# Configuration
# ============================================================

class MultimodalConfig:
    """Multimodal perception configuration."""

    # Vision
    LMSTUDIO_URL = os.getenv("LMSTUDIO_URL", "http://192.168.56.1:1234")
    VISION_MODEL = "qwen3-vl-8b"

    # Voice
    WHISPER_MODEL = os.getenv("WHISPER_MODEL", "base")
    WHISPER_LANGUAGE = os.getenv("WHISPER_LANGUAGE", "en")

    # Limits
    MAX_IMAGE_SIZE_MB = 10
    MAX_AUDIO_DURATION_SEC = 300
    TIMEOUT_SECONDS = 120


# ============================================================
# Data Classes
# ============================================================

class ModalityType(Enum):
    """Supported modalities."""
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"  # Future


@dataclass
class PerceptionResult:
    """Result from multimodal perception."""
    modality: ModalityType
    content: str
    confidence: float
    metadata: Dict[str, Any]
    duration_ms: float
    receipt_id: str
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            **asdict(self),
            "modality": self.modality.value,
        }


@dataclass
class VisionAnalysis:
    """Vision analysis result."""
    description: str
    objects_detected: List[str]
    text_extracted: str
    confidence: float
    dimensions: Tuple[int, int]  # width, height


@dataclass
class VoiceTranscription:
    """Voice transcription result."""
    text: str
    language: str
    confidence: float
    duration_seconds: float
    segments: List[Dict[str, Any]]


# ============================================================
# Vision Perception
# ============================================================

class VisionPerception:
    """
    Vision perception using qwen3-vl-8b via LM Studio.

    Capabilities:
    - Image description
    - Object detection
    - Text extraction (OCR)
    - Scene understanding
    """

    def __init__(self):
        self.logger = logging.getLogger("bizra.multimodal.vision")
        self._session = None

    async def _get_session(self):
        if self._session is None:
            import aiohttp
            self._session = aiohttp.ClientSession()
        return self._session

    async def close(self):
        if self._session:
            await self._session.close()
            self._session = None

    def _encode_image(self, image_path: Path) -> str:
        """Encode image to base64."""
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")

    def _get_mime_type(self, path: Path) -> str:
        """Get MIME type for image."""
        suffix = path.suffix.lower()
        mime_types = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".gif": "image/gif",
            ".webp": "image/webp",
            ".bmp": "image/bmp",
        }
        return mime_types.get(suffix, "image/png")

    async def analyze_image(
        self,
        image_path: Union[str, Path],
        prompt: str = "Describe this image in detail.",
    ) -> PerceptionResult:
        """
        Analyze an image using vision model.

        Args:
            image_path: Path to the image file
            prompt: Analysis prompt

        Returns:
            PerceptionResult with analysis
        """
        import aiohttp

        start = time.time()
        receipt_id = f"VIS-{uuid.uuid4().hex[:8].upper()}"
        timestamp = datetime.now(timezone.utc).isoformat()

        image_path = Path(image_path)

        if not image_path.exists():
            return PerceptionResult(
                modality=ModalityType.IMAGE,
                content=f"Error: Image not found: {image_path}",
                confidence=0.0,
                metadata={"error": "file_not_found"},
                duration_ms=(time.time() - start) * 1000,
                receipt_id=receipt_id,
                timestamp=timestamp,
            )

        # Check file size
        size_mb = image_path.stat().st_size / (1024 * 1024)
        if size_mb > MultimodalConfig.MAX_IMAGE_SIZE_MB:
            return PerceptionResult(
                modality=ModalityType.IMAGE,
                content=f"Error: Image too large: {size_mb:.1f}MB > {MultimodalConfig.MAX_IMAGE_SIZE_MB}MB",
                confidence=0.0,
                metadata={"error": "file_too_large", "size_mb": size_mb},
                duration_ms=(time.time() - start) * 1000,
                receipt_id=receipt_id,
                timestamp=timestamp,
            )

        # Encode image
        image_base64 = self._encode_image(image_path)
        mime_type = self._get_mime_type(image_path)

        # Build request
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{mime_type};base64,{image_base64}"
                        }
                    }
                ]
            }
        ]

        try:
            session = await self._get_session()
            async with session.post(
                f"{MultimodalConfig.LMSTUDIO_URL}/v1/chat/completions",
                json={
                    "model": MultimodalConfig.VISION_MODEL,
                    "messages": messages,
                    "temperature": 0.1,
                    "max_tokens": 1000,
                },
                timeout=aiohttp.ClientTimeout(total=MultimodalConfig.TIMEOUT_SECONDS)
            ) as resp:
                duration = (time.time() - start) * 1000

                if resp.status == 200:
                    data = await resp.json()
                    content = data.get("choices", [{}])[0].get("message", {}).get("content", "")

                    return PerceptionResult(
                        modality=ModalityType.IMAGE,
                        content=content,
                        confidence=0.9,
                        metadata={
                            "model": MultimodalConfig.VISION_MODEL,
                            "image_path": str(image_path),
                            "size_mb": size_mb,
                            "prompt": prompt,
                        },
                        duration_ms=duration,
                        receipt_id=receipt_id,
                        timestamp=timestamp,
                    )
                else:
                    return PerceptionResult(
                        modality=ModalityType.IMAGE,
                        content=f"Error: HTTP {resp.status}",
                        confidence=0.0,
                        metadata={"error": f"http_{resp.status}"},
                        duration_ms=duration,
                        receipt_id=receipt_id,
                        timestamp=timestamp,
                    )

        except asyncio.TimeoutError:
            return PerceptionResult(
                modality=ModalityType.IMAGE,
                content="Error: Vision analysis timeout",
                confidence=0.0,
                metadata={"error": "timeout"},
                duration_ms=(time.time() - start) * 1000,
                receipt_id=receipt_id,
                timestamp=timestamp,
            )
        except Exception as e:
            self.logger.error(f"Vision analysis error: {e}")
            return PerceptionResult(
                modality=ModalityType.IMAGE,
                content=f"Error: {e}",
                confidence=0.0,
                metadata={"error": str(e)},
                duration_ms=(time.time() - start) * 1000,
                receipt_id=receipt_id,
                timestamp=timestamp,
            )


# ============================================================
# Voice Perception
# ============================================================

class VoicePerception:
    """
    Voice perception using Whisper.

    Capabilities:
    - Audio transcription
    - Language detection
    - Speaker diarization (future)
    """

    def __init__(self):
        self.logger = logging.getLogger("bizra.multimodal.voice")
        self._whisper_available = self._check_whisper()

    def _check_whisper(self) -> bool:
        """Check if Whisper is available."""
        try:
            import whisper
            return True
        except ImportError:
            try:
                # Try faster-whisper
                import faster_whisper
                return True
            except ImportError:
                self.logger.warning("Whisper not available. Install with: pip install openai-whisper")
                return False

    async def transcribe_audio(
        self,
        audio_path: Union[str, Path],
        language: Optional[str] = None,
    ) -> PerceptionResult:
        """
        Transcribe audio file.

        Args:
            audio_path: Path to audio file
            language: Optional language hint

        Returns:
            PerceptionResult with transcription
        """
        start = time.time()
        receipt_id = f"VOI-{uuid.uuid4().hex[:8].upper()}"
        timestamp = datetime.now(timezone.utc).isoformat()

        audio_path = Path(audio_path)

        if not audio_path.exists():
            return PerceptionResult(
                modality=ModalityType.AUDIO,
                content=f"Error: Audio not found: {audio_path}",
                confidence=0.0,
                metadata={"error": "file_not_found"},
                duration_ms=(time.time() - start) * 1000,
                receipt_id=receipt_id,
                timestamp=timestamp,
            )

        if not self._whisper_available:
            # Fallback to external whisper CLI
            return await self._transcribe_cli(audio_path, language, receipt_id, timestamp, start)

        try:
            # Use faster-whisper if available
            try:
                from faster_whisper import WhisperModel

                model = WhisperModel(
                    MultimodalConfig.WHISPER_MODEL,
                    device="cpu",
                    compute_type="int8"
                )

                segments, info = model.transcribe(
                    str(audio_path),
                    language=language or MultimodalConfig.WHISPER_LANGUAGE,
                )

                text = " ".join([seg.text for seg in segments])
                duration = (time.time() - start) * 1000

                return PerceptionResult(
                    modality=ModalityType.AUDIO,
                    content=text.strip(),
                    confidence=0.9,
                    metadata={
                        "model": f"faster-whisper-{MultimodalConfig.WHISPER_MODEL}",
                        "language": info.language,
                        "language_probability": info.language_probability,
                        "audio_path": str(audio_path),
                    },
                    duration_ms=duration,
                    receipt_id=receipt_id,
                    timestamp=timestamp,
                )

            except ImportError:
                # Fall back to openai-whisper
                import whisper

                model = whisper.load_model(MultimodalConfig.WHISPER_MODEL)
                result = model.transcribe(
                    str(audio_path),
                    language=language,
                )

                duration = (time.time() - start) * 1000

                return PerceptionResult(
                    modality=ModalityType.AUDIO,
                    content=result["text"].strip(),
                    confidence=0.85,
                    metadata={
                        "model": f"whisper-{MultimodalConfig.WHISPER_MODEL}",
                        "language": result.get("language", "unknown"),
                        "audio_path": str(audio_path),
                    },
                    duration_ms=duration,
                    receipt_id=receipt_id,
                    timestamp=timestamp,
                )

        except Exception as e:
            self.logger.error(f"Transcription error: {e}")
            return PerceptionResult(
                modality=ModalityType.AUDIO,
                content=f"Error: {e}",
                confidence=0.0,
                metadata={"error": str(e)},
                duration_ms=(time.time() - start) * 1000,
                receipt_id=receipt_id,
                timestamp=timestamp,
            )

    async def _transcribe_cli(
        self,
        audio_path: Path,
        language: Optional[str],
        receipt_id: str,
        timestamp: str,
        start: float,
    ) -> PerceptionResult:
        """Transcribe using whisper CLI."""
        try:
            cmd = [
                "whisper",
                str(audio_path),
                "--model", MultimodalConfig.WHISPER_MODEL,
                "--output_format", "json",
            ]
            if language:
                cmd.extend(["--language", language])

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=MultimodalConfig.TIMEOUT_SECONDS,
            )

            if result.returncode == 0:
                # Parse JSON output
                output_file = audio_path.with_suffix(".json")
                if output_file.exists():
                    with open(output_file) as f:
                        data = json.load(f)
                    text = data.get("text", "")
                    output_file.unlink()  # Cleanup

                    return PerceptionResult(
                        modality=ModalityType.AUDIO,
                        content=text.strip(),
                        confidence=0.8,
                        metadata={
                            "model": f"whisper-cli-{MultimodalConfig.WHISPER_MODEL}",
                            "audio_path": str(audio_path),
                        },
                        duration_ms=(time.time() - start) * 1000,
                        receipt_id=receipt_id,
                        timestamp=timestamp,
                    )

            return PerceptionResult(
                modality=ModalityType.AUDIO,
                content=f"Error: CLI failed: {result.stderr}",
                confidence=0.0,
                metadata={"error": "cli_failed"},
                duration_ms=(time.time() - start) * 1000,
                receipt_id=receipt_id,
                timestamp=timestamp,
            )

        except Exception as e:
            return PerceptionResult(
                modality=ModalityType.AUDIO,
                content=f"Error: {e}",
                confidence=0.0,
                metadata={"error": str(e)},
                duration_ms=(time.time() - start) * 1000,
                receipt_id=receipt_id,
                timestamp=timestamp,
            )


# ============================================================
# Unified Multimodal Interface
# ============================================================

class MultimodalPerception:
    """
    Unified multimodal perception interface.

    Combines vision and voice into a single API.
    """

    def __init__(self):
        self.vision = VisionPerception()
        self.voice = VoicePerception()
        self.logger = logging.getLogger("bizra.multimodal")

    async def close(self):
        """Cleanup resources."""
        await self.vision.close()

    async def perceive(
        self,
        input_path: Union[str, Path],
        modality: Optional[ModalityType] = None,
        prompt: Optional[str] = None,
    ) -> PerceptionResult:
        """
        Perceive input using appropriate modality.

        Auto-detects modality based on file extension if not specified.
        """
        input_path = Path(input_path)
        suffix = input_path.suffix.lower()

        # Auto-detect modality
        if modality is None:
            if suffix in [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"]:
                modality = ModalityType.IMAGE
            elif suffix in [".mp3", ".wav", ".m4a", ".ogg", ".flac", ".webm"]:
                modality = ModalityType.AUDIO
            else:
                modality = ModalityType.TEXT

        # Route to appropriate perception
        if modality == ModalityType.IMAGE:
            return await self.vision.analyze_image(
                input_path,
                prompt or "Describe this image in detail."
            )
        elif modality == ModalityType.AUDIO:
            return await self.voice.transcribe_audio(input_path)
        else:
            # Text modality - just read the file
            start = time.time()
            receipt_id = f"TXT-{uuid.uuid4().hex[:8].upper()}"
            timestamp = datetime.now(timezone.utc).isoformat()

            try:
                content = input_path.read_text(encoding="utf-8")
                return PerceptionResult(
                    modality=ModalityType.TEXT,
                    content=content,
                    confidence=1.0,
                    metadata={"file_path": str(input_path)},
                    duration_ms=(time.time() - start) * 1000,
                    receipt_id=receipt_id,
                    timestamp=timestamp,
                )
            except Exception as e:
                return PerceptionResult(
                    modality=ModalityType.TEXT,
                    content=f"Error: {e}",
                    confidence=0.0,
                    metadata={"error": str(e)},
                    duration_ms=(time.time() - start) * 1000,
                    receipt_id=receipt_id,
                    timestamp=timestamp,
                )

    async def analyze_screenshot(
        self,
        screenshot_path: Union[str, Path],
        analysis_type: str = "ui",
    ) -> PerceptionResult:
        """
        Analyze a screenshot for specific purposes.

        Analysis types:
        - ui: UI/UX analysis
        - code: Code screenshot analysis
        - diagram: Architecture/diagram analysis
        - evidence: Evidence verification
        """
        prompts = {
            "ui": "Analyze this UI screenshot. Describe the layout, components, and any usability observations.",
            "code": "Analyze this code screenshot. Identify the programming language, describe what the code does, and note any issues.",
            "diagram": "Analyze this diagram. Describe the architecture, components, and their relationships.",
            "evidence": "Analyze this image as evidence. Describe what it shows and any relevant details for verification.",
        }

        prompt = prompts.get(analysis_type, prompts["ui"])
        return await self.vision.analyze_image(screenshot_path, prompt)


# ============================================================
# Demo / Test
# ============================================================

async def demo():
    """Demo multimodal capabilities."""
    print("\n" + "=" * 60)
    print("  BIZRA MULTIMODAL PERCEPTION DEMO")
    print("=" * 60)

    perception = MultimodalPerception()

    try:
        # Test vision availability
        print("\n  Vision Model: ", end="")
        import aiohttp
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{MultimodalConfig.LMSTUDIO_URL}/v1/models",
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        models = [m.get("id", "") for m in data.get("data", [])]
                        if any("vl" in m.lower() or "vision" in m.lower() for m in models):
                            print("AVAILABLE (Vision model detected)")
                        else:
                            print("PARTIAL (No vision model loaded)")
                    else:
                        print("UNAVAILABLE")
        except Exception:
            print("UNAVAILABLE (LM Studio not reachable)")

        # Test voice availability
        print("  Voice Model: ", end="")
        try:
            import whisper
            print("AVAILABLE (openai-whisper)")
        except ImportError:
            try:
                import faster_whisper
                print("AVAILABLE (faster-whisper)")
            except ImportError:
                print("NOT INSTALLED (pip install openai-whisper)")

        print("\n  Multimodal Perception Layer: READY")
        print("  " + "-" * 56)
        print("  Use cases:")
        print("    - Image analysis for evidence verification")
        print("    - Screenshot analysis for UI validation")
        print("    - Audio transcription for voice commands")
        print("    - Cross-modal context understanding")

    finally:
        await perception.close()


if __name__ == "__main__":
    asyncio.run(demo())
