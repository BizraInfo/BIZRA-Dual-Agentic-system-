"""
BIZRA Genesis Sealer
====================
Creates the "Genesis Receipt" - the root of trust for the hash chain.
Seals the Constitution and establishes the initial state.
"""

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Dict, Any

# In a real scenario, private key comes from HSM/Vault
# Here we simulate with a generated key for demonstration if not provided
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

CONSTITUTION_PATH = Path(os.getenv("BIZRA_IHSAN_CONSTITUTION", "constitution/ihsan_v1.yaml"))
RECEIPTS_DIR = Path(os.getenv("BIZRA_RECEIPTS_DIR", "docs/evidence/receipts"))

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk: break
            h.update(chunk)
    return h.hexdigest()

def create_genesis_receipt():
    print("🌟 Initiating Genesis Seal...")
    
    # 1. Load Policy
    if not CONSTITUTION_PATH.exists():
        print(f"❌ Constitution not found at {CONSTITUTION_PATH}")
        return
        
    policy_hash = sha256_file(CONSTITUTION_PATH)
    print(f"📜 Constitution Hash: {policy_hash}")
    
    # 2. Generate/Load Identity (Simulated)
    # In prod, load from BIZRA_NODE_KEY
    priv_key = Ed25519PrivateKey.generate()
    pub_key_hex = priv_key.public_key().public_bytes_raw().hex()
    
    node_id = "node_0"
    print(f"🔑 Node Identity: {node_id} ({pub_key_hex[:8]}...)")
    
    # 3. Create Genesis Payload
    genesis_payload = {
        "event": "GENESIS_SEAL",
        "node_id": node_id,
        "policy_ref": "ihsan_v1",
        "policy_hash": policy_hash,
        "timestamp": time.time(),
        "prev_hash": "0000000000000000000000000000000000000000000000000000000000000000", # Genesis constant
        "message": "BIZRA Node0 Sovereign Activation"
    }
    
    # Canonicalize
    payload_bytes = json.dumps(genesis_payload, sort_keys=True, separators=(',', ':')).encode('utf-8')
    
    # 4. Sign
    signature = priv_key.sign(payload_bytes)
    sig_hex = signature.hex()
    
    # 5. Form Receipt
    receipt = {
        "receipt_id": "receipt_0",
        "type": "GENESIS",
        "payload": genesis_payload,
        "signature": sig_hex,
        "signer_pubkey": pub_key_hex # Self-signed for genesis (should be trusted via out-of-band registry)
    }
    
    # 6. Save
    RECEIPTS_DIR.mkdir(parents=True, exist_ok=True)
    outfile = RECEIPTS_DIR / "genesis_receipt.json"
    with open(outfile, "w") as f:
        json.dump(receipt, f, indent=2)
        
    print(f"✅ Genesis Receipt Sealed: {outfile}")
    print(f"   Signature: {sig_hex[:16]}...")

if __name__ == "__main__":
    create_genesis_receipt()
