"""
bizra_kernel/hop_orchestrator.py - Multi-Hop Reasoning Orchestrator
=====================================================================

Implements multi-hop reasoning with progressive SAPE validation.
Each hop:
1. Retrieves relevant nodes from Gold Mine
2. Generates thoughts via GoT
3. Validates via SAPE probes
4. Accumulates context for next hop

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                    HOP ORCHESTRATOR                             │
    ├─────────────────────────────────────────────────────────────────┤
    │                                                                 │
    │  Query → [Hop 1] → [Hop 2] → [Hop 3] → Synthesized Answer      │
    │            ↓         ↓         ↓                                │
    │         Retrieve  Retrieve  Retrieve                            │
    │            ↓         ↓         ↓                                │
    │          Think     Think     Think                              │
    │            ↓         ↓         ↓                                │
    │         Validate  Validate  Validate                            │
    │            ↓         ↓         ↓                                │
    │        Accumulate Accumulate Accumulate                         │
    │                                                                 │
    │  SAPE Validation at each hop (fail-fast on threshold breach)   │
    │  Evidence receipt generation for audit trail                    │
    └─────────────────────────────────────────────────────────────────┘

Part of BIZRA Genesis Gold Mine Integration
"""

import hashlib
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Default validation threshold (can be overridden per session)
DEFAULT_VALIDATION_THRESHOLD = 0.85


class HopStatus(Enum):
    """Status of a reasoning hop."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    VALIDATED = "validated"
    FAILED_VALIDATION = "failed_validation"
    COMPLETED = "completed"
    SKIPPED = "skipped"


@dataclass
class ReasoningHop:
    """A single hop in multi-hop reasoning."""
    hop_number: int
    query: str
    status: HopStatus = HopStatus.PENDING
    retrieved_nodes: List[Dict[str, Any]] = field(default_factory=list)
    thought_content: str = ""
    thought_id: Optional[str] = None
    sape_validation: Dict[str, float] = field(default_factory=dict)
    ihsan_score: float = 0.0
    accumulated_context: str = ""
    latency_ms: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "hop_number": self.hop_number,
            "query": self.query,
            "status": self.status.value,
            "retrieved_count": len(self.retrieved_nodes),
            "thought_content": self.thought_content[:200] if self.thought_content else "",
            "thought_id": self.thought_id,
            "ihsan_score": self.ihsan_score,
            "sape_validation": self.sape_validation,
            "latency_ms": self.latency_ms,
            "timestamp": self.timestamp,
        }


@dataclass
class HopPlan:
    """Plan for multi-hop reasoning."""
    original_query: str
    planned_hops: List[str]  # Sub-queries for each hop
    max_hops: int
    validation_threshold: float
    entities_detected: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original_query": self.original_query,
            "planned_hops": self.planned_hops,
            "max_hops": self.max_hops,
            "validation_threshold": self.validation_threshold,
            "entities_detected": self.entities_detected,
        }


class HopValidationError(Exception):
    """Raised when a hop fails SAPE validation."""

    def __init__(self, hop_number: int, ihsan_score: float, threshold: float):
        self.hop_number = hop_number
        self.ihsan_score = ihsan_score
        self.threshold = threshold
        super().__init__(
            f"Hop {hop_number} failed validation: "
            f"Ihsan score {ihsan_score:.3f} < threshold {threshold:.3f}"
        )


class HopOrchestrator:
    """
    Multi-hop reasoning with progressive SAPE validation.

    Features:
    - Query decomposition into sub-queries
    - Gold Mine knowledge retrieval per hop
    - GoT thought generation
    - SAPE validation (fail-fast)
    - Context accumulation
    - Evidence receipt generation

    Usage:
        from bizra_kernel.gold_mine_connector import GoldMineConnector
        from bizra_kernel.got_orchestrator import GoTOrchestrator

        gold_mine = GoldMineConnector()
        await gold_mine.initialize()

        got = GoTOrchestrator("session-001")
        orch = HopOrchestrator("session-001", gold_mine, got)

        plan = await orch.plan_hops("How does BIZRA SAPE work?", max_hops=3)
        hops, answer = await orch.execute_plan(plan)
    """

    def __init__(
        self,
        session_id: str,
        gold_mine,
        got_orchestrator=None,
        sape_validator=None,
        validation_threshold: float = DEFAULT_VALIDATION_THRESHOLD,
    ):
        """
        Initialize hop orchestrator.

        Args:
            session_id: Unique session identifier
            gold_mine: GoldMineConnector instance
            got_orchestrator: Optional GoTOrchestrator instance
            sape_validator: Optional SAPE validation function
            validation_threshold: Minimum Ihsan score for hop validation
        """
        self.session_id = session_id
        self.gold_mine = gold_mine
        self.got = got_orchestrator
        self.sape_validator = sape_validator
        self.validation_threshold = validation_threshold

        # Execution state
        self.hops: List[ReasoningHop] = []
        self.total_latency_ms: float = 0.0
        self.start_time: Optional[float] = None

    async def plan_hops(
        self,
        query: str,
        max_hops: int = 3,
    ) -> HopPlan:
        """
        Decompose query into sub-queries based on entities and complexity.

        This uses a simple entity-based decomposition strategy:
        1. Extract entities from the query
        2. Create sub-queries for each significant entity
        3. Add a synthesis query at the end

        Args:
            query: Original user query
            max_hops: Maximum number of hops to plan

        Returns:
            HopPlan with planned sub-queries
        """
        # Extract entities from query
        entities = self._extract_entities(query)

        # Plan sub-queries
        sub_queries = []

        # Hop 1: Core question focused on main entity
        if entities:
            main_entity = entities[0]
            sub_queries.append(f"What is {main_entity} and what are its key components?")
        else:
            sub_queries.append(f"What are the key concepts in: {query}")

        # Hop 2: Relationship exploration
        if len(entities) >= 2:
            sub_queries.append(f"How do {entities[0]} and {entities[1]} relate to each other?")
        elif len(sub_queries) < max_hops:
            sub_queries.append(f"What are the important relationships in: {query}")

        # Hop 3: Synthesis and application
        if len(sub_queries) < max_hops:
            sub_queries.append(f"Synthesize the answer to: {query}")

        # Limit to max_hops
        sub_queries = sub_queries[:max_hops]

        return HopPlan(
            original_query=query,
            planned_hops=sub_queries,
            max_hops=max_hops,
            validation_threshold=self.validation_threshold,
            entities_detected=entities,
        )

    def _extract_entities(self, query: str) -> List[str]:
        """Extract significant entities from query."""
        entities = []

        # BIZRA-specific terms
        bizra_terms = [
            "BIZRA", "SAPE", "Ihsan", "FATE", "PAT", "SAT",
            "GoT", "SNR", "probe", "kernel", "constitution",
            "Gold Mine", "receipt", "validation", "threshold",
        ]

        query_lower = query.lower()
        for term in bizra_terms:
            if term.lower() in query_lower:
                entities.append(term)

        # Extract capitalized words (potential entities)
        for word in query.split():
            clean = word.strip(".,?!:;\"'()[]")
            if (
                len(clean) > 2
                and clean[0].isupper()
                and clean not in entities
                and clean.lower() not in ["how", "what", "why", "where", "when", "the", "and", "for"]
            ):
                entities.append(clean)

        return entities[:5]  # Limit to 5 entities

    async def execute_hop(
        self,
        hop_query: str,
        hop_number: int,
        context: str = "",
    ) -> ReasoningHop:
        """
        Execute a single reasoning hop.

        Steps:
        1. Retrieve relevant nodes from Gold Mine
        2. Generate thought via GoT (if available)
        3. Validate via SAPE probes
        4. Accumulate context

        Args:
            hop_query: Query for this hop
            hop_number: Sequential hop number
            context: Accumulated context from previous hops

        Returns:
            ReasoningHop with results

        Raises:
            HopValidationError: If SAPE validation fails
        """
        hop_start = time.perf_counter()

        hop = ReasoningHop(
            hop_number=hop_number,
            query=hop_query,
            status=HopStatus.IN_PROGRESS,
            accumulated_context=context,
        )

        try:
            # Step 1: Retrieve from Gold Mine
            if self.gold_mine is not None:
                entities = self._extract_entities(hop_query)
                for entity in entities[:3]:
                    nodes = self.gold_mine.query_by_entity(entity, limit=5)
                    for node in nodes:
                        hop.retrieved_nodes.append(node.to_dict())

            # Step 2: Generate thought
            thought_content = self._generate_thought(hop_query, hop.retrieved_nodes, context)
            hop.thought_content = thought_content

            # Link to GoT if available
            if self.got is not None:
                from bizra_kernel.got_orchestrator import RelationType

                thought_node = self.got.add_thought(
                    content=thought_content,
                    lens="knowledge",
                    snr=0.0,  # Will be updated after validation
                )
                hop.thought_id = thought_node.id

                # Link to previous hop's thought if exists
                if len(self.hops) > 0 and self.hops[-1].thought_id:
                    self.got.link_thoughts(
                        self.hops[-1].thought_id,
                        thought_node.id,
                        RelationType.DERIVES,
                    )

            # Step 3: SAPE validation
            hop.sape_validation, hop.ihsan_score = await self._validate_hop(thought_content)

            # Update GoT SNR if available
            if self.got is not None and hop.thought_id:
                if hop.thought_id in self.got.nodes:
                    self.got.nodes[hop.thought_id].snr_score = hop.ihsan_score

            # Check threshold (fail-fast)
            if hop.ihsan_score < self.validation_threshold:
                hop.status = HopStatus.FAILED_VALIDATION
                hop.latency_ms = (time.perf_counter() - hop_start) * 1000
                raise HopValidationError(
                    hop_number=hop_number,
                    ihsan_score=hop.ihsan_score,
                    threshold=self.validation_threshold,
                )

            # Step 4: Accumulate context
            new_context = self._build_accumulated_context(hop)
            hop.accumulated_context = new_context
            hop.status = HopStatus.VALIDATED

        except HopValidationError:
            raise
        except Exception as e:
            logger.error("Hop %d execution error: %s", hop_number, e)
            hop.status = HopStatus.FAILED_VALIDATION
            hop.sape_validation["error"] = str(e)

        hop.latency_ms = (time.perf_counter() - hop_start) * 1000
        return hop

    def _generate_thought(
        self,
        query: str,
        retrieved_nodes: List[Dict[str, Any]],
        context: str,
    ) -> str:
        """Generate thought content based on query and retrieved information."""
        parts = []

        # Include context from previous hops
        if context:
            parts.append(f"[Prior Context]\n{context[:500]}")

        # Include retrieved knowledge
        if retrieved_nodes:
            node_summaries = []
            for node in retrieved_nodes[:5]:
                summary = f"- [{node.get('kind', 'Unknown')}] {node.get('label', 'Unknown')}"
                if node.get('source'):
                    summary += f" (from: {node['source']})"
                node_summaries.append(summary)
            parts.append(f"[Retrieved Knowledge]\n" + "\n".join(node_summaries))

        # Add the query
        parts.append(f"[Query]\n{query}")

        # Generate a synthesis (in production, this would use an LLM)
        parts.append(f"[Synthesis]\nBased on the retrieved knowledge, addressing: {query}")

        return "\n\n".join(parts)

    async def _validate_hop(
        self,
        content: str,
    ) -> Tuple[Dict[str, float], float]:
        """
        Validate hop content via SAPE probes.

        Returns:
            Tuple of (validation_scores_dict, overall_ihsan_score)
        """
        if self.sape_validator is not None:
            # Use provided validator
            return await self.sape_validator(content)

        # Default validation (heuristic-based)
        scores = {
            "groundedness": 0.85,
            "relevance": 0.88,
            "safety": 0.95,
            "correctness": 0.82,
        }

        # Adjust based on content characteristics
        if len(content) < 50:
            scores["groundedness"] *= 0.9
            scores["correctness"] *= 0.9

        if "[Retrieved Knowledge]" in content:
            scores["groundedness"] *= 1.05  # Boost for grounded content

        # Calculate Ihsan score (simplified weighted average)
        weights = {
            "groundedness": 0.25,
            "relevance": 0.25,
            "safety": 0.30,
            "correctness": 0.20,
        }

        ihsan = sum(scores[k] * weights[k] for k in scores)
        return scores, min(ihsan, 1.0)

    def _build_accumulated_context(self, hop: ReasoningHop) -> str:
        """Build accumulated context including this hop's findings."""
        context_parts = []

        # Include previous context
        if hop.accumulated_context:
            context_parts.append(hop.accumulated_context)

        # Add this hop's contribution
        contribution = f"[Hop {hop.hop_number}] {hop.query}\n"
        contribution += f"Found {len(hop.retrieved_nodes)} relevant nodes. "
        contribution += f"Ihsan: {hop.ihsan_score:.3f}"

        if hop.thought_content:
            # Extract synthesis portion
            if "[Synthesis]" in hop.thought_content:
                synthesis = hop.thought_content.split("[Synthesis]")[-1].strip()
                contribution += f"\nSynthesis: {synthesis[:200]}"

        context_parts.append(contribution)

        return "\n\n".join(context_parts)

    async def execute_plan(
        self,
        plan: HopPlan,
    ) -> Tuple[List[ReasoningHop], str]:
        """
        Execute all planned hops.

        Args:
            plan: HopPlan from plan_hops()

        Returns:
            Tuple of (list_of_hops, final_synthesized_answer)
        """
        self.start_time = time.perf_counter()
        self.hops = []
        context = ""

        for i, hop_query in enumerate(plan.planned_hops):
            hop = await self.execute_hop(hop_query, i + 1, context)
            self.hops.append(hop)

            if hop.status == HopStatus.VALIDATED:
                context = hop.accumulated_context
            else:
                # Stop on validation failure
                break

        self.total_latency_ms = (time.perf_counter() - self.start_time) * 1000

        # Generate final answer
        final_answer = self._synthesize_answer(plan)

        return self.hops, final_answer

    def _synthesize_answer(self, plan: HopPlan) -> str:
        """Synthesize final answer from completed hops."""
        validated_hops = [h for h in self.hops if h.status == HopStatus.VALIDATED]

        if not validated_hops:
            return "Unable to generate answer due to validation failures."

        # Build answer from accumulated context
        last_hop = validated_hops[-1]

        answer_parts = [
            f"[Answer to: {plan.original_query}]",
            "",
            f"Based on {len(validated_hops)} reasoning hops:",
        ]

        for hop in validated_hops:
            answer_parts.append(f"  Hop {hop.hop_number}: {hop.query} (Ihsan: {hop.ihsan_score:.3f})")

        answer_parts.extend([
            "",
            "[Synthesis]",
            last_hop.accumulated_context.split("[Synthesis]")[-1].strip()[:500]
            if "[Synthesis]" in last_hop.accumulated_context
            else last_hop.accumulated_context[:500],
        ])

        return "\n".join(answer_parts)

    def get_evidence_receipt(self) -> Dict[str, Any]:
        """Generate audit receipt with hop lineage."""
        return {
            "receipt_id": hashlib.sha256(
                f"{self.session_id}:{datetime.now(timezone.utc).isoformat()}".encode()
            ).hexdigest()[:16],
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "session_id": self.session_id,
            "orchestrator": "HopOrchestrator",
            "hops": [h.to_dict() for h in self.hops],
            "total_hops_planned": len(self.hops),
            "validated_hops": len([h for h in self.hops if h.status == HopStatus.VALIDATED]),
            "failed_hops": len([h for h in self.hops if h.status == HopStatus.FAILED_VALIDATION]),
            "total_latency_ms": self.total_latency_ms,
            "validation_threshold": self.validation_threshold,
            "gold_mine_available": self.gold_mine is not None and self.gold_mine._initialized,
            "got_available": self.got is not None,
        }


if __name__ == "__main__":
    import asyncio

    async def test():
        # Test without actual Gold Mine
        orch = HopOrchestrator(
            session_id="test-001",
            gold_mine=None,
            got_orchestrator=None,
        )

        # Plan hops
        plan = await orch.plan_hops("How does BIZRA SAPE validation work?", max_hops=3)
        print(f"\nHop Plan:")
        print(f"  Query: {plan.original_query}")
        print(f"  Entities: {plan.entities_detected}")
        print(f"  Planned Hops:")
        for i, q in enumerate(plan.planned_hops, 1):
            print(f"    {i}. {q}")

        # Execute (will use mock data)
        hops, answer = await orch.execute_plan(plan)

        print(f"\nExecution Results:")
        for hop in hops:
            print(f"  Hop {hop.hop_number}: {hop.status.value} (Ihsan: {hop.ihsan_score:.3f})")

        print(f"\nFinal Answer:\n{answer[:500]}")

        print(f"\nEvidence Receipt:")
        receipt = orch.get_evidence_receipt()
        print(f"  Receipt ID: {receipt['receipt_id']}")
        print(f"  Validated: {receipt['validated_hops']}/{receipt['total_hops_planned']}")
        print(f"  Total Latency: {receipt['total_latency_ms']:.2f}ms")

    asyncio.run(test())
