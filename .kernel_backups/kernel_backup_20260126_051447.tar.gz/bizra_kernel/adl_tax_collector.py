"""
BIZRA Adl (Adalah - Justice) Tax Collector
===========================================
Implements Harberger tax mechanism for network bandwidth allocation and economic incentives.
Every Ihsān Receipt pays Harberger Tax to the network, creating a virtuous cycle of Ihsān-compliant behavior.

Key Principle: Higher Ihsān = Lower Tax (virtuous cycle)
Tax is burned (sent to 0x0 address) or redistributed to low-Gini nodes.
"""

import hashlib
import json
import logging
import time
from typing import Dict, List, Optional, Tuple
from decimal import Decimal, getcontext
from dataclasses import dataclass, field
from datetime import datetime


# Set decimal precision for financial calculations
getcontext().prec = 28


@dataclass
class TaxReceipt:
    """Receipt for Harberger tax payment."""
    task_id: str
    amount_gwei: Decimal
    ihsan_score: Decimal
    tax_rate: Decimal
    timestamp: float
    burned_address: str = "0x0000000000000000000000000000000000000000"
    tx_hash: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "amount_gwei": str(self.amount_gwei),
            "ihsan_score": str(self.ihsan_score),
            "tax_rate": str(self.tax_rate),
            "timestamp": self.timestamp,
            "burned_address": self.burned_address,
            "tx_hash": self.tx_hash,
            "human_readable": f"{self.amount_gwei} gwei (Ihsān: {self.ihsan_score})"
        }


@dataclass
class NetworkNode:
    """Network node participating in the Adl tax system."""
    node_id: str
    gini_coefficient: Decimal  # 0.0 (perfect equality) to 1.0 (perfect inequality)
    bandwidth_usage_gwei: Decimal = Decimal('0')
    tax_paid_gwei: Decimal = Decimal('0')
    ihsan_cumulative: Decimal = Decimal('0')
    last_redistribution: float = field(default_factory=time.time)
    
    def update_gini(self, new_gini: Decimal):
        """Update Gini coefficient (simplified)."""
        self.gini_coefficient = new_gini
    
    def add_tax_payment(self, amount_gwei: Decimal, ihsan_score: Decimal):
        """Record a tax payment."""
        self.tax_paid_gwei += amount_gwei
        self.ihsan_cumulative += ihsan_score


class AdlTaxCollector:
    """
    Adl (Justice) Tax Collector for Harberger tax mechanism.
    
    Implements:
    - Ihsān-adjusted tax rates (higher Ihsān = lower tax)
    - Tax burning to 0x0 address
    - Redistribution to low-Gini nodes
    - Network bandwidth economic incentives
    """
    
    def __init__(self, base_tax_rate_gwei: Decimal = Decimal('100')):
        """
        Initialize Adl tax collector.
        
        Args:
            base_tax_rate_gwei: Base tax rate in gwei per byte (default: 100 gwei/byte)
        """
        self.base_tax_rate_gwei = base_tax_rate_gwei
        self.nodes: Dict[str, NetworkNode] = {}
        self.tax_receipts: List[TaxReceipt] = []
        self.total_burned_gwei = Decimal('0')
        self.total_redistributed_gwei = Decimal('0')
        
        # Initialize with some default nodes for simulation
        self._initialize_default_nodes()
    
    def _initialize_default_nodes(self):
        """Initialize default network nodes for simulation."""
        # Node 0: Genesis node (low Gini)
        self.nodes["node_0"] = NetworkNode(
            node_id="node_0",
            gini_coefficient=Decimal('0.25'),  # Good equality
            bandwidth_usage_gwei=Decimal('0'),
            tax_paid_gwei=Decimal('0'),
            ihsan_cumulative=Decimal('0')
        )
        
        # Node 1: High bandwidth node (medium Gini)
        self.nodes["node_1"] = NetworkNode(
            node_id="node_1",
            gini_coefficient=Decimal('0.45'),
            bandwidth_usage_gwei=Decimal('1000000'),  # 1M gwei used
            tax_paid_gwei=Decimal('50000'),
            ihsan_cumulative=Decimal('4.5')
        )
        
        # Node 2: Low Ihsān node (high Gini)
        self.nodes["node_2"] = NetworkNode(
            node_id="node_2",
            gini_coefficient=Decimal('0.65'),
            bandwidth_usage_gwei=Decimal('500000'),
            tax_paid_gwei=Decimal('100000'),  # Paid more tax due to low Ihsān
            ihsan_cumulative=Decimal('2.8')
        )
    
    def compute_bandwidth_tax(self, 
                             size_bytes: int, 
                             ihsan_score: Decimal,
                             node_id: Optional[str] = None) -> Decimal:
        """
        Compute Harberger tax for bandwidth usage.
        
        Formula: tax = size_bytes * base_rate * (1 / ihsan_score)
        Higher Ihsān = lower tax (virtuous cycle)
        
        Args:
            size_bytes: Size of data in bytes.
            ihsan_score: Ihsān score (0.0 to 1.0).
            node_id: Optional node ID for node-specific adjustments.
            
        Returns:
            Decimal: Tax amount in gwei.
        """
        if ihsan_score <= Decimal('0'):
            raise ValueError("Ihsān score must be positive")
        
        # Base calculation
        base_tax = Decimal(size_bytes) * self.base_tax_rate_gwei
        
        # Ihsān adjustment: higher Ihsān = lower tax
        # Using 1/ihsan_score means perfect Ihsān (1.0) = base tax, lower Ihsān = higher tax
        ihsan_factor = Decimal('1') / ihsan_score
        
        # Node-specific adjustment based on Gini coefficient
        gini_factor = Decimal('1')
        if node_id and node_id in self.nodes:
            node = self.nodes[node_id]
            # Higher Gini = higher tax (encourages equality)
            gini_factor = Decimal('1') + node.gini_coefficient
        
        total_tax = base_tax * ihsan_factor * gini_factor
        
        # Round to nearest gwei
        return total_tax.quantize(Decimal('1'))
    
    def process_tax_payment(self,
                          task_id: str,
                          size_bytes: int,
                          ihsan_score: Decimal,
                          node_id: Optional[str] = None) -> TaxReceipt:
        """
        Process a tax payment and create a receipt.
        
        Args:
            task_id: Task identifier.
            size_bytes: Size of data in bytes.
            ihsan_score: Ihsān score (0.0 to 1.0).
            node_id: Optional node ID.
            
        Returns:
            TaxReceipt: The tax receipt.
        """
        # Compute tax
        tax_amount = self.compute_bandwidth_tax(size_bytes, ihsan_score, node_id)
        
        # Create receipt
        receipt = TaxReceipt(
            task_id=task_id,
            amount_gwei=tax_amount,
            ihsan_score=ihsan_score,
            tax_rate=self.base_tax_rate_gwei,
            timestamp=time.time(),
            tx_hash=self._generate_tx_hash(task_id, tax_amount)
        )
        
        # Record receipt
        self.tax_receipts.append(receipt)
        
        # Update node if provided
        if node_id and node_id in self.nodes:
            self.nodes[node_id].add_tax_payment(tax_amount, ihsan_score)
        
        # Burn tax (send to 0x0)
        self.total_burned_gwei += tax_amount
        
        # Redistribute if conditions met (e.g., time-based or threshold-based)
        self._check_redistribution()
        
        logging.info(f"[ADL TAX] Task {task_id}: {tax_amount} gwei burned (Ihsān: {ihsan_score})")
        return receipt
    
    def _generate_tx_hash(self, task_id: str, amount: Decimal) -> str:
        """Generate a simulated transaction hash."""
        data = f"{task_id}_{amount}_{time.time()}".encode('utf-8')
        return hashlib.sha256(data).hexdigest()[:16]
    
    def _check_redistribution(self):
        """Check if redistribution should occur and execute it."""
        # Simple time-based redistribution (every 24 hours in simulation)
        current_time = time.time()
        
        # Check if 24 hours have passed since last redistribution
        for node_id, node in self.nodes.items():
            if current_time - node.last_redistribution >= 86400:  # 24 hours
                self._redistribute_to_node(node_id)
                node.last_redistribution = current_time
    
    def _redistribute_to_node(self, node_id: str):
        """Redistribute burned funds to a node based on its Gini coefficient."""
        node = self.nodes.get(node_id)
        if not node:
            return
        
        # Lower Gini = more redistribution (reward equality)
        # Formula: redistribution = total_burned * (1 - gini) * redistribution_factor
        redistribution_factor = Decimal('0.1')  # 10% of burned funds
        gini_factor = Decimal('1') - node.gini_coefficient
        
        if gini_factor > Decimal('0'):
            redistribution_amount = self.total_burned_gwei * redistribution_factor * gini_factor
            
            # In real implementation, this would be a transfer
            # For simulation, we just record it
            self.total_redistributed_gwei += redistribution_amount
            logging.info(f"[ADL TAX] Redistributed {redistribution_amount} gwei to {node_id} (Gini: {node.gini_coefficient})")
    
    def get_node_statistics(self, node_id: str) -> Optional[Dict]:
        """Get statistics for a specific node."""
        node = self.nodes.get(node_id)
        if not node:
            return None
        
        return {
            "node_id": node.node_id,
            "gini_coefficient": str(node.gini_coefficient),
            "tax_paid_gwei": str(node.tax_paid_gwei),
            "bandwidth_usage_gwei": str(node.bandwidth_usage_gwei),
            "ihsan_cumulative": str(node.ihsan_cumulative),
            "ihsan_average": str(node.ihsan_cumulative / len(self.tax_receipts) if self.tax_receipts else "0"),
            "last_redistribution": node.last_redistribution
        }
    
    def get_system_statistics(self) -> Dict:
        """Get overall system statistics."""
        total_tax_gwei = sum(receipt.amount_gwei for receipt in self.tax_receipts)
        
        return {
            "total_receipts": len(self.tax_receipts),
            "total_tax_gwei": str(total_tax_gwei),
            "total_burned_gwei": str(self.total_burned_gwei),
            "total_redistributed_gwei": str(self.total_redistributed_gwei),
            "base_tax_rate_gwei": str(self.base_tax_rate_gwei),
            "active_nodes": len(self.nodes),
            "virtuous_cycle_factor": self._calculate_virtuous_cycle_factor()
        }
    
    def _calculate_virtuous_cycle_factor(self) -> str:
        """Calculate the virtuous cycle factor (average Ihsān improvement)."""
        if not self.tax_receipts:
            return "0.0"
        
        # Sort by timestamp and calculate Ihsān trend
        sorted_receipts = sorted(self.tax_receipts, key=lambda r: r.timestamp)
        
        if len(sorted_receipts) < 2:
            return "0.0"
        
        # Simple linear regression for Ihsān trend
        times = [r.timestamp for r in sorted_receipts]
        ihsan_scores = [float(r.ihsan_score) for r in sorted_receipts]
        
        # Calculate slope (positive = improving Ihsān)
        n = len(times)
        sum_x = sum(times)
        sum_y = sum(ihsan_scores)
        sum_xy = sum(t * s for t, s in zip(times, ihsan_scores))
        sum_x2 = sum(t * t for t in times)
        
        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x) if (n * sum_x2 - sum_x * sum_x) != 0 else 0
        
        return str(slope * 86400)  # Convert to per-day improvement


# Global instance for easy access
_adl_tax_collector = None

def get_adl_tax_collector() -> AdlTaxCollector:
    """Get or create the Adl tax collector instance."""
    global _adl_tax_collector
    
    if _adl_tax_collector is None:
        _adl_tax_collector = AdlTaxCollector()
    
    return _adl_tax_collector


# For standalone testing
if __name__ == "__main__":
    import random
    
    logging.basicConfig(level=logging.INFO)
    
    collector = AdlTaxCollector()
    
    # Simulate some tax payments
    for i in range(10):
        task_id = f"test_task_{i:03d}"
        size_bytes = random.randint(100, 10000)
        ihsan_score = Decimal(str(round(random.uniform(0.7, 1.0), 3)))
        node_id = random.choice(["node_0", "node_1", "node_2"])
        
        receipt = collector.process_tax_payment(task_id, size_bytes, ihsan_score, node_id)
        print(f"Tax Payment: {receipt.to_dict()['human_readable']}")
    
    # Print statistics
    stats = collector.get_system_statistics()
    print("\nSystem Statistics:")
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    # Print node statistics
    for node_id in ["node_0", "node_1", "node_2"]:
        node_stats = collector.get_node_statistics(node_id)
        if node_stats:
            print(f"\nNode {node_id}:")
            for key, value in node_stats.items():
                print(f"  {key}: {value}")