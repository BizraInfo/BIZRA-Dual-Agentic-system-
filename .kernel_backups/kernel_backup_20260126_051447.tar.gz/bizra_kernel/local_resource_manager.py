"""
BIZRA Local Resource Manager
============================
Manages and allocates local compute resources for optimal BIZRA operation.

This module provides:
1. GPU VRAM allocation for LLM models
2. CPU core affinity for parallel agents
3. Memory pool management for warm pools
4. Storage I/O optimization
5. Resource reservation and release

Hardware Profile (Node0 - MSI Titan GT77 HX):
- CPU: Intel Core i9-14900HX (24 cores, 32 threads)
- RAM: 128GB DDR5
- GPU: NVIDIA RTX 4090 Laptop (16GB VRAM)
- Storage: NVMe SSD

Usage:
    from bizra_kernel.local_resource_manager import LocalResourceManager

    manager = LocalResourceManager()
    await manager.initialize()

    # Allocate GPU for model
    allocation = await manager.allocate_gpu_memory("deepseek-r1:14b", 8000)

    # Release when done
    await manager.release_allocation(allocation.allocation_id)
"""

import asyncio
import hashlib
import json
import logging
import os
import subprocess
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from collections import defaultdict

import psutil

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

# Node0 Hardware Profile
NODE0_PROFILE = {
    "cpu_model": "Intel Core i9-14900HX",
    "cpu_cores_physical": 24,
    "cpu_cores_logical": 32,
    "ram_gb": 128,
    "gpu_model": "NVIDIA GeForce RTX 4090 Laptop GPU",
    "gpu_vram_mb": 16376,
}

# LLM Model VRAM Requirements (approximate MB)
MODEL_VRAM_REQUIREMENTS = {
    # Ollama models
    "deepseek-r1:14b": 10000,
    "deepseek-r1:8b": 6000,
    "deepseek-r1:7b": 5000,
    "llama3.1:8b": 5500,
    "llama3.1:70b": 40000,  # Won't fit in 16GB
    "mistral:latest": 4500,
    "mistral:7b": 4500,
    "qwen2.5:7b": 4500,
    "qwen2.5:14b": 9000,
    "nomic-embed-text:latest": 500,
    # Default for unknown models
    "default_7b": 5000,
    "default_14b": 9000,
}

# Agent memory requirements (MB)
AGENT_MEMORY_REQUIREMENTS = {
    "MasterReasoner": 4096,
    "MemoryArchitect": 2048,
    "CreativeSynthesizer": 2048,
    "DataAnalyzer": 2048,
    "Communicator": 1024,
    "ExecutionPlanner": 2048,
    "EthicsGuardian": 2048,
    "PoiVerifier": 512,
    "ResourceAllocator": 512,
    "RiskGuardian": 512,
    "GovernanceEngine": 512,
    "EvidenceEngine": 512,
}

# Reservation limits
MAX_GPU_RESERVATION_PERCENT = 90  # Keep 10% headroom
MAX_MEMORY_RESERVATION_PERCENT = 85  # Keep 15% headroom
MAX_CPU_RESERVATION_PERCENT = 80  # Keep 20% headroom


# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA CLASSES
# ═══════════════════════════════════════════════════════════════════════════════

class ResourceType(Enum):
    CPU = "cpu"
    GPU_VRAM = "gpu_vram"
    MEMORY = "memory"
    STORAGE_IO = "storage_io"


class AllocationStatus(Enum):
    PENDING = "pending"
    ACTIVE = "active"
    RELEASED = "released"
    FAILED = "failed"


@dataclass
class ResourceAllocation:
    """Represents a resource allocation."""
    allocation_id: str
    resource_type: ResourceType
    requested_amount: int  # MB for memory/VRAM, cores for CPU
    allocated_amount: int
    requester: str  # Model name or agent name
    status: AllocationStatus
    created_at: datetime
    released_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ResourcePool:
    """Tracks available resources in a pool."""
    resource_type: ResourceType
    total_capacity: int
    reserved: int
    allocations: Dict[str, ResourceAllocation] = field(default_factory=dict)

    @property
    def available(self) -> int:
        return self.total_capacity - self.reserved

    @property
    def utilization_percent(self) -> float:
        return (self.reserved / self.total_capacity * 100) if self.total_capacity > 0 else 0


@dataclass
class GPUInfo:
    """Detailed GPU information."""
    index: int
    name: str
    total_memory_mb: int
    free_memory_mb: int
    used_memory_mb: int
    utilization_percent: float
    temperature_c: float
    power_usage_w: float
    power_limit_w: float
    compute_capability: str = ""


@dataclass
class WarmPoolConfig:
    """Configuration for warm pools."""
    agent_name: str
    target_size: int
    current_size: int
    memory_per_instance_mb: int
    priority: int  # Higher = more important


# ═══════════════════════════════════════════════════════════════════════════════
# LOCAL RESOURCE MANAGER
# ═══════════════════════════════════════════════════════════════════════════════

class LocalResourceManager:
    """
    Manages local compute resources for BIZRA operations.

    Thread-safe resource allocation with support for:
    - GPU VRAM management
    - System memory pools
    - CPU affinity
    - Warm pool optimization
    """

    def __init__(self):
        self._initialized = False
        self._lock = asyncio.Lock()
        self._allocation_lock = threading.Lock()

        # Resource pools
        self._gpu_pool: Optional[ResourcePool] = None
        self._memory_pool: Optional[ResourcePool] = None
        self._cpu_pool: Optional[ResourcePool] = None

        # Tracking
        self._allocations: Dict[str, ResourceAllocation] = {}
        self._model_allocations: Dict[str, str] = {}  # model_name -> allocation_id
        self._agent_allocations: Dict[str, str] = {}  # agent_name -> allocation_id

        # Warm pools
        self._warm_pool_configs: Dict[str, WarmPoolConfig] = {}

        # Metrics
        self._total_allocations = 0
        self._failed_allocations = 0

    async def initialize(self) -> "LocalResourceManager":
        """Initialize the resource manager."""
        if self._initialized:
            return self

        logger.info("🔧 Initializing Local Resource Manager...")

        # Detect GPU
        gpu_info = await self._detect_gpu()
        if gpu_info:
            self._gpu_pool = ResourcePool(
                resource_type=ResourceType.GPU_VRAM,
                total_capacity=gpu_info.total_memory_mb,
                reserved=gpu_info.used_memory_mb,  # Account for current usage
            )
            logger.info(f"  GPU: {gpu_info.name} ({gpu_info.total_memory_mb}MB VRAM)")
        else:
            logger.warning("  No GPU detected")

        # Initialize memory pool
        mem = psutil.virtual_memory()
        total_mb = mem.total // (1024 * 1024)
        used_mb = mem.used // (1024 * 1024)

        self._memory_pool = ResourcePool(
            resource_type=ResourceType.MEMORY,
            total_capacity=total_mb,
            reserved=used_mb,
        )
        logger.info(f"  RAM: {total_mb // 1024}GB total, {(total_mb - used_mb) // 1024}GB available")

        # Initialize CPU pool (use logical cores)
        cpu_count = psutil.cpu_count(logical=True) or 32
        self._cpu_pool = ResourcePool(
            resource_type=ResourceType.CPU,
            total_capacity=cpu_count,
            reserved=0,
        )
        logger.info(f"  CPU: {cpu_count} logical cores")

        # Setup default warm pools
        self._setup_default_warm_pools()

        self._initialized = True
        logger.info("✅ Local Resource Manager initialized")

        return self

    def _setup_default_warm_pools(self):
        """Setup default warm pool configurations."""
        # PAT agents - higher priority, larger pools
        self._warm_pool_configs["MasterReasoner"] = WarmPoolConfig(
            agent_name="MasterReasoner",
            target_size=2,
            current_size=0,
            memory_per_instance_mb=AGENT_MEMORY_REQUIREMENTS["MasterReasoner"],
            priority=10,
        )
        self._warm_pool_configs["MemoryArchitect"] = WarmPoolConfig(
            agent_name="MemoryArchitect",
            target_size=1,
            current_size=0,
            memory_per_instance_mb=AGENT_MEMORY_REQUIREMENTS["MemoryArchitect"],
            priority=8,
        )
        self._warm_pool_configs["EthicsGuardian"] = WarmPoolConfig(
            agent_name="EthicsGuardian",
            target_size=1,
            current_size=0,
            memory_per_instance_mb=AGENT_MEMORY_REQUIREMENTS["EthicsGuardian"],
            priority=9,
        )

        # SAT agents - lower priority, smaller pools
        for sat_agent in ["PoiVerifier", "RiskGuardian", "GovernanceEngine"]:
            self._warm_pool_configs[sat_agent] = WarmPoolConfig(
                agent_name=sat_agent,
                target_size=1,
                current_size=0,
                memory_per_instance_mb=AGENT_MEMORY_REQUIREMENTS.get(sat_agent, 512),
                priority=5,
            )

    async def _detect_gpu(self) -> Optional[GPUInfo]:
        """Detect NVIDIA GPU using nvidia-smi."""
        try:
            result = subprocess.run(
                [
                    "nvidia-smi",
                    "--query-gpu=index,name,memory.total,memory.free,memory.used,utilization.gpu,temperature.gpu,power.draw,power.limit",
                    "--format=csv,noheader,nounits"
                ],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode != 0:
                return None

            parts = result.stdout.strip().split(",")
            if len(parts) < 9:
                return None

            return GPUInfo(
                index=int(parts[0].strip()),
                name=parts[1].strip(),
                total_memory_mb=int(float(parts[2].strip())),
                free_memory_mb=int(float(parts[3].strip())),
                used_memory_mb=int(float(parts[4].strip())),
                utilization_percent=float(parts[5].strip()),
                temperature_c=float(parts[6].strip()),
                power_usage_w=float(parts[7].strip()) if parts[7].strip() != "[N/A]" else 0,
                power_limit_w=float(parts[8].strip()) if parts[8].strip() != "[N/A]" else 0,
            )
        except Exception as e:
            logger.debug(f"GPU detection failed: {e}")
            return None

    # ═══════════════════════════════════════════════════════════════════════════
    # ALLOCATION METHODS
    # ═══════════════════════════════════════════════════════════════════════════

    def _generate_allocation_id(self, resource_type: ResourceType, requester: str) -> str:
        """Generate unique allocation ID."""
        timestamp = datetime.now(timezone.utc).isoformat()
        data = f"{resource_type.value}:{requester}:{timestamp}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    async def allocate_gpu_memory(
        self,
        model_name: str,
        required_mb: Optional[int] = None,
        force: bool = False
    ) -> Optional[ResourceAllocation]:
        """
        Allocate GPU VRAM for a model.

        Args:
            model_name: Name of the model (e.g., "deepseek-r1:14b")
            required_mb: Required VRAM in MB (auto-detected if not provided)
            force: Force allocation even if over limit

        Returns:
            ResourceAllocation if successful, None if failed
        """
        if not self._gpu_pool:
            logger.warning("No GPU pool available")
            return None

        # Determine required VRAM
        if required_mb is None:
            # Try to match model name pattern
            required_mb = MODEL_VRAM_REQUIREMENTS.get(model_name)
            if required_mb is None:
                # Estimate based on model size indicator
                if "70b" in model_name.lower():
                    required_mb = 40000
                elif "14b" in model_name.lower():
                    required_mb = MODEL_VRAM_REQUIREMENTS["default_14b"]
                elif "7b" in model_name.lower() or "8b" in model_name.lower():
                    required_mb = MODEL_VRAM_REQUIREMENTS["default_7b"]
                else:
                    required_mb = 4000  # Default assumption

        async with self._lock:
            # Check if model already has allocation
            if model_name in self._model_allocations:
                existing_id = self._model_allocations[model_name]
                if existing_id in self._allocations:
                    existing = self._allocations[existing_id]
                    if existing.status == AllocationStatus.ACTIVE:
                        logger.debug(f"Model {model_name} already has active allocation")
                        return existing

            # Check available VRAM
            gpu_info = await self._detect_gpu()
            if gpu_info:
                actual_free = gpu_info.free_memory_mb
            else:
                actual_free = self._gpu_pool.available

            max_allocatable = int(self._gpu_pool.total_capacity * MAX_GPU_RESERVATION_PERCENT / 100)
            available = min(actual_free, max_allocatable - self._gpu_pool.reserved)

            if required_mb > available and not force:
                logger.warning(
                    f"Insufficient GPU memory for {model_name}: "
                    f"need {required_mb}MB, have {available}MB"
                )
                self._failed_allocations += 1
                return None

            # Create allocation
            allocation_id = self._generate_allocation_id(ResourceType.GPU_VRAM, model_name)
            allocation = ResourceAllocation(
                allocation_id=allocation_id,
                resource_type=ResourceType.GPU_VRAM,
                requested_amount=required_mb,
                allocated_amount=min(required_mb, available),
                requester=model_name,
                status=AllocationStatus.ACTIVE,
                created_at=datetime.now(timezone.utc),
                metadata={"gpu_name": gpu_info.name if gpu_info else "unknown"},
            )

            # Update tracking
            self._allocations[allocation_id] = allocation
            self._model_allocations[model_name] = allocation_id
            self._gpu_pool.reserved += allocation.allocated_amount
            self._gpu_pool.allocations[allocation_id] = allocation
            self._total_allocations += 1

            logger.info(
                f"✅ Allocated {allocation.allocated_amount}MB GPU VRAM for {model_name} "
                f"(ID: {allocation_id[:8]})"
            )

            return allocation

    async def allocate_memory(
        self,
        requester: str,
        required_mb: int,
        force: bool = False
    ) -> Optional[ResourceAllocation]:
        """Allocate system memory for an agent or process."""
        async with self._lock:
            max_allocatable = int(self._memory_pool.total_capacity * MAX_MEMORY_RESERVATION_PERCENT / 100)
            available = max_allocatable - self._memory_pool.reserved

            if required_mb > available and not force:
                logger.warning(
                    f"Insufficient memory for {requester}: "
                    f"need {required_mb}MB, have {available}MB"
                )
                self._failed_allocations += 1
                return None

            allocation_id = self._generate_allocation_id(ResourceType.MEMORY, requester)
            allocation = ResourceAllocation(
                allocation_id=allocation_id,
                resource_type=ResourceType.MEMORY,
                requested_amount=required_mb,
                allocated_amount=min(required_mb, available),
                requester=requester,
                status=AllocationStatus.ACTIVE,
                created_at=datetime.now(timezone.utc),
            )

            self._allocations[allocation_id] = allocation
            self._agent_allocations[requester] = allocation_id
            self._memory_pool.reserved += allocation.allocated_amount
            self._memory_pool.allocations[allocation_id] = allocation
            self._total_allocations += 1

            logger.debug(f"Allocated {allocation.allocated_amount}MB memory for {requester}")
            return allocation

    async def allocate_cpu_cores(
        self,
        requester: str,
        cores: int,
        force: bool = False
    ) -> Optional[ResourceAllocation]:
        """Allocate CPU cores for a process."""
        async with self._lock:
            max_allocatable = int(self._cpu_pool.total_capacity * MAX_CPU_RESERVATION_PERCENT / 100)
            available = max_allocatable - self._cpu_pool.reserved

            if cores > available and not force:
                logger.warning(
                    f"Insufficient CPU cores for {requester}: "
                    f"need {cores}, have {available}"
                )
                self._failed_allocations += 1
                return None

            allocation_id = self._generate_allocation_id(ResourceType.CPU, requester)
            allocation = ResourceAllocation(
                allocation_id=allocation_id,
                resource_type=ResourceType.CPU,
                requested_amount=cores,
                allocated_amount=min(cores, available),
                requester=requester,
                status=AllocationStatus.ACTIVE,
                created_at=datetime.now(timezone.utc),
            )

            self._allocations[allocation_id] = allocation
            self._cpu_pool.reserved += allocation.allocated_amount
            self._cpu_pool.allocations[allocation_id] = allocation
            self._total_allocations += 1

            logger.debug(f"Allocated {allocation.allocated_amount} CPU cores for {requester}")
            return allocation

    async def release_allocation(self, allocation_id: str) -> bool:
        """Release a resource allocation."""
        async with self._lock:
            if allocation_id not in self._allocations:
                logger.warning(f"Allocation {allocation_id} not found")
                return False

            allocation = self._allocations[allocation_id]
            if allocation.status != AllocationStatus.ACTIVE:
                logger.debug(f"Allocation {allocation_id} already released")
                return False

            # Update pool
            pool = self._get_pool_for_type(allocation.resource_type)
            if pool:
                pool.reserved -= allocation.allocated_amount
                if allocation_id in pool.allocations:
                    del pool.allocations[allocation_id]

            # Update allocation
            allocation.status = AllocationStatus.RELEASED
            allocation.released_at = datetime.now(timezone.utc)

            # Remove from tracking
            if allocation.requester in self._model_allocations:
                del self._model_allocations[allocation.requester]
            if allocation.requester in self._agent_allocations:
                del self._agent_allocations[allocation.requester]

            logger.debug(f"Released allocation {allocation_id[:8]} for {allocation.requester}")
            return True

    def _get_pool_for_type(self, resource_type: ResourceType) -> Optional[ResourcePool]:
        """Get the resource pool for a given type."""
        if resource_type == ResourceType.GPU_VRAM:
            return self._gpu_pool
        elif resource_type == ResourceType.MEMORY:
            return self._memory_pool
        elif resource_type == ResourceType.CPU:
            return self._cpu_pool
        return None

    # ═══════════════════════════════════════════════════════════════════════════
    # WARM POOL MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════

    async def get_warm_pool_status(self) -> Dict[str, Any]:
        """Get status of all warm pools."""
        status = {}
        total_memory_reserved = 0

        for name, config in self._warm_pool_configs.items():
            pool_memory = config.current_size * config.memory_per_instance_mb
            total_memory_reserved += pool_memory

            status[name] = {
                "target_size": config.target_size,
                "current_size": config.current_size,
                "memory_per_instance_mb": config.memory_per_instance_mb,
                "total_memory_mb": pool_memory,
                "priority": config.priority,
                "fill_percent": (config.current_size / config.target_size * 100) if config.target_size > 0 else 0,
            }

        return {
            "pools": status,
            "total_memory_reserved_mb": total_memory_reserved,
            "total_memory_reserved_gb": round(total_memory_reserved / 1024, 2),
        }

    async def fill_warm_pools(self) -> Dict[str, int]:
        """Fill warm pools up to their target sizes."""
        filled = {}

        # Sort by priority (highest first)
        sorted_configs = sorted(
            self._warm_pool_configs.values(),
            key=lambda x: x.priority,
            reverse=True
        )

        for config in sorted_configs:
            slots_needed = config.target_size - config.current_size

            if slots_needed <= 0:
                continue

            # Check if we have enough memory
            memory_needed = slots_needed * config.memory_per_instance_mb

            allocation = await self.allocate_memory(
                f"warm_pool:{config.agent_name}",
                memory_needed,
                force=False
            )

            if allocation:
                config.current_size = config.target_size
                filled[config.agent_name] = slots_needed
                logger.info(f"Filled warm pool {config.agent_name}: {slots_needed} slots")
            else:
                # Try partial fill
                available = self._memory_pool.available
                slots_possible = available // config.memory_per_instance_mb

                if slots_possible > 0:
                    allocation = await self.allocate_memory(
                        f"warm_pool:{config.agent_name}",
                        slots_possible * config.memory_per_instance_mb,
                        force=False
                    )
                    if allocation:
                        config.current_size += slots_possible
                        filled[config.agent_name] = slots_possible

        return filled

    # ═══════════════════════════════════════════════════════════════════════════
    # STATUS AND REPORTING
    # ═══════════════════════════════════════════════════════════════════════════

    async def get_status(self) -> Dict[str, Any]:
        """Get comprehensive resource status."""
        gpu_info = await self._detect_gpu() if self._gpu_pool else None

        status = {
            "initialized": self._initialized,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "metrics": {
                "total_allocations": self._total_allocations,
                "failed_allocations": self._failed_allocations,
                "active_allocations": sum(
                    1 for a in self._allocations.values()
                    if a.status == AllocationStatus.ACTIVE
                ),
            },
            "pools": {},
        }

        # GPU pool
        if self._gpu_pool:
            status["pools"]["gpu_vram"] = {
                "total_mb": self._gpu_pool.total_capacity,
                "reserved_mb": self._gpu_pool.reserved,
                "available_mb": self._gpu_pool.available,
                "utilization_percent": round(self._gpu_pool.utilization_percent, 1),
                "actual_free_mb": gpu_info.free_memory_mb if gpu_info else None,
                "temperature_c": gpu_info.temperature_c if gpu_info else None,
            }

        # Memory pool
        if self._memory_pool:
            mem = psutil.virtual_memory()
            status["pools"]["memory"] = {
                "total_mb": self._memory_pool.total_capacity,
                "reserved_mb": self._memory_pool.reserved,
                "available_mb": self._memory_pool.available,
                "utilization_percent": round(self._memory_pool.utilization_percent, 1),
                "actual_used_percent": mem.percent,
            }

        # CPU pool
        if self._cpu_pool:
            status["pools"]["cpu"] = {
                "total_cores": self._cpu_pool.total_capacity,
                "reserved_cores": self._cpu_pool.reserved,
                "available_cores": self._cpu_pool.available,
                "utilization_percent": round(self._cpu_pool.utilization_percent, 1),
                "actual_usage_percent": psutil.cpu_percent(interval=0.1),
            }

        # Active allocations
        status["allocations"] = {
            aid: {
                "resource_type": a.resource_type.value,
                "requester": a.requester,
                "allocated_mb": a.allocated_amount,
                "created_at": a.created_at.isoformat(),
            }
            for aid, a in self._allocations.items()
            if a.status == AllocationStatus.ACTIVE
        }

        return status

    async def get_model_recommendations(self) -> List[Dict[str, Any]]:
        """Get recommendations for which models can fit in available VRAM."""
        if not self._gpu_pool:
            return [{"error": "No GPU available"}]

        gpu_info = await self._detect_gpu()
        available_vram = gpu_info.free_memory_mb if gpu_info else self._gpu_pool.available

        recommendations = []

        for model, required_mb in sorted(
            MODEL_VRAM_REQUIREMENTS.items(),
            key=lambda x: x[1]
        ):
            fits = required_mb <= available_vram
            recommendations.append({
                "model": model,
                "required_mb": required_mb,
                "fits": fits,
                "headroom_mb": available_vram - required_mb if fits else 0,
            })

        return recommendations

    async def optimize_for_inference(
        self,
        primary_model: str,
        secondary_models: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Optimize resource allocation for LLM inference workload.

        Args:
            primary_model: Main model to prioritize
            secondary_models: Additional models that may be used

        Returns:
            Optimization results and allocations
        """
        results = {
            "primary_model": primary_model,
            "allocations": [],
            "warnings": [],
            "optimizations": [],
        }

        # Allocate for primary model
        primary_req = MODEL_VRAM_REQUIREMENTS.get(primary_model, 5000)
        primary_alloc = await self.allocate_gpu_memory(primary_model, primary_req)

        if primary_alloc:
            results["allocations"].append({
                "model": primary_model,
                "allocated_mb": primary_alloc.allocated_amount,
                "status": "success",
            })
        else:
            results["warnings"].append(f"Could not allocate VRAM for {primary_model}")
            return results

        # Check for secondary models
        if secondary_models:
            remaining = self._gpu_pool.available if self._gpu_pool else 0

            for model in secondary_models:
                req = MODEL_VRAM_REQUIREMENTS.get(model, 5000)
                if req <= remaining:
                    alloc = await self.allocate_gpu_memory(model, req)
                    if alloc:
                        results["allocations"].append({
                            "model": model,
                            "allocated_mb": alloc.allocated_amount,
                            "status": "success",
                        })
                        remaining -= alloc.allocated_amount
                else:
                    results["warnings"].append(
                        f"Insufficient VRAM for {model} (need {req}MB, have {remaining}MB)"
                    )

        # Memory optimization recommendations
        if self._memory_pool:
            mem_available = self._memory_pool.available
            if mem_available > 32000:  # 32GB+
                results["optimizations"].append(
                    "Enable maximum warm pool sizes for fast agent spawning"
                )
            elif mem_available > 16000:  # 16GB+
                results["optimizations"].append(
                    "Use medium warm pool sizes, prioritize PAT agents"
                )
            else:
                results["optimizations"].append(
                    "Low memory: disable warm pools, use on-demand spawning"
                )

        return results


# ═══════════════════════════════════════════════════════════════════════════════
# CONVENIENCE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

_manager_instance: Optional[LocalResourceManager] = None


async def get_resource_manager() -> LocalResourceManager:
    """Get or create the singleton resource manager."""
    global _manager_instance
    if _manager_instance is None:
        _manager_instance = LocalResourceManager()
        await _manager_instance.initialize()
    return _manager_instance


async def allocate_for_model(model_name: str) -> Optional[ResourceAllocation]:
    """Quick allocation for a model."""
    manager = await get_resource_manager()
    return await manager.allocate_gpu_memory(model_name)


async def get_available_vram() -> int:
    """Get available GPU VRAM in MB."""
    manager = await get_resource_manager()
    if manager._gpu_pool:
        gpu_info = await manager._detect_gpu()
        return gpu_info.free_memory_mb if gpu_info else manager._gpu_pool.available
    return 0


async def get_resource_status() -> Dict[str, Any]:
    """Get current resource status."""
    manager = await get_resource_manager()
    return await manager.get_status()


# ═══════════════════════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="BIZRA Local Resource Manager")
    parser.add_argument("--status", action="store_true", help="Show resource status")
    parser.add_argument("--recommend", action="store_true", help="Model recommendations")
    parser.add_argument("--warm-pools", action="store_true", help="Show warm pool status")
    parser.add_argument("--allocate", type=str, help="Allocate VRAM for model")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(message)s")

    manager = await get_resource_manager()

    if args.allocate:
        alloc = await manager.allocate_gpu_memory(args.allocate)
        if alloc:
            print(f"✅ Allocated {alloc.allocated_amount}MB for {args.allocate}")
        else:
            print(f"❌ Failed to allocate for {args.allocate}")

    elif args.recommend:
        recs = await manager.get_model_recommendations()
        if args.json:
            print(json.dumps(recs, indent=2))
        else:
            print("\n" + "=" * 50)
            print("  MODEL RECOMMENDATIONS")
            print("=" * 50 + "\n")
            for rec in recs:
                icon = "✅" if rec["fits"] else "❌"
                print(f"  {icon} {rec['model']}: {rec['required_mb']}MB", end="")
                if rec["fits"]:
                    print(f" (headroom: {rec['headroom_mb']}MB)")
                else:
                    print(" (won't fit)")
            print()

    elif args.warm_pools:
        status = await manager.get_warm_pool_status()
        if args.json:
            print(json.dumps(status, indent=2))
        else:
            print("\n" + "=" * 50)
            print("  WARM POOL STATUS")
            print("=" * 50 + "\n")
            for name, pool in status["pools"].items():
                print(f"  {name}:")
                print(f"    Size: {pool['current_size']}/{pool['target_size']}")
                print(f"    Memory: {pool['total_memory_mb']}MB")
            print(f"\n  Total Reserved: {status['total_memory_reserved_gb']}GB\n")

    else:
        status = await manager.get_status()
        if args.json:
            print(json.dumps(status, indent=2))
        else:
            print("\n" + "=" * 50)
            print("  RESOURCE STATUS")
            print("=" * 50 + "\n")

            if "gpu_vram" in status["pools"]:
                gpu = status["pools"]["gpu_vram"]
                print(f"  GPU VRAM:")
                print(f"    Total: {gpu['total_mb']}MB")
                print(f"    Available: {gpu['available_mb']}MB ({100-gpu['utilization_percent']:.0f}%)")
                if gpu.get("temperature_c"):
                    print(f"    Temperature: {gpu['temperature_c']}°C")

            if "memory" in status["pools"]:
                mem = status["pools"]["memory"]
                print(f"\n  System Memory:")
                print(f"    Total: {mem['total_mb']//1024}GB")
                print(f"    Available: {mem['available_mb']//1024}GB")

            if "cpu" in status["pools"]:
                cpu = status["pools"]["cpu"]
                print(f"\n  CPU:")
                print(f"    Cores: {cpu['total_cores']}")
                print(f"    Usage: {cpu['actual_usage_percent']:.1f}%")

            print(f"\n  Allocations: {status['metrics']['active_allocations']} active\n")


if __name__ == "__main__":
    asyncio.run(main())
