"""
BIZRA Chain Verifier
====================
Audits the receipt chain for continuity, integrity, and monotonic sequence.
Implements P0 Audit Requirement: Chain Verifier CLI.
"""

import hashlib
import json
import sys
import os
from pathlib import Path
from typing import List, Dict

# Import PKI (assuming pki.py is in same folder)
try:
    from bizra_kernel.pki import registry
except ImportError:
    # Standalone support
    sys.path.append(str(Path(__file__).parent.parent))
    from bizra_kernel.pki import registry

RECEIPTS_DIR = Path(os.getenv("BIZRA_RECEIPTS_DIR", "docs/evidence/receipts"))

def canonicalize(data: Dict) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(',', ':')).encode('utf-8')

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def verify_chain(dir_path: Path = RECEIPTS_DIR) -> bool:
    print(f"🔍 Verifying receipt chain in {dir_path}...")
    
    if not dir_path.exists():
        print("❌ Receipt directory not found.")
        return False
        
    files = sorted(dir_path.glob("*.json"))
    if not files:
        print("⚠️  No receipts found.")
        return True
        
    print(f"found {len(files)} receipts.")
    
    valid = True
    prev_hash = "0000000000000000000000000000000000000000000000000000000000000000"
    
    for i, file_path in enumerate(files):
        try:
            with open(file_path, "r") as f:
                receipt = json.load(f)
            
            payload = receipt.get("payload", {})
            receipt_id = receipt.get("receipt_id", "?")
            
            # 1. Verify Hash Chain
            curr_prev_hash = payload.get("prev_hash")
            if curr_prev_hash != prev_hash:
                print(f"❌ [FAIL] Chain Broken at {receipt_id} ({file_path.name})")
                print(f"   Expected prev: {prev_hash}")
                print(f"   Found prev:    {curr_prev_hash}")
                valid = False
            
            # 2. Verify Signature
            agent_id = payload.get("node_id") or payload.get("agent_id")
            sig_hex = receipt.get("signature")
            
            if not agent_id or not sig_hex:
                 print(f"❌ [FAIL] Missing ID or Signature at {receipt_id}")
                 valid = False
            else:
                msg_bytes = canonicalize(payload)
                sig_bytes = bytes.fromhex(sig_hex)
                
                # Check signature (using registry)
                if registry.verify(agent_id, msg_bytes, sig_bytes):
                     pass # Signature OK
                else:
                     # Check if it implies a self-signed genesis key in payload (bootstrapping)
                     if receipt.get("type") == "GENESIS" and receipt.get("signer_pubkey"):
                         # Verify against self-contained key for Genesis (Trust on First Use model for this script)
                         from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
                         try:
                             pub = Ed25519PublicKey.from_public_bytes(bytes.fromhex(receipt.get("signer_pubkey")))
                             pub.verify(sig_bytes, msg_bytes)
                             # print(f"   (Verified via genesis key)")
                         except Exception as e:
                             print(f"❌ [FAIL] Invalid Genesis Signature at {receipt_id}: {e}")
                             valid = False
                     else:
                        print(f"❌ [FAIL] Invalid Signature at {receipt_id} (Agent: {agent_id})")
                        valid = False

            # Update prev_hash for next link
            # The hash of the current receipt (or payload? Audit says prev || canonical_unsigned)
            # "receipt.hash_chain.current == SHA256(prev || canonical_bytes(unsigned_receipt))"
            # Here I assume payload contains the prev_hash, so I just hash the payload or the full receipt?
            # Impl details vary. I will use SHA256(canonical(payload)) as the link for this impl.
            prev_hash = sha256_bytes(canonicalize(payload))
            
        except Exception as e:
            print(f"❌ [ERROR] Processing {file_path.name}: {e}")
            valid = False
            
    if valid:
        print("✅ Chain Verification Passed.")
    else:
        print("🛑 Chain Verification FAILED.")
        
    return valid

if __name__ == "__main__":
    import os
    if len(sys.argv) > 1:
        verify_chain(Path(sys.argv[1]))
    else:
        verify_chain()
