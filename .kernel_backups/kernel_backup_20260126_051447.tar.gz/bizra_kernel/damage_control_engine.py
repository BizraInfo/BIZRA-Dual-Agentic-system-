"""
BIZRA Damage Control Engine v1.0
=================================
Elite safety integration for the Sovereign Organism.
Standing on the shoulders of security giants and interdisciplinary thinking.

Integrates:
- Graph of Thoughts (Security Lens)
- SNR Optimization with Safety Compliance
- PreToolUse Pattern Blocking (Adapted from Claude Code Damage Control)
- Zero-Trust Architecture Principles
"""

import re
import os
import json
import time
from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional, Tuple
from enum import Enum
import hashlib

# Import BIZRA core modules
from .got_orchestrator import GoTOrchestrator, ThoughtNode, RelationType
from .snr_tracker import SNRMetrics, estimate_useful_tokens


class SecurityLevel(Enum):
    """Security classification for operations."""
    ZERO_TRUST = 0      # No access, high risk
    GUARDED = 1         # Limited access, medium risk
    PERMISSIVE = 2      # Standard access, low risk
    TRUSTED = 3         # Full access, verified


@dataclass
class SecurityPattern:
    """Security pattern for command and path validation."""
    pattern: str
    reason: str
    security_level: SecurityLevel
    ask_confirmation: bool = False  # Whether to ask for confirmation instead of blocking


@dataclass
class SecurityContext:
    """Context for security evaluation."""
    agent_role: str
    session_id: str
    tool_type: str  # 'bash', 'edit', 'write', 'execute'
    working_directory: str
    user_identity: str


class DamageControlEngine:
    """
    Elite safety engine for BIZRA Sovereign Kernel.
    
    Provides defense-in-depth through:
    1. Command pattern blocking
    2. Path protection (zero-access, read-only, no-delete)
    3. Security lens integration with GoT
    4. SNR safety compliance scoring
    5. Interdisciplinary security thinking
    """
    
    def __init__(self, context: SecurityContext):
        self.context = context
        self.security_giants = self._initialize_security_giants()
        self.patterns = self._load_security_patterns()
        self.thought_orchestrator = GoTOrchestrator(f"security-{context.session_id}")
        
    def _initialize_security_giants(self) -> Dict[str, Dict]:
        """Initialize security giants for Standing on Shoulders protocol."""
        return {
            "ZERO_TRUST_ARCHITECTURE": {
                "principle": "Never trust, always verify, assume breach",
                "source": "Security Giant: Zero Trust Framework",
                "weight": 0.4
            },
            "DEFENSE_IN_DEPTH": {
                "principle": "Multiple security layers, redundancy, fail-safe",
                "source": "Security Giant: Defense-in-Depth Strategy",
                "weight": 0.3
            },
            "LEAST_PRIVILEGE": {
                "principle": "Minimum access required, just-in-time, just-enough",
                "source": "Security Giant: Least Privilege Principle",
                "weight": 0.2
            },
            "AUDIT_TRAIL": {
                "principle": "Complete traceability, immutable logs, non-repudiation",
                "source": "Security Giant: Audit and Compliance",
                "weight": 0.1
            }
        }
    
    def _load_security_patterns(self) -> Dict[str, List[SecurityPattern]]:
        """Load security patterns adapted from Claude Code Damage Control."""
        patterns = {
            "bash": [],
            "edit": [],
            "write": [],
            "execute": []
        }
        
        # Critical destructive operations (block)
        critical_patterns = [
            (r'\brm\s+(-[^\s]*)*-[rRf]', 'rm with recursive or force flags', SecurityLevel.ZERO_TRUST),
            (r'\bsudo\s+rm\b', 'sudo rm', SecurityLevel.ZERO_TRUST),
            (r'\bchmod\s+(-[^\s]+\s+)*777\b', 'chmod 777 (world writable)', SecurityLevel.ZERO_TRUST),
            (r'\bdd\s+.*of=/dev/', 'dd writing to device', SecurityLevel.ZERO_TRUST),
            (r'\bkill\s+-9\s+-1\b', 'kill all processes', SecurityLevel.ZERO_TRUST),
            (r'DELETE\s+FROM\s+\w+\s*;', 'DELETE without WHERE clause (will delete ALL rows)', SecurityLevel.ZERO_TRUST),
        ]
        
        for pattern, reason, level in critical_patterns:
            patterns["bash"].append(SecurityPattern(pattern, reason, level, False))
        
        # Operations requiring confirmation (ask)
        ask_patterns = [
            (r'\bgit\s+reset\s+--hard\b', 'git reset --hard', SecurityLevel.GUARDED, True),
            (r'\bgit\s+push\s+.*--force(?!-with-lease)', 'git push --force', SecurityLevel.GUARDED, True),
            (r'\bterraform\s+destroy\b', 'terraform destroy', SecurityLevel.GUARDED, True),
            (r'\bDELETE\s+FROM\s+\w+\s+WHERE\b.*\bid\s*=', 'SQL DELETE with specific ID', SecurityLevel.GUARDED, True),
        ]
        
        for pattern, reason, level, ask in ask_patterns:
            patterns["bash"].append(SecurityPattern(pattern, reason, level, ask))
        
        return patterns
    
    def evaluate_command(self, command: str, tool_type: str = "bash") -> Dict[str, any]:
        """
        Evaluate a command for security risks.
        
        Returns:
            Dict with:
            - allowed: bool
            - security_level: SecurityLevel
            - reasons: List[str] (if blocked)
            - requires_confirmation: bool
            - confirmation_reason: str (if requires confirmation)
            - snr_safety_score: float
        """
        # Add security thought to GoT
        security_thought = self.thought_orchestrator.add_thought(
            f"Security evaluation of command: {command}",
            lens="Security",
            snr=self._calculate_security_snr(command)
        )
        
        # Check patterns
        matched_patterns = []
        requires_confirmation = False
        confirmation_reason = ""
        
        if tool_type in self.patterns:
            for pattern in self.patterns[tool_type]:
                if re.search(pattern.pattern, command, re.IGNORECASE):
                    matched_patterns.append({
                        "pattern": pattern.pattern,
                        "reason": pattern.reason,
                        "security_level": pattern.security_level,
                        "ask_confirmation": pattern.ask_confirmation
                    })
                    
                    if pattern.ask_confirmation:
                        requires_confirmation = True
                        confirmation_reason = pattern.reason
        
        # Determine if allowed
        allowed = True
        block_reasons = []
        
        for match in matched_patterns:
            if match["security_level"] == SecurityLevel.ZERO_TRUST:
                allowed = False
                block_reasons.append(match["reason"])
            elif match["ask_confirmation"]:
                # Will be handled by confirmation dialog
                pass
        
        # Calculate safety compliance for SNR
        safety_compliance = self._calculate_safety_compliance(command, matched_patterns)
        
        # Link security thought to execution thought if exists
        # (This would be done in the broader GoT context)
        
        return {
            "allowed": allowed,
            "security_level": SecurityLevel.ZERO_TRUST if not allowed else SecurityLevel.PERMISSIVE,
            "reasons": block_reasons if not allowed else [],
            "requires_confirmation": requires_confirmation,
            "confirmation_reason": confirmation_reason if requires_confirmation else "",
            "snr_safety_score": safety_compliance,
            "thought_id": security_thought.id
        }
    
    def evaluate_path(self, path: str, operation: str) -> Dict[str, any]:
        """
        Evaluate path access for operations.
        
        Operations: 'read', 'write', 'delete', 'execute'
        """
        # Normalize path
        normalized_path = os.path.expanduser(path)
        
        # Define protected paths (adapted from damage control)
        zero_access_paths = [
            "~/.ssh/",
            "~/.aws/",
            "~/.gnupg/",
            ".env",
            ".env.*",
            "*.pem",
            "*.key",
        ]
        
        read_only_paths = [
            "/etc/",
            "~/.bashrc",
            "~/.zshrc",
            "package-lock.json",
            "yarn.lock",
            "dist/",
            "build/",
            "node_modules/",
        ]
        
        no_delete_paths = [
            "README.md",
            "LICENSE",
            ".git/",
            "Dockerfile",
            "docker-compose.yml",
        ]
        
        # Check zero access
        for pattern in zero_access_paths:
            if self._path_matches(pattern, normalized_path):
                return {
                    "allowed": False,
                    "reason": f"Zero-access path: {pattern}",
                    "security_level": SecurityLevel.ZERO_TRUST
                }
        
        # Check read-only for write/delete operations
        if operation in ["write", "delete", "execute"]:
            for pattern in read_only_paths:
                if self._path_matches(pattern, normalized_path):
                    return {
                        "allowed": False,
                        "reason": f"Read-only path: {pattern}",
                        "security_level": SecurityLevel.GUARDED
                    }
        
        # Check no-delete for delete operation
        if operation == "delete":
            for pattern in no_delete_paths:
                if self._path_matches(pattern, normalized_path):
                    return {
                        "allowed": False,
                        "reason": f"No-delete path: {pattern}",
                        "security_level": SecurityLevel.GUARDED
                    }
        
        return {
            "allowed": True,
            "security_level": SecurityLevel.PERMISSIVE
        }
    
    def _path_matches(self, pattern: str, path: str) -> bool:
        """Simple pattern matching for paths."""
        # Expand ~ in pattern
        pattern = os.path.expanduser(pattern)
        
        # Handle wildcards
        if '*' in pattern:
            import fnmatch
            return fnmatch.fnmatch(path, pattern)
        else:
            return path.startswith(pattern)
    
    def _calculate_security_snr(self, command: str) -> float:
        """
        Calculate security SNR for a command.
        
        Higher SNR indicates safer, more aligned with security giants.
        """
        # Check alignment with security giants
        alignment_score = 0.0
        
        for key, giant in self.security_giants.items():
            principle = giant["principle"].lower()
            weight = giant["weight"]
            
            # Count matching words (simple approach)
            matches = sum(1 for word in principle.split() if word in command.lower())
            total_words = len(principle.split())
            
            if total_words > 0:
                alignment_score += weight * (matches / total_words)
        
        # Penalty for risky operations (detected by patterns)
        penalty = 0.0
        for pattern in self.patterns["bash"]:
            if re.search(pattern.pattern, command, re.IGNORECASE):
                if pattern.security_level == SecurityLevel.ZERO_TRUST:
                    penalty += 0.5
                elif pattern.security_level == SecurityLevel.GUARDED:
                    penalty += 0.2
        
        security_snr = max(0.0, alignment_score - penalty)
        return min(1.0, security_snr)
    
    def _calculate_safety_compliance(self, command: str, matched_patterns: List) -> float:
        """
        Calculate safety compliance score (0.0 to 1.0).
        
        Used to extend SNR formula: SNR = base_snr * safety_compliance
        """
        if not matched_patterns:
            return 1.0  # No patterns matched, fully safe
        
        # Calculate penalty based on security levels
        penalty = 0.0
        for match in matched_patterns:
            if match["security_level"] == SecurityLevel.ZERO_TRUST:
                penalty += 0.5
            elif match["security_level"] == SecurityLevel.GUARDED:
                penalty += 0.2
            elif match["security_level"] == SecurityLevel.PERMISSIVE:
                penalty += 0.05
        
        safety_compliance = max(0.0, 1.0 - penalty)
        return safety_compliance
    
    def get_security_thoughts(self) -> str:
        """Get the security graph of thoughts visualization."""
        return self.thought_orchestrator.visualize_text()
    
    def elevate_security_sape(self) -> str:
        """Elevate security patterns to higher-order principles."""
        return self.thought_orchestrator.elevate_sape()
    
    def generate_security_report(self, command: str, evaluation: Dict) -> Dict[str, any]:
        """Generate comprehensive security report."""
        return {
            "command": command,
            "hash": hashlib.sha256(command.encode()).hexdigest()[:16],
            "timestamp": time.time(),
            "evaluation": evaluation,
            "security_giants_alignment": self._get_giants_alignment(command),
            "thought_graph": self.get_security_thoughts(),
            "sape_elevation": self.elevate_security_sape()
        }


# Global instance for easy access
_damage_control_engine = None

def get_damage_control_engine(context: Optional[SecurityContext] = None) -> DamageControlEngine:
    """Get or create the damage control engine instance."""
    global _damage_control_engine
    
    if _damage_control_engine is None and context is not None:
        _damage_control_engine = DamageControlEngine(context)
    
    return _damage_control_engine


# Example usage and testing
if __name__ == "__main__":
    import time
    
    context = SecurityContext(
        agent_role="PEAK_MASTERPIECE_ORCHESTRATOR",
        session_id="test-session-001",
        tool_type="bash",
        working_directory="/home/test",
        user_identity="architect"
    )
    
    engine = DamageControlEngine(context)
    
    # Test commands
    test_commands = [
        "rm -rf /tmp/test",
        "git status",
        "chmod 777 /etc/passwd",
        "DELETE FROM users WHERE id = 1;",
        "terraform destroy -auto-approve",
    ]
    
    print("🔒 BIZRA Damage Control Engine Test")
    print("=" * 60)
    
    for cmd in test_commands:
        print(f"\nCommand: {cmd}")
        result = engine.evaluate_command(cmd)
        print(f"  Allowed: {result['allowed']}")
        print(f"  Security Level: {result['security_level'].name}")
        print(f"  Safety SNR: {result['snr_safety_score']:.3f}")
        
        if result['reasons']:
            print(f"  Block Reasons: {result['reasons']}")
        
        if result['requires_confirmation']:
            print(f"  Requires Confirmation: {result['confirmation_reason']}")
    
    print("\n" + "=" * 60)
    print("Security Thoughts Graph:")
    print(engine.get_security_thoughts())
    print("\nSAPE Elevation:")
    print(engine.elevate_security_sape())