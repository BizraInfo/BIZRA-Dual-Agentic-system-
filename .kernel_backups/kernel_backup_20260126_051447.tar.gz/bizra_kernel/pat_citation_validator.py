"""
PAT Citation Validator - Elite Practitioner Citation Verification System

Validates that all practitioner citations in PAT responses meet elite tier
requirements and are properly attributed with evidence backing.

BIZRA PAT System Component
SNR Target: 0.98+ | Citation Integrity: 100%
"""

import re
import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple
import yaml
from pathlib import Path


class CitationStatus(Enum):
    """Citation validation status."""
    VALID = "valid"
    INVALID_PRACTITIONER = "invalid_practitioner"
    INVALID_TIER = "invalid_tier"
    MISSING_CONTEXT = "missing_context"
    INSUFFICIENT_RELEVANCE = "insufficient_relevance"
    UNVERIFIED = "unverified"


class CitationType(Enum):
    """Types of practitioner citations."""
    DIRECT_QUOTE = "direct_quote"           # "[Name] states that..."
    METHODOLOGY = "methodology"              # "Using [Name]'s approach..."
    FRAMEWORK = "framework"                  # "[Name]'s framework suggests..."
    PRINCIPLE = "principle"                  # "Per [Name]'s principle..."
    CONTRIBUTION = "contribution"            # "[Name] contributed..."
    IMPLICIT = "implicit"                    # Referenced without explicit attribution


@dataclass
class Citation:
    """A single practitioner citation."""
    practitioner_name: str
    domain: str
    citation_type: CitationType
    context: str
    relevance_score: float = 0.0
    tier: str = ""
    status: CitationStatus = CitationStatus.UNVERIFIED
    evidence_hash: str = ""

    def __post_init__(self):
        if not self.evidence_hash:
            self.evidence_hash = self._compute_hash()

    def _compute_hash(self) -> str:
        """Compute citation evidence hash."""
        content = f"{self.practitioner_name}:{self.domain}:{self.context}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]


@dataclass
class CitationValidationResult:
    """Result of citation validation."""
    total_citations: int
    valid_citations: int
    invalid_citations: int
    citations_by_domain: Dict[str, List[Citation]]
    citations_by_status: Dict[CitationStatus, List[Citation]]
    domain_coverage: Dict[str, int]
    tier_distribution: Dict[str, int]
    average_relevance: float
    meets_requirements: bool
    errors: List[str]
    warnings: List[str]
    evidence_chain: List[str]

    @property
    def validity_ratio(self) -> float:
        """Calculate validity ratio."""
        if self.total_citations == 0:
            return 0.0
        return self.valid_citations / self.total_citations

    @property
    def domains_covered(self) -> int:
        """Count domains with sufficient citations."""
        return sum(1 for count in self.domain_coverage.values() if count >= 3)


class PATCitationValidator:
    """
    Elite Practitioner Citation Validation System.

    Ensures all practitioner citations in PAT responses meet quality standards:
    - Practitioners must be in registry
    - Tier must be top_1%
    - Minimum 3 practitioners per domain
    - Relevance score >= 0.60
    - Proper attribution format
    """

    MIN_PRACTITIONERS_PER_DOMAIN = 3
    REQUIRED_TIER = "top_1%"
    MIN_RELEVANCE = 0.60

    # Citation extraction patterns
    CITATION_PATTERNS = [
        # Direct attribution: "According to Terence Tao..."
        r"(?:According to|As (?:noted|stated|observed|argued) by|Per)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)",
        # Methodology: "Using Lamport's approach..."
        r"(?:Using|Applying|Following)\s+([A-Z][a-z]+(?:'s)?)",
        # Framework reference: "Parfit's framework..."
        r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'s\s+(?:framework|principle|theory|approach|method|work)",
        # Contribution: "Sutton contributed..."
        r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:contributed|demonstrated|proved|established|showed)",
        # Table format: "| Mathematics | Terence Tao | top_1% |"
        r"\|\s*\w+\s*\|\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s*\|\s*top_1%",
        # Parenthetical: "(Hinton, 2012)"
        r"\(([A-Z][a-z]+)(?:,?\s*\d{4})?\)",
        # "X and Y" joint citation
        r"([A-Z][a-z]+)\s+and\s+([A-Z][a-z]+)\s+(?:developed|created|proposed)",
    ]

    def __init__(self, domains_path: Optional[str] = None):
        """Initialize with practitioner registry."""
        self.domains_path = domains_path or "config/pat_enforcement/pat_domains.yaml"
        self._load_registry()

    def _load_registry(self):
        """Load practitioner registry from YAML."""
        self.practitioners: Dict[str, Dict] = {}
        self.name_to_domain: Dict[str, str] = {}
        self.domain_practitioners: Dict[str, List[str]] = {}

        registry_path = Path(self.domains_path)
        if not registry_path.exists():
            # Try relative to module
            module_dir = Path(__file__).parent.parent
            registry_path = module_dir / self.domains_path

        if registry_path.exists():
            with open(registry_path, 'r') as f:
                data = yaml.safe_load(f)

            for domain, practitioners in data.get('practitioners', {}).items():
                self.domain_practitioners[domain] = []
                for p in practitioners:
                    name = p.get('name', '')
                    self.practitioners[name] = {
                        'domain': domain,
                        'tier': p.get('tier', ''),
                        'expertise': p.get('expertise', []),
                        'keywords': p.get('relevance_keywords', []),
                    }
                    self.name_to_domain[name] = domain
                    self.domain_practitioners[domain].append(name)

                    # Also index by last name for matching
                    last_name = name.split()[-1] if name else ''
                    if last_name and last_name not in self.name_to_domain:
                        self.name_to_domain[last_name] = domain

    def extract_citations(self, content: str) -> List[Citation]:
        """Extract all practitioner citations from content."""
        citations = []
        found_names: Set[str] = set()

        for pattern in self.CITATION_PATTERNS:
            matches = re.finditer(pattern, content, re.IGNORECASE)
            for match in matches:
                # Handle patterns with multiple groups
                for group in match.groups():
                    if group:
                        name = group.strip()
                        if name and name not in found_names:
                            citation = self._create_citation(name, content, match)
                            if citation:
                                citations.append(citation)
                                found_names.add(name)

        # Also check for known practitioners directly
        for name in self.practitioners.keys():
            if name in content and name not in found_names:
                citation = self._create_citation(name, content, None)
                if citation:
                    citations.append(citation)
                    found_names.add(name)

        return citations

    def _create_citation(self, name: str, content: str, match: Optional[re.Match]) -> Optional[Citation]:
        """Create a citation object from extracted name."""
        # Resolve practitioner
        full_name = self._resolve_practitioner(name)
        if not full_name:
            return None

        practitioner = self.practitioners.get(full_name)
        if not practitioner:
            return None

        # Determine citation type
        citation_type = self._determine_citation_type(content, name)

        # Extract context (surrounding text)
        context = self._extract_context(content, name)

        # Calculate relevance
        relevance = self._calculate_relevance(full_name, context)

        return Citation(
            practitioner_name=full_name,
            domain=practitioner['domain'],
            citation_type=citation_type,
            context=context,
            relevance_score=relevance,
            tier=practitioner['tier'],
            status=CitationStatus.UNVERIFIED,
        )

    def _resolve_practitioner(self, name: str) -> Optional[str]:
        """Resolve partial name to full practitioner name."""
        # Direct match
        if name in self.practitioners:
            return name

        # Last name match
        if name in self.name_to_domain:
            domain = self.name_to_domain[name]
            for pname in self.domain_practitioners.get(domain, []):
                if pname.endswith(name) or name in pname:
                    return pname

        # Fuzzy match
        name_lower = name.lower()
        for pname in self.practitioners.keys():
            if name_lower in pname.lower() or pname.lower() in name_lower:
                return pname

        return None

    def _determine_citation_type(self, content: str, name: str) -> CitationType:
        """Determine the type of citation based on context."""
        # Find context around name
        idx = content.lower().find(name.lower())
        if idx == -1:
            return CitationType.IMPLICIT

        start = max(0, idx - 50)
        context = content[start:idx + len(name) + 50].lower()

        if any(word in context for word in ['according to', 'states', 'argues', 'noted']):
            return CitationType.DIRECT_QUOTE
        if any(word in context for word in ['using', 'applying', 'following']):
            return CitationType.METHODOLOGY
        if "'s framework" in context or "'s theory" in context:
            return CitationType.FRAMEWORK
        if "'s principle" in context or "per " in context:
            return CitationType.PRINCIPLE
        if any(word in context for word in ['contributed', 'developed', 'created']):
            return CitationType.CONTRIBUTION

        return CitationType.IMPLICIT

    def _extract_context(self, content: str, name: str) -> str:
        """Extract surrounding context for citation."""
        idx = content.find(name)
        if idx == -1:
            idx = content.lower().find(name.lower())
        if idx == -1:
            return ""

        start = max(0, idx - 100)
        end = min(len(content), idx + len(name) + 100)
        return content[start:end].strip()

    def _calculate_relevance(self, name: str, context: str) -> float:
        """Calculate relevance score based on keyword matching."""
        practitioner = self.practitioners.get(name, {})
        keywords = practitioner.get('keywords', [])
        expertise = practitioner.get('expertise', [])

        if not keywords and not expertise:
            return 0.70  # Default relevance for known practitioners

        all_keywords = set(k.lower() for k in keywords + expertise)
        context_lower = context.lower()

        matches = sum(1 for kw in all_keywords if kw in context_lower)
        if not all_keywords:
            return 0.70

        return min(1.0, 0.50 + (matches / len(all_keywords)) * 0.50)

    def validate_citation(self, citation: Citation) -> Citation:
        """Validate a single citation."""
        errors = []

        # Check if practitioner exists
        if citation.practitioner_name not in self.practitioners:
            citation.status = CitationStatus.INVALID_PRACTITIONER
            return citation

        practitioner = self.practitioners[citation.practitioner_name]

        # Check tier
        if practitioner['tier'] != self.REQUIRED_TIER:
            citation.status = CitationStatus.INVALID_TIER
            return citation

        # Check relevance
        if citation.relevance_score < self.MIN_RELEVANCE:
            citation.status = CitationStatus.INSUFFICIENT_RELEVANCE
            return citation

        # Check context
        if not citation.context or len(citation.context) < 20:
            citation.status = CitationStatus.MISSING_CONTEXT
            return citation

        citation.status = CitationStatus.VALID
        return citation

    def validate_response(self, content: str, required_domains: Optional[List[str]] = None) -> CitationValidationResult:
        """
        Validate all citations in a PAT response.

        Args:
            content: The response content to validate
            required_domains: Optional list of domains that must be covered

        Returns:
            CitationValidationResult with detailed validation results
        """
        # Extract citations
        citations = self.extract_citations(content)

        # Validate each citation
        validated_citations = [self.validate_citation(c) for c in citations]

        # Organize by domain and status
        by_domain: Dict[str, List[Citation]] = {}
        by_status: Dict[CitationStatus, List[Citation]] = {s: [] for s in CitationStatus}
        domain_coverage: Dict[str, int] = {}
        tier_distribution: Dict[str, int] = {}

        valid_count = 0
        invalid_count = 0
        total_relevance = 0.0
        evidence_chain = []

        for citation in validated_citations:
            # By domain
            if citation.domain not in by_domain:
                by_domain[citation.domain] = []
            by_domain[citation.domain].append(citation)

            # By status
            by_status[citation.status].append(citation)

            # Counts
            if citation.status == CitationStatus.VALID:
                valid_count += 1
                domain_coverage[citation.domain] = domain_coverage.get(citation.domain, 0) + 1
                tier_distribution[citation.tier] = tier_distribution.get(citation.tier, 0) + 1
                total_relevance += citation.relevance_score
                evidence_chain.append(citation.evidence_hash)
            else:
                invalid_count += 1

        # Check requirements
        errors = []
        warnings = []

        # Check domain coverage
        if required_domains:
            for domain in required_domains:
                count = domain_coverage.get(domain, 0)
                if count < self.MIN_PRACTITIONERS_PER_DOMAIN:
                    errors.append(
                        f"Domain '{domain}' has {count} valid citations, "
                        f"requires {self.MIN_PRACTITIONERS_PER_DOMAIN}"
                    )

        # Check overall coverage
        domains_with_min = sum(
            1 for count in domain_coverage.values()
            if count >= self.MIN_PRACTITIONERS_PER_DOMAIN
        )

        if domains_with_min < 3:
            errors.append(
                f"Only {domains_with_min} domains have minimum citations, requires 3"
            )

        # Warnings for invalid citations
        for status, cites in by_status.items():
            if status != CitationStatus.VALID and cites:
                warnings.append(
                    f"{len(cites)} citations have status: {status.value}"
                )

        # Calculate average relevance
        avg_relevance = total_relevance / valid_count if valid_count > 0 else 0.0

        # Determine if requirements met
        meets_requirements = (
            len(errors) == 0 and
            valid_count >= 9 and  # 3 domains × 3 practitioners
            avg_relevance >= self.MIN_RELEVANCE
        )

        return CitationValidationResult(
            total_citations=len(validated_citations),
            valid_citations=valid_count,
            invalid_citations=invalid_count,
            citations_by_domain=by_domain,
            citations_by_status=by_status,
            domain_coverage=domain_coverage,
            tier_distribution=tier_distribution,
            average_relevance=avg_relevance,
            meets_requirements=meets_requirements,
            errors=errors,
            warnings=warnings,
            evidence_chain=evidence_chain,
        )

    def generate_citation_report(self, result: CitationValidationResult) -> str:
        """Generate a formatted citation validation report."""
        lines = [
            "## Citation Validation Report",
            "",
            f"**Timestamp:** {datetime.now().isoformat()}",
            f"**Total Citations:** {result.total_citations}",
            f"**Valid:** {result.valid_citations} | **Invalid:** {result.invalid_citations}",
            f"**Validity Ratio:** {result.validity_ratio:.2%}",
            f"**Average Relevance:** {result.average_relevance:.3f}",
            "",
            "### Domain Coverage",
            "",
            "| Domain | Valid Citations | Status |",
            "|--------|-----------------|--------|",
        ]

        for domain, count in sorted(result.domain_coverage.items()):
            status = "✓" if count >= self.MIN_PRACTITIONERS_PER_DOMAIN else "✗"
            lines.append(f"| {domain} | {count} | {status} |")

        lines.extend([
            "",
            "### Tier Distribution",
            "",
        ])

        for tier, count in sorted(result.tier_distribution.items()):
            lines.append(f"- **{tier}**: {count} citations")

        if result.errors:
            lines.extend([
                "",
                "### Errors",
                "",
            ])
            for error in result.errors:
                lines.append(f"- ❌ {error}")

        if result.warnings:
            lines.extend([
                "",
                "### Warnings",
                "",
            ])
            for warning in result.warnings:
                lines.append(f"- ⚠️ {warning}")

        lines.extend([
            "",
            f"### Overall Status: {'✓ PASS' if result.meets_requirements else '✗ FAIL'}",
            "",
            f"Evidence Chain: `{'-'.join(result.evidence_chain[:5])}`",
        ])

        return "\n".join(lines)

    def suggest_additional_citations(
        self,
        current_domains: List[str],
        target_per_domain: int = 3
    ) -> Dict[str, List[str]]:
        """
        Suggest additional practitioners to cite for uncovered domains.

        Args:
            current_domains: Domains currently covered
            target_per_domain: Target number of practitioners per domain

        Returns:
            Dict mapping domains to suggested practitioner names
        """
        suggestions = {}

        # Find domains needing more coverage
        all_domains = set(self.domain_practitioners.keys())
        covered = set(current_domains)
        uncovered = all_domains - covered

        for domain in uncovered:
            practitioners = self.domain_practitioners.get(domain, [])
            if practitioners:
                # Suggest top practitioners from this domain
                suggestions[domain] = practitioners[:target_per_domain]

        return suggestions


# Receipt generation for citation validation
def generate_citation_receipt(result: CitationValidationResult, session_id: str) -> Dict:
    """Generate an evidence receipt for citation validation."""
    receipt_content = {
        "total": result.total_citations,
        "valid": result.valid_citations,
        "domains": list(result.domain_coverage.keys()),
        "relevance": result.average_relevance,
        "evidence_chain": result.evidence_chain,
    }

    return {
        "receipt_id": f"cite-{session_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        "receipt_type": "citation_validation",
        "timestamp": datetime.now().isoformat(),
        "session_id": session_id,
        "validation_result": {
            "total_citations": result.total_citations,
            "valid_citations": result.valid_citations,
            "validity_ratio": result.validity_ratio,
            "domains_covered": result.domains_covered,
            "average_relevance": result.average_relevance,
            "meets_requirements": result.meets_requirements,
        },
        "errors": result.errors,
        "warnings": result.warnings,
        "integrity_hash": hashlib.sha256(
            str(receipt_content).encode()
        ).hexdigest(),
    }


if __name__ == "__main__":
    # Test the citation validator
    validator = PATCitationValidator()

    test_content = """
    ## Elite Practitioner Anchoring

    | Domain | Practitioner | Tier | Relevance | Key Contributions |
    | ------ | ------------ | ---- | --------- | ----------------- |
    | Mathematics | Terence Tao | top_1% | 0.95 | harmonic analysis |
    | Computer Science | Leslie Lamport | top_1% | 0.92 | distributed systems |
    | Philosophy | Derek Parfit | top_1% | 0.88 | ethics, rationality |

    According to Terence Tao, the mathematical foundations require careful analysis.
    Using Lamport's approach to distributed consensus, we can ensure safety.
    Parfit's framework for ethical reasoning guides our decision-making.
    """

    result = validator.validate_response(test_content)
    report = validator.generate_citation_report(result)
    print(report)

    print("\n" + "="*60 + "\n")

    receipt = generate_citation_receipt(result, "test-session")
    import json
    print(json.dumps(receipt, indent=2))
