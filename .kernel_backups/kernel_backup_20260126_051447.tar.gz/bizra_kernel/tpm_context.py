"""
BIZRA TPM Context Module
========================
Hardware Root of Trust integration for the Sovereign Kernel.
Provides TPM 2.0 operations, PCR measurements, and secure boot verification.

In simulation mode (when real TPM is unavailable), uses software emulation
with the same API for development and testing.
"""

import hashlib
import json
import logging
import os
from typing import Dict, List, Optional, Tuple
from enum import Enum


class TpmMode(Enum):
    """TPM operation mode."""
    REAL = 1
    SIMULATION = 2


class TpmContext:
    """
    TPM Context for hardware root of trust operations.
    
    Provides:
    - PCR measurement and extension
    - Attestation verification
    - Secure boot integrity checks
    - Merkle tree root for measured boot
    """
    
    def __init__(self, mode: TpmMode = None):
        """
        Initialize TPM context.
        
        Args:
            mode: TpmMode.REAL for actual TPM, TpmMode.SIMULATION for software emulation.
                  If None, auto-detect (prefers REAL if available).
        """
        self.mode = mode or self._detect_tpm_mode()
        self.pcrs = {i: bytes(20) for i in range(24)}  # SHA-1 PCRs, initialized to 20 zero bytes
        self.merkle_tree = {}
        self.measured_hashes = {}
        
        # For simulation mode, we'll store the PCR values in memory
        # In real mode, we'd use the TPM's actual PCRs
        self._simulation_pcrs = {i: bytearray(20) for i in range(24)}
        
        # Load or create initial state
        self._initialize_context()
    
    def _detect_tpm_mode(self) -> TpmMode:
        """
        Detect if real TPM is available.
        
        Returns:
            TpmMode.REAL if TPM device exists, otherwise TpmMode.SIMULATION.
        """
        # Check for TPM device in typical Linux locations
        tpm_paths = [
            "/dev/tpm0",
            "/dev/tpmrm0",
            "/sys/class/tpm/tpm0"
        ]
        
        for path in tpm_paths:
            if os.path.exists(path):
                logging.info(f"[TPM] Real TPM detected at {path}")
                return TpmMode.REAL
        
        logging.warning("[TPM] No real TPM detected, running in simulation mode")
        return TpmMode.SIMULATION
    
    def _initialize_context(self):
        """Initialize TPM context with PCRs and Merkle tree."""
        # Initialize PCR 0 with a known boot hash (simulated)
        if self.mode == TpmMode.SIMULATION:
            # In simulation, we start with a known genesis hash
            genesis_hash = hashlib.sha256(b"BIZRA_GENESIS_BOOT").digest()
            self._extend_pcr_simulation(0, genesis_hash)
            
            # Also measure our own code
            self.measure_module("sovereign_main.py")
            self.measure_module("bizra_kernel/tpm_context.py")
    
    def _extend_pcr_simulation(self, pcr_index: int, data: bytes):
        """
        Extend a PCR in simulation mode.
        
        PCR extension formula: new_pcr = SHA1(old_pcr + data)
        """
        if pcr_index not in self._simulation_pcrs:
            raise ValueError(f"Invalid PCR index: {pcr_index}")
        
        old_value = self._simulation_pcrs[pcr_index]
        hash_input = bytes(old_value) + data
        new_value = hashlib.sha1(hash_input).digest()
        
        self._simulation_pcrs[pcr_index] = bytearray(new_value)
        logging.debug(f"[TPM] Extended PCR[{pcr_index}] to {new_value.hex()[:16]}...")
    
    def measure_module(self, module_path: str) -> bytes:
        """
        Measure a module (file) and extend PCR.
        
        Args:
            module_path: Path to the module/file to measure.
            
        Returns:
            bytes: The hash of the measured module.
        """
        try:
            with open(module_path, 'rb') as f:
                content = f.read()
        except FileNotFoundError:
            # For simulation, if file doesn't exist, use the path as content
            content = module_path.encode('utf-8')
        
        # Calculate hash (SHA-256 for module measurement)
        module_hash = hashlib.sha256(content).digest()
        
        # Store the measured hash for later verification
        self.measured_hashes[module_path] = module_hash
        
        # Extend PCR 12 for kernel modules, PCR 13 for FATE, PCR 14 for spine
        # This follows the patina UEFI firmware measurement scheme
        if "sovereign_main.py" in module_path:
            pcr_index = 12  # Kernel core
        elif "fate" in module_path.lower():
            pcr_index = 13  # FATE engine
        elif "spine" in module_path.lower():
            pcr_index = 14  # Sovereign spine
        else:
            pcr_index = 15  # Other modules
        
        if self.mode == TpmMode.SIMULATION:
            self._extend_pcr_simulation(pcr_index, module_hash)
        else:
            # In real mode, we'd call TPM2_Extend
            # This is a placeholder for actual TPM integration
            pass
        
        logging.info(f"[TPM] Measured {module_path} -> PCR[{pcr_index}]")
        return module_hash
    
    def extend_pcr(self, event_name: str, data: str) -> bytes:
        """
        Extend a PCR with an event (for logging and attestation).
        
        Args:
            event_name: Name of the event (e.g., "FATE_VIOLATION").
            data: Event data string.
            
        Returns:
            bytes: The new PCR value after extension.
        """
        # Use PCR 16 for system events (according to TCG spec)
        pcr_index = 16
        
        # Create event structure
        event = {
            "name": event_name,
            "data": data,
            "timestamp": time.time()
        }
        event_bytes = json.dumps(event, sort_keys=True).encode('utf-8')
        
        if self.mode == TpmMode.SIMULATION:
            self._extend_pcr_simulation(pcr_index, event_bytes)
            return bytes(self._simulation_pcrs[pcr_index])
        else:
            # Real TPM extension would go here
            # For now, return zeros in real mode (placeholder)
            return bytes(20)
    
    def verify_attestation(self) -> bool:
        """
        Verify TPM attestation (quote verification).
        
        Returns:
            bool: True if attestation is valid, False otherwise.
        """
        if self.mode == TpmMode.SIMULATION:
            # In simulation, we trust our own measurements
            logging.info("[TPM] Simulation mode: Attestation accepted (self-trust)")
            return True
        else:
            # Real TPM attestation verification would go here
            # This would involve:
            # 1. Getting a quote from the TPM
            # 2. Verifying the quote signature against the AIK
            # 3. Checking PCR values against expected values
            logging.warning("[TPM] Real TPM attestation not implemented in this version")
            return True  # Placeholder
    
    def get_merkle_root(self) -> str:
        """
        Get the Merkle root of all measurements.
        
        Returns:
            str: Hex-encoded Merkle root.
        """
        # Build Merkle tree from measured hashes
        if not self.measured_hashes:
            return hashlib.sha256(b"GENESIS").hexdigest()
        
        # Sort by module path for deterministic ordering
        sorted_hashes = [self.measured_hashes[k] for k in sorted(self.measured_hashes.keys())]
        
        # Simple Merkle tree: hash concatenation of all hashes
        combined = b"".join(sorted_hashes)
        merkle_root = hashlib.sha256(combined).digest()
        
        return merkle_root.hex()
    
    def get_pcr_value(self, pcr_index: int) -> bytes:
        """
        Get current PCR value.
        
        Args:
            pcr_index: PCR index (0-23).
            
        Returns:
            bytes: PCR value.
        """
        if pcr_index not in range(24):
            raise ValueError(f"Invalid PCR index: {pcr_index}")
        
        if self.mode == TpmMode.SIMULATION:
            return bytes(self._simulation_pcrs[pcr_index])
        else:
            # Real TPM read would go here
            return bytes(20)  # Placeholder
    
    def get_expected_hash(self, module_name: str) -> Optional[bytes]:
        """
        Get the expected hash for a module (if it was measured during boot).
        
        Args:
            module_name: Module name or path.
            
        Returns:
            bytes or None: The expected hash if module was measured, None otherwise.
        """
        return self.measured_hashes.get(module_name)


# Global instance for easy access
_tpm_context = None

def get_tpm_context() -> TpmContext:
    """Get or create the TPM context instance."""
    global _tpm_context
    
    if _tpm_context is None:
        _tpm_context = TpmContext()
    
    return _tpm_context


# For standalone testing
if __name__ == "__main__":
    import time
    
    logging.basicConfig(level=logging.INFO)
    
    tpm = TpmContext()
    print(f"TPM Mode: {tpm.mode.name}")
    
    # Measure some modules
    tpm.measure_module("sovereign_main.py")
    tpm.measure_module("bizra_kernel/fate_engine.py")
    tpm.measure_module("bizra_kernel/spine.rs")
    
    # Extend an event
    tpm.extend_pcr("BOOT_COMPLETE", "System booted successfully")
    
    # Get Merkle root
    merkle_root = tpm.get_merkle_root()
    print(f"Merkle Root: {merkle_root[:32]}...")
    
    # Verify attestation
    if tpm.verify_attestation():
        print("TPM Attestation: VERIFIED")
    else:
        print("TPM Attestation: FAILED")
