"""
PAT Practitioner Registry - Elite Practitioner Lookup
======================================================
Provides access to elite practitioners (top 1%) per domain.

From PAT Enforcement Constitution:
- min_per_domain: 3
- tier_required: top_1%
- relevance_threshold: 0.60
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple
from pathlib import Path
import yaml
import re


@dataclass
class Practitioner:
    """An elite practitioner record."""
    id: str
    name: str
    domain: str
    tier: str
    specializations: List[str]
    citation_impact: float
    keywords: List[str]

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "domain": self.domain,
            "tier": self.tier,
            "specializations": self.specializations,
            "citation_impact": self.citation_impact,
            "keywords": self.keywords,
        }


@dataclass
class PractitionerMatch:
    """A matched practitioner with relevance score."""
    practitioner: Practitioner
    relevance_score: float
    matched_keywords: List[str]
    matched_specializations: List[str]

    def to_dict(self) -> dict:
        return {
            "practitioner": self.practitioner.to_dict(),
            "relevance_score": self.relevance_score,
            "matched_keywords": self.matched_keywords,
            "matched_specializations": self.matched_specializations,
        }


@dataclass
class DomainPractitioners:
    """Practitioners for a specific domain."""
    domain: str
    practitioners: List[PractitionerMatch]
    total_count: int
    top_1_percent_count: int

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "practitioners": [p.to_dict() for p in self.practitioners],
            "total_count": self.total_count,
            "top_1_percent_count": self.top_1_percent_count,
        }


class PractitionerRegistry:
    """
    Registry of elite practitioners for PAT enforcement.

    Provides:
    - Domain-based lookup
    - Keyword-based matching
    - Relevance scoring
    - Top 1% verification
    """

    MIN_PRACTITIONERS_PER_DOMAIN = 3
    TIER_REQUIRED = "top_1%"
    RELEVANCE_THRESHOLD = 0.60

    def __init__(self, config_path: Optional[str] = None):
        """Initialize registry with domain config."""
        self.config_path = config_path or self._default_config_path()
        self._load_registry()

    def _default_config_path(self) -> str:
        """Get default config path."""
        base = Path(__file__).parent.parent
        return str(base / "config" / "pat_enforcement" / "pat_domains.yaml")

    def _load_registry(self) -> None:
        """Load practitioner registry from YAML."""
        try:
            with open(self.config_path, 'r') as f:
                config = yaml.safe_load(f)
                self.practitioners_data = config.get("practitioners", {})
        except FileNotFoundError:
            self.practitioners_data = self._minimal_registry()

        # Build indexed structures
        self._build_indices()

    def _minimal_registry(self) -> dict:
        """Minimal fallback registry if config not found."""
        return {
            "computer_science": [
                {
                    "id": "leslie_lamport",
                    "name": "Leslie Lamport",
                    "tier": "top_1%",
                    "specializations": ["distributed_systems", "temporal_logic"],
                    "citation_impact": 0.99,
                    "keywords": ["consensus", "paxos", "tla+"],
                },
            ],
            "philosophy": [
                {
                    "id": "derek_parfit",
                    "name": "Derek Parfit",
                    "tier": "top_1%",
                    "specializations": ["personal_identity", "ethics"],
                    "citation_impact": 0.97,
                    "keywords": ["reasons", "consequentialism"],
                },
            ],
            "mathematics": [
                {
                    "id": "terence_tao",
                    "name": "Terence Tao",
                    "tier": "top_1%",
                    "specializations": ["harmonic_analysis", "prime_numbers"],
                    "citation_impact": 0.99,
                    "keywords": ["combinatorics", "analysis"],
                },
            ],
        }

    def _build_indices(self) -> None:
        """Build keyword and specialization indices."""
        self.by_domain: Dict[str, List[Practitioner]] = {}
        self.by_keyword: Dict[str, List[Practitioner]] = {}
        self.by_specialization: Dict[str, List[Practitioner]] = {}
        self.all_practitioners: List[Practitioner] = []

        for domain, practitioners in self.practitioners_data.items():
            self.by_domain[domain] = []

            for p_data in practitioners:
                practitioner = Practitioner(
                    id=p_data.get("id", "unknown"),
                    name=p_data.get("name", "Unknown"),
                    domain=domain,
                    tier=p_data.get("tier", "unranked"),
                    specializations=p_data.get("specializations", []),
                    citation_impact=p_data.get("citation_impact", 0.5),
                    keywords=p_data.get("keywords", []),
                )

                self.by_domain[domain].append(practitioner)
                self.all_practitioners.append(practitioner)

                # Index by keyword
                for keyword in practitioner.keywords:
                    if keyword not in self.by_keyword:
                        self.by_keyword[keyword] = []
                    self.by_keyword[keyword].append(practitioner)

                # Index by specialization
                for spec in practitioner.specializations:
                    if spec not in self.by_specialization:
                        self.by_specialization[spec] = []
                    self.by_specialization[spec].append(practitioner)

    def get_domain_practitioners(self, domain: str) -> List[Practitioner]:
        """Get all practitioners for a domain."""
        return self.by_domain.get(domain, [])

    def get_top_tier_only(self, domain: str) -> List[Practitioner]:
        """Get only top 1% practitioners for a domain."""
        return [
            p for p in self.by_domain.get(domain, [])
            if p.tier == self.TIER_REQUIRED
        ]

    def calculate_relevance(
        self,
        practitioner: Practitioner,
        query: str
    ) -> Tuple[float, List[str], List[str]]:
        """
        Calculate relevance of practitioner to query.

        Returns:
            Tuple of (score, matched_keywords, matched_specializations)
        """
        query_lower = query.lower()
        matched_keywords = []
        matched_specializations = []

        # Check keyword matches
        for keyword in practitioner.keywords:
            keyword_pattern = r'\b' + keyword.replace('_', ' ') + r'\b'
            if re.search(keyword_pattern, query_lower):
                matched_keywords.append(keyword)

        # Check specialization matches
        for spec in practitioner.specializations:
            spec_pattern = r'\b' + spec.replace('_', ' ') + r'\b'
            if re.search(spec_pattern, query_lower):
                matched_specializations.append(spec)

        # Calculate score
        keyword_score = min(len(matched_keywords) * 0.2, 0.4)
        spec_score = min(len(matched_specializations) * 0.3, 0.6)
        base_score = 0.3 if matched_keywords or matched_specializations else 0.0

        # Boost by citation impact
        impact_boost = practitioner.citation_impact * 0.3

        relevance_score = min(1.0, base_score + keyword_score + spec_score + impact_boost)

        return relevance_score, matched_keywords, matched_specializations

    def find_relevant_practitioners(
        self,
        domain: str,
        query: str,
        min_count: int = 3,
        min_relevance: float = 0.60
    ) -> DomainPractitioners:
        """
        Find relevant practitioners for a domain based on query.

        Args:
            domain: Target domain
            query: Query to match against
            min_count: Minimum practitioners to return
            min_relevance: Minimum relevance threshold

        Returns:
            DomainPractitioners with matched practitioners
        """
        domain_practitioners = self.get_top_tier_only(domain)
        all_domain = self.get_domain_practitioners(domain)

        matches = []
        for practitioner in domain_practitioners:
            relevance, keywords, specs = self.calculate_relevance(practitioner, query)
            if relevance >= min_relevance or len(matches) < min_count:
                matches.append(PractitionerMatch(
                    practitioner=practitioner,
                    relevance_score=relevance,
                    matched_keywords=keywords,
                    matched_specializations=specs,
                ))

        # Sort by relevance
        matches.sort(key=lambda x: x.relevance_score, reverse=True)

        # If we don't have enough, add lower relevance matches
        if len(matches) < min_count and len(domain_practitioners) > len(matches):
            remaining = [
                p for p in domain_practitioners
                if p.id not in {m.practitioner.id for m in matches}
            ]
            for practitioner in remaining[:min_count - len(matches)]:
                relevance, keywords, specs = self.calculate_relevance(practitioner, query)
                matches.append(PractitionerMatch(
                    practitioner=practitioner,
                    relevance_score=relevance,
                    matched_keywords=keywords,
                    matched_specializations=specs,
                ))

        return DomainPractitioners(
            domain=domain,
            practitioners=matches[:min_count],
            total_count=len(all_domain),
            top_1_percent_count=len(domain_practitioners),
        )

    def find_practitioners_for_domains(
        self,
        domains: List[str],
        query: str
    ) -> Dict[str, DomainPractitioners]:
        """
        Find practitioners for multiple domains.

        Args:
            domains: List of domains
            query: Query to match against

        Returns:
            Dict mapping domain to DomainPractitioners
        """
        result = {}
        for domain in domains:
            result[domain] = self.find_relevant_practitioners(domain, query)
        return result

    def search_by_keyword(
        self,
        keyword: str,
        top_n: int = 5
    ) -> List[Practitioner]:
        """Search practitioners by keyword."""
        keyword_lower = keyword.lower().replace(' ', '_')
        matches = self.by_keyword.get(keyword_lower, [])
        return matches[:top_n]

    def search_by_specialization(
        self,
        specialization: str,
        top_n: int = 5
    ) -> List[Practitioner]:
        """Search practitioners by specialization."""
        spec_lower = specialization.lower().replace(' ', '_')
        matches = self.by_specialization.get(spec_lower, [])
        return matches[:top_n]

    def validate_practitioners(
        self,
        practitioners: Dict[str, List[dict]],
        domains: List[str]
    ) -> Tuple[bool, List[str]]:
        """
        Validate that practitioners meet PAT requirements.

        Args:
            practitioners: Dict mapping domain to list of practitioner dicts
            domains: Required domains

        Returns:
            Tuple of (is_valid, list_of_issues)
        """
        issues = []

        for domain in domains:
            domain_practitioners = practitioners.get(domain, [])

            # Check count
            if len(domain_practitioners) < self.MIN_PRACTITIONERS_PER_DOMAIN:
                issues.append(
                    f"{domain}: has {len(domain_practitioners)}, "
                    f"need {self.MIN_PRACTITIONERS_PER_DOMAIN}"
                )

            # Check tier
            for p in domain_practitioners:
                if p.get("tier") != self.TIER_REQUIRED:
                    issues.append(
                        f"{domain}/{p.get('id', 'unknown')}: "
                        f"tier is {p.get('tier')}, need {self.TIER_REQUIRED}"
                    )

            # Check relevance
            for p in domain_practitioners:
                if p.get("relevance_score", 0) < self.RELEVANCE_THRESHOLD:
                    issues.append(
                        f"{domain}/{p.get('id', 'unknown')}: "
                        f"relevance {p.get('relevance_score', 0):.2f} "
                        f"below threshold {self.RELEVANCE_THRESHOLD}"
                    )

        return len(issues) == 0, issues

    def get_statistics(self) -> dict:
        """Get registry statistics."""
        return {
            "total_practitioners": len(self.all_practitioners),
            "domains_covered": len(self.by_domain),
            "top_1_percent_count": sum(
                1 for p in self.all_practitioners
                if p.tier == self.TIER_REQUIRED
            ),
            "keywords_indexed": len(self.by_keyword),
            "specializations_indexed": len(self.by_specialization),
            "practitioners_per_domain": {
                domain: len(practitioners)
                for domain, practitioners in self.by_domain.items()
            },
        }

    def format_for_response(
        self,
        domain_practitioners: Dict[str, DomainPractitioners]
    ) -> str:
        """
        Format practitioners for PAT response section.

        Returns markdown table format.
        """
        lines = ["| Domain | Practitioner | Tier | Relevance | Specializations |",
                "| ------ | ------------ | ---- | --------- | --------------- |"]

        for domain, dp in domain_practitioners.items():
            for match in dp.practitioners:
                p = match.practitioner
                specs = ", ".join(p.specializations[:3])
                lines.append(
                    f"| {domain} | {p.name} | {p.tier} | "
                    f"{match.relevance_score:.2f} | {specs} |"
                )

        return "\n".join(lines)


if __name__ == "__main__":
    # Test the registry
    registry = PractitionerRegistry()

    stats = registry.get_statistics()
    print(f"Registry stats: {stats}")

    # Test finding practitioners
    query = "distributed systems and consensus protocols"
    result = registry.find_relevant_practitioners("computer_science", query)

    print(f"\nPractitioners for computer_science:")
    for match in result.practitioners:
        print(f"  {match.practitioner.name}: {match.relevance_score:.2f}")
        print(f"    Keywords: {match.matched_keywords}")

    # Test multi-domain
    domains = ["computer_science", "philosophy", "mathematics"]
    multi_result = registry.find_practitioners_for_domains(domains, query)
    print(f"\nMulti-domain search:")
    for domain, dp in multi_result.items():
        print(f"  {domain}: {len(dp.practitioners)} practitioners")
