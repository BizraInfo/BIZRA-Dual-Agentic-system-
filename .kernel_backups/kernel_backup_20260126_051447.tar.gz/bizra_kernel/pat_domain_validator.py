"""
PAT Domain Validator - Cross-Pollination Validation
====================================================
Validates that content spans 3+ unrelated domains with
unrelatedness score >= 0.70 for elite cross-pollination.

From PAT Enforcement Constitution:
- min_domains: 3
- unrelatedness_threshold: 0.70
- min_cross_connections: 2
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple
from datetime import datetime
from pathlib import Path
import yaml
import re


@dataclass
class DomainMatch:
    """A matched domain with relevance score."""
    domain: str
    cluster: str
    relevance_score: float
    matched_keywords: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "cluster": self.cluster,
            "relevance_score": self.relevance_score,
            "matched_keywords": self.matched_keywords,
        }


@dataclass
class CrossConnection:
    """A connection point between two domains."""
    source_domain: str
    target_domain: str
    connection_type: str
    synthesis_point: str
    strength: float = 1.0

    def to_dict(self) -> dict:
        return {
            "source": self.source_domain,
            "target": self.target_domain,
            "type": self.connection_type,
            "synthesis": self.synthesis_point,
            "strength": self.strength,
        }


@dataclass
class CrossPollinationResult:
    """Result of cross-pollination validation."""
    domain_count: int
    domains: List[DomainMatch]
    clusters: Set[str]
    unrelatedness_score: float
    cross_connections: List[CrossConnection]
    meets_threshold: bool
    gate_passed: bool
    corrections_needed: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    def to_dict(self) -> dict:
        return {
            "domain_count": self.domain_count,
            "domains": [d.to_dict() for d in self.domains],
            "clusters": list(self.clusters),
            "unrelatedness_score": self.unrelatedness_score,
            "cross_connections": [c.to_dict() for c in self.cross_connections],
            "meets_threshold": self.meets_threshold,
            "gate_passed": self.gate_passed,
            "corrections_needed": self.corrections_needed,
            "timestamp": self.timestamp,
        }


class DomainCrossPollinationValidator:
    """
    Validates cross-pollination requirements for PAT enforcement.

    Requirements:
    - 3+ domains from different clusters
    - Unrelatedness score >= 0.70
    - 2+ cross-connections between domains
    """

    MIN_DOMAINS = 3
    UNRELATEDNESS_THRESHOLD = 0.70
    MIN_CROSS_CONNECTIONS = 2

    def __init__(self, config_path: Optional[str] = None):
        """Initialize validator with domain registry."""
        self.config_path = config_path or self._default_config_path()
        self._load_registry()

    def _default_config_path(self) -> str:
        """Get default config path."""
        base = Path(__file__).parent.parent
        return str(base / "config" / "pat_enforcement" / "pat_domains.yaml")

    def _load_registry(self) -> None:
        """Load domain registry from YAML."""
        try:
            with open(self.config_path, 'r') as f:
                self.registry = yaml.safe_load(f)
        except FileNotFoundError:
            # Use minimal fallback registry
            self.registry = self._minimal_registry()

        self.clusters = self.registry.get("clusters", {})
        self.unrelatedness_matrix = self.registry.get("unrelatedness_matrix", {})
        self.domain_to_cluster = self.registry.get("domain_to_cluster", {})

        # Build keyword index
        self.keyword_to_domain: Dict[str, List[str]] = {}
        for cluster_id, cluster_data in self.clusters.items():
            keywords = cluster_data.get("keywords", [])
            domains = cluster_data.get("domains", [])
            for kw in keywords:
                if kw not in self.keyword_to_domain:
                    self.keyword_to_domain[kw] = []
                self.keyword_to_domain[kw].extend(domains)

    def _minimal_registry(self) -> dict:
        """Minimal fallback registry if config not found."""
        return {
            "clusters": {
                "formal_sciences": {
                    "id": "FORMAL",
                    "domains": ["mathematics", "computer_science", "logic"],
                    "keywords": ["algorithm", "proof", "computation"],
                },
                "humanities": {
                    "id": "HUMAN",
                    "domains": ["philosophy", "ethics", "history"],
                    "keywords": ["meaning", "value", "culture"],
                },
                "engineering": {
                    "id": "ENGINEER",
                    "domains": ["software_engineering", "systems_engineering"],
                    "keywords": ["design", "architecture", "implementation"],
                },
            },
            "unrelatedness_matrix": {
                "FORMAL": {"FORMAL": 0.0, "HUMAN": 0.80, "ENGINEER": 0.35},
                "HUMAN": {"FORMAL": 0.80, "HUMAN": 0.0, "ENGINEER": 0.85},
                "ENGINEER": {"FORMAL": 0.35, "HUMAN": 0.85, "ENGINEER": 0.0},
            },
            "domain_to_cluster": {
                "mathematics": "FORMAL",
                "computer_science": "FORMAL",
                "logic": "FORMAL",
                "philosophy": "HUMAN",
                "ethics": "HUMAN",
                "history": "HUMAN",
                "software_engineering": "ENGINEER",
                "systems_engineering": "ENGINEER",
            },
        }

    def extract_domains(self, content: str) -> List[DomainMatch]:
        """
        Extract domains from content based on keyword matching.

        Args:
            content: Text to analyze for domain presence

        Returns:
            List of matched domains with relevance scores
        """
        content_lower = content.lower()
        domain_scores: Dict[str, Tuple[float, List[str]]] = {}

        # Match keywords
        for keyword, domains in self.keyword_to_domain.items():
            # Use word boundary matching
            pattern = r'\b' + re.escape(keyword.replace('_', ' ')) + r'\b'
            matches = len(re.findall(pattern, content_lower))

            if matches > 0:
                for domain in domains:
                    if domain not in domain_scores:
                        domain_scores[domain] = (0.0, [])
                    score, keywords = domain_scores[domain]
                    # Diminishing returns for repeated keywords
                    new_score = score + min(matches * 0.2, 0.5)
                    domain_scores[domain] = (new_score, keywords + [keyword])

        # Also check for explicit domain mentions
        for domain, cluster in self.domain_to_cluster.items():
            domain_pattern = r'\b' + domain.replace('_', ' ') + r'\b'
            if re.search(domain_pattern, content_lower):
                if domain not in domain_scores:
                    domain_scores[domain] = (0.0, [])
                score, keywords = domain_scores[domain]
                domain_scores[domain] = (score + 0.8, keywords + [domain])

        # Convert to DomainMatch objects
        matches = []
        for domain, (score, keywords) in domain_scores.items():
            cluster = self.domain_to_cluster.get(domain, "UNKNOWN")
            matches.append(DomainMatch(
                domain=domain,
                cluster=cluster,
                relevance_score=min(score, 1.0),
                matched_keywords=list(set(keywords)),
            ))

        # Sort by relevance and return top matches
        matches.sort(key=lambda x: x.relevance_score, reverse=True)
        return matches

    def calculate_unrelatedness(self, clusters: Set[str]) -> float:
        """
        Calculate unrelatedness score for a set of clusters.

        Higher score = more diverse (better for cross-pollination).

        Args:
            clusters: Set of cluster IDs

        Returns:
            Average pairwise unrelatedness (0.0 to 1.0)
        """
        if len(clusters) < 2:
            return 0.0

        cluster_list = list(clusters)
        total_unrelatedness = 0.0
        pair_count = 0

        for i, c1 in enumerate(cluster_list):
            for c2 in cluster_list[i + 1:]:
                # Get unrelatedness from matrix
                unrelatedness = self.unrelatedness_matrix.get(c1, {}).get(c2, 0.5)
                total_unrelatedness += unrelatedness
                pair_count += 1

        return total_unrelatedness / pair_count if pair_count > 0 else 0.0

    def identify_cross_connections(
        self,
        domains: List[DomainMatch],
        content: str
    ) -> List[CrossConnection]:
        """
        Identify synthesis points between domains in content.

        Args:
            domains: List of matched domains
            content: Original content to search for connections

        Returns:
            List of cross-connections found
        """
        connections = []

        # Connection keywords that suggest synthesis
        synthesis_indicators = [
            ("applies to", "application"),
            ("similar to", "analogy"),
            ("derived from", "derivation"),
            ("combined with", "synthesis"),
            ("leverages", "leverage"),
            ("inspired by", "inspiration"),
            ("parallels", "parallel"),
            ("integrates", "integration"),
        ]

        content_lower = content.lower()

        # Check for explicit connections between domain pairs
        for i, d1 in enumerate(domains):
            for d2 in domains[i + 1:]:
                # Check if both domains are mentioned in proximity
                d1_pattern = r'\b' + d1.domain.replace('_', ' ') + r'\b'
                d2_pattern = r'\b' + d2.domain.replace('_', ' ') + r'\b'

                d1_matches = list(re.finditer(d1_pattern, content_lower))
                d2_matches = list(re.finditer(d2_pattern, content_lower))

                if d1_matches and d2_matches:
                    # Check proximity (within 200 chars)
                    for m1 in d1_matches:
                        for m2 in d2_matches:
                            distance = abs(m1.start() - m2.start())
                            if distance < 200:
                                # Look for synthesis indicators between them
                                start = min(m1.start(), m2.start())
                                end = max(m1.end(), m2.end())
                                between = content_lower[start:end + 50]

                                connection_type = "proximity"
                                for indicator, conn_type in synthesis_indicators:
                                    if indicator in between:
                                        connection_type = conn_type
                                        break

                                connections.append(CrossConnection(
                                    source_domain=d1.domain,
                                    target_domain=d2.domain,
                                    connection_type=connection_type,
                                    synthesis_point=content[start:end + 50][:100],
                                    strength=1.0 - (distance / 200),
                                ))

        # Deduplicate by domain pair
        seen_pairs = set()
        unique_connections = []
        for conn in connections:
            pair = tuple(sorted([conn.source_domain, conn.target_domain]))
            if pair not in seen_pairs:
                seen_pairs.add(pair)
                unique_connections.append(conn)

        return unique_connections

    def validate(
        self,
        domains_or_content: List[str] | str,
        content: Optional[str] = None
    ) -> CrossPollinationResult:
        """
        Validate cross-pollination requirements.

        Args:
            domains_or_content: Either list of domain names or content string
            content: If first arg is domains list, provide content separately

        Returns:
            CrossPollinationResult with validation details
        """
        # Handle both signatures
        if isinstance(domains_or_content, str):
            # Content string provided, extract domains
            content_text = domains_or_content
            domain_matches = self.extract_domains(content_text)
        else:
            # Domain list provided
            domain_matches = []
            for domain in domains_or_content:
                cluster = self.domain_to_cluster.get(domain, "UNKNOWN")
                domain_matches.append(DomainMatch(
                    domain=domain,
                    cluster=cluster,
                    relevance_score=1.0,
                    matched_keywords=[domain],
                ))
            content_text = content or ""

        # Get unique clusters
        clusters = set(d.cluster for d in domain_matches if d.cluster != "UNKNOWN")

        # Calculate unrelatedness
        unrelatedness = self.calculate_unrelatedness(clusters)

        # Identify cross-connections
        cross_connections = self.identify_cross_connections(domain_matches, content_text)

        # Check thresholds
        domain_count = len(clusters)
        meets_domain_threshold = domain_count >= self.MIN_DOMAINS
        meets_unrelatedness = unrelatedness >= self.UNRELATEDNESS_THRESHOLD
        meets_connections = len(cross_connections) >= self.MIN_CROSS_CONNECTIONS

        # Determine corrections needed
        corrections = []
        if not meets_domain_threshold:
            corrections.append(f"Need {self.MIN_DOMAINS - domain_count} more domains from different clusters")
        if not meets_unrelatedness:
            corrections.append(f"Unrelatedness {unrelatedness:.2f} below threshold {self.UNRELATEDNESS_THRESHOLD}")
        if not meets_connections:
            corrections.append(f"Need {self.MIN_CROSS_CONNECTIONS - len(cross_connections)} more cross-domain connections")

        gate_passed = meets_domain_threshold and meets_unrelatedness
        meets_threshold = gate_passed and meets_connections

        return CrossPollinationResult(
            domain_count=domain_count,
            domains=domain_matches[:10],  # Top 10 domains
            clusters=clusters,
            unrelatedness_score=unrelatedness,
            cross_connections=cross_connections,
            meets_threshold=meets_threshold,
            gate_passed=gate_passed,
            corrections_needed=corrections,
        )

    def suggest_expansion(
        self,
        current_clusters: Set[str],
        target_unrelatedness: float = 0.75
    ) -> List[str]:
        """
        Suggest additional clusters to improve unrelatedness.

        Args:
            current_clusters: Currently included clusters
            target_unrelatedness: Target unrelatedness score

        Returns:
            List of suggested cluster IDs to add
        """
        if not current_clusters:
            return ["FORMAL", "HUMAN", "NATURAL"]  # Default diverse set

        suggestions = []
        all_clusters = set(self.unrelatedness_matrix.keys())
        remaining = all_clusters - current_clusters

        for candidate in remaining:
            # Calculate average unrelatedness with current clusters
            total = 0.0
            for current in current_clusters:
                total += self.unrelatedness_matrix.get(current, {}).get(candidate, 0.5)
            avg_unrelatedness = total / len(current_clusters)

            if avg_unrelatedness >= target_unrelatedness:
                suggestions.append((candidate, avg_unrelatedness))

        # Sort by unrelatedness (higher is better)
        suggestions.sort(key=lambda x: x[1], reverse=True)
        return [s[0] for s in suggestions[:3]]

    def get_domains_for_cluster(self, cluster_id: str) -> List[str]:
        """Get all domains belonging to a cluster."""
        for cluster_data in self.clusters.values():
            if cluster_data.get("id") == cluster_id:
                return cluster_data.get("domains", [])
        return []


# Convenience function for quick validation
def validate_cross_pollination(content: str) -> CrossPollinationResult:
    """Quick validation of content for cross-pollination requirements."""
    validator = DomainCrossPollinationValidator()
    return validator.validate(content)


if __name__ == "__main__":
    # Test the validator
    test_content = """
    The mathematics of formal verification provides rigorous proofs for software correctness.
    This approach combines philosophy of logic with systems engineering best practices.
    Drawing from neuroscience research on decision-making, we can apply algorithmic
    optimization techniques to create more robust distributed systems.
    """

    validator = DomainCrossPollinationValidator()
    result = validator.validate(test_content)

    print(f"Domain Count: {result.domain_count}")
    print(f"Clusters: {result.clusters}")
    print(f"Unrelatedness Score: {result.unrelatedness_score:.3f}")
    print(f"Gate Passed: {result.gate_passed}")
    print(f"Meets Threshold: {result.meets_threshold}")
    print(f"Corrections: {result.corrections_needed}")
