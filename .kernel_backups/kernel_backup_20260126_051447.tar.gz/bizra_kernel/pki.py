"""
BIZRA PKI (Public Key Infrastructure)
=====================================
Implements the Identity Registry requirements from Genesis Audit.
Binds Agent/Node IDs to Ed25519 Public Keys.
"""

import json
import os
from pathlib import Path
from typing import Dict, Optional
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

REGISTRY_PATH = Path(os.getenv("BIZRA_IDENTITY_REGISTRY", "config/identity_registry.json"))

class IdentityRegistry:
    def __init__(self, registry_path: Path = REGISTRY_PATH):
        self.registry_path = registry_path
        self._keys: Dict[str, Ed25519PublicKey] = {}
        self._load()

    def _load(self):
        if not self.registry_path.exists():
            # Fallback for dev: hardcoded Genesis Node key
            # In production, this file MUST exist.
            print(f"⚠️  Registry not found at {self.registry_path}. Using dev defaults.")
            # Example dev key (hex)
            dev_pub = "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a" 
            self._keys["node_0"] = self._hex_to_key(dev_pub)
            return

        try:
            with open(self.registry_path, "r") as f:
                data = json.load(f)
                for agent_id, pub_hex in data.items():
                    self._keys[agent_id] = self._hex_to_key(pub_hex)
        except Exception as e:
            print(f"❌ Failed to load identity registry: {e}")

    def _hex_to_key(self, hex_str: str) -> Ed25519PublicKey:
        return Ed25519PublicKey.from_public_bytes(bytes.fromhex(hex_str))

    def get_key(self, agent_id: str) -> Optional[Ed25519PublicKey]:
        return self._keys.get(agent_id)

    def verify(self, agent_id: str, message: bytes, signature: bytes) -> bool:
        """Verify a signature for a given agent."""
        key = self.get_key(agent_id)
        if not key:
            print(f"❌ Unknown agent: {agent_id}")
            return False
        
        try:
            key.verify(signature, message)
            return True
        except InvalidSignature:
            return False
        except Exception as e:
            print(f"❌ verification error: {e}")
            return False

# Global instance
registry = IdentityRegistry()
