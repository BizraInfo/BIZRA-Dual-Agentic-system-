"""
BIZRA Unified Node0 Orchestrator
=================================
The central nervous system of Node0 - harmonizing hardware, software, and data.

This module provides:
1. Unified identity verification (Ed25519 + Hardware Covenant)
2. Local resource management (CPU, GPU, Memory, Storage)
3. Service health orchestration (all Docker services)
4. Data lake integration (BIZRA-DATA-LAKE)
5. Standalone operation verification (no external dependencies)

Architecture:
    ┌─────────────────────────────────────────────────────────────┐
    │                  UNIFIED NODE0 ORCHESTRATOR                 │
    ├─────────────────────────────────────────────────────────────┤
    │  Identity Layer    │  Resource Layer   │  Service Layer    │
    │  ├─ Ed25519 Keys   │  ├─ CPU Manager   │  ├─ Docker Svcs   │
    │  ├─ HW Fingerprint │  ├─ GPU Manager   │  ├─ Ollama/LLM    │
    │  └─ Tiered Covenant│  ├─ Memory Pool   │  ├─ Redis State   │
    │                    │  └─ Storage Index │  └─ Health Probes │
    ├─────────────────────────────────────────────────────────────┤
    │                    Data Lake Bridge                         │
    │  ├─ Gold Layer (Curated Data)                              │
    │  ├─ PoI Ledger (Proof-of-Impact)                           │
    │  └─ Evidence Sync (Bidirectional)                          │
    └─────────────────────────────────────────────────────────────┘

Usage:
    from bizra_kernel.node0_unified import UnifiedNode0

    node0 = await UnifiedNode0.initialize()
    status = await node0.full_health_check()
    resources = await node0.get_resource_status()
"""

import asyncio
import hashlib
import json
import logging
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import aiohttp
import psutil

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════════

class HealthStatus(Enum):
    """Health status levels."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class ResourceType(Enum):
    """Types of local resources."""
    CPU = "cpu"
    GPU = "gpu"
    MEMORY = "memory"
    STORAGE = "storage"
    NETWORK = "network"


class ServiceType(Enum):
    """Types of services."""
    DOCKER = "docker"
    OLLAMA = "ollama"
    RUST_ELITE = "rust_elite"
    PYTHON_KERNEL = "python_kernel"
    DATA_LAKE = "data_lake"


# Ihsān threshold - must be >= 0.95 for all operations
IHSAN_THRESHOLD = 0.95

# Local service endpoints
SERVICE_ENDPOINTS = {
    "rust_elite": "http://localhost:8080",
    "python_kernel": "http://localhost:8010",
    "ollama": "http://localhost:11434",
    "postgres": "localhost:5433",
    "redis": "localhost:6380",
    "neo4j": "localhost:7687",
    "chromadb": "http://localhost:8001",
    "grafana": "http://localhost:3000",
    "prometheus": "http://localhost:9090",
}


# ═══════════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class CPUStatus:
    """CPU resource status."""
    model: str
    cores_physical: int
    cores_logical: int
    frequency_mhz: float
    usage_percent: float
    temperature_c: Optional[float] = None

    @property
    def is_healthy(self) -> bool:
        return self.usage_percent < 95 and (self.temperature_c is None or self.temperature_c < 90)


@dataclass
class GPUStatus:
    """GPU resource status."""
    name: str
    memory_total_mb: int
    memory_used_mb: int
    memory_free_mb: int
    utilization_percent: float
    temperature_c: Optional[float] = None
    driver_version: Optional[str] = None
    cuda_version: Optional[str] = None

    @property
    def memory_usage_percent(self) -> float:
        return (self.memory_used_mb / self.memory_total_mb * 100) if self.memory_total_mb > 0 else 0

    @property
    def is_healthy(self) -> bool:
        return self.memory_usage_percent < 95 and (self.temperature_c is None or self.temperature_c < 85)


@dataclass
class MemoryStatus:
    """System memory status."""
    total_gb: float
    available_gb: float
    used_gb: float
    usage_percent: float
    swap_total_gb: float
    swap_used_gb: float

    @property
    def is_healthy(self) -> bool:
        return self.usage_percent < 90


@dataclass
class StorageStatus:
    """Storage status for a mount point."""
    mount_point: str
    total_gb: float
    used_gb: float
    free_gb: float
    usage_percent: float
    filesystem: str

    @property
    def is_healthy(self) -> bool:
        return self.usage_percent < 90


@dataclass
class ServiceStatus:
    """Status of a single service."""
    name: str
    service_type: ServiceType
    status: HealthStatus
    endpoint: Optional[str] = None
    response_time_ms: Optional[float] = None
    version: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None


@dataclass
class IdentityStatus:
    """Node0 identity verification status."""
    node_id: str
    public_key_fingerprint: str
    tier1_verified: bool
    tier2_verified: bool
    tier3_verified: bool
    hardware_fingerprint: str
    in_restricted_mode: bool
    last_verified: datetime
    warnings: List[str] = field(default_factory=list)


@dataclass
class DataLakeStatus:
    """BIZRA-DATA-LAKE status."""
    connected: bool
    gold_layer_accessible: bool
    poi_ledger_entries: int
    knowledge_nodes: int
    knowledge_edges: int
    last_sync: Optional[datetime] = None
    storage_used_gb: float = 0.0
    error: Optional[str] = None


@dataclass
class UnifiedStatus:
    """Complete unified Node0 status."""
    node_id: str
    hostname: str
    platform: str
    timestamp: datetime

    # Identity
    identity: IdentityStatus

    # Resources
    cpu: CPUStatus
    gpu: Optional[GPUStatus]
    memory: MemoryStatus
    storage: List[StorageStatus]

    # Services
    services: List[ServiceStatus]

    # Data Lake
    data_lake: DataLakeStatus

    # Aggregate health
    overall_health: HealthStatus
    ihsan_score: float
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "node_id": self.node_id,
            "hostname": self.hostname,
            "platform": self.platform,
            "timestamp": self.timestamp.isoformat(),
            "identity": {
                "node_id": self.identity.node_id,
                "public_key_fingerprint": self.identity.public_key_fingerprint,
                "tier1_verified": self.identity.tier1_verified,
                "tier2_verified": self.identity.tier2_verified,
                "tier3_verified": self.identity.tier3_verified,
                "hardware_fingerprint": self.identity.hardware_fingerprint,
                "in_restricted_mode": self.identity.in_restricted_mode,
                "last_verified": self.identity.last_verified.isoformat(),
                "warnings": self.identity.warnings,
            },
            "cpu": {
                "model": self.cpu.model,
                "cores_physical": self.cpu.cores_physical,
                "cores_logical": self.cpu.cores_logical,
                "frequency_mhz": self.cpu.frequency_mhz,
                "usage_percent": self.cpu.usage_percent,
                "temperature_c": self.cpu.temperature_c,
                "is_healthy": self.cpu.is_healthy,
            },
            "gpu": {
                "name": self.gpu.name,
                "memory_total_mb": self.gpu.memory_total_mb,
                "memory_used_mb": self.gpu.memory_used_mb,
                "memory_free_mb": self.gpu.memory_free_mb,
                "utilization_percent": self.gpu.utilization_percent,
                "temperature_c": self.gpu.temperature_c,
                "driver_version": self.gpu.driver_version,
                "is_healthy": self.gpu.is_healthy,
            } if self.gpu else None,
            "memory": {
                "total_gb": self.memory.total_gb,
                "available_gb": self.memory.available_gb,
                "used_gb": self.memory.used_gb,
                "usage_percent": self.memory.usage_percent,
                "is_healthy": self.memory.is_healthy,
            },
            "storage": [
                {
                    "mount_point": s.mount_point,
                    "total_gb": s.total_gb,
                    "used_gb": s.used_gb,
                    "free_gb": s.free_gb,
                    "usage_percent": s.usage_percent,
                    "is_healthy": s.is_healthy,
                }
                for s in self.storage
            ],
            "services": [
                {
                    "name": s.name,
                    "type": s.service_type.value,
                    "status": s.status.value,
                    "endpoint": s.endpoint,
                    "response_time_ms": s.response_time_ms,
                    "version": s.version,
                    "error": s.error,
                }
                for s in self.services
            ],
            "data_lake": {
                "connected": self.data_lake.connected,
                "gold_layer_accessible": self.data_lake.gold_layer_accessible,
                "poi_ledger_entries": self.data_lake.poi_ledger_entries,
                "knowledge_nodes": self.data_lake.knowledge_nodes,
                "knowledge_edges": self.data_lake.knowledge_edges,
                "storage_used_gb": self.data_lake.storage_used_gb,
                "last_sync": self.data_lake.last_sync.isoformat() if self.data_lake.last_sync else None,
                "error": self.data_lake.error,
            },
            "overall_health": self.overall_health.value,
            "ihsan_score": self.ihsan_score,
            "warnings": self.warnings,
            "errors": self.errors,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# UNIFIED NODE0 ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════════════════════

class UnifiedNode0:
    """
    Unified Node0 Orchestrator - The central nervous system of BIZRA.

    Harmonizes hardware, software, and data resources into a single
    coherent system that operates locally without external dependencies.
    """

    def __init__(self):
        """Initialize the unified Node0 orchestrator."""
        self._initialized = False
        self._identity = None
        self._hardware_fingerprint = None
        self._last_status: Optional[UnifiedStatus] = None
        self._http_session: Optional[aiohttp.ClientSession] = None

        # Data lake paths
        self._data_lake_path = Path(os.getenv(
            "DATA_LAKE_PATH",
            "/mnt/c/BIZRA-DATA-LAKE"
        ))
        self._gold_layer_path = self._data_lake_path / "04_GOLD"
        self._poi_ledger_path = self._gold_layer_path / "poi_ledger.jsonl"

    async def initialize(self) -> "UnifiedNode0":
        """
        Initialize the unified Node0 system.

        Returns self for method chaining.
        """
        if self._initialized:
            return self

        logger.info("🚀 Initializing Unified Node0 Orchestrator...")

        # Initialize HTTP session
        self._http_session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=5)
        )

        # Load identity
        await self._load_identity()

        # Verify hardware covenant
        await self._verify_hardware_covenant()

        self._initialized = True
        logger.info("✅ Unified Node0 Orchestrator initialized")

        return self

    async def close(self):
        """Clean up resources."""
        if self._http_session:
            await self._http_session.close()
            self._http_session = None
        self._initialized = False

    async def __aenter__(self) -> "UnifiedNode0":
        return await self.initialize()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    # ═══════════════════════════════════════════════════════════════════════════
    # IDENTITY MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════

    async def _load_identity(self):
        """Load Node0 identity from secure storage."""
        try:
            from bizra_kernel.node0_identity import Node0Identity
            self._identity = Node0Identity.load_or_create()
            logger.info(f"✅ Node0 identity loaded: {self._identity.public_key_fingerprint[:16]}...")
        except ImportError:
            logger.warning("⚠️ Node0Identity not available, using fallback")
            self._identity = None
        except Exception as e:
            logger.error(f"❌ Failed to load Node0 identity: {e}")
            self._identity = None

    async def _verify_hardware_covenant(self):
        """Verify hardware covenant (tiered verification)."""
        try:
            from bizra_kernel.hardware_fingerprint import generate_fingerprint
            self._hardware_fingerprint = generate_fingerprint()
            tier1 = self._hardware_fingerprint.get("tiered_covenant", {}).get("tier_1_root", {})
            logger.info(f"✅ Hardware covenant verified: {tier1.get('hash', 'N/A')[:16]}...")
        except ImportError:
            logger.warning("⚠️ Hardware fingerprint not available")
            self._hardware_fingerprint = None
        except Exception as e:
            logger.error(f"❌ Failed to verify hardware covenant: {e}")
            self._hardware_fingerprint = None

    async def get_identity_status(self) -> IdentityStatus:
        """Get current Node0 identity status."""
        now = datetime.now(timezone.utc)
        warnings = []

        if self._identity:
            node_id = self._identity.public_key_fingerprint[:16]
            pub_key_fp = self._identity.public_key_fingerprint
            in_restricted = getattr(self._identity, 'restricted_mode', False)
        else:
            node_id = "UNKNOWN"
            pub_key_fp = "NOT_LOADED"
            in_restricted = True
            warnings.append("Node0 identity not loaded")

        if self._hardware_fingerprint:
            covenant = self._hardware_fingerprint.get("tiered_covenant", {})
            tier1 = covenant.get("tier_1_root", {}).get("hash", "")[:32]
            tier1_verified = True  # If we got the fingerprint, tier1 passed
            tier2_verified = True
            tier3_verified = True
        else:
            tier1 = "NOT_VERIFIED"
            tier1_verified = False
            tier2_verified = False
            tier3_verified = False
            warnings.append("Hardware covenant not verified")

        return IdentityStatus(
            node_id=node_id,
            public_key_fingerprint=pub_key_fp,
            tier1_verified=tier1_verified,
            tier2_verified=tier2_verified,
            tier3_verified=tier3_verified,
            hardware_fingerprint=tier1,
            in_restricted_mode=in_restricted,
            last_verified=now,
            warnings=warnings,
        )

    # ═══════════════════════════════════════════════════════════════════════════
    # RESOURCE MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════

    async def get_cpu_status(self) -> CPUStatus:
        """Get CPU resource status."""
        try:
            freq = psutil.cpu_freq()

            # Get CPU model
            if platform.system() == "Linux":
                try:
                    with open("/proc/cpuinfo") as f:
                        for line in f:
                            if "model name" in line:
                                model = line.split(":")[1].strip()
                                break
                        else:
                            model = platform.processor() or "Unknown"
                except:
                    model = platform.processor() or "Unknown"
            else:
                model = platform.processor() or "Unknown"

            # Try to get temperature
            temp = None
            try:
                temps = psutil.sensors_temperatures()
                if temps:
                    for name, entries in temps.items():
                        if entries:
                            temp = entries[0].current
                            break
            except:
                pass

            return CPUStatus(
                model=model,
                cores_physical=psutil.cpu_count(logical=False) or 0,
                cores_logical=psutil.cpu_count(logical=True) or 0,
                frequency_mhz=freq.current if freq else 0,
                usage_percent=psutil.cpu_percent(interval=0.1),
                temperature_c=temp,
            )
        except Exception as e:
            logger.error(f"Failed to get CPU status: {e}")
            return CPUStatus(
                model="Unknown",
                cores_physical=0,
                cores_logical=0,
                frequency_mhz=0,
                usage_percent=0,
                temperature_c=None,
            )

    async def get_gpu_status(self) -> Optional[GPUStatus]:
        """Get GPU resource status via nvidia-smi."""
        try:
            result = subprocess.run(
                [
                    "nvidia-smi",
                    "--query-gpu=name,memory.total,memory.used,memory.free,utilization.gpu,temperature.gpu,driver_version",
                    "--format=csv,noheader,nounits"
                ],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode != 0:
                return None

            parts = result.stdout.strip().split(",")
            if len(parts) < 7:
                return None

            # Get CUDA version
            cuda_result = subprocess.run(
                ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=5
            )

            return GPUStatus(
                name=parts[0].strip(),
                memory_total_mb=int(float(parts[1].strip())),
                memory_used_mb=int(float(parts[2].strip())),
                memory_free_mb=int(float(parts[3].strip())),
                utilization_percent=float(parts[4].strip()),
                temperature_c=float(parts[5].strip()),
                driver_version=parts[6].strip(),
                cuda_version=None,  # Would need nvcc for this
            )
        except FileNotFoundError:
            logger.debug("nvidia-smi not found, no NVIDIA GPU")
            return None
        except Exception as e:
            logger.warning(f"Failed to get GPU status: {e}")
            return None

    async def get_memory_status(self) -> MemoryStatus:
        """Get system memory status."""
        try:
            mem = psutil.virtual_memory()
            swap = psutil.swap_memory()

            return MemoryStatus(
                total_gb=round(mem.total / (1024**3), 2),
                available_gb=round(mem.available / (1024**3), 2),
                used_gb=round(mem.used / (1024**3), 2),
                usage_percent=mem.percent,
                swap_total_gb=round(swap.total / (1024**3), 2),
                swap_used_gb=round(swap.used / (1024**3), 2),
            )
        except Exception as e:
            logger.error(f"Failed to get memory status: {e}")
            return MemoryStatus(
                total_gb=0,
                available_gb=0,
                used_gb=0,
                usage_percent=0,
                swap_total_gb=0,
                swap_used_gb=0,
            )

    async def get_storage_status(self) -> List[StorageStatus]:
        """Get storage status for all mount points."""
        storage_list = []

        # Key mount points to check
        mount_points = ["/", "/mnt/c", "/mnt/d", str(self._data_lake_path)]
        checked = set()

        for mount in mount_points:
            if mount in checked:
                continue

            try:
                if not os.path.exists(mount):
                    continue

                usage = psutil.disk_usage(mount)
                storage_list.append(StorageStatus(
                    mount_point=mount,
                    total_gb=round(usage.total / (1024**3), 2),
                    used_gb=round(usage.used / (1024**3), 2),
                    free_gb=round(usage.free / (1024**3), 2),
                    usage_percent=usage.percent,
                    filesystem="unknown",
                ))
                checked.add(mount)
            except Exception as e:
                logger.debug(f"Failed to get storage for {mount}: {e}")

        return storage_list

    # ═══════════════════════════════════════════════════════════════════════════
    # SERVICE HEALTH
    # ═══════════════════════════════════════════════════════════════════════════

    async def _check_http_service(
        self,
        name: str,
        endpoint: str,
        health_path: str = "/health"
    ) -> ServiceStatus:
        """Check health of an HTTP service."""
        import time

        start = time.perf_counter()
        try:
            async with self._http_session.get(f"{endpoint}{health_path}") as resp:
                elapsed = (time.perf_counter() - start) * 1000

                if resp.status == 200:
                    try:
                        data = await resp.json()
                        version = data.get("version", None)
                    except:
                        version = None

                    return ServiceStatus(
                        name=name,
                        service_type=ServiceType.DOCKER,
                        status=HealthStatus.HEALTHY,
                        endpoint=endpoint,
                        response_time_ms=round(elapsed, 2),
                        version=version,
                    )
                else:
                    return ServiceStatus(
                        name=name,
                        service_type=ServiceType.DOCKER,
                        status=HealthStatus.DEGRADED,
                        endpoint=endpoint,
                        response_time_ms=round(elapsed, 2),
                        error=f"HTTP {resp.status}",
                    )
        except asyncio.TimeoutError:
            return ServiceStatus(
                name=name,
                service_type=ServiceType.DOCKER,
                status=HealthStatus.UNHEALTHY,
                endpoint=endpoint,
                error="Timeout",
            )
        except Exception as e:
            return ServiceStatus(
                name=name,
                service_type=ServiceType.DOCKER,
                status=HealthStatus.UNHEALTHY,
                endpoint=endpoint,
                error=str(e)[:100],
            )

    async def _check_ollama(self) -> ServiceStatus:
        """Check Ollama LLM service status."""
        endpoint = SERVICE_ENDPOINTS["ollama"]
        start = __import__("time").perf_counter()

        try:
            async with self._http_session.get(f"{endpoint}/api/tags") as resp:
                elapsed = (__import__("time").perf_counter() - start) * 1000

                if resp.status == 200:
                    data = await resp.json()
                    models = data.get("models", [])

                    return ServiceStatus(
                        name="ollama",
                        service_type=ServiceType.OLLAMA,
                        status=HealthStatus.HEALTHY,
                        endpoint=endpoint,
                        response_time_ms=round(elapsed, 2),
                        details={"model_count": len(models), "models": [m["name"] for m in models]},
                    )
                else:
                    return ServiceStatus(
                        name="ollama",
                        service_type=ServiceType.OLLAMA,
                        status=HealthStatus.DEGRADED,
                        endpoint=endpoint,
                        error=f"HTTP {resp.status}",
                    )
        except Exception as e:
            return ServiceStatus(
                name="ollama",
                service_type=ServiceType.OLLAMA,
                status=HealthStatus.UNHEALTHY,
                endpoint=endpoint,
                error=str(e)[:100],
            )

    async def _check_docker_services(self) -> List[ServiceStatus]:
        """Check all Docker container services."""
        services = []

        try:
            result = subprocess.run(
                ["docker", "compose", "ps", "--format", "json"],
                capture_output=True,
                text=True,
                timeout=10,
                cwd="/mnt/c/BIZRA-Dual-Agentic-system--main"
            )

            if result.returncode == 0:
                # Parse each line as JSON (docker compose outputs one JSON per line)
                for line in result.stdout.strip().split("\n"):
                    if not line.strip():
                        continue
                    try:
                        container = json.loads(line)
                        name = container.get("Name", "").split("-")[-1].replace("-1", "")
                        state = container.get("State", "unknown")
                        health = container.get("Health", "")

                        if state == "running" and health == "healthy":
                            status = HealthStatus.HEALTHY
                        elif state == "running":
                            status = HealthStatus.DEGRADED
                        else:
                            status = HealthStatus.UNHEALTHY

                        services.append(ServiceStatus(
                            name=name,
                            service_type=ServiceType.DOCKER,
                            status=status,
                            details={"state": state, "health": health},
                        ))
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            logger.warning(f"Failed to check Docker services: {e}")

        return services

    async def get_service_status(self) -> List[ServiceStatus]:
        """Get status of all services."""
        services = []

        # Check Docker services
        docker_services = await self._check_docker_services()
        services.extend(docker_services)

        # Check Ollama
        ollama_status = await self._check_ollama()
        services.append(ollama_status)

        # Check Rust Elite (if not already in Docker list)
        if not any(s.name == "elite" for s in services):
            elite_status = await self._check_http_service(
                "rust_elite",
                SERVICE_ENDPOINTS["rust_elite"],
                "/health"
            )
            services.append(elite_status)

        # Check Python Kernel (if not already in Docker list)
        if not any(s.name == "kernel" for s in services):
            kernel_status = await self._check_http_service(
                "python_kernel",
                SERVICE_ENDPOINTS["python_kernel"],
                "/health"
            )
            services.append(kernel_status)

        return services

    # ═══════════════════════════════════════════════════════════════════════════
    # DATA LAKE INTEGRATION
    # ═══════════════════════════════════════════════════════════════════════════

    async def get_data_lake_status(self) -> DataLakeStatus:
        """Get BIZRA-DATA-LAKE status."""
        connected = self._data_lake_path.exists()
        gold_accessible = self._gold_layer_path.exists()
        poi_entries = 0
        storage_used = 0.0
        error = None

        if not connected:
            return DataLakeStatus(
                connected=False,
                gold_layer_accessible=False,
                poi_ledger_entries=0,
                knowledge_nodes=0,
                knowledge_edges=0,
                error=f"Data lake path not found: {self._data_lake_path}",
            )

        try:
            # Count PoI ledger entries
            if self._poi_ledger_path.exists():
                with open(self._poi_ledger_path) as f:
                    poi_entries = sum(1 for _ in f)

            # Calculate storage used
            for path in self._data_lake_path.rglob("*"):
                if path.is_file():
                    storage_used += path.stat().st_size / (1024**3)

            # Try to get knowledge graph stats
            kg_nodes = 0
            kg_edges = 0
            indexed_path = self._data_lake_path / "03_INDEXED"
            if indexed_path.exists():
                # Count parquet files as proxy for nodes
                kg_nodes = len(list(indexed_path.rglob("*.parquet")))

        except Exception as e:
            error = str(e)[:100]

        return DataLakeStatus(
            connected=connected,
            gold_layer_accessible=gold_accessible,
            poi_ledger_entries=poi_entries,
            knowledge_nodes=kg_nodes if 'kg_nodes' in dir() else 0,
            knowledge_edges=kg_edges if 'kg_edges' in dir() else 0,
            storage_used_gb=round(storage_used, 2),
            last_sync=datetime.now(timezone.utc),
            error=error,
        )

    # ═══════════════════════════════════════════════════════════════════════════
    # UNIFIED STATUS
    # ═══════════════════════════════════════════════════════════════════════════

    async def full_health_check(self) -> UnifiedStatus:
        """
        Perform a full health check of all Node0 components.

        Returns comprehensive unified status.
        """
        if not self._initialized:
            await self.initialize()

        now = datetime.now(timezone.utc)
        warnings = []
        errors = []

        # Gather all status information concurrently
        identity_task = self.get_identity_status()
        cpu_task = self.get_cpu_status()
        gpu_task = self.get_gpu_status()
        memory_task = self.get_memory_status()
        storage_task = self.get_storage_status()
        services_task = self.get_service_status()
        data_lake_task = self.get_data_lake_status()

        (
            identity,
            cpu,
            gpu,
            memory,
            storage,
            services,
            data_lake,
        ) = await asyncio.gather(
            identity_task,
            cpu_task,
            gpu_task,
            memory_task,
            storage_task,
            services_task,
            data_lake_task,
        )

        # Aggregate warnings
        warnings.extend(identity.warnings)

        if not cpu.is_healthy:
            warnings.append(f"CPU usage high: {cpu.usage_percent}%")
        if gpu and not gpu.is_healthy:
            warnings.append(f"GPU issue: temp={gpu.temperature_c}°C, mem={gpu.memory_usage_percent}%")
        if not memory.is_healthy:
            warnings.append(f"Memory usage high: {memory.usage_percent}%")
        for s in storage:
            if not s.is_healthy:
                warnings.append(f"Storage {s.mount_point} usage high: {s.usage_percent}%")

        # Count service health
        healthy_services = sum(1 for s in services if s.status == HealthStatus.HEALTHY)
        total_services = len(services)

        for s in services:
            if s.status == HealthStatus.UNHEALTHY:
                errors.append(f"Service {s.name} unhealthy: {s.error}")
            elif s.status == HealthStatus.DEGRADED:
                warnings.append(f"Service {s.name} degraded: {s.error}")

        if data_lake.error:
            warnings.append(f"Data lake: {data_lake.error}")

        # Calculate overall health
        if errors or not identity.tier1_verified:
            overall = HealthStatus.UNHEALTHY
        elif warnings or healthy_services < total_services:
            overall = HealthStatus.DEGRADED
        else:
            overall = HealthStatus.HEALTHY

        # Calculate Ihsān score based on health metrics
        ihsan_components = []

        # Correctness (0.22) - Identity and verification
        ihsan_components.append((0.22, 1.0 if identity.tier1_verified else 0.5))

        # Safety (0.22) - Resource headroom
        safety_score = min(1.0, (100 - cpu.usage_percent) / 100 * 0.5 + (100 - memory.usage_percent) / 100 * 0.5)
        ihsan_components.append((0.22, safety_score))

        # User benefit (0.14) - Services available
        ihsan_components.append((0.14, healthy_services / max(1, total_services)))

        # Efficiency (0.12) - Resource efficiency
        efficiency = 0.5 + (cpu.usage_percent / 200)  # Some usage is good
        ihsan_components.append((0.12, min(1.0, efficiency)))

        # Auditability (0.12) - Data lake accessible
        ihsan_components.append((0.12, 1.0 if data_lake.connected else 0.5))

        # Anti-centralization (0.08) - Local operation
        ihsan_components.append((0.08, 1.0))  # We're fully local

        # Robustness (0.06) - Storage health
        storage_health = sum(1 for s in storage if s.is_healthy) / max(1, len(storage))
        ihsan_components.append((0.06, storage_health))

        # Adl fairness (0.04) - Equal resource distribution
        ihsan_components.append((0.04, 0.95))  # Assume fair

        ihsan_score = sum(weight * score for weight, score in ihsan_components)

        status = UnifiedStatus(
            node_id=identity.node_id,
            hostname=platform.node(),
            platform=platform.system(),
            timestamp=now,
            identity=identity,
            cpu=cpu,
            gpu=gpu,
            memory=memory,
            storage=storage,
            services=services,
            data_lake=data_lake,
            overall_health=overall,
            ihsan_score=round(ihsan_score, 4),
            warnings=warnings,
            errors=errors,
        )

        self._last_status = status
        return status

    async def get_resource_summary(self) -> Dict[str, Any]:
        """Get a quick summary of available resources."""
        cpu = await self.get_cpu_status()
        gpu = await self.get_gpu_status()
        memory = await self.get_memory_status()

        return {
            "cpu": {
                "model": cpu.model,
                "cores": cpu.cores_logical,
                "usage_percent": cpu.usage_percent,
                "available_percent": 100 - cpu.usage_percent,
            },
            "gpu": {
                "name": gpu.name if gpu else "None",
                "vram_total_gb": round(gpu.memory_total_mb / 1024, 1) if gpu else 0,
                "vram_free_gb": round(gpu.memory_free_mb / 1024, 1) if gpu else 0,
                "utilization_percent": gpu.utilization_percent if gpu else 0,
            },
            "memory": {
                "total_gb": memory.total_gb,
                "available_gb": memory.available_gb,
                "usage_percent": memory.usage_percent,
            },
            "summary": f"CPU: {cpu.cores_logical} cores @ {100-cpu.usage_percent:.0f}% free | "
                      f"RAM: {memory.available_gb:.1f}GB free | "
                      f"GPU: {gpu.name if gpu else 'None'} ({gpu.memory_free_mb//1024}GB free)" if gpu else "",
        }

    # ═══════════════════════════════════════════════════════════════════════════
    # STANDALONE VERIFICATION
    # ═══════════════════════════════════════════════════════════════════════════

    async def verify_standalone_operation(self) -> Dict[str, Any]:
        """
        Verify that Node0 can operate fully standalone without external dependencies.

        Returns verification results with any issues found.
        """
        results = {
            "standalone_ready": True,
            "checks": [],
            "issues": [],
            "recommendations": [],
        }

        # Check 1: Identity loaded
        if self._identity:
            results["checks"].append({"name": "Node0 Identity", "status": "PASS"})
        else:
            results["checks"].append({"name": "Node0 Identity", "status": "FAIL"})
            results["issues"].append("Node0 identity not loaded")
            results["standalone_ready"] = False

        # Check 2: Hardware covenant verified
        if self._hardware_fingerprint:
            results["checks"].append({"name": "Hardware Covenant", "status": "PASS"})
        else:
            results["checks"].append({"name": "Hardware Covenant", "status": "WARN"})
            results["issues"].append("Hardware covenant not verified")

        # Check 3: Local LLM available (Ollama)
        ollama = await self._check_ollama()
        if ollama.status == HealthStatus.HEALTHY:
            model_count = ollama.details.get("model_count", 0)
            results["checks"].append({
                "name": "Local LLM (Ollama)",
                "status": "PASS",
                "details": f"{model_count} models available"
            })
        else:
            results["checks"].append({"name": "Local LLM (Ollama)", "status": "FAIL"})
            results["issues"].append("Ollama not available - no local LLM")
            results["recommendations"].append("Start Ollama: ollama serve")
            results["standalone_ready"] = False

        # Check 4: Docker services
        docker_services = await self._check_docker_services()
        healthy_count = sum(1 for s in docker_services if s.status == HealthStatus.HEALTHY)
        total_count = len(docker_services)

        if healthy_count == total_count and total_count > 0:
            results["checks"].append({
                "name": "Docker Services",
                "status": "PASS",
                "details": f"{healthy_count}/{total_count} healthy"
            })
        elif healthy_count > 0:
            results["checks"].append({
                "name": "Docker Services",
                "status": "WARN",
                "details": f"{healthy_count}/{total_count} healthy"
            })
            unhealthy = [s.name for s in docker_services if s.status != HealthStatus.HEALTHY]
            results["issues"].append(f"Unhealthy services: {', '.join(unhealthy)}")
        else:
            results["checks"].append({"name": "Docker Services", "status": "FAIL"})
            results["issues"].append("No Docker services running")
            results["recommendations"].append("Start services: docker compose up -d")
            results["standalone_ready"] = False

        # Check 5: Data Lake accessible
        data_lake = await self.get_data_lake_status()
        if data_lake.connected and data_lake.gold_layer_accessible:
            results["checks"].append({
                "name": "BIZRA-DATA-LAKE",
                "status": "PASS",
                "details": f"{data_lake.storage_used_gb}GB, {data_lake.poi_ledger_entries} PoI entries"
            })
        elif data_lake.connected:
            results["checks"].append({"name": "BIZRA-DATA-LAKE", "status": "WARN"})
            results["issues"].append("Gold layer not accessible")
        else:
            results["checks"].append({"name": "BIZRA-DATA-LAKE", "status": "FAIL"})
            results["issues"].append(f"Data lake not found: {self._data_lake_path}")
            results["standalone_ready"] = False

        # Check 6: GPU available
        gpu = await self.get_gpu_status()
        if gpu:
            results["checks"].append({
                "name": "GPU (NVIDIA)",
                "status": "PASS",
                "details": f"{gpu.name}, {gpu.memory_free_mb}MB free"
            })
        else:
            results["checks"].append({"name": "GPU (NVIDIA)", "status": "WARN"})
            results["issues"].append("No NVIDIA GPU detected")
            results["recommendations"].append("GPU recommended for LLM inference")

        # Check 7: Sufficient memory
        memory = await self.get_memory_status()
        if memory.available_gb >= 16:
            results["checks"].append({
                "name": "System Memory",
                "status": "PASS",
                "details": f"{memory.available_gb}GB available"
            })
        elif memory.available_gb >= 8:
            results["checks"].append({
                "name": "System Memory",
                "status": "WARN",
                "details": f"{memory.available_gb}GB available"
            })
            results["issues"].append("Low memory - may affect performance")
        else:
            results["checks"].append({"name": "System Memory", "status": "FAIL"})
            results["issues"].append(f"Insufficient memory: {memory.available_gb}GB")
            results["standalone_ready"] = False

        return results


# ═══════════════════════════════════════════════════════════════════════════════
# CONVENIENCE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

async def get_node0_status() -> Dict[str, Any]:
    """Quick function to get Node0 status."""
    async with UnifiedNode0() as node0:
        status = await node0.full_health_check()
        return status.to_dict()


async def verify_node0_standalone() -> Dict[str, Any]:
    """Quick function to verify standalone operation."""
    async with UnifiedNode0() as node0:
        return await node0.verify_standalone_operation()


async def get_resource_summary() -> Dict[str, Any]:
    """Quick function to get resource summary."""
    async with UnifiedNode0() as node0:
        return await node0.get_resource_summary()


# ═══════════════════════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    """CLI entry point for Node0 unified status."""
    import argparse

    parser = argparse.ArgumentParser(description="BIZRA Unified Node0 Status")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--verify", action="store_true", help="Verify standalone operation")
    parser.add_argument("--resources", action="store_true", help="Show resource summary only")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s"
    )

    async with UnifiedNode0() as node0:
        if args.verify:
            result = await node0.verify_standalone_operation()
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print("\n" + "=" * 60)
                print("  BIZRA NODE0 STANDALONE VERIFICATION")
                print("=" * 60 + "\n")

                for check in result["checks"]:
                    status_icon = "✅" if check["status"] == "PASS" else "⚠️" if check["status"] == "WARN" else "❌"
                    details = f" ({check.get('details', '')})" if check.get('details') else ""
                    print(f"  {status_icon} {check['name']}{details}")

                print()
                if result["issues"]:
                    print("Issues:")
                    for issue in result["issues"]:
                        print(f"  ⚠️ {issue}")

                if result["recommendations"]:
                    print("\nRecommendations:")
                    for rec in result["recommendations"]:
                        print(f"  💡 {rec}")

                print()
                if result["standalone_ready"]:
                    print("✅ NODE0 IS STANDALONE READY")
                else:
                    print("❌ NODE0 NOT STANDALONE READY - Fix issues above")
                print()

        elif args.resources:
            result = await node0.get_resource_summary()
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print("\n" + "=" * 60)
                print("  BIZRA NODE0 RESOURCE SUMMARY")
                print("=" * 60 + "\n")
                print(f"  CPU: {result['cpu']['model']}")
                print(f"       {result['cpu']['cores']} cores, {result['cpu']['available_percent']:.1f}% available")
                print(f"  GPU: {result['gpu']['name']}")
                print(f"       {result['gpu']['vram_free_gb']}GB VRAM free")
                print(f"  RAM: {result['memory']['available_gb']}GB available / {result['memory']['total_gb']}GB total")
                print()

        else:
            status = await node0.full_health_check()
            if args.json:
                print(json.dumps(status.to_dict(), indent=2))
            else:
                print("\n" + "=" * 60)
                print("  BIZRA UNIFIED NODE0 STATUS")
                print("=" * 60 + "\n")

                # Identity
                print(f"  Node ID: {status.identity.node_id}")
                print(f"  Hostname: {status.hostname}")
                print(f"  Platform: {status.platform}")
                print()

                # Health
                health_icon = "✅" if status.overall_health == HealthStatus.HEALTHY else "⚠️" if status.overall_health == HealthStatus.DEGRADED else "❌"
                print(f"  Overall Health: {health_icon} {status.overall_health.value.upper()}")
                print(f"  Ihsān Score: {status.ihsan_score:.4f} (threshold: {IHSAN_THRESHOLD})")
                print()

                # Resources
                print("  Resources:")
                print(f"    CPU: {status.cpu.model[:40]}... ({status.cpu.usage_percent}% used)")
                if status.gpu:
                    print(f"    GPU: {status.gpu.name} ({status.gpu.memory_used_mb}MB/{status.gpu.memory_total_mb}MB)")
                print(f"    RAM: {status.memory.used_gb}GB/{status.memory.total_gb}GB ({status.memory.usage_percent}%)")
                print()

                # Services
                print("  Services:")
                for svc in status.services:
                    icon = "✅" if svc.status == HealthStatus.HEALTHY else "⚠️" if svc.status == HealthStatus.DEGRADED else "❌"
                    print(f"    {icon} {svc.name}: {svc.status.value}")
                print()

                # Data Lake
                print("  Data Lake:")
                print(f"    Connected: {'✅' if status.data_lake.connected else '❌'}")
                print(f"    Storage: {status.data_lake.storage_used_gb}GB")
                print(f"    PoI Entries: {status.data_lake.poi_ledger_entries}")
                print()

                # Warnings/Errors
                if status.warnings:
                    print("  Warnings:")
                    for w in status.warnings[:5]:
                        print(f"    ⚠️ {w}")
                if status.errors:
                    print("  Errors:")
                    for e in status.errors[:5]:
                        print(f"    ❌ {e}")

                print()


if __name__ == "__main__":
    asyncio.run(main())
