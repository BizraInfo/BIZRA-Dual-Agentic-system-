"""
bizra_kernel/got_orchestrator.py - Graph of Thoughts (GoT)
==========================================================
Implements the Peak Masterpiece reasoning engine by enabling
multi-node thinking, edge relationship mapping, and SAPE 
elevation of interconnected insights.
"""

import uuid
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Any
from enum import Enum

class RelationType(Enum):
    SUPPORTS = "supports"
    CONTRADICTS = "contradicts"
    GENERALIZES = "generalizes"
    DERIVES = "derives"
    REFLECTS = "reflects"

@dataclass
class ThoughtNode:
    """A single unit of reasoning in the Graph of Thoughts."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    content: str = ""
    lens: str = "generic"
    snr_score: float = 0.0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict = field(default_factory=dict)

@dataclass
class ThoughtEdge:
    """A relationship between two thought nodes."""
    source_id: str
    target_id: str
    relation: RelationType
    weight: float = 1.0

class GoTOrchestrator:
    """
    Orchestrates the Graph of Thoughts (GoT) for elite reasoning.
    
    Features:
    - Multi-lens thought generation
    - Dynamic connection mapping
    - SAPE elevation of graph patterns
    - SNR calculation for the entire thought cluster
    """
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.nodes: Dict[str, ThoughtNode] = {}
        self.edges: List[ThoughtEdge] = []
        self.lenses: Set[str] = set()
        
    def add_thought(self, content: str, lens: str = "symbolic", snr: float = 0.0) -> ThoughtNode:
        """Add a new thought node to the graph."""
        node = ThoughtNode(content=content, lens=lens, snr_score=snr)
        self.nodes[node.id] = node
        self.lenses.add(lens)
        return node
        
    def link_thoughts(self, source_id: str, target_id: str, relation: RelationType, weight: float = 1.0):
        """Establish a connection between two thoughts."""
        if source_id in self.nodes and target_id in self.nodes:
            self.edges.append(ThoughtEdge(source_id, target_id, relation, weight))
            
    def get_cluster_snr(self) -> float:
        """Calculate the composite SNR of the current graph."""
        if not self.nodes:
            return 0.0
        total_snr = sum(n.snr_score for n in self.nodes.values())
        # Apply a 'diversity bonus' for multiple interdisciplinary lenses
        diversity_multiplier = 1.0 + (len(self.lenses) * 0.05)
        return min(1.0, (total_snr / len(self.nodes)) * diversity_multiplier)
        
    def summarize(self) -> Dict[str, Any]:
        """Return a concise receipt of the graph for auditing."""
        return {
            "session_id": self.session_id,
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "lenses": list(self.lenses),
            "cluster_snr": self.get_cluster_snr(),
            "nodes": [
                {"id": n.id, "lens": n.lens, "snr": n.snr_score, "content": n.content[:120]}
                for n in self.nodes.values()
            ],
            "edges": [
                {"source": e.source_id, "target": e.target_id, "relation": e.relation.value, "weight": e.weight}
                for e in self.edges
            ],
        }

    def elevate_sape(self) -> str:
        """
        Elevate the current graph into a higher-order principle.
        (Integration point for SAPEEngine)
        """
        # 1. Detect patterns in edges (e.g., clusters with heavy 'supports' links)
        # 2. Identify 'tensions' (contradiction links)
        # 3. Synthesize a resolution
        
        lenses_str = ", ".join(list(self.lenses))
        return f"ELEVATION: Synthesized {len(self.nodes)} thoughts across lenses ({lenses_str}). " \
               f"Resulting SNR: {self.get_cluster_snr():.3f}. Status: SOVEREIGN INSIGHT."

    def visualize_text(self) -> str:
        """Text-based graph representation for logging/receipts."""
        output = [f"GoT Session: {self.session_id}", "Nodes:"]
        for nid, node in self.nodes.items():
            output.append(f"  [{nid}] ({node.lens}) SNR: {node.snr_score:.2f} -> {node.content[:50]}...")
        output.append("Edges:")
        for edge in self.edges:
            output.append(f"  [{edge.source_id}] --{edge.relation.value}--> [{edge.target_id}] (w:{edge.weight})")
        return "\n".join(output)

if __name__ == "__main__":
    # Sample interdisciplinary graph
    got = GoTOrchestrator("peak-test-001")
    n1 = got.add_thought("System must align with the 0.99 threshold.", lens="Ethical", snr=0.99)
    n2 = got.add_thought("TigerBeetle provides deterministic state.", lens="Technical", snr=0.98)
    n3 = got.add_thought("Formal verification prevents hallucination.", lens="Logical", snr=0.97)
    
    got.link_thoughts(n2.id, n1.id, RelationType.SUPPORTS)
    got.link_thoughts(n3.id, n2.id, RelationType.GENERALIZES)
    
    print(got.visualize_text())
    print(got.elevate_sape())
