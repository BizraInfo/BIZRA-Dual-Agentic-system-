import hashlib
import json
import time
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

@dataclass
class Transaction:
    id: str
    state_name: str
    data: Any
    prev_hash: str
    hash: Optional[str] = None
    timestamp: float = field(default_factory=time.time)

class StateLedger:
    """
    BIZRA State Ledger — The Immutable Chain of Truth.
    Hardened with atomic disk persistence and SHA256 integrity chaining.
    """
    def __init__(self, storage_path: str = "bizra_memory/ledger.json"):
        self.storage_path = storage_path
        self.chain: List[Dict[str, Any]] = []
        self.state_root = "0" * 64
        self._load_from_disk()

    def _load_from_disk(self):
        """Load history from disk and verify integrity chain."""
        if not os.path.exists(self.storage_path):
            os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
            self._create_genesis_block()
            return

        try:
            with open(self.storage_path, "r") as f:
                data = json.load(f)
                self.chain = data.get("history", [])
                if not self.verify_integrity():
                    print("[!] CRITICAL: Ledger Integrity Failure detected! Resetting to Genesis.")
                    self._create_genesis_block()
                else:
                    self.state_root = self.chain[-1]["hash"]
        except Exception as e:
            print(f"[-] Failed to load ledger: {e}. Starting fresh.")
            self._create_genesis_block()

    def _create_genesis_block(self):
        genesis = {
            "index": 0,
            "timestamp": time.time(),
            "state": "GENESIS",
            "data": "Universal Genesis Activation — BIZRA Node0",
            "prev_hash": "0" * 64
        }
        genesis["hash"] = self._calculate_hash(genesis)
        self.chain = [genesis]
        self.state_root = genesis["hash"]
        self._save_to_disk()

    def _save_to_disk(self):
        """Atomic save to disk."""
        data = {
            "state_root": self.state_root,
            "history": self.chain
        }
        temp_path = self.storage_path + ".tmp"
        with open(temp_path, "w") as f:
            json.dump(data, f, indent=4)
        os.replace(temp_path, self.storage_path)

    def _calculate_hash(self, block: Dict[str, Any]) -> str:
        block_copy = block.copy()
        block_copy.pop("hash", None)
        block_str = json.dumps(block_copy, sort_keys=True)
        return hashlib.sha256(block_str.encode()).hexdigest()

    def verify_integrity(self) -> bool:
        if not self.chain: return False
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            prev = self.chain[i-1]
            if current["prev_hash"] != prev["hash"]: return False
            if current["hash"] != self._calculate_hash(current): return False
        return True

    def append_state(self, state_name: str, data: Any):
        prev_hash = self.chain[-1]["hash"] if self.chain else "0" * 64
        new_block = {
            "index": len(self.chain),
            "timestamp": time.time(),
            "state": state_name,
            "data": data,
            "prev_hash": prev_hash
        }
        new_block["hash"] = self._calculate_hash(new_block)
        self.chain.append(new_block)
        self.state_root = new_block["hash"]
        self._save_to_disk()
        return new_block["hash"]

    def get_latest_state(self) -> Dict[str, Any]:
        return self.chain[-1] if self.chain else {}
